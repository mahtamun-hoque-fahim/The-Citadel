# Hydration Errors — Deep Diagnostic Guide for Next.js 16

React 19 (used by Next 16) **throws** hydration mismatches instead of warning. This catches more bugs in dev but also means errors that were quietly suppressed in Next 14/15 now block the app. The new error overlay shows server vs client diffs — read it before guessing.

This document enumerates every cause and the diagnostic for each.

## Cause 1: Stale `.next/` build cache

**This is underdiagnosed and often the answer.** The server renders code from an outdated build artifact. The client renders from current source. They don't match.

### Diagnostic

Search your current source for the exact server-rendered string shown in the error. If it isn't found, the build cache is stale.

### Fix

```bash
rm -rf .next && next dev
```

Takes ~10 seconds. Try this **before** re-reading components — it's the cheapest diagnostic.

### When it tends to happen

- Heavy editing across `'use client'` boundaries in the same session
- Edits to imported JSON files
- HMR not picking up a change in a server-only file
- Switching git branches without restarting the dev server

---

## Cause 2: Browser-only APIs in render

`window`, `document`, `localStorage`, `sessionStorage`, `navigator` — none of these exist during SSR. Calling them in the render path produces different HTML on server (where they're `undefined`) and client (where they're populated).

### Wrong

```tsx
export default function Header() {
  return <div>Width: {window.innerWidth}</div>
}
```

### Right (with `useEffect`)

```tsx
'use client'
import { useState, useEffect } from 'react'

export default function Header() {
  const [width, setWidth] = useState<number | null>(null)
  useEffect(() => {
    setWidth(window.innerWidth)
    const onResize = () => setWidth(window.innerWidth)
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])
  return <div>Width: {width ?? '—'}</div>
}
```

### Right (with `dynamic` ssr: false)

For a whole component that genuinely cannot SSR:

```tsx
import dynamic from 'next/dynamic'
const ClientOnlyMap = dynamic(() => import('./Map'), { ssr: false })
```

---

## Cause 3: Time-dependent rendering

`Date.now()`, `new Date()`, `Date.now().toString()`, `toLocaleString()` — any of these render differently on server (server's clock, server's timezone, server's locale) and client (browser's clock, browser's timezone, browser's locale).

### Wrong

```tsx
export default function Footer() {
  return <p>Generated at {new Date().toLocaleString()}</p>
}
```

### Right — render after mount

```tsx
'use client'
import { useState, useEffect } from 'react'
export default function Footer() {
  const [time, setTime] = useState<string | null>(null)
  useEffect(() => {
    setTime(new Date().toLocaleString())
  }, [])
  return <p>Generated at {time ?? '...'}</p>
}
```

### Right — fix the locale/timezone

If you want SSR to render the timestamp, specify an explicit locale and timezone so server and client agree:

```tsx
<p>{new Date().toLocaleString('en-US', { timeZone: 'UTC' })}</p>
```

### Right — surgical `suppressHydrationWarning`

For a single leaf node where the mismatch is intentional and acceptable:

```tsx
<span suppressHydrationWarning>{new Date().toLocaleString()}</span>
```

`suppressHydrationWarning` works on a single element only — it doesn't cascade to children.

---

## Cause 4: Random values in render

`Math.random()`, `crypto.randomUUID()` in the render path produce different values on each render. Server renders one, client hydrates with another, mismatch.

### Wrong

```tsx
export default function Component() {
  return <div id={`box-${Math.random()}`} />
}
```

### Right — use `useId` (React 18+)

```tsx
import { useId } from 'react'
export default function Component() {
  const id = useId()
  return <div id={`box-${id}`} />
}
```

### Right — generate once, pass as a prop from a stable source

```tsx
// Generate on the server, pass to client
export default async function Parent() {
  const id = crypto.randomUUID()
  return <Child id={id} />
}
```

---

## Cause 5: Invalid HTML nesting

React 19 surfaces invalid nesting as a hydration error. The browser silently "fixes" your invalid HTML — `<a><a>` becomes `<a></a><a>`, `<p><div>` becomes `<p></p><div>` — but React's virtual DOM still expects your original structure. Mismatch.

### Common offenders

- `<a>` inside `<a>` (often when wrapping `<Link>` around something that's already a link)
- `<button>` inside `<button>`
- `<p>` containing `<div>`, `<ul>`, `<table>`, or another `<p>`
- `<tr>` outside of `<thead>`/`<tbody>`/`<tfoot>`
- `<form>` inside `<form>`
- `<li>` outside of `<ul>`/`<ol>`/`<menu>`

### Diagnostic

The React DevTools (or the Next 16 dev overlay) names the parent element. Look at where it is in the DOM tree — usually a `<Link>` or `<button>` that's been nested unintentionally.

### Fix

Restructure the markup. Most cases:
- Replace nested `<a>` with a button-styled `<span>` inside the outer `<a>`
- Use `<div>` instead of `<p>` when the content includes block elements
- Move forms apart, never nest them

---

## Cause 6: External scripts / browser extensions modifying the DOM

Ad networks, analytics, polyfills, and most aggressively **browser extensions** (Grammarly, ColorZilla, dark mode extensions, password managers) inject attributes into `<html>` or `<body>` before React hydrates. React sees attributes that weren't in the server HTML and throws.

### Symptoms

- Error mentions an attribute like `data-grammarly-extension`, `data-darkreader-mode`, `data-new-gr-c-s-check-loaded`, or similar
- Error is on `<html>` or `<body>`
- Only some users see it (those with the extension installed)
- It vanishes in incognito mode with extensions disabled

### Fix

Add `suppressHydrationWarning` to the affected element. For `<html>` and `<body>`, this is acceptable because the noise is from external modification you can't control:

```tsx
// app/layout.tsx
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body suppressHydrationWarning>{children}</body>
    </html>
  )
}
```

Only do this at the root for browser-extension cases. Don't slap `suppressHydrationWarning` on regular components — it hides real bugs.

---

## Cause 7: CDN/Edge modifying the HTML response

Cloudflare's "Auto Minify" feature (now deprecated but still found in older zones) and similar HTML-rewriters change the server response after Next.js sends it. The browser then renders the modified HTML, but React tries to hydrate against the original component tree. Mismatch.

### Diagnostic

- Hydration errors only in production, never in dev
- The error mentions whitespace changes, attribute reordering, or unexpected entity changes
- Inspecting the response HTML in DevTools Network tab shows it's different from what your local `next dev` serves

### Fix

In your CDN/Edge config:
- **Cloudflare:** Disable Auto Minify (Rules → Configuration Rules)
- **Cloudflare:** Disable Email Address Obfuscation if it's modifying mailto links
- **Cloudflare:** Disable Rocket Loader if it's reordering scripts
- Any custom HTML rewriter at the CDN layer needs to be disabled or made aware of React's hydration markers

---

## Cause 8: Next.js 16 specific — dynamic data without `<Suspense>` under `cacheComponents`

When `cacheComponents: true` is on, a component that reads dynamic data (`await cookies()`, `await headers()`, `await params`, `await searchParams`, uncached `fetch`) **must** be inside a `<Suspense>` boundary. Otherwise, the static shell ships without the dynamic content, the client expects it on hydration, mismatch.

### Diagnostic

The error name is `Uncached data was accessed outside of <Suspense>`. The dev overlay names the component.

### Fix

Wrap the dynamic component:

```tsx
export default function Page() {
  return (
    <>
      <StaticShell />
      <Suspense fallback={<Skeleton />}>
        <DynamicContent />
      </Suspense>
    </>
  )
}

async function DynamicContent() {
  const c = await cookies()
  return <p>Hello {c.get('name')?.value}</p>
}
```

For the fallback, match the visual shape of the eventual content to avoid layout shift.

---

## Cause 9: Conditional rendering based on `typeof window`

```tsx
// Wrong — server renders one branch, client renders another
const isClient = typeof window !== 'undefined'
return <div>{isClient ? <ClientChart /> : <Placeholder />}</div>
```

### Fix — use `useState` + `useEffect`

```tsx
'use client'
const [mounted, setMounted] = useState(false)
useEffect(() => setMounted(true), [])
return <div>{mounted ? <ClientChart /> : <Placeholder />}</div>
```

This pattern guarantees the server and the first client render match (both `false`), then the client transitions to `true` after mount.

---

## The diagnostic playbook

When you see a hydration error in Next 16, walk through this list in order. Each step is cheap and most errors are resolved by step 2 or 3.

### Step 1: Read the overlay

The Next 16 dev overlay shows the server vs client diff and names the element. Get the element name and the differing attribute/content.

### Step 2: Search for the offending string in the source

```bash
grep -rn "the-offending-server-rendered-string" app/ src/ components/
```

If no match, the build cache is stale. Go to step 3.

### Step 3: Clear the cache

```bash
rm -rf .next && next dev
```

If this resolves it, done. If not, go to step 4.

### Step 4: Identify the cause category

From the error and the element:

- Error on `<html>` or `<body>` with extension-like attribute → Cause 6 (browser extension). Add `suppressHydrationWarning` to root.
- Error mentions a date, time, or locale string → Cause 3 (time-dependent).
- Error mentions a random-looking value → Cause 4 (random in render).
- Error mentions invalid nesting → Cause 5 (HTML nesting).
- Error is `Uncached data was accessed outside of <Suspense>` → Cause 8 (cacheComponents).
- Error only in production, never dev → Cause 7 (CDN modification).
- Component uses `window`/`document` directly → Cause 2 (browser-only API).
- Component uses `typeof window` for branching → Cause 9.

### Step 5: Apply the fix from the relevant Cause section

### Step 6: Verify with a clean build

```bash
rm -rf .next && next dev
```

If the error is still there after a clean build and you've applied the fix, the cause is something else — return to step 2 with the new error.

---

## When to use `suppressHydrationWarning`

This attribute suppresses the *error* without fixing the *underlying mismatch*. React still re-renders client-side; you're just hiding the warning.

### Acceptable uses

- `<html>` and `<body>` to silence browser-extension noise that you can't control
- Leaf nodes where the mismatch is intentional and the user-visible flash is acceptable (e.g. a clock that shows server time initially, then client time after mount)

### Unacceptable uses

- On a component wrapper to silence errors you don't understand — this hides real bugs
- On any element that wraps real interactive content — `onClick` handlers and the like can break silently

The rule: suppress at leaves, never at branches.

---

## React 19 specific notes

React 19's hydration overlay (used by Next 16) is more aggressive than React 18's. Specifically:

- Hydration mismatches throw instead of warning. Pages that silently misrendered in Next 14/15 now error in Next 16.
- The overlay shows side-by-side server/client diffs — read these, they pinpoint the issue.
- View Transitions and `<Activity>` (new in React 19.2) may interact with hydration in unexpected ways if you're early-adopting them. Their docs cover the specifics.
- `useEffectEvent` is the new way to separate reactive from non-reactive logic in Effects — if you have `useEffect` dependencies you're working around, look at `useEffectEvent` first.

If you've upgraded to Next 16 and are seeing a flood of new hydration errors that didn't exist in 15, the issue is almost always that React 19 is now throwing what was previously warning-only. The bug existed before; you just see it now.
