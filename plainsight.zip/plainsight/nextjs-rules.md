# Next.js 14/15/16 + Tailwind rules

The non-layout failures that ship in generated code. Server vs client, hydration traps, async params (Next 15+), font wiring, Tailwind v3-vs-v4, route conventions, Server Actions, streaming, middleware.

## Server vs client components

Default to server. Add `"use client"` only when the file uses:

- `useState`, `useReducer`, `useRef` with effect-driven updates
- `useEffect`, `useLayoutEffect`
- Event handlers: `onClick`, `onChange`, `onSubmit`, `onKeyDown`
- Browser APIs: `window`, `document`, `localStorage`, `navigator`, `MediaRecorder`, `IntersectionObserver`
- React Context that holds mutable state
- Hooks that depend on the above: `usePathname`, `useSearchParams`, `useRouter` from `next/navigation`, `useTheme` from `next-themes`, `useFormStatus` from `react-dom`

Static marketing copy, server-rendered tables, footers, layouts, and most page-level files are server components. They ship zero JavaScript for the static parts, never hydration-mismatch, and can `await` data directly in the component body.

The pattern: keep `page.tsx` and `layout.tsx` as server components. Extract interactive bits into their own `"use client"` components and import them.

```tsx
// app/page.tsx — server component
import Hero from "@/components/hero";
import Features from "@/components/features";
import RecorderDemo from "@/components/recorder-demo"; // "use client" inside

export default async function Page() {
  const stats = await getStats(); // direct DB/API call, no useEffect
  return (
    <>
      <Hero stats={stats} />
      <Features />
      <RecorderDemo />
    </>
  );
}
```

## The client boundary cascade

Once a component is `"use client"`, all its children render in the client bundle UNLESS they're passed as `children`/props from a server parent. Pattern:

```tsx
// components/client-shell.tsx
"use client";
export default function ClientShell({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  return <div onClick={() => setOpen(!open)}>{children}</div>;
  //                                          ^^^^^^^^^^
  //  This `children` can be server-rendered content!
}

// app/page.tsx — server component
import ClientShell from "@/components/client-shell";
import ServerData from "@/components/server-data"; // server component

export default function Page() {
  return (
    <ClientShell>
      <ServerData /> {/* still server-rendered */}
    </ClientShell>
  );
}
```

This lets you wrap server content in interactive client shells without pulling the server content into the client bundle.

## Hydration traps

Hydration errors come from server-rendered HTML differing from the first client render.

**1. `Date.now()`, `Math.random()`, or `new Date()` in render bodies of shared components.**

```tsx
// BROKEN
function Component() {
  const id = Math.random();
  return <div data-id={id} />;
}

// CORRECT — server-only generation, or client-only via useEffect
import { headers } from "next/headers";
// ...generate ID server-side and pass down
```

**2. Direct `window` / `localStorage` access at module top level or in render body of client components.**

```tsx
// BROKEN
"use client";
const theme = localStorage.getItem("theme"); // crashes during SSR build

// CORRECT
"use client";
import { useEffect, useState } from "react";

function useTheme() {
  const [theme, setTheme] = useState<string | null>(null);
  useEffect(() => setTheme(localStorage.getItem("theme")), []);
  return theme;
}
```

**3. Conditional rendering based on browser-only state in initial render.**

```tsx
"use client";
export function ClientOnly({ children }: { children: React.ReactNode }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  if (!mounted) return null;
  return <>{children}</>;
}
```

**4. Browser extensions injecting attributes on `<body>` or `<html>`.**

Grammarly, Dark Reader, password managers add attributes after page load. If the warning points at `<body>` / `<html>` with an attribute you did not write, add `suppressHydrationWarning` to that tag only:

```tsx
<html lang="en" suppressHydrationWarning>
  <body suppressHydrationWarning>{children}</body>
</html>
```

Do NOT spray `suppressHydrationWarning` on inner components — it silences real bugs.

**5. Time zone / locale formatting between server and client.**

```tsx
// BROKEN — server formats in UTC, client in user's TZ
<p>{new Date(post.createdAt).toLocaleString()}</p>

// CORRECT — format on server, render the string
<p>{formattedDate}</p>

// or use suppressHydrationWarning ONLY on the dynamic element
<time dateTime={post.createdAt} suppressHydrationWarning>
  {new Date(post.createdAt).toLocaleString()}
</time>
```

## Async params and searchParams (Next 15+)

In Next.js 15 and 16, `params`, `searchParams`, `cookies()`, `headers()`, and `draftMode()` are all async. Awaiting them is mandatory.

```tsx
// CORRECT — Next 15/16
export default async function Page({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const { slug } = await params;
  const sp = await searchParams;
  const q = typeof sp.q === "string" ? sp.q : undefined;
  return <div>{slug} {q}</div>;
}
```

```tsx
// BROKEN in Next 15+ — throws sync-dynamic-API error
export default function Page({ params }: { params: { slug: string } }) {
  return <div>{params.slug}</div>;
}
```

Same for `cookies()` and `headers()`:

```tsx
import { cookies, headers } from "next/headers";

export async function GET() {
  const cookieStore = await cookies();
  const token = cookieStore.get("session")?.value;
  const h = await headers();
  const ua = h.get("user-agent");
  return Response.json({ token, ua });
}
```

If you see `sync-dynamic-apis` warnings in dev, you have an unawaited dynamic API call somewhere.

## Server Actions

```tsx
// app/actions.ts
"use server";

import { revalidatePath, revalidateTag } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";

const schema = z.object({
  text: z.string().min(1).max(500),
});

export async function createNote(prevState: unknown, formData: FormData) {
  const parsed = schema.safeParse({ text: formData.get("text") });
  if (!parsed.success) {
    return { error: parsed.error.errors[0].message };
  }
  await db.notes.insert({ text: parsed.data.text });
  revalidatePath("/notes");
  redirect("/notes");
}
```

```tsx
// app/notes/new/page.tsx — server component
import { createNote } from "@/app/actions";
import { SubmitButton } from "./submit-button"; // "use client"

export default function NewNote() {
  return (
    <form action={createNote} className="space-y-4">
      <textarea name="text" required className="..." />
      <SubmitButton />
    </form>
  );
}
```

```tsx
// app/notes/new/submit-button.tsx
"use client";
import { useFormStatus } from "react-dom";

export function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <button disabled={pending} className="...">
      {pending ? "Saving..." : "Save"}
    </button>
  );
}
```

Server Actions remove the need for an API route in most form-submit flows. Validate input with Zod or similar, mutate the DB, revalidate the relevant path or cache tag, redirect or return state.

For `useActionState` (Next 15+, replaces deprecated `useFormState`):

```tsx
"use client";
import { useActionState } from "react";
import { createNote } from "@/app/actions";

export default function Form() {
  const [state, action, pending] = useActionState(createNote, null);
  return (
    <form action={action}>
      <textarea name="text" />
      {state?.error && <p className="text-red-400">{state.error}</p>}
      <button disabled={pending}>{pending ? "..." : "Save"}</button>
    </form>
  );
}
```

## Streaming with Suspense

For slow data, wrap the slow part in `<Suspense>` so the rest of the page streams immediately.

```tsx
// app/dashboard/page.tsx — server component
import { Suspense } from "react";
import StatsGrid from "./stats-grid"; // async server component
import RecentActivity from "./recent-activity"; // async server component

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <h1>Dashboard</h1>
      <Suspense fallback={<StatsGridSkeleton />}>
        <StatsGrid />
      </Suspense>
      <Suspense fallback={<ActivitySkeleton />}>
        <RecentActivity />
      </Suspense>
    </div>
  );
}
```

```tsx
// app/dashboard/stats-grid.tsx
export default async function StatsGrid() {
  const stats = await getStats(); // slow
  return <div className="grid grid-cols-4 gap-4">...</div>;
}
```

`loading.tsx` is the page-level equivalent — fallback for the entire route while data fetches.

## Route conventions

Each file in `app/` has a specific role:

| File | Role |
|---|---|
| `page.tsx` | Renders the route |
| `layout.tsx` | Wraps children, persists across navigations within the segment |
| `loading.tsx` | Suspense fallback for the route (auto-wraps `page.tsx`) |
| `error.tsx` | Error boundary for the route — MUST be `"use client"` |
| `not-found.tsx` | Renders when `notFound()` is called or no route matches |
| `template.tsx` | Like layout but re-renders on each navigation |
| `route.ts` | API endpoint (`GET`, `POST`, etc.) |
| `middleware.ts` | Runs on every request (project root, not in `app/`) |

Route groups: `app/(marketing)/page.tsx` — the `(marketing)` segment is ignored in the URL but lets you scope layouts.

Parallel routes: `app/@modal/...` — render multiple "slots" at the same URL.

Intercepting routes: `app/(.)photo/[id]/page.tsx` — intercept navigation to show a modal instead of a full page.

## Fonts

Use `next/font/google` or `next/font/local` in the root layout. Apply via CSS variable.

```tsx
// app/layout.tsx
import { Inter, JetBrains_Mono } from "next/font/google";

const sans = Inter({ subsets: ["latin"], variable: "--font-sans" });
const mono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-mono" });

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${sans.variable} ${mono.variable}`}>
      <body className="bg-neutral-950 font-sans text-neutral-100 antialiased">
        {children}
      </body>
    </html>
  );
}
```

**Tailwind v4** `globals.css`:

```css
@import "tailwindcss";

@theme {
  --font-sans: var(--font-sans), ui-sans-serif, system-ui, sans-serif;
  --font-mono: var(--font-mono), ui-monospace, SFMono-Regular, monospace;
}
```

**Tailwind v3** `tailwind.config.ts`:

```ts
import type { Config } from "tailwindcss";

export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ["var(--font-sans)", "ui-sans-serif", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "monospace"],
      },
    },
  },
} satisfies Config;
```

## Tailwind v3 vs v4

Check `package.json` first. The `tailwindcss` version dictates everything.

**Tailwind v4** (`tailwindcss@^4`):

```css
/* globals.css */
@import "tailwindcss";

@theme {
  --color-violet-500: oklch(0.6 0.22 290);
}
```

```js
// postcss.config.mjs
export default { plugins: { "@tailwindcss/postcss": {} } };
```

No `tailwind.config.ts` required. Custom keyframes, animations, colors go in `@theme`.

**Tailwind v3** (`tailwindcss@^3`):

```css
/* globals.css */
@tailwind base;
@tailwind components;
@tailwind utilities;
```

```js
// postcss.config.js
module.exports = { plugins: { tailwindcss: {}, autoprefixer: {} } };
```

`tailwind.config.ts` is required for tokens and content paths.

**The silent failure:** writing `@tailwind base;` in a v4 project produces no error and no styles. Utility classes appear in the HTML but render unstyled. Always grep `package.json` before touching `globals.css`.

## Image component

```tsx
import Image from "next/image";

{/* Known dimensions */}
<Image src="/og.png" alt="..." width={1200} height={630} priority className="rounded-2xl" />

{/* Fill container */}
<div className="relative aspect-video">
  <Image src="/cover.jpg" alt="..." fill className="object-cover" />
</div>

{/* External image */}
{/* Add the domain to next.config.js images.remotePatterns */}
<Image src="https://images.unsplash.com/..." alt="..." width={800} height={600} />
```

`priority` only on above-the-fold images (LCP candidates). For decorative backgrounds, use CSS, not `<Image>`.

## Metadata

```tsx
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: { default: "App", template: "%s — App" },
  description: "...",
  openGraph: {
    title: "App",
    description: "...",
    images: [{ url: "/og.png", width: 1200, height: 630 }],
    type: "website",
  },
  twitter: { card: "summary_large_image" },
};
```

For dynamic metadata, `generateMetadata` is async with Promise params:

```tsx
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = await getPost(slug);
  return { title: post.title, description: post.excerpt };
}
```

## Middleware

```ts
// middleware.ts (project root)
import { NextResponse, type NextRequest } from "next/server";

export function middleware(req: NextRequest) {
  const token = req.cookies.get("session")?.value;
  const isProtected = req.nextUrl.pathname.startsWith("/app");
  if (isProtected && !token) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("from", req.nextUrl.pathname);
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\..*).*)"],
};
```

Middleware runs at the edge — no Node APIs, only Web APIs. Use it for auth checks, redirects, A/B testing cookie sets, and rewrites. Don't use it for heavy work — it runs on every request.

## API routes (when Server Actions aren't enough)

```ts
// app/api/notes/route.ts
import { NextRequest } from "next/server";

export async function GET(req: NextRequest) {
  const notes = await db.notes.findMany();
  return Response.json(notes);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const note = await db.notes.insert(body);
  return Response.json(note, { status: 201 });
}
```

Use API routes for: webhooks, third-party callbacks (OAuth, Stripe), CRON endpoints, public APIs consumed by non-Next.js clients. For form submissions and mutations from your own UI, prefer Server Actions.

## ESLint

Next 15+ ships with flat config (`eslint.config.mjs`). Do not mix with `.eslintrc.json`. If both exist, delete the legacy one — flat config wins, but the legacy file confuses editors.

## Common build-time errors

- `"Hydration failed..."` → see Hydration traps
- `"Route used \`params.slug\`. \`params\` should be awaited"` → Next 15+ params are async
- `"You're importing a component that needs ..."` → server-only API in a client tree, or vice versa
- `"Module not found: Can't resolve 'fs'"` → Node module in a client component
- Unstyled page → Tailwind v3 directives in v4 project (or vice versa), or `globals.css` not imported
- `"sync-dynamic-apis"` → unawaited `cookies()` / `headers()` / `params` / `searchParams`
- `"Functions cannot be passed directly to Client Components"` → passed a server function as prop to a client component without `"use server"`

## Performance defaults

- `priority` on above-the-fold images only
- `dynamic = "force-static"` on routes that don't need dynamic rendering
- `revalidate = N` in seconds for ISR
- `unstable_cache` (or `cache` from `react`) for expensive computations
- Use Suspense boundaries to stream slow data instead of blocking the whole page
- Avoid `"use client"` at the top of `page.tsx` and `layout.tsx` — extract interactivity into child components
