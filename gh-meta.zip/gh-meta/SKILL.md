---
name: gh-meta
description: >
  GitHub metadata manager for Fahim's projects. Fills the GitHub About section
  (description, homepage, topics), manages semantic versioning via git tags and
  npm version, generates changelogs from git log, and creates GitHub releases via
  gh CLI. Two modes: INIT (project creation — seed About from BRAIN.md) and
  RELEASE (ship time — bump version, generate changelog, create GitHub release,
  sync About). ALWAYS use when Fahim says "gh-meta", "fill about", "cut a release",
  "bump version", "version bump", "tag this", "what version am I on", "update release",
  "ship the release", "create github release", "gh release", "seed the about",
  "release history", or "update topics". Runs in Phase 5 after Council POST says SHIP,
  before ticket-checker. Also runs at Phase 0 init after repo-maintainer scaffolds docs.
  Reads BRAIN.md for initial seeding; reads Airborne/Humanizer output for polished
  release descriptions. Never edits code — metadata and versioning only.
---

# gh-meta

GitHub metadata manager. Two modes: **INIT** (project creation) and **RELEASE** (ship time).
Read-only **READ** mode also available for status checks without writing anything.

---

## When to Use

| Trigger | Mode |
|---|---|
| New project, repo-maintainer just scaffolded docs | INIT |
| "fill about", "gh-meta init", "seed github about", "set up topics" | INIT |
| Council POST said SHIP | RELEASE |
| "bump version", "cut a release", "tag this", "gh-meta release" | RELEASE |
| "what version am I on", "release list", "release history" | READ |
| Topics or description changed without a version bump | SYNC (About only) |

---

## Phase 0 — Always First: Auth + Snapshot

Run this before any write operation.

```bash
# 1. Verify gh CLI is authenticated
gh auth status

# 2. Snapshot current GitHub state before overwriting anything
gh repo view --json name,description,url,topics,latestRelease,defaultBranchRef
```

If `gh auth status` fails: stop. Tell Fahim to run `gh auth login` first. Do not proceed until authenticated.

---

## INIT Mode — Seed the About Section at Project Start

**Trigger:** New project, immediately after repo-maintainer scaffolds docs.

### Step 1 — Read BRAIN.md

Extract:
- Project tagline / one-liner → `--description`
- Deployment URL → `--homepage`
- Tech stack list → base topics

### Step 2 — Auto-generate topics from package.json

Scan `dependencies` + `devDependencies` and apply this mapping:

| Detected package | Topics to add |
|---|---|
| `next` | `nextjs` |
| `typescript` / `@types/*` | `typescript` |
| `tailwindcss` | `tailwind-css` |
| `drizzle-orm` | `drizzle-orm` |
| `better-auth` | `better-auth` |
| `@neondatabase/serverless` | `neon` · `postgresql` |
| `lemon-squeezy` / `@lemonsqueezy/*` | `lemon-squeezy` · `saas` |
| `@upstash/redis` | `upstash` · `redis` |
| `resend` | `resend` |
| `cloudinary` | `cloudinary` |
| `ably` | `ably` · `realtime` |
| `framer-motion` | `framer-motion` |
| `@vercel/og` | `vercel` |
| `zod` | `zod` |
| `trpc` / `@trpc/*` | `trpc` |
| `socket.io` | `websocket` · `realtime` |
| `stripe` | `stripe` · `payments` |

Always add project-category tags from BRAIN.md "What It Is" section (e.g. `saas`, `dashboard`, `auth`, `payments`, `open-source`).

GitHub topic limit: 20. Trim least-specific ones if over.

### Step 3 — Output the command

```bash
gh repo edit \
  --description "One-line description from BRAIN.md tagline" \
  --homepage "https://your-deployed-url.com" \
  --topics "nextjs,typescript,tailwind-css,drizzle-orm,better-auth,neon,saas"
```

### Step 4 — Generate README badges

Inject these at the top of README.md (below the project title):

```markdown
![Version](https://img.shields.io/github/v/release/mahtamun-hoque-fahim/{repo}?style=flat-square&color=00e676)
![License](https://img.shields.io/github/license/mahtamun-hoque-fahim/{repo}?style=flat-square)
![Stars](https://img.shields.io/github/stars/mahtamun-hoque-fahim/{repo}?style=flat-square)
```

Replace `{repo}` with the actual repo name. Badges are live — they pull from GitHub automatically once a release is cut.

---

## RELEASE Mode — Cut a Version at Ship Time

**Trigger:** Council POST said SHIP. Runs before ticket-checker.

Order is strict. Do not skip steps.

### Step 1 — Read current version

```bash
git describe --tags --abbrev=0        # latest tag → e.g. v1.0.0
git describe --tags                   # current position → e.g. v1.0.0-3-gabcd123
git tag -l --sort=-v:refname          # full tag history, semver sorted
```

If no tags exist yet: first release, starting from `v0.1.0`. Ask Fahim: patch, minor, or major for the first cut?

### Step 2 — Generate changelog from git log

```bash
# Commits since last tag (or all commits if first release)
git log $(git describe --tags --abbrev=0 2>/dev/null || git rev-list --max-parents=0 HEAD)..HEAD \
  --pretty=format:"- %s (%h)"
```

Claude sorts and formats the raw output into structured sections:

```markdown
## [vX.Y.Z] — YYYY-MM-DD

### Added
- New feature description (abc1234)

### Fixed
- Bug description (def5678)

### Changed
- Behaviour change description (ghi9012)
```

Prepend this entry to `CHANGELOG.md`. Create the file if it doesn't exist.

Commit prefixes as a guide:
- `feat:` / `add:` → Added
- `fix:` / `bug:` → Fixed
- `refactor:` / `chore:` / `style:` → Changed
- `docs:` → skip (internal)

### Step 3 — Bump the version

**For Next.js / Node projects (package.json present):**

```bash
npm version patch    # bug fix: 1.0.0 → 1.0.1
npm version minor    # new feature: 1.0.0 → 1.1.0
npm version major    # breaking change: 1.0.0 → 2.0.0
```

`npm version` automatically edits `package.json`, commits `vX.Y.Z`, and creates the git tag.

**For projects without package.json:**

```bash
# Edit VERSION file manually, then:
git add CHANGELOG.md VERSION
git commit -m "chore: release vX.Y.Z"
git tag -a vX.Y.Z -m "Release vX.Y.Z"
```

### Step 4 — Push code and tag together

```bash
git push origin main --follow-tags
```

`--follow-tags` pushes the commit and the new tag in one command. Never push them separately — race conditions between code and tag cause broken release states.

### Step 5 — Create the GitHub release

```bash
gh release create vX.Y.Z \
  --title "vX.Y.Z — Short title from Airborne/Humanizer copy" \
  --notes "$(git log PREV_TAG..vX.Y.Z --pretty=format:'- %s (%h)')"
```

Claude generates this command filled in with the real version number, a polished title (sourced from Airborne/Humanizer if available, otherwise from BRAIN.md tagline), and the formatted changelog notes from Step 2.

### Step 6 — Sync About description (if changed)

Run only if Airborne/Humanizer produced copy that improves on the original INIT description:

```bash
gh repo edit \
  --description "Updated polished description from Airborne/Humanizer output" \
  --homepage "https://live-deployed-url.com"
```

Topics are sticky — only update if the stack genuinely changed (new major dependency added or removed).

---

## READ Mode — Check State Without Writing

No writes. Safe to run at any time.

```bash
gh auth status                                         # confirm authenticated
gh release list                                        # all releases, newest first
gh release view                                        # latest release detail
gh repo view --json name,description,url,topics,latestRelease   # full current metadata
git describe --tags --abbrev=0                         # current version tag
git tag -l --sort=-v:refname                           # full version history
git log $(git describe --tags --abbrev=0)..HEAD --oneline       # unreleased commits
```

Use when Fahim says "what version am I on", "show release history", or "what's unreleased."

---

## SYNC Mode — About Only (No Version Bump)

When description or topics need updating without a release:

```bash
gh auth status

# Read current state
gh repo view --json description,url,topics

# Update only what changed
gh repo edit \
  --description "..." \
  --topics "..."
```

Do not run `npm version` or create a release in this mode.

---

## Pipeline Position

### Phase 0 — Project Init

```
singularity → BRAIN.md committed
  → tree-man → SITETREE.md
  → Council PRE-BUILD → verdict
  → repo-maintainer → docs scaffolded
  → gh-meta INIT mode      ← seeds About + README badges
  → build begins
```

### Phase 5 — Ship

```
Council POST → SHIP verdict
  → gh-meta RELEASE mode
      ↳ Step 1: read current version
      ↳ Step 2: changelog from git log
      ↳ Step 3: npm version patch/minor/major
      ↳ Step 4: git push --follow-tags
      ↳ Step 5: gh release create
      ↳ Step 6: gh repo edit (description sync if changed)
  → ticket-checker
  → git push to production
```

---

## Connections

| Skill | Direction | What transfers |
|---|---|---|
| **singularity** | singularity → gh-meta | BRAIN.md: description, deployment URL, tech stack → INIT About command |
| **airborne** | airborne → gh-meta | Polished meta description → RELEASE About update + release title |
| **humanizer** | humanizer → gh-meta | De-AI'd copy → RELEASE About update |
| **repo-maintainer** | gh-meta → repo-maintainer | `git describe --tags` version tag → README version badge in AGENTS.md sync |
| **compass** | compass routes to gh-meta | Phase 5 slot: after Council POST, before ticket-checker |
| **ticket-checker** | gh-meta → ticket-checker | Checkpoint: version bumped, release created, About synced |

---

## Output Format

gh-meta always produces this structure:

```
┌──────────────────────────────────────────────────────┐
│  gh-meta — [INIT / RELEASE / READ / SYNC]            │
│  Project: [name]    Mode: [mode]    Date: [YYYY-MM-DD]│
└──────────────────────────────────────────────────────┘

VERSION
  Current:   v1.x.x
  Previous:  v1.x.y
  Bump type: patch / minor / major

CHANGELOG
  Commits since last tag: [N]
  [formatted CHANGELOG.md entry — copy-paste ready]

COMMANDS (run in order)
  1. [command]
  2. [command]
  3. [command]
  ...

BADGES (inject into README.md)
  [markdown badge lines]

STATUS: DONE / NEEDS AUTH / BLOCKED: [reason]
```

All commands are numbered, copy-paste ready, and ordered for safe execution. Never reorder them.

---

## Trigger Phrases

`gh-meta` · `fill about` · `cut a release` · `bump version` · `version bump` ·
`tag this` · `what version am I on` · `update release` · `ship the release` ·
`create github release` · `gh release` · `seed the about` · `release history` ·
`update topics` · `gh-meta init` · `gh-meta release` · `gh-meta read` · `gh-meta sync`
