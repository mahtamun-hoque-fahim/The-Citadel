# Content Roadmap & Future Scope

The site at launch is the floor, not the ceiling. This file is how Airborne plans the next 90+ days of content and identifies new keyword surface area.

---

## The Topical Authority Principle

Google ranks sites that **demonstrably know their topic**, not just sites with one good page. A single well-written page about DELF B2 will be outranked by a site with 20 interconnected pages covering DELF mechanics, sample answers, prep timelines, scoring, and tutor profiles — even if each individual page is slightly weaker.

This is why Airborne always recommends a **topical cluster** plan, not just a launch page.

---

## Cornerstone Content — The 3-to-5 Anchor Pages

Cornerstone pages are the long-form, highly-optimized pages the rest of the site links into. They are:

- 1,500–4,000+ words of genuinely useful content
- Target a primary keyword with real volume
- Receive internal links from every related blog post
- Updated regularly (quarterly minimum)

### Selection criteria

Pick 3–5 cornerstone pages by intersecting:

1. **High commercial intent** for the product (turns readers into users)
2. **Sufficient search volume** to matter (not just long-tail)
3. **Topics where the site can credibly be the best resource**

### Cornerstone template (in the report)

```
### Cornerstone: "Complete DELF B2 Prep Guide"
- Primary keyword: "DELF B2 prep guide"
- Target URL: /guides/delf-b2-prep
- Estimated length: 3,500 words
- Sections (H2 outline):
  - What is the DELF B2 exam?
  - How is DELF B2 scored?
  - The 4 sections explained
  - 8-week study plan
  - Sample writing prompts and answers
  - Sample oral exam questions
  - Common mistakes to avoid
  - Practice resources
- Internal links from: every /blog/delf-* post, /exams/delf-b2
- Schema: Article + FAQPage + BreadcrumbList
```

---

## Topical Cluster Plan — The Blog Layer

Once cornerstones are picked, blog posts orbit each cornerstone. Each post:

- Targets one long-tail keyword cluster
- Links up to its cornerstone (passes authority up)
- Cornerstone links down to it (distributes authority)

### The pillar-cluster model

```
                ┌────────────────────────────────┐
                │ Cornerstone: DELF B2 Prep Guide│
                └──────┬──────────┬──────────────┘
                       │          │
       ┌───────────────┼──────────┴───────────────────┐
       │               │                              │
┌──────▼─────┐  ┌──────▼─────┐                ┌──────▼──────┐
│ Blog: DELF │  │ Blog: DELF │   ...          │ Blog: DELF  │
│ B2 writing │  │ B2 scoring │                │ B2 timing   │
│ templates  │  │ explained  │                │ strategy    │
└────────────┘  └────────────┘                └─────────────┘
```

Each blog post:
- Has one H1 with the cluster's long-tail keyword
- Answers 5–10 related questions in H2 form
- Includes one upward link to the cornerstone

### Blog cluster output format (in the report)

```
### Cluster 1: DELF B2 Writing Section
**Cornerstone link:** /guides/delf-b2-prep
**Cluster intent:** Informational, anxious-pre-exam audience

**Post 1 — High priority**
- Title: 7 DELF B2 Writing Templates from Students Who Scored 16+
- Slug: /blog/delf-b2-writing-templates
- Primary KW: "DELF B2 writing templates"
- Word count target: 2,000
- Schema: Article + FAQPage

**Post 2 — Medium priority**
- Title: How to Structure a DELF B2 Essay (with 3 Worked Examples)
- Slug: /blog/structure-delf-b2-essay
- Primary KW: "DELF B2 essay structure"
- Word count target: 1,800

**Post 3 — Lower priority**
- Title: 12 Common Mistakes in DELF B2 Production Écrite
- Slug: /blog/delf-b2-writing-mistakes
- Primary KW: "DELF B2 writing mistakes"
- Word count target: 1,500
```

---

## Content Volume — How Much Is Enough?

| Goal | Cornerstones | Blog posts | Timeline |
|---|---|---|---|
| Launch credibly | 1–2 | 5–10 | 0–30 days |
| Establish topical authority in a niche | 3–5 | 20–40 | 90 days |
| Compete for primary commercial KW | 5+ | 50+ | 6–12 months |

A site with 3 cornerstones and 20 supporting posts almost always outranks a site with one excellent page on the same primary keyword, assuming similar backlink profiles.

---

## Feature Gap Analysis — Un-Coded Surface Area

The most overlooked SEO move is **building things that earn keywords**, not just writing about them. Airborne identifies features that would unlock new search visibility.

### Common high-leverage features

| Feature | Keyword type unlocked | Effort |
|---|---|---|
| Free calculator / tool | "free [thing] calculator", "[thing] estimator" | Medium |
| Glossary / encyclopedia | "what is [term]" × hundreds | Medium |
| Template / sample library | "[thing] template", "[thing] example" | Low-Medium |
| Comparison / vs pages | "[thing] vs [thing]" | Low |
| Pricing / cost guides | "how much does [thing] cost" | Low |
| Public dataset / report | Backlinks from journalists and bloggers | High |
| Public profiles (tutors, courses) | Long-tail names + locations | Medium |
| API / integrations directory | "[product] [integration]" | Medium |

### How to surface these in the report

```
### Feature Gaps (Un-Coded Surface Area)

**Gap 1 — Free DELF B2 Readiness Quiz**
- Why: searches for "am I ready for DELF B2" and variants have intent but no good tool exists
- Estimated keyword surface: 15–20 long-tail queries
- Effort: 1 sprint
- Schema: SoftwareApplication + Quiz

**Gap 2 — DELF Sample Answer Library**
- Why: "DELF B2 sample answers" gets searched but only PDFs from forums rank
- Keyword surface: hundreds of long-tail queries (one per prompt × level)
- Effort: 2 sprints (content + UI)
- Schema: Article + ItemList

**Gap 3 — Tutor profile pages**
- Why: each tutor profile is its own indexable page with unique long-tail
- Keyword surface: "[language] tutor [location]" patterns
- Effort: 1 sprint (template + 10 profiles)
- Schema: Person + Service
```

---

## Adjacent Market Expansion

Once the core ranks, look 1–2 hops away. These are keyword segments that overlap with the product's core but represent new audiences or new use cases.

### Adjacent-market identification

Ask:
1. **Who else searches the same long-tail terms** but for a different reason?
2. **What problems does our current audience have BEFORE they need our product?** (top-of-funnel)
3. **What problems do they have AFTER?** (post-conversion content earns lifetime value + brand search)
4. **What geographic or linguistic adjacent markets** are underserved?

### Example for LearnDE

Core: French and German exam prep (DELF, DSH, TestDaF)

Adjacent markets:
- **Before exam prep:** "should I take DELF or TCF" → comparison content earns traffic from undecided learners
- **After exam:** "what visas does DELF B2 unlock" → connects to immigration/student visa keywords
- **Geographic:** Expand prep content to Nepali, Sri Lankan, and Indian audiences with same exam targets but different cultural references
- **Adjacent exams:** Add IELTS / TOEFL prep using the same platform → opens an entirely new traffic stream

### Report format

```
### Adjacent Markets (6–12 month horizon)

**Market 1 — Pre-exam comparison content**
- Keyword segment: "DELF vs TCF", "DSH vs TestDaF", "which French exam for visa"
- Audience: learners who haven't picked an exam yet
- Estimated lift: 15–30% incremental top-of-funnel traffic
- Implementation: 5 comparison pages, each ~1,500 words

**Market 2 — Post-exam outcomes**
- Keyword segment: "DELF B2 for French citizenship", "DSH for German university admission"
- Audience: students using the exam result for visa or admission
- Estimated lift: high commercial intent, captures lifetime value
- Implementation: 3 outcome guides, link from result delivery emails

**Market 3 — IELTS / TOEFL prep**
- Keyword segment: massive English-exam keyword universe
- Audience: same demographic, different exam
- Estimated lift: 3–10× current addressable traffic
- Implementation: new course modules, takes a quarter to build
```

---

## Prioritization — Impact vs Effort

Every roadmap item gets ranked by impact and effort. The report should produce something like:

```
| # | Item | Impact | Effort | Priority |
|---|------|--------|--------|----------|
| 1 | Publish cornerstone: DELF B2 Prep Guide | High | Medium | Now |
| 2 | Add JSON-LD to all existing pages | High | Low | Now |
| 3 | Free DELF Readiness Quiz tool | High | High | Next 30 days |
| 4 | Cluster 1 (3 blog posts on writing) | Medium | Medium | Next 30 days |
| 5 | Tutor profile pages | Medium | Medium | Next 60 days |
| 6 | IELTS adjacent expansion | Very High | Very High | Q3 |
```

Default rule: **Low-effort + High-impact items go first.** Schema markup, meta tags, canonical tags, and sitemap fixes almost always belong in the first 24 hours of the roadmap.

---

## Cadence Recommendations

For each project Airborne plans, recommend a publishing cadence:

| Site size | Blog cadence | Cornerstone refresh |
|---|---|---|
| Pre-launch / 0–5 pages | Weekly while building, 2x/week first month | Build all cornerstones in first 30 days |
| Established (20+ pages) | Weekly | Quarterly review and update |
| Mature (100+ pages) | 2x/week | Monthly review of top 10 |

Consistency beats volume. One post per week, every week, for 6 months outranks 20 posts in one month followed by silence.
