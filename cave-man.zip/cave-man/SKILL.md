---
name: cave-man
description: >
  Post-build visual-opportunity audit for Fahim's stack (Next.js,
  Tailwind, dark-first palette). Runs LAST in POST-BUILD, after
  airborne/humanizer, right before council — audits the truly final page
  set so nothing it briefs gets rewritten later. Scans every page
  (SITETREE.md, else `/app`) and classifies each visual zone NEEDS-ART
  (high-impact zone, empty or filled with a cheap CSS-only filler),
  HAS-ART (real asset already wired, pass), or KEEP-FLAT (dashboards,
  settings, admin CRUD — art is noise there). For NEEDS-ART zones, inserts
  a reserved-space placeholder plus a locked one-line IMAGE-BRIEF comment
  tag describing exactly what to design. Never generates the artwork
  itself — the brief is the deliverable, the art is Fahim's. A scoped
  motion-hive touch-up follows to skeleton-treat the new placeholders
  before council. Trigger: "cave-man", "visual audit", "image audit",
  "where should images go", "find image opportunities", or a finished
  site that still reads flat or templated.
---

# cave-man

**Purpose:** find every place a custom visual would actually move the needle,
find every place it would not, and prep the structural slot for the first
without ever trying to draw the picture itself.

**Position in Fahim's pipeline:**
```
Waterborne → motion-hive → Valley of Death → Sentinel → Airborne → Humanizer → cave-man → motion-hive touch-up → Council POST
```

---

## Why This Exists

Sites built by Claude tend to read flat because the only "visual content" a
model can produce on its own is CSS — gradient meshes, icon-in-a-circle
grids, abstract blobs. Those patterns are cheap to generate and that's
exactly why they read as templated. The sites that look expensive (Linear,
Stripe, Vercel marketing pages) almost always have a custom photograph,
illustration, or render doing real work in the hero and feature zones —
something a designer made, not something a stylesheet generated.

Fahim has a decade in Figma. The correct division of labor is: Claude
identifies *where* a visual is needed and *what it should be*, Fahim makes
the actual call on what it looks like. cave-man only does the first half.

---

## Phase 0 — Read Context First

- `SITETREE.md` — primary route list. If missing, scan `/app` directly and
  note in the report: `"SITETREE.md missing — scanned /app directly,
  recommend running tree-man"`. Do not block on its absence.
- `BRAIN.md` or `DESIGN_GUIDE.md` — palette tokens and product mood. Briefs
  must reference real tokens (`bg-surface`, `accent`, `accent/20`) — never
  raw hex.
- `PLANNER.md` — which routes are public/marketing vs internal/functional.
  This distinction drives every verdict in Phase 1.

---

## Phase 1 — Classify Every Page

Tag each route MARKETING or FUNCTIONAL:

| Signal | Classification |
|---|---|
| Landing, pricing, about, feature pages, onboarding, empty states, 404, anything used as an og:image surface | MARKETING |
| Dashboard, settings, admin CRUD, internal tools, data tables, forms | FUNCTIONAL |

FUNCTIONAL pages get one line in the report — `"flat is correct"` — and are
skipped. Do not hunt for art opportunities on a settings page. Custom
illustration on a functional surface is a regression, not a feature.

---

## Phase 2 — Walk MARKETING Pages, Zone by Zone

For each visual zone (hero, feature row, testimonial block, CTA banner,
empty state, og:image), classify:

| Verdict | Meaning |
|---|---|
| **HAS-ART** | Already wired to a real photo, illustration, or render via an actual image file. Pass, leave alone. |
| **NEEDS-ART** | Empty, or filled with a generic CSS-only filler (icon-in-circle, gradient blob, repeated icon grid) sitting in a high-impact zone. |
| **EXCEPTION-SMALL-ART** | A small illustration genuinely helps comprehension even on an otherwise functional surface — e.g. a friendly "no results" empty-state graphic. Rare. Brief it small. |

**Icon fatigue check:** if four or more feature cards on one page repeat the
identical icon-in-circle treatment, that is one combined NEEDS-ART
opportunity (one hero illustration, one pattern), not four separate briefs.
Merge them.

---

## Phase 3 — Print the Audit Table Before Touching Anything

| Page | Zone | Verdict | Current Treatment | Notes |
|---|---|---|---|---|
| `app/page.tsx` | Hero | NEEDS-ART | gradient blob + lucide icon | highest-traffic page, biggest lift |
| `app/page.tsx` | Feature row | NEEDS-ART | 4x identical icon-in-circle | icon fatigue — merge into one illustration |
| `app/pricing/page.tsx` | Plan cards | HAS-ART | real screenshot already wired | pass |
| `app/dashboard/page.tsx` | — | FUNCTIONAL | — | flat is correct, skipped |

Print this and wait before inserting anything, unless told to run
autonomously — then proceed in priority order: highest-traffic marketing
pages first, icon-fatigue merges before single-zone fixes.

---

## Phase 4 — Insert Placeholder + Brief

For every **NEEDS-ART** and **EXCEPTION-SMALL-ART** zone, insert a
reserved-space placeholder directly in the component, with the locked
comment tag immediately above it:

```tsx
{/* IMAGE-BRIEF: hero-01 | 16:9 | abstract 3D render, dark surface bg-surface, accent glow accent, single floating UI card at 3/4 angle, soft volumetric light top-left, no baked-in text */}
<div
  data-image-slot="hero-01"
  className="aspect-video w-full rounded-xl border border-dashed border-white/10 bg-surface/40"
/>
```

**Format is locked:** `slot-id | aspect-ratio | brief text`, in that order,
one line, always. This is what keeps `grep -r "IMAGE-BRIEF:"` reliable
across every project in the portfolio. If a brief feels too long, trim the
brief — never break the format.

Rules for this phase:
- Pull palette language straight from `DESIGN_GUIDE.md` tokens. Never write
  `#131720` or `#00e676` into a brief.
- Reserve correct aspect ratio for the slot's actual grid position — don't
  guess; check the surrounding layout.
- Do not style, animate, or otherwise finish the placeholder beyond
  reserving its space and tagging it. A small **scoped** motion-hive
  touch-up runs immediately after cave-man — not a full re-audit, it only
  applies skeleton-shimmer treatment to the new `data-image-slot`
  elements cave-man just inserted.
- Never generate the actual image file. No image-gen calls for production
  art. The brief is the deliverable.

---

## Phase 5 — Cave Report

```
────────────────────────────────────────
CAVE-MAN — [Project Name] — [Date]
────────────────────────────────────────
Pages scanned:          N marketing, N functional
Zones already correct:  N  (HAS-ART)
Zones needing art:      N  (NEEDS-ART / EXCEPTION)
Cheap fillers replaced: N
Icon-fatigue merges:    N

NEEDS ART — design these next:
  hero-01    16:9   app/page.tsx:42        — abstract 3D render, dark surface...
  feat-02    1:1    app/page.tsx:88        — flat illustration, single accent color...
  empty-03   4:3    app/search/page.tsx:21 — small friendly empty-state graphic...

KEEP FLAT — no art needed, do not touch:
  /dashboard, /settings, /admin/*  — functional surfaces

Harvest this list again anytime:  grep -r "IMAGE-BRIEF:" .
────────────────────────────────────────
motion-hive touch-up is clear to run (scoped — new placeholders only).
────────────────────────────────────────
```

---

## Operating Rules

- **Never generates the artwork.** The brief is the deliverable — the art
  is Fahim's, made wherever he chooses.
- **Never writes to a living doc.** No edits to `DESIGN_GUIDE.md`,
  `PLANNER.md`, or `BRAIN.md`. The brief lives only as an inline code
  comment beside its placeholder — nothing for repo-maintainer to sync,
  nothing to drift out of date.
- **Never touches FUNCTIONAL pages** beyond the one-line confirmation.
- **Locked tag format, no exceptions:** `slot-id | ratio | brief`.
- **If SITETREE.md is missing,** scan `/app` directly, flag the gap, do not
  block.
- **These placeholders are not mock data.** A `data-image-slot` div is a
  pending art slot, not a fake-data stand-in — valley-of-death's
  hardcoded-data check should not flag it (see note added to
  valley-of-death Section C.4).

---

## Pipeline Position

cave-man runs last in the POST-BUILD sequence — after airborne and
humanizer, not early. Running it after every correctness gate
(valley-of-death, sentinel) and both copy passes (airborne, humanizer)
means it audits the page set in its actually-final state: nothing it
briefs can still get invalidated by a later step rewriting the page out
from under it.

The trade-off: the placeholders it inserts arrive after motion-hive's
full sweep has already happened, so without a follow-up they'd sit on
the page as untreated static boxes. A small **scoped** motion-hive
touch-up runs immediately after cave-man to fix exactly that — not a
full re-audit, just skeleton-shimmer treatment for the handful of new
`data-image-slot` elements — before council POST closes out the build.
