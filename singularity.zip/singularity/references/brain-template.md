# BRAIN.md — [Project Name]

> This file is maintained by the Singularity skill. It is the identity document of this project.
> When Claude drifts, hallucinates, or loses context — this file is the source of truth.
> Do not confuse this with PLANNER.md (tasks/phases) or DESIGN_GUIDE.md (design tokens).

---

## The One-Line Truth

[One sentence. What this project IS. Brutal and honest.]

---

## Why It Exists

[2–4 sentences. The problem, the gap, the person it's for. Why Fahim is building it.]

---

## What It Must Become

[The north star. Not a feature list — the end state in spirit. What does "done" feel like?]

---

## Core Decisions (Locked)

These decisions are final. Claude must not question or work around them without explicit confirmation from Fahim.

- [LOCKED] [Decision] — [One-line reason]
- [LOCKED] [Decision] — [One-line reason]
- [LOCKED] [Decision] — [One-line reason]

---

## Visual Identity (Locked)

> Chosen in Phase 1.5. These values are locked. Do not substitute with `#00e676`, `#0a0a0a`, `#131720`, or `#6C63FF`. Do not invent new values. If you need a token not listed here, derive it from the accent at reduced opacity and flag it for Fahim.

| Token          | Value       | Usage                            |
|----------------|-------------|----------------------------------|
| `bg`           | [value]     | Page background                  |
| `surface`      | [value]     | Card, panel, input backgrounds   |
| `surface-elevated` | [value] | Raised elements, dropdowns       |
| `accent`       | [value]     | Primary actions, links, glows    |
| `accent-faint` | [value]     | Ring/border accent at 10% opacity|
| `border`       | [value]     | Default border colour            |
| `text`         | [value]     | Primary text                     |
| Font (display) | [family]    | Headings                         |
| Font (body)    | [family]    | Body copy                        |
| Font (mono)    | [family]    | Code, numbers                    |



## What It Must Never Become

[Anti-goals. The drift traps. What this project should never turn into, no matter how logical it seems in the moment.]

- Never [x]
- Never [y]
- Never [z]

---

## Current State

```
Status: [Alpha / Beta / MVP / Production / Paused / Abandoned]
Last updated: [YYYY-MM-DD]

What works:
- 

What's broken or incomplete:
- 

What's next (in spirit, not tasks):
- 
```

---

## The Stack (Frozen)

These are confirmed for this project. Do not suggest alternatives unless Fahim initiates a migration.

| Layer | Choice |
|---|---|
| Framework | Next.js [version] App Router |
| Language | TypeScript |
| Styling | Tailwind CSS [version] |
| Database | Neon (PostgreSQL) + Drizzle ORM |
| Auth | [Better Auth / NextAuth v5 / Clerk] |
| Deployment | Vercel (primary) + Cloudflare Pages (secondary) |
| Email | Resend |
| [Other] | [Service] |

---

## Constraints & Non-Negotiables

Hard limits. Technical, design, legal, or personal.

- Must deploy to both Vercel and Cloudflare Pages (Edge Runtime compatible)
- No emojis in UI — lucide-react icons only
- Dark-first, no light mode
- No Supabase
- [Add project-specific constraints]

---

## Context Hooks (for Claude)

Things Claude tends to forget or get wrong on this specific project. Treat these as hard truth.

- [Hook 1]
- [Hook 2]
- [Hook 3]

---

*Last updated by Bushmaster on [date]*
