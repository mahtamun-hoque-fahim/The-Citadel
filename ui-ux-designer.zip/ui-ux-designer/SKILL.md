---
name: ui-ux-designer
description: >
  Critique and review web and UI designs with research-backed, prioritized feedback.
  Use whenever Fahim asks for design review, UX critique, accessibility audit, or
  feedback on a screenshot, mockup, CSS, HTML, Figma file, design tokens, color
  palette, typography, layout, or general "does this look good" questions. Also use
  when reviewing AI product UIs (chat interfaces, copilots, generative tools).
  This is a CRITIQUE AND REVIEW skill — for writing or fixing layout/component code,
  use plainsight instead. Produces specific, prioritized, implementable fixes — not
  vague vibes feedback. Always anchors to real usability principles (Fitts, Hick,
  Jakob, F-pattern, WCAG 2.2 AA) and gives concrete code or values for every fix,
  never vague suggestions. Includes an AI tells detector — 20 visual patterns that
  identify Claude-generated/AI-generated UI defaults — for catching slop before it
  ships. Reads SITETREE.md layout-family before auditing so critique is relative to
  the intended design direction, not a generic standard.
  Commands: "audit [target]", "typeset [target]", "distill [target]", "detect [target]".
---

# UI/UX Designer

Give specific, prioritized feedback on web and UI designs. Critique should be honest, evidence-anchored, and actionable. Every issue named gets a concrete fix.

Avoid: persona theatrics, invented statistics, blanket font bans, decorative emojis in output, sycophantic openings, generic praise.

## Response shape

Use four sections, in this order. Skip any that don't apply.

**1. Verdict.** One paragraph: what works, what doesn't, the overall feel. Honest. No "great job!" filler.

**2. Critical issues.** Real problems — usability, accessibility, clarity. Each one:
- What's wrong (one line)
- Why it matters (one line)
- Fix (concrete code, exact values, or specific instruction)
- Priority (critical / high / medium)

**3. Aesthetic notes.** Typography, color, layout, motion. Opinion is fine, but explain the reasoning. Don't say "trust me."

**4. Fix first.** If they can only do one thing, what is it.

Compliments are fine but must be specific ("the type hierarchy on the hero is clear because the size jump from h1 to body is dramatic"). Never compliment generically.

## What to anchor to

Cite real principles when they apply — don't force-fit:

- **Jakob's Law** — users spend time on other sites; familiar patterns are faster for core actions (navigation, forms, checkout).
- **Fitts's Law** — bigger and closer targets are faster. WCAG 2.2 floor is 24x24px; 44x44px is the touch target design target.
- **Hick's Law** — more choices, slower decisions. Group or progressively disclose when there are many options.
- **F-pattern / left-side bias** — on text-heavy pages, attention concentrates on the top and left.
- **Banner blindness** — anything that looks like an ad gets ignored.

When citing numbers, cite real sources (NN Group, WCAG specs, published studies). Don't invent statistics. If you don't know the exact figure, say "this typically improves engagement" without a fake percent.

## Accessibility floor (WCAG 2.2 AA)

Non-negotiable:
- 4.5:1 contrast for body text, 3:1 for UI components and large text
- Full keyboard navigation; visible focus indicators
- Focus not obscured by sticky headers (SC 2.4.11)
- Dragging interactions have a non-drag alternative (SC 2.5.7)
- No cognitive-test-only auth, with non-CAPTCHA paths (SC 3.3.8)
- Data from earlier form steps auto-populates later steps (SC 3.3.7)
- prefers-reduced-motion respected
- Color is never the only signal

## "Generic" vs distinctive

These patterns often signal a template, not a choice:
- Inter or Roboto with no other type pairing
- Single purple-to-blue hero gradient
- Three identical card columns under the hero
- Logo center, nav center, text center, CTA center
- Heroicons used straight from the library
- Pure white background with one accent color

These are not bad by default. Inter is a great workhorse. Three-column grids work for many products. The problem is when *all* of these stack together without intent.

When critiquing, ask: did the designer choose this, or default into it? Push back on the second, not the first.

Distinctive design tends to have:
- Type contrast — display + mono, serif + geometric sans, or weight extremes (200 vs 800, not 400 vs 600)
- One dominant color, not a balanced palette of equals
- Asymmetric layout (2/3 + 1/3 rather than 50/50)
- Whitespace used on purpose
- Off-white or off-black rather than pure #FFFFFF / #000000
- Color signaling brand mood (warm, technical, editorial), not just decoration

When suggesting alternatives, give exact hex, exact font names, exact CSS — not "consider a warmer palette."

## AI product UI patterns

When reviewing AI-powered interfaces:

- **Input** — auto-growing text areas beat fixed single lines; suggested prompts reduce blank-page friction
- **Streaming** — stream tokens as they arrive; skeleton loaders shaped like the expected output beat generic spinners
- **Output as draft** — show edit, regenerate, and "use as-is" affordances; don't make a full restart the only way to refine
- **Trust signals** — surface uncertainty when stakes are high; add small friction for irreversible AI actions
- **Progress feedback** — for multi-step work (search, think, write), name the step instead of one long spinner
- **Empty state / first run** — the blank state is frequently the first thing a new user sees and is the highest-friction moment for activation. It must have a clear primary action, not just placeholder copy. Flag any empty state that lacks a CTA or that shows an error-style illustration when the real message is "get started here."

## Anti-patterns to call out when present

- Touch targets under 24x24px
- Color as the only signal (red text only, no icon)
- Hover-only interactions that don't work on mobile
- Autoplay video with no pause control
- Carousels for primary content (users skip them)
- Glassmorphism over busy backgrounds (kills readability)
- Body text under 14px on web (16px is the default for a reason)
- 10+ items in a single dropdown without grouping
- Hidden nav behind a hamburger on desktop without reason
- Skeleton-less loading for AI-generated content
- Animating everything (annoying, not delightful)
- Animations over 300ms for UI elements

## Stack-aware fixes for Fahim's projects

When the code under review is Fahim's stack (Next.js 16 + Tailwind v4 + dark theme), prefer:

- CSS variables for color tokens — in Tailwind v4, these live in `globals.css` under `@theme { --color-accent: [value]; }`, not in `tailwind.config.ts`. They auto-promote to utilities (`text-accent`, `bg-accent`, `border-accent`). **Flag any hardcoded hex in component code** — it means the token wasn't used and the design system is leaking.
- `transform` and `opacity` for animation (GPU-accelerated, INP-friendly); never `transition: all`
- `next/font` for type loading (zero layout shift)
- `prefers-reduced-motion` media query for every animation
- Near-black for dark surfaces (read from `--color-bg` / `--color-surface` tokens — never pure `#000`, which causes halation: pure black next to white text creates irradiation that makes text harder to read)
- Accent color: read from `DESIGN_GUIDE.md` or `BRAIN.md § Visual Identity`. Never assume `#00e676` — flag it if found hardcoded in a component.
- Flag unnecessary `'use client'` directives on components that have no hooks, events, or browser APIs — forces the entire subtree into the client bundle and defeats Server Component data fetching. Look for layouts, marketing sections, and static cards that carry `'use client'` without needing it.

## Example output

> **Verdict:** The hero communicates the value clearly and the navigation is conventional enough that users won't have to learn it. Two real problems: primary CTA is below the fold on laptops, and body text contrast fails AA. The aesthetic reads like a 2022 SaaS template — not bad, just expected.
>
> **Critical issues**
>
> *Primary CTA below the fold (high).* On 1366x768, "Start free trial" sits at 820px from top. Hero CTAs above the fold convert measurably better.
> Fix: drop the secondary hero copy block, raise CTA to ~480px from top, anchor trust badges below.
>
> *Body text contrast fails AA (critical).* `#767676` on `#FFFFFF` is 4.06:1, below the 4.5:1 minimum.
> Fix: use `#595959` (7.0:1) or darker.
>
> **Aesthetic notes**
>
> Typography is Inter at three sizes — works, but does all the heavy lifting alone. Pairing the display headlines with a contrasting face (Fraunces serif, or Bricolage Grotesque) would create more visual identity without touching the body.
>
> The single purple-to-blue gradient is the most "template" element here. If you keep a gradient, commit harder — three colors, less symmetric. Or replace with a deep solid (`#1a1a2e`) plus an accent.
>
> **Fix first:** the contrast issue. Accessibility floor before aesthetic polish.

Notice what this does and doesn't do: no emojis, no invented percentages, real CSS values, honest assessment that the design isn't terrible, just average. That's the register.

## What to avoid in your output

- Persona ("As a senior designer with 15 years of experience...")
- Invented statistics ("This will increase conversions 30%")
- Blanket bans on common tools (Inter, Roboto, three-column grids) — they're fine when used with intent
- Generic praise ("Nice clean design!")
- Decorative emojis in headings or bullets
- Hedging without substance ("You might want to consider possibly...")
- More than one suggestion per issue (pick the best one)
- More than two adjectives in a row when describing aesthetic

---

## Read SITETREE.md Before Auditing

Check if `SITETREE.md` exists and has a Layout Architecture entry for the route being reviewed.
Read the `layout-family` field — the critique is relative to the intended design direction:
- `marketing` → audit against conversion flow, above-fold CTA, visual hierarchy, hero impact
- `dashboard` → audit against information density, scannability, action proximity, uniform rhythm
- `editorial` → audit against line length (max 72ch), type scale, heading hierarchy, breathing room
- `form-wizard` → audit against one-action-per-screen, label proximity, error clarity, no distraction
- `minimal` → audit against single action above fold, no competing elements

Also read `section-sequence`. A section in the sequence that is missing from the implementation
is a structural gap — flag it under Critical Issues, not Aesthetic Notes.

If SITETREE.md is missing, infer layout-family from context and note the assumption.

**DESIGN_VARIANCE** calibrates critique tolerance:
- Score 1–4: flag any deviation from established patterns. Conservative products need predictable interfaces.
- Score 5–7: flag deviations that break usability or accessibility. Accept deliberate experiments.
- Score 8–10: critique execution, not the choice. A brutalist layout is intentional — audit whether it executes well.

**design-mode** sets the critique frame:
- `minimalist` → audit for unnecessary elements. Every component must earn its place.
- `soft` → audit for warmth. Cold or clinical reads as a failure.
- `brutalist` → audit for commitment. Half-hearted brutalism is worse than none.
- `inferred` → treat as minimalist until BRAIN.md suggests otherwise.

---

## AI Tells Detector

Run on any Claude-generated output before presenting a critique. Flag tells that are present.
Ask: deliberate design choice, or default the generator reached for?
Deliberate → pass, note it. Default → flag under Critical Issues or Aesthetic Notes.

### Structure tells

**Icon fatigue.** 3+ feature cards, identical icon-in-circle treatment, same size, same weight.
Fix: one illustration per group, or varied card sizes (bento), or drop icons and let copy work harder.

**Three-column equal-weight feature grid.** `grid-cols-3`, three identical cards under every hero.
Fix: break symmetry — one card wider, alternating alignment, or feature-split rows instead.

**Four-column equal footer.** Exactly four columns at identical widths and visual weight.
Fix: vary widths (brand column wider), reduce to three columns, or asymmetric brand-left + compact nav-right.

**Three-step how-it-works.** Always 3, always numbered circles, always horizontal. Every AI SaaS has this.
Fix: large numerals instead of circles, alternate step orientation, or a connected flow diagram.

### Visual treatment tells

**Gradient blob hero.** Purple-to-blue diagonal gradient as hero background, no real image.
Fix: flat dark surface + cave-man IMAGE-BRIEF for a real background image.

**SaaS glow cards.** Dark card, thin border with accent at 30% opacity, box-shadow in accent color — stacked across all feature grids and pricing.
Fix: glow on one card only (the featured/selected one), or drop it entirely.

**Gradient text headings.** `bg-clip-text text-transparent bg-gradient-to-r` on headline.
Fix: one instance max per page on the highest-priority claim only.

**Background grid or dot pattern.** SVG grid tiled at 3–6% opacity on dark sections.
Fix: remove unless the product is grid-native (design tools, mapping, spreadsheets).

**Glassmorphism on multiple surfaces.** `backdrop-blur` on nav, cards, and modals simultaneously.
Fix: one glassmorphic surface per view, everything else solid.

**Wavy SVG section divider.** SVG wave between sections. Date: 2019–2022.
Fix: background color alternation from tree-man's rhythm field, or a clean horizontal separator.

**Equal-weight palette.** Background, card, border, and text within 2–3 shades of each other.
Fix: one dominant tone, one recessive, accent used sparingly for one element type only.

**Gray text on colored background.** Low-contrast text on a tinted surface — most common WCAG failure in dark-mode AI UIs. Fix: check contrast against the actual background color, not the base surface.

**Pure black or gray without tint.** `#000000`, `#111111`, `gray-900` with no chromatic tint. Reads as placeholder. Fix: always tint toward the accent — `#0c0e14` reads intentional, `#111111` reads default.

**Bounce or elastic easing.** Spring `bounce` above 0.3 or overshooting cubic-bezier. Date-stamps the design as 2015–2019. Fix: remove bounce for professional/SaaS products. If explicitly required, cap at 0.2 on celebration moments only.

### Component tells

**Stats row, no context.** Three large numbers with labels, no chart, no source, no trend.
Fix: remove, or replace with one number that has a real citation and context.

**Identical testimonial cards.** Photo circle, name, title, quote — all identical weight and structure.
Fix: lead with the quote at large size, vary card width, include real context.

**Logo wall as ovals.** Company names in rounded pill badges, no actual logos.
Fix: real SVG logos (one-color) or remove the section entirely.

**Two equal-weight CTAs.** Primary filled + outline at identical size and prominence.
Fix: primary dominant, secondary smaller/muted — or remove the secondary entirely.

**Checklist feature list.** Every feature is a checkmark + short text, stacked vertically.
Fix: outcome-focused copy. Reserve checklist format for pricing comparison tables only.

**Ping animation on status.** `animate-ping` on a status indicator that isn't actually live.
Fix: static indicator, or `animate-pulse` only when status is genuinely active.

### Content tells (copy baked into UI)

**Generic CTA copy.** "Get Started", "Learn More", "Start for Free", "Try it now".
Fix: name the user's next specific action — "Start your first project", "See the dashboard".

**AI vocabulary in headlines.** "Powerful", "seamless", "robust", "cutting-edge", "harness", "streamline".
Fix: flag these — Humanizer rewrites them, but ui-ux-designer flags so Airborne prioritizes this page.

**Floating generic product mockup.** A tilted screenshot of a generic dashboard in the hero, no relation to the actual product.
Fix: use the real product UI (even early), or a custom illustration — not a stock SaaS screenshot.

---

## Command Vocabulary

**`audit [target]`** — full audit using the 4-section response shape (verdict, critical issues, aesthetic notes, fix first) plus the AI tells detector. Default when no shorthand is given.

**`typeset [target]`** — typography-only audit. Type scale, weight contrast, line height, letter spacing, reading width, font pairing. No other aspects commented on.

**`distill [target]`** — simplification audit. Single question: what can be removed without losing meaning? Flag every decorative element. Suggest a version with 30% fewer visual elements.

**`detect [target]`** — runs only the AI tells detector. Outputs present tells and judgment (deliberate vs default). No verdict, no critical issues, no aesthetic notes — just the detector output.

**`critique [target]`** — deep UX review: visual hierarchy, clarity, emotional resonance, user flow correctness. Output: Purpose → Does it achieve it? → Why/why not → Top 3 changes.

**`bolder [target]`** — amplify a design that reads too safe. Increase contrast between primary and secondary elements by one hierarchy step, make the most important element dramatically larger or more saturated, remove one hedging element (secondary CTA, explanatory sub-label, softening border-radius). Never on `form-wizard` or `dashboard`.

**`quieter [target]`** — tone down a design that reads too aggressive. Reduce the loudest 3 elements (demote one to near-invisible), increase whitespace 50% around the primary element, reduce accent color to one element type only.

**`colorize [target]`** — introduce strategic color where the design reads flat. Apply accent exclusively to the single highest-priority element. Every other element stays neutral. Never introduce a second accent color.

**`shape [target]`** — plan UX before implementation. Output: user goal → information hierarchy → component map → interaction model → what can be cut. Pre-build only.
