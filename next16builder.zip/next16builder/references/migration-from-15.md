# Migrating from Next.js 15 to 16

Use this when the user has an existing Next.js 15 project and wants to upgrade. For greenfield projects, do not read this — go back to `SKILL.md`.

## Step 0: Verify prerequisites

```bash
node --version           # >= 20.9.0
npx tsc --version        # >= 5.1.0
```

If either is too old, stop and tell the user — the upgrade will fail otherwise.

## Step 1: Run the codemod (do this BEFORE manual edits)

```bash
npx @next/codemod@canary upgrade latest
```

The codemod handles automatically:
- Updates `next.config` to move `experimental.turbopack` → top-level `turbopack`
- Migrates from `next lint` to ESLint CLI usage
- Renames `middleware.ts` → `proxy.ts` and `middleware` function → `proxy`
- Removes `unstable_` prefix from stabilized APIs (`cacheLife`, `cacheTag`)
- Removes `experimental_ppr` Route Segment Config from pages/layouts
- Migrates async dynamic APIs (params, searchParams, cookies, headers)

For async APIs specifically (the most error-prone migration), there is a dedicated codemod:

```bash
npx @next/codemod@canary next-async-request-api .
```

## Step 2: Bump packages

```bash
npm install next@latest react@latest react-dom@latest
npm install -D @types/react@latest @types/react-dom@latest typescript@latest
```

## Step 3: Generate type helpers

```bash
npx next typegen
```

This creates global `PageProps`, `LayoutProps`, `RouteContext` types you can use like `PageProps<'/blog/[slug]'>`.

## Step 4: Manual sweeps (codemod cannot catch everything)

### 4.1 Audit `next.config`

Remove these keys entirely if present:
- `serverRuntimeConfig`
- `publicRuntimeConfig`
- `eslint` (top-level block)
- `amp`
- `experimental.ppr`
- `experimental.dynamicIO`
- `experimental.useCache`
- `experimental.turbopack` (move to top-level `turbopack`)
- `devIndicators.appIsrStatus`
- `devIndicators.buildActivity`
- `devIndicators.buildActivityPosition`

Replace these:
- `images.domains: [...]` → `images.remotePatterns: [{ protocol, hostname }]`

Add these if you want PPR behavior:
- `cacheComponents: true`

### 4.2 Audit `package.json` scripts

Remove `--turbopack` from dev/build scripts (it's default now).
Remove `next lint` — replace with `eslint .` or `biome check`.

### 4.3 Audit `revalidateTag` calls

Every `revalidateTag('foo')` needs a second arg:
- `revalidateTag('foo', 'max')` — most common
- `revalidateTag('foo', 'hours')` / `'minutes'` / `'seconds'` for shorter lifetimes
- Or define a custom profile in `next.config`

If you want immediate read-your-writes (user form submission), use `updateTag('foo')` instead — it's a different function from `next/cache`, Server Action only.

### 4.4 Audit AMP

If `useAmp` from `next/amp` or `export const config = { amp: true }` appears anywhere, remove them. AMP is gone.

### 4.5 Audit parallel routes

For every `app/@slot/` directory, create `app/@slot/default.tsx`:

```tsx
export default function Default() {
  return null
}
```

Otherwise the build fails in v16.

### 4.6 Audit `next/legacy/image`

Replace every `import Image from 'next/legacy/image'` with `import Image from 'next/image'`. The legacy component will be removed in a future version.

### 4.7 Audit `getConfig()`

Search the codebase for `getConfig`. Every occurrence needs to become a direct `process.env.X` read (server) or `process.env.NEXT_PUBLIC_X` read (client).

## Step 5: Build and fix

```bash
npm run build
```

Common errors and their fixes are in the main SKILL.md section 12.

The most common one you will hit: **synchronous params access**. The codemod handles most but not all cases. If you see:

```
TypeError: Cannot destructure property 'X' of 'params' as it is a Promise
```

Find the page/layout/route file and add `async` to the function, add `await` to the params read.

## Step 6: Scroll behavior

If the user had `scroll-behavior: smooth` on `<html>` globally and relied on Next.js overriding it during navigation, add `data-scroll-behavior="smooth"` to the `<html>` element in `app/layout.tsx`:

```tsx
<html lang="en" data-scroll-behavior="smooth">
```

Without this attribute, v16 will no longer override smooth scrolling during route changes.

## Step 7: Test on staging

The Next.js 16 changes that most commonly break production:
1. Custom webpack plugins (Turbopack incompatibility)
2. Module federation (Turbopack does not support)
3. Legacy CSS-in-JS (Emotion v10-, styled-components v5-)
4. Sass `~` tilde imports (use bare specifiers or `turbopack.resolveAlias: { '~*': '*' }`)

Run a full smoke test on a preview deployment before promoting to production.

## Optional: Enable React Compiler

After the upgrade is stable, you can enable automatic memoization:

```bash
npm install -D babel-plugin-react-compiler
```

```ts
// next.config.ts
const nextConfig: NextConfig = {
  reactCompiler: true,
}
```

Expect slower build times — the compiler relies on Babel.
