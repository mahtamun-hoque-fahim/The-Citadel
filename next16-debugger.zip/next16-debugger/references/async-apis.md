# Async Request APIs — Exhaustive Reference

Every API in this list returns a Promise in Next.js 16 and must be awaited. This document exists because the surface is wider than most developers realize — it's not just `cookies()` and `params`.

## Full list of async APIs

### From `next/headers`
- `cookies()` → `Promise<ReadonlyRequestCookies>`
- `headers()` → `Promise<ReadonlyHeaders>`
- `draftMode()` → `Promise<DraftMode>`

### From file-convention props
- `params` in `page.tsx`, `layout.tsx`, `route.ts`, `default.tsx` → `Promise<{ ... }>`
- `searchParams` in `page.tsx` → `Promise<Record<string, string | string[] | undefined>>`
- `params` in `generateMetadata` → `Promise<{ ... }>`
- `params` in `opengraph-image.tsx`, `twitter-image.tsx`, `icon.tsx`, `apple-icon.tsx` → `Promise<{ ... }>`
- `id` argument in image generation functions when `generateImageMetadata` is used → `Promise<string>`
- `id` argument in `sitemap.tsx` when `generateSitemaps` is used → `Promise<string>`

### Note on `generateImageMetadata` and `generateSitemaps` themselves
The metadata-generating functions still receive **synchronous** `params`. Only the image/sitemap function they're paired with receives async `params` and `id`. This asymmetry trips people up.

## Before / after patterns

### Page component with params

```tsx
// Before (Next 14/15)
export default function Page({ params }: { params: { slug: string } }) {
  return <h1>{params.slug}</h1>
}

// After (Next 16) — with manual types
export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  return <h1>{slug}</h1>
}

// After (Next 16) — with typegen helper
export default async function Page(props: PageProps<'/blog/[slug]'>) {
  const { slug } = await props.params
  return <h1>{slug}</h1>
}
```

### Layout with params

```tsx
// After (Next 16)
export default async function Layout(props: LayoutProps<'/[locale]'>) {
  const { locale } = await props.params
  return <div lang={locale}>{props.children}</div>
}
```

### Route handler

```ts
// Before
export async function GET(req: Request, { params }: { params: { id: string } }) {
  return Response.json({ id: params.id })
}

// After (Next 16)
export async function GET(_req: Request, ctx: RouteContext<'/api/items/[id]'>) {
  const { id } = await ctx.params
  return Response.json({ id })
}
```

### Page with searchParams

```tsx
// Before
export default function Page({ searchParams }: { searchParams: { q?: string } }) {
  return <p>Searching for {searchParams.q ?? 'nothing'}</p>
}

// After
export default async function Page(props: PageProps<'/search'>) {
  const { q } = await props.searchParams
  return <p>Searching for {q ?? 'nothing'}</p>
}
```

### generateMetadata with async params

```tsx
// After
export async function generateMetadata(
  props: PageProps<'/blog/[slug]'>
): Promise<Metadata> {
  const { slug } = await props.params
  const post = await getPost(slug)
  return { title: post.title }
}
```

### opengraph-image with async params and id

```tsx
// app/shop/[slug]/opengraph-image.tsx

// generateImageMetadata still gets SYNC params
export function generateImageMetadata({ params }: { params: { slug: string } }) {
  return [{ id: 'square' }, { id: 'wide' }]
}

// The Image function gets ASYNC params AND async id
export default async function Image({
  params,
  id,
}: {
  params: Promise<{ slug: string }>
  id: Promise<string>
}) {
  const { slug } = await params
  const imageId = await id
  // ... render image
}
```

### sitemap with async id

```ts
// app/product/sitemap.ts
export async function generateSitemaps() {
  return [{ id: 0 }, { id: 1 }, { id: 2 }]
}

export default async function sitemap({ id }: { id: Promise<string> }) {
  const resolvedId = await id
  const start = Number(resolvedId) * 50000
  // ... return entries
}
```

### Cookies in a Server Action

```ts
'use server'
export async function setTheme(theme: 'light' | 'dark') {
  const cookieStore = await cookies()
  cookieStore.set('theme', theme)
}
```

### Headers in a Server Component

```tsx
async function UserAgentBanner() {
  const h = await headers()
  const ua = h.get('user-agent')
  return <p>You're on {ua}</p>
}
```

## Pitfalls and how to spot them

### Pitfall 1: Passing the Promise around

```ts
// Wrong — passes a Promise as if it were the resolved value
async function getUser(c: ReadonlyRequestCookies) { /* ... */ }
export default async function Page() {
  const user = await getUser(cookies()) // type error: ReadonlyRequestCookies vs Promise<...>
}

// Right — resolve first, then pass
export default async function Page() {
  const c = await cookies()
  const user = await getUser(c)
}
```

### Pitfall 2: Spreading or iterating

```ts
// All of these count as sync access and will throw
const allCookies = { ...cookies() }
const cookieNames = Object.keys(cookies())
for (const cookie of cookies()) { /* ... */ }
const cookieList = [...headers()]

// Right
const c = await cookies()
const allCookies = { ...c }
// etc.
```

### Pitfall 3: Calling inside a timer

```ts
// Wrong — async context is lost by the time the callback runs
setTimeout(async () => {
  const c = await cookies() // DynamicServerError
}, 100)

// Right — read first, defer second
const c = await cookies()
setTimeout(() => {
  // use c here
}, 100)
```

### Pitfall 4: Calling after an unawaited promise

```ts
// Wrong — the awaited callback runs after the request context closes
async function GET() {
  someAsyncWorkWithoutAwait() // detached
  const c = await cookies() // may throw if context already torn down
}

// Right — await everything in order
async function GET() {
  await someAsyncWork()
  const c = await cookies()
}
```

### Pitfall 5: Treating `params` like a sync object inside a Promise chain

```tsx
// Wrong
export default async function Page(props: PageProps<'/[slug]'>) {
  return props.params.then(p => <h1>{p.slug}</h1>) // returning a Promise as JSX
}

// Right
export default async function Page(props: PageProps<'/[slug]'>) {
  const { slug } = await props.params
  return <h1>{slug}</h1>
}
```

## Codemod coverage

The official codemod fixes about 90% of these patterns:

```bash
npx @next/codemod@canary next-async-request-api .
```

Look for `@next-codemod-error` markers in the codebase after running — those flag spots the codemod couldn't transform automatically. They need manual review.

## Type generation

`npx next typegen` is required. It produces global types:
- `PageProps<RoutePath>`
- `LayoutProps<RoutePath>`
- `RouteContext<RoutePath>`

These give type-safe access to params for the route at `RoutePath`. They were introduced in 15.5 and are the canonical type pattern in 16.
