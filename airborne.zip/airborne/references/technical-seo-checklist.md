# Technical SEO Checklist

The layer that determines whether Google can crawl, index, and rank the content at all. This file is organized so Airborne can produce ready-to-commit files (robots.txt, sitemap, headers) and stack-specific performance recommendations.

**For Next.js 14/15/16 syntax differences (especially `generateMetadata` and async `params`), read `references/nextjs-versions.md`.** This file covers the framework-agnostic technical SEO layer; the version file covers the syntax variations.

---

## The Indexability Floor

Before anything else, verify the site can be indexed. Common bugs:

- [ ] No `<meta name="robots" content="noindex">` left over from staging
- [ ] `X-Robots-Tag: noindex` not set at the server / CDN level
- [ ] `robots.txt` is not blocking `/` or core paths
- [ ] Site is reachable on both `www` and apex (one redirects to the other; pick a canonical)
- [ ] HTTPS works and HTTP redirects to HTTPS with a 301
- [ ] No infinite redirect loops
- [ ] Sitemap is submitted to Google Search Console
- [ ] Domain is verified in Google Search Console

---

## robots.txt — Template

Most sites need something close to this. Customize the disallow paths.

```
# robots.txt for learnde.com

User-agent: *
Allow: /

# Block staging, admin, and internal API routes
Disallow: /admin/
Disallow: /api/
Disallow: /staff/
Disallow: /_next/
Disallow: /studio/

# Allow crawling of sitemap-referenced media
Allow: /api/og/

# Sitemap
Sitemap: https://learnde.com/sitemap.xml
```

Special cases:

- **Next.js App Router:** also exists as `app/robots.ts` — programmatic version, useful when paths are computed.

```ts
// app/robots.ts
import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      { userAgent: "*", allow: "/", disallow: ["/admin/", "/api/", "/staff/"] },
    ],
    sitemap: "https://learnde.com/sitemap.xml",
  };
}
```

- **Block AI crawlers if desired:** add `User-agent: GPTBot` / `User-agent: CCBot` / `User-agent: ClaudeBot` blocks. This is a policy decision — surface it to the user, don't decide silently.

---

## sitemap.xml — Template

### Static XML version

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://learnde.com/</loc>
    <lastmod>2026-05-23</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>https://learnde.com/exams/delf-b2</loc>
    <lastmod>2026-05-20</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>
</urlset>
```

### Next.js App Router version

> Same syntax works on Next.js 14, 15, and 16. The sitemap convention is stable across versions.

```ts
// app/sitemap.ts
import type { MetadataRoute } from "next";
import { getAllPosts, getAllExams } from "@/lib/content";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = "https://learnde.com";
  const posts = await getAllPosts();
  const exams = await getAllExams();

  const staticPages: MetadataRoute.Sitemap = [
    { url: baseUrl, lastModified: new Date(), changeFrequency: "weekly", priority: 1.0 },
    { url: `${baseUrl}/about`, lastModified: new Date(), changeFrequency: "monthly", priority: 0.6 },
    { url: `${baseUrl}/pricing`, lastModified: new Date(), changeFrequency: "monthly", priority: 0.8 },
  ];

  const dynamicPages: MetadataRoute.Sitemap = [
    ...posts.map((p) => ({
      url: `${baseUrl}/blog/${p.slug}`,
      lastModified: p.updatedAt,
      changeFrequency: "monthly" as const,
      priority: 0.7,
    })),
    ...exams.map((e) => ({
      url: `${baseUrl}/exams/${e.slug}`,
      lastModified: e.updatedAt,
      changeFrequency: "monthly" as const,
      priority: 0.8,
    })),
  ];

  return [...staticPages, ...dynamicPages];
}
```

### Sitemap rules

- One sitemap per 50,000 URLs / 50 MB. Beyond that, use a sitemap index.
- Only include canonical, indexable URLs. Don't list pages with `noindex`.
- `lastmod` should reflect real content changes, not deploy timestamps.
- Submit the sitemap URL in Google Search Console and Bing Webmaster Tools.

---

## Canonical Tags

Every page should declare a canonical URL. In Next.js App Router:

```tsx
// Works on Next.js 14, 15, and 16
// For dynamic routes with params, see references/nextjs-versions.md for the version-specific async params syntax
export async function generateMetadata(): Promise<Metadata> {
  return {
    alternates: {
      canonical: "https://learnde.com/exams/delf-b2",
    },
  };
}
```

### Canonical decision rules

| Scenario | Canonical points to |
|---|---|
| Same content on `?ref=twitter` URLs | The base URL without query params |
| Paginated list (`/blog?page=2`) | The first page (`/blog`) OR self-canonical with `rel="prev/next"` deprecated, prefer self |
| `www` vs apex | Whichever the brand uses; the other 301-redirects |
| Trailing slash variants | Pick one, redirect the other |
| Print version, AMP, mobile-specific URL | Canonical points to the standard version |
| Cross-posted content | Canonical points to the original publisher |

---

## Open Graph + Twitter Card Meta

Every page needs a social meta block. Next.js App Router pattern:

```tsx
// Static metadata export — works on Next 14/15/16 identically.
// For dynamic params (e.g. /blog/[slug]), use generateMetadata with version-specific async params syntax — see references/nextjs-versions.md.
export const metadata: Metadata = {
  title: "DELF B2 Practice Tests — Built by Native Tutors | LearnDE",
  description: "Free DELF B2 mock exams with tutor feedback. Start without a card.",
  openGraph: {
    title: "DELF B2 Practice Tests — Built by Native Tutors",
    description: "Free DELF B2 mock exams with tutor feedback. Start without a card.",
    url: "https://learnde.com/exams/delf-b2",
    siteName: "LearnDE",
    images: [{ url: "https://learnde.com/og/delf-b2.png", width: 1200, height: 630 }],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "DELF B2 Practice Tests — Built by Native Tutors",
    description: "Free DELF B2 mock exams with tutor feedback. Start without a card.",
    images: ["https://learnde.com/og/delf-b2.png"],
    creator: "@learnde",
  },
};
```

### OG image rules

- **Dimensions:** 1200 × 630 px (1.91:1 ratio)
- **File size:** under 1 MB, ideally under 300 KB
- **Format:** PNG or JPG. Use Next.js dynamic OG generation (`app/og/route.tsx`) for per-page images.
- **Text:** large, readable at thumbnail size. Brand mark in a corner.

---

## Core Web Vitals — Stack-Specific Levers

Google's three Core Web Vitals targets (good thresholds):

| Metric | Target | What it measures |
|---|---|---|
| LCP (Largest Contentful Paint) | < 2.5s | When the main content renders |
| INP (Interaction to Next Paint) | < 200ms | How fast the page responds to clicks/taps |
| CLS (Cumulative Layout Shift) | < 0.1 | How much the layout shifts after load |

### Next.js (App Router, Vercel)

LCP levers (all versions):
- Use `next/image` for the hero image with `priority` and explicit `sizes`
- Use Server Components by default; client components only where interactive
- Preload critical fonts with `next/font/local` or `next/font/google` and `display: "swap"`
- Set `Cache-Control` headers on static assets (Vercel does this by default for `/_next/static/`)

LCP levers — version-specific caching:
- **Next 14:** `fetch()` is cached by default. Use `revalidate` option for ISR on marketing pages.
- **Next 15:** `fetch()` is **not** cached by default. Add `cache: "force-cache"` or `next: { revalidate: N }` explicitly on data fetches for marketing pages, or LCP will suffer from repeated origin hits.
- **Next 16:** Use **Cache Components** (`'use cache'` directive) for static-ish SEO pages. Set `cacheComponents: true` in `next.config.ts`. This gives static performance with dynamic flexibility.

INP levers (all versions):
- Split heavy client bundles with dynamic imports (`next/dynamic`)
- Move analytics scripts to `next/script` with `strategy="afterInteractive"` or `"lazyOnload"`
- Avoid hydrating large client trees — push to Server Components where possible
- **Next 16:** React Compiler (opt-in via `reactCompiler: true` in `next.config.ts`) auto-memoizes components — reduces unnecessary re-renders and improves INP

CLS levers (all versions):
- Set explicit `width` and `height` on all images and embeds
- Reserve space for ads, banners, cookie consent before they load
- Avoid injecting content above existing content after load

Build performance (affects deployment speed, not Core Web Vitals directly):
- **Next 16:** Turbopack is the default bundler — no flag needed. ~2.5x faster production builds than webpack.

### Cloudflare Pages

- Enable Brotli and Auto Minify in dashboard
- Use Cloudflare Workers for edge logic instead of origin round-trips
- Set Cache Rules to long-cache static assets (`/_next/static/*`, `/images/*`)
- For Next.js on Cloudflare, route the entire app through `@cloudflare/next-on-pages` and verify Edge Runtime compatibility per route
- Use the `_headers` file for fine-grained header control

### Plain React SPA (Vite, CRA)

- Prerender critical routes — SPA + no prerender means Google sees a mostly empty `<body>`. Use `vite-plugin-ssr`, `prerender.io`, or migrate to a meta-framework.
- If prerender is not feasible, at minimum render the meta title, description, and H1 in the initial HTML.

---

## URL Structure Rules

- **Lowercase.** `/Blog/My-Post` and `/blog/my-post` are different URLs to crawlers.
- **Hyphenated, not underscored.** Hyphens are word separators; underscores are not.
- **Short.** Under 60 characters where possible.
- **Hierarchical, not flat.** `/exams/delf/b2` beats `/delf-b2-exam`.
- **No file extensions.** `/about`, not `/about.html`.
- **No session IDs or tracking params in canonical URLs.** Use UTM in marketing links, but the canonical version is param-free.
- **No duplicate URLs with trailing slash differences.** Pick one (`/blog/post` or `/blog/post/`) and 301 the other.

---

## Headers and HTTPS

- HSTS header for HTTPS-only browsers: `Strict-Transport-Security: max-age=31536000; includeSubDomains; preload`
- Content Security Policy for security (does not directly affect SEO but reduces hijack risk)
- `X-Robots-Tag` header for non-HTML files (PDFs, etc.) — set `noindex` if those shouldn't rank

---

## The Full Pre-Launch Audit Checklist

Before declaring SEO done, walk this list:

- [ ] Each page has a unique meta title (50–60 chars)
- [ ] Each page has a unique meta description (150–160 chars)
- [ ] Each page has exactly one H1
- [ ] H2/H3 hierarchy is logical (no H3 without an H2 above it)
- [ ] Every image has `alt` text (or `alt=""` if decorative)
- [ ] All internal links use descriptive anchor text
- [ ] Canonical tag is set on every page
- [ ] Open Graph + Twitter Card meta on every page
- [ ] JSON-LD schema on every page (at minimum: `WebSite` + appropriate type)
- [ ] `robots.txt` exists and references the sitemap
- [ ] `sitemap.xml` exists and includes all indexable URLs
- [ ] Sitemap submitted to Google Search Console
- [ ] Site verified in Google Search Console + Bing Webmaster
- [ ] LCP < 2.5s, INP < 200ms, CLS < 0.1 on PageSpeed Insights
- [ ] No console errors on load
- [ ] Mobile-friendly test passes
- [ ] HTTPS with valid certificate
- [ ] No `noindex` left from staging
- [ ] Schema validates with no errors on the Rich Results Test
