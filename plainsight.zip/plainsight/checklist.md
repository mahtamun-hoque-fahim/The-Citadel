# Checklist

Two modes. Run the relevant set before declaring a task done.

## BUILD checklist — before saying "done"

When generating new code from `patterns/`.

### Structure

- [ ] Every `<section>` has an inner container `<div className="mx-auto max-w-* px-*">` — not collapsed
- [ ] Horizontal padding declared at the breakpoints used (`px-4 sm:px-6 lg:px-8`)
- [ ] Vertical rhythm via `py-*` on the section, not margins on children
- [ ] Each section has a sensible `max-w-*` for its purpose (7xl for marketing, 4xl for reading, etc.)

### Centering

- [ ] Block-level centered elements have BOTH `mx-auto` AND a `max-w-*`
- [ ] Text-wrap centering uses `text-center` on a width-bounded parent
- [ ] No paragraph with `max-w-*` and missing `mx-auto`
- [ ] If using `flex flex-col items-center`, children don't need `mx-auto` but multi-line text still needs `text-center`

### Hero

- [ ] Height is `min-h-[calc(100svh-Xrem)]` matching the header height
- [ ] Uses `svh` or `dvh`, never `vh`
- [ ] CTA buttons live inside their own `<div className="flex flex-col sm:flex-row gap-* ...">` wrapper
- [ ] Buttons NOT direct siblings of the subtitle `<p>`
- [ ] Any visual/mockup is in its own block with explicit `mt-*`, not a sibling of the buttons

### Grids

- [ ] Responsive columns at every breakpoint: `grid-cols-1 sm:grid-cols-2 lg:grid-cols-4`
- [ ] Parent of the grid is NOT `flex flex-col items-center` without a width
- [ ] Spacing via `gap-*`, not margins between siblings
- [ ] Card heights match in a row: `h-full` on cards, `flex flex-col` for footer pin

### Marquee

- [ ] Container has `overflow-hidden`
- [ ] Track has `flex w-max`
- [ ] Each item has `whitespace-nowrap`
- [ ] Content rendered N times in source
- [ ] Animation translates by exactly `-100/N %`
- [ ] Keyframes in `globals.css` matching Tailwind version

### Navigation

- [ ] Sticky navbar has `z-40` (or appropriate); modals will be `z-50`
- [ ] No `overflow-*` on ancestors of sticky elements
- [ ] Mobile drawer locks body scroll while open
- [ ] Drawer closes on Escape key
- [ ] Drawer backdrop is a separate element from the panel (so panel clicks don't dismiss)
- [ ] Dropdowns inside `overflow-hidden` cards use a portal-based library or are restructured

### Forms

- [ ] Every `<label>` has `htmlFor` matching an `<input>` `id`
- [ ] `autoComplete` attributes set correctly
- [ ] `focus:outline-none` is paired with `focus:ring-2 ...` (never remove focus without replacement)
- [ ] Cancel/secondary buttons have `type="button"`
- [ ] Submit buttons declare `type="submit"` (optional but clear)
- [ ] Action bar uses `flex-col-reverse sm:flex-row` so primary stacks on top on mobile
- [ ] Error state uses `aria-invalid` and `aria-describedby` for accessibility

### Modals / dialogs

- [ ] Backdrop is `fixed inset-0 z-50`
- [ ] Body scroll locked while open
- [ ] Escape key closes
- [ ] Backdrop click closes (and is a separate element from the panel)
- [ ] `role="dialog"` and `aria-modal="true"` on the dialog
- [ ] Focus trap implemented (or using Radix/Headless UI)

### Tables and data

- [ ] Tables wrapped in `overflow-x-auto` for mobile
- [ ] `min-w-[Npx]` on table to prevent column squish
- [ ] Sticky `<thead>` has a solid `bg-*` background
- [ ] Long text fields have `truncate` AND parent has `min-w-0`
- [ ] Side elements (avatars, badges, actions) have `shrink-0`

### Text overflow

- [ ] Any flex child with potentially long text has `min-w-0`
- [ ] Truncation applied via `truncate` (single line) or `line-clamp-N` (multi line)
- [ ] Code blocks use `overflow-x-auto` on `<pre>`

### Next.js component model

- [ ] `"use client"` only on files that need it (state, effects, event handlers, refs, browser APIs)
- [ ] No `useState` / `useEffect` / `onClick` in a file without `"use client"`
- [ ] No bare `window` / `localStorage` / `document` outside `useEffect` in client components
- [ ] `params` and `searchParams` typed as `Promise<...>` and awaited (Next 15+)
- [ ] `cookies()` and `headers()` from `next/headers` are awaited
- [ ] Fonts loaded via `next/font` in root layout, applied via CSS variable
- [ ] `globals.css` imported in `app/layout.tsx`
- [ ] Error boundary (`error.tsx`) is a `"use client"` component
- [ ] `loading.tsx` exists for slow routes

### Tailwind version sanity

- [ ] Checked `package.json` to confirm v3 or v4
- [ ] `globals.css` directives match (`@import "tailwindcss"` for v4, three `@tailwind` lines for v3)
- [ ] Custom tokens in `@theme {}` (v4) or `tailwind.config.ts` (v3)
- [ ] PostCSS config matches the version

### Hydration safety

- [ ] No `Math.random()` or `Date.now()` in render bodies of components rendering on both server and client
- [ ] No `localStorage` / `window` reads outside `useEffect` in client components
- [ ] `<html>` or `<body>` modified by browser extensions has `suppressHydrationWarning` on that tag only
- [ ] Server and client render the same content for the same input
- [ ] Locale-dependent formatting (dates, numbers, currencies) handled consistently

### Accessibility

- [ ] Every interactive icon-only button has `aria-label`
- [ ] Form fields have associated labels
- [ ] Active nav items have `aria-current="page"`
- [ ] Focus rings visible on all interactive elements
- [ ] Tab order follows visual order (no `tabindex > 0`)
- [ ] Color contrast meets WCAG AA (use `text-neutral-400` minimum on dark backgrounds)
- [ ] Status changes announced via `role="alert"` or `aria-live`

### Project conventions

- [ ] Color palette matches project (not hardcoded `neutral`/`violet` if project uses different)
- [ ] Component library used consistently (shadcn Button, not hand-rolled, if shadcn is in the project)
- [ ] Icon library matches what the project already uses
- [ ] Class organization matches file conventions (`clsx`/`cn` vs. inline strings)
- [ ] No emojis anywhere — UI text, code, comments, commit messages

### Mental render

- [ ] Imagined the rendered output at 375px, 768px, 1280px, 1920px
- [ ] Confirmed no element relies on `mx-auto` without `max-w-*` (or vice versa)
- [ ] Confirmed no button is a direct sibling of a `<p>` without a flex wrapper
- [ ] Confirmed sticky elements have no `overflow-*` ancestors

---

## FIX checklist — before saying "fixed"

When patching an existing broken layout.

### Diagnosis

- [ ] Symptom described in one sentence
- [ ] Symptom matched against `symptoms.md` to confirm cause
- [ ] Read the relevant existing code to verify the cause
- [ ] Identified the minimum-viable patch level (add class / change class / wrap / restructure / replace)

### Patch quality

- [ ] Change is the smallest possible to solve the symptom
- [ ] No unrelated improvements bundled in
- [ ] Project conventions preserved (color palette, component library, class style)
- [ ] No new dependencies introduced
- [ ] No `"use client"` added unless absolutely required by the fix
- [ ] Existing accessibility features preserved (focus management, ARIA, semantic tags)

### Verification

- [ ] Mentally walked through the new render — symptom gone
- [ ] No new symptom introduced (re-scan against the twelve failure modes)
- [ ] Adjacent components / sections still work (the patch didn't break a neighbor)
- [ ] If the fix surfaced a hidden second bug, acknowledged it and offered options

### Communication

- [ ] Named the bug in plain language
- [ ] Showed the before/after of just the changed lines
- [ ] Briefly stated the rule (one sentence)
- [ ] Did NOT rewrite the entire component
- [ ] Did NOT lecture about unrelated improvements
- [ ] Stopped after the fix

---

## Universal final step

Before declaring anything done (build or fix), read the JSX top to bottom once at the section level. Ask:

- Where does each heading sit horizontally? (center / left / right)
- Where do subtitles, buttons, and visuals sit relative to it?
- Does anything that should be centered have BOTH `mx-auto` AND a width constraint?
- Are button groups inside a flex wrapper, or bare siblings of a paragraph?
- Do sticky elements have any `overflow-*` ancestors?
- Does any flex child with long text have `min-w-0`?
- Do any modals/dropdowns inside `overflow-hidden` cards portal out to `<body>`?

If you can answer all of those without re-reading the JSX twice, the layout is robust. If not, refactor until it is obvious.
