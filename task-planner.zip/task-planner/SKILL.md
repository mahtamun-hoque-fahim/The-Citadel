---
name: task-planner
description: >
  Reads PLANNER.md and scans the existing codebase to generate a precise,
  atomic execution plan — exact files to create or edit, 2–5 minute tasks,
  one verification step per task, dependencies resolved in order. Bridges
  the gap between architecture spec and what to actually type next. Always
  runs in retrofit mode: scans what already exists first, generates only
  the remaining delta so you never re-do completed work. ALWAYS use when
  Fahim says "task-planner", "task plan", "what should I build next", "break
  this down into tasks", "atomic tasks", "plan the session", "generate tasks
  from PLANNER", "what's left to build", "next steps", or whenever a
  PLANNER.md exists and the next development steps need to be clarified. Use
  proactively at the START of every build session — before writing any code.
---

# Task Planner

Turns a PLANNER.md into a session-ready execution checklist.

Every task is scoped to 2–5 minutes, names exact file paths, and includes a
verification step you can run immediately. Tasks are ordered so prerequisites
come first — no guessing what to do next.

**Position in Fahim's pipeline:**
```
BRAIN.md + PLANNER.md → task-planner → build session
                          (always before touching code)
```

---

## Phase 0 — Retrofit Scan (always runs first)

Never assume a blank slate. Real projects always have partial work.

Run this scan before generating any tasks:

```bash
# 1. Read the spec
cat BRAIN.md 2>/dev/null || echo "No BRAIN.md"
cat PLANNER.md

# 2. Check Next.js version (governs which builder skill applies)
cat package.json | grep '"next"'

# 3. Map what's actually implemented
find app/ -type f \( -name "*.tsx" -o -name "*.ts" \) | sort
find src/ -type f \( -name "*.tsx" -o -name "*.ts" \) 2>/dev/null | sort
find db/ -type f 2>/dev/null | sort
find lib/ -type f 2>/dev/null | sort

# 4. Confirm env setup exists
ls .env.local .env.example 2>/dev/null
```

After scanning, build the **delta** — tasks for everything in PLANNER.md that
the codebase does not yet implement. Completed phases (marked `[x]`) are skipped
unless you find a mismatch between what the spec says and what the code does.

### Scan summary format

Print this before generating tasks:

```
TASK PLANNER — [Project] — [date]
──────────────────────────────────
SPEC : BRAIN.md [found/missing] | PLANNER.md [found/missing]
STACK: Next.js [version] | [auth lib] | [DB lib]
PHASES: N total — N done [x] — N in progress [~] — N pending [ ]
SCOPE: N routes found | N DB tables found | N env vars confirmed
──────────────────────────────────
Generating tasks for: Phase X, Phase Y, ...
```

---

## Phase 1 — Extract Work from PLANNER.md and SITETREE.md

Read these PLANNER.md sections in order to source tasks:

| Section | What to generate |
|---|---|
| Timeline / Phases | One task group per `[~]` or `[ ]` phase |
| DB Schema | One task per table not yet in `db/schema.ts` |
| API Routes | One task per `route.ts` file missing from `app/api/` |
| `SITETREE.md` (if present) | One task per row whose Status is still `planned` — this is the authoritative page list, more precise than inferring pages from prose. Falls back to "User Flows" below only if SITETREE.md doesn't exist |
| User Flows | Fallback only: one task per page/layout that enforces auth but doesn't exist yet, used when no `SITETREE.md` exists for this project |
| Env Vars | One setup task if `.env.local` is missing required vars |
| Next Steps | Treat as supplemental — cross-reference against the above |

---

## Phase 2 — Task Generation Rules

### Time-bounding
Tasks must fit **2–5 minutes** of focused work. If a natural unit of work
is larger, split it. Good splits:

| Too big (10+ min) | Split into |
|---|---|
| "Wire up auth" | TASK: create `lib/auth.ts` · TASK: create `app/api/auth/[...all]/route.ts` · TASK: add session guard to `/dashboard` |
| "Build dashboard" | TASK: scaffold `app/dashboard/page.tsx` · TASK: add data fetch from DB · TASK: wire up stat cards |
| "Create DB schema" | One task per table if schema has 3+ tables |

### File specificity
Always name the exact file path. Never write "create the auth file" — write
`lib/auth.ts`. When multiple files are touched in one task, list them all.

### Verification step
Every task needs a concrete verification — something Fahim can run or observe:

| Type | Example |
|---|---|
| Build check | `npm run build` exits 0 |
| Type check | `npx tsc --noEmit` no errors |
| DB check | `npx drizzle-kit push` exits 0; table visible in Neon |
| Route check | `curl http://localhost:3000/api/health` returns 200 |
| UI check | Page renders at `localhost:3000/[route]` without error |
| Auth check | Unauthenticated GET to `/dashboard` redirects to `/sign-in` |
| Import check | Component imported in a parent file compiles without TS error |

### Dependency ordering
List tasks in dependency order. If TASK-003 depends on TASK-001 and TASK-002,
it appears after them. Use the `Needs` field to make the dependency explicit.
A task with `Needs: —` can be started at any time (good for parallelism).

---

## Phase 3 — Deliverable

Output two sections: **Sprint Board** (at a glance) followed by **Task Detail**
(full breakdown).

---

### Sprint Board

One row per task. Print this first so Fahim can see the full session scope.

```
SPRINT BOARD — [Project] — [Phase(s)] — est. N min
═══════════════════════════════════════════════════════════════════════
ID        Title                                    Files              Time  Needs
───────────────────────────────────────────────────────────────────────
TASK-001  [title]                                  [file]             3 min  —
TASK-002  [title]                                  [file]             5 min  —
TASK-003  [title]                                  [file]             4 min  001
...
═══════════════════════════════════════════════════════════════════════
Total: N tasks — est. N min
```

---

### Task Detail

Full card per task, in the same order as the sprint board.

```
┌─ TASK-001 ──────────────────────────────────────────────────────────┐
│  [Short imperative title]                           Phase: [name]   │
│  Files    : [exact path(s)]                         Time : N min    │
│  Needs    : TASK-XXX, TASK-XXX  (or "—")                            │
├─────────────────────────────────────────────────────────────────────┤
│  Do       : [One concrete action. What to create, change, or wire.] │
│  Verify   : [Exact command or observable check. Pass = done.]       │
└─────────────────────────────────────────────────────────────────────┘

┌─ TASK-002 ──────────────────────────────────────────────────────────┐
│  ...                                                                │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Scope and Modes

### Retrofit mode (default)

Retrofit mode fires whenever a project already has some code. It:
- Skips tasks for any file that exists and implements what PLANNER.md describes
- Generates tasks only for the delta (missing files, unwired routes, partial phases)
- Marks in-progress phases (`[~]`) with a scan-confirmed status before generating

If a file exists but deviates from the spec (e.g. a route exists but doesn't
enforce auth when PLANNER.md says it must), generate a **fix task** rather than
skipping it.

Fix task format:
```
┌─ TASK-007 [FIX] ────────────────────────────────────────────────────┐
│  Add server-side auth guard to /dashboard/page.tsx   Phase: Auth    │
│  Files    : app/dashboard/page.tsx                   Time : 3 min   │
│  Needs    : TASK-003                                                 │
├─────────────────────────────────────────────────────────────────────┤
│  Do       : Call `auth()` at the top of the page component and      │
│             redirect to /sign-in if session is null.                │
│  Verify   : unauthenticated GET to /dashboard → 302 to /sign-in     │
└─────────────────────────────────────────────────────────────────────┘
```

### Fresh mode

Fires when no `app/` or `src/` directory exists yet (brand-new project, repo
just scaffolded). Skip the scan entirely and generate a complete build sequence
from PLANNER.md from scratch. Group tasks by phase in PLANNER order.

Fresh mode auto-inserts these mandatory setup tasks at the top of the list if
PLANNER.md doesn't already account for them:

| ID | Task | Files | Time |
|---|---|---|---|
| TASK-001 | Scaffold project with `create-next-app` | — | 2 min |
| TASK-002 | Install core dependencies | `package.json` | 3 min |
| TASK-003 | Configure Tailwind and globals | `tailwind.config.ts`, `globals.css` | 4 min |
| TASK-004 | Set up environment variables | `.env.local`, `.env.example` | 2 min |
| TASK-005 | Create Neon DB + push Drizzle schema | `db/schema.ts`, `db/index.ts` | 5 min |

---

## Relationship to other skills

| Skill | When to use it relative to task-planner |
|---|---|
| **singularity** | Before task-planner — fetch brain first if context feels lost |
| **tree-man** | Before task-planner, at project start — writes SITETREE.md, the authoritative page list task-planner sources page tasks from |
| **repo-maintainer** | After task-planner output is reviewed — if PLANNER.md is stale, update it first |
| **next15builder / next16builder** | During execution — open in parallel with task-planner output for pattern reference |
| **valley-of-death** | After build session — confirms task-planner's delta was fully resolved |
| **plainsight** | During execution — handles UI layout tasks that task-planner identifies |

---

## Operating Rules

- **Scan before generating.** Never skip Phase 0. A task generated for a file
  that already exists wastes Fahim's time.
- **Exact file paths.** Ambiguous paths fail. If PLANNER.md says "create the
  auth config" — derive the correct path from the codebase scan, not from
  imagination.
- **2–5 min ceiling is hard.** If you cannot fit a task into 5 minutes, split
  it. Two focused tasks beat one vague big one every time.
- **Verification is not optional.** Every task must have a check Fahim can run
  immediately. "It looks right" is not a verification.
- **Fix tasks are real tasks.** A spec mismatch found during the scan is as
  important as a missing file. Flag it explicitly with `[FIX]` in the task ID.
- **Don't generate tasks for locked stack choices.** If BRAIN.md says
  `[LOCKED] No Google OAuth`, do not generate a task for Google OAuth even if
  PLANNER.md's User Flows mention social login from a previous draft.
- **Ask before generating for ambiguous phases.** If a phase in PLANNER.md has
  no implementation details (e.g. "Phase 4: Polish" with no route list), ask
  Fahim to clarify rather than generating vague tasks.
