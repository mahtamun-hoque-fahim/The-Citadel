# Data display

Tables, lists, cards, stat tiles, badges, avatars, pagination, empty states.

## Table — responsive

Tables are the source of most "blowout on mobile" bugs. The fix is always: wrap in an `overflow-x-auto` container.

```tsx
<div className="overflow-x-auto rounded-lg border border-neutral-800">
  <table className="w-full min-w-[640px] text-sm">
    <thead className="bg-neutral-900/50 text-left text-xs uppercase tracking-wider text-neutral-400">
      <tr>
        <th scope="col" className="px-4 py-3 font-medium">Name</th>
        <th scope="col" className="px-4 py-3 font-medium">Email</th>
        <th scope="col" className="px-4 py-3 font-medium">Role</th>
        <th scope="col" className="px-4 py-3 font-medium">Status</th>
        <th scope="col" className="relative px-4 py-3"><span className="sr-only">Actions</span></th>
      </tr>
    </thead>
    <tbody className="divide-y divide-neutral-800">
      {rows.map((row) => (
        <tr key={row.id} className="hover:bg-neutral-900/30">
          <td className="px-4 py-3 font-medium">{row.name}</td>
          <td className="px-4 py-3 text-neutral-400">{row.email}</td>
          <td className="px-4 py-3 text-neutral-400">{row.role}</td>
          <td className="px-4 py-3">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-green-500/10 px-2 py-0.5 text-xs font-medium text-green-400">
              <span className="size-1.5 rounded-full bg-green-400" />
              Active
            </span>
          </td>
          <td className="px-4 py-3 text-right">
            <button className="text-sm text-neutral-400 hover:text-white">Edit</button>
          </td>
        </tr>
      ))}
    </tbody>
  </table>
</div>
```

Critical bits:
- `overflow-x-auto` on the wrapper. Mobile users scroll horizontally.
- `min-w-[640px]` on the table forces it wider than the smallest viewport — without this, columns squash into illegible chunks at narrow widths.
- `divide-y divide-neutral-800` for row borders. Cleaner than per-row `border-b`.
- `scope="col"` on header cells, `scope="row"` if you have row headers — accessibility.

## Table — sticky header

```tsx
<div className="max-h-96 overflow-auto rounded-lg border border-neutral-800">
  <table className="w-full text-sm">
    <thead className="sticky top-0 bg-neutral-950 text-left text-xs uppercase tracking-wider text-neutral-400">
      {/* ... */}
    </thead>
    <tbody>{/* ... */}</tbody>
  </table>
</div>
```

`sticky top-0` on `<thead>` works because the scroll container is the wrapper `<div>` with `overflow-auto`. The sticky element needs a scroll context to stick to — the wrapper provides it.

If sticky fails: check that NO ancestor between the sticky element and the scroll container has `overflow-hidden`.

## Table — mobile fallback (card list)

For complex tables, render as a card list below `md`:

```tsx
{/* Mobile cards */}
<div className="space-y-2 md:hidden">
  {rows.map((row) => (
    <div key={row.id} className="rounded-lg border border-neutral-800 bg-neutral-900/30 p-4">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate font-medium">{row.name}</p>
          <p className="truncate text-sm text-neutral-400">{row.email}</p>
        </div>
        <span className="shrink-0 rounded-full bg-green-500/10 px-2 py-0.5 text-xs text-green-400">Active</span>
      </div>
      <div className="mt-3 flex items-center justify-between text-sm">
        <span className="text-neutral-400">{row.role}</span>
        <button className="text-violet-400">Edit</button>
      </div>
    </div>
  ))}
</div>

{/* Desktop table */}
<div className="hidden overflow-x-auto rounded-lg border border-neutral-800 md:block">
  <table>...</table>
</div>
```

`min-w-0` on the flex child containing the name/email enables `truncate` to actually truncate. `shrink-0` on the badge prevents it from being squeezed when the name is long.

## Card — basic

```tsx
<div className="rounded-2xl border border-neutral-800 bg-neutral-900/50 p-6">
  <h3 className="text-lg font-semibold">Card title</h3>
  <p className="mt-2 text-sm text-neutral-400">
    Card body text explaining what this is.
  </p>
</div>
```

## Card grid — equal heights

```tsx
<div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
  {items.map((item) => (
    <div
      key={item.id}
      className="flex h-full flex-col rounded-2xl border border-neutral-800 bg-neutral-900/50 p-6"
    >
      <div className="flex size-10 items-center justify-center rounded-xl bg-violet-500/10">
        <item.icon className="size-5 text-violet-400" />
      </div>
      <h3 className="mt-4 text-lg font-semibold">{item.title}</h3>
      <p className="mt-2 text-sm text-neutral-400">{item.body}</p>

      {/* Footer pinned to bottom regardless of body length */}
      <div className="mt-auto pt-4">
        <a href={item.href} className="text-sm text-violet-400 hover:underline">
          Learn more →
        </a>
      </div>
    </div>
  ))}
</div>
```

How equal heights work:
- Grid items default to `align-items: stretch` so cards already match heights in their row.
- `h-full` on the card root makes it fill that stretched height (belt and braces — sometimes a parent overrides stretch).
- `flex flex-col` inside the card sets up the column axis.
- `mt-auto` on the footer pushes it to the bottom, leaving the body to consume the middle.

This is the universal "uneven content, even card heights, aligned footers" pattern.

## Card — with image

```tsx
<article className="overflow-hidden rounded-2xl border border-neutral-800 bg-neutral-900/50">
  <div className="relative aspect-video">
    <Image src={post.cover} alt="" fill className="object-cover" />
  </div>
  <div className="p-6">
    <p className="text-xs uppercase tracking-wider text-violet-400">{post.category}</p>
    <h3 className="mt-2 text-lg font-semibold leading-tight">
      <a href={`/blog/${post.slug}`} className="hover:underline">{post.title}</a>
    </h3>
    <p className="mt-2 line-clamp-2 text-sm text-neutral-400">{post.excerpt}</p>
  </div>
</article>
```

- `overflow-hidden` on the article so the image's top corners clip to the rounded outer shape.
- `aspect-video` (16:9) on the image wrapper prevents layout shift while the image loads.
- `next/image` with `fill` + `object-cover` to crop to the box.
- `line-clamp-2` on the excerpt prevents long content from blowing the card height.

## Stat tile

```tsx
<div className="rounded-2xl border border-neutral-800 bg-neutral-900/50 p-6">
  <p className="text-sm font-medium text-neutral-400">Monthly active users</p>
  <p className="mt-2 text-3xl font-bold tracking-tight">12,483</p>
  <p className="mt-2 inline-flex items-center gap-1 text-xs">
    <TrendingUp className="size-3 text-green-400" />
    <span className="font-medium text-green-400">+12.5%</span>
    <span className="text-neutral-500">vs last month</span>
  </p>
</div>
```

In a grid:

```tsx
<div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
  <StatTile ... />
  <StatTile ... />
  <StatTile ... />
  <StatTile ... />
</div>
```

## List — with avatars and metadata

```tsx
<ul className="divide-y divide-neutral-800 rounded-lg border border-neutral-800 bg-neutral-900/30">
  {users.map((user) => (
    <li key={user.id} className="flex items-center gap-3 p-4 hover:bg-neutral-900/50">
      <Avatar src={user.avatar} name={user.name} />
      <div className="min-w-0 flex-1">
        <p className="truncate font-medium">{user.name}</p>
        <p className="truncate text-sm text-neutral-400">{user.email}</p>
      </div>
      <span className="shrink-0 text-xs text-neutral-500">{user.lastSeen}</span>
    </li>
  ))}
</ul>
```

`min-w-0 flex-1` on the text column is the universal fix for "long names break my layout". `shrink-0` on side elements prevents them from being squeezed.

## Avatar

```tsx
export function Avatar({ src, name, size = 40 }: { src?: string; name: string; size?: number }) {
  const initials = name.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase();
  return src ? (
    <img
      src={src}
      alt=""
      width={size}
      height={size}
      className="shrink-0 rounded-full object-cover"
      style={{ width: size, height: size }}
    />
  ) : (
    <div
      className="flex shrink-0 items-center justify-center rounded-full bg-neutral-800 text-xs font-medium text-neutral-300"
      style={{ width: size, height: size }}
    >
      {initials}
    </div>
  );
}
```

`shrink-0` is the universal avatar fix — without it, the avatar gets squeezed inside flex rows when content next to it is long.

## Badge

```tsx
{/* Solid */}
<span className="inline-flex items-center rounded-full bg-violet-500/15 px-2 py-0.5 text-xs font-medium text-violet-300">
  New
</span>

{/* With dot */}
<span className="inline-flex items-center gap-1.5 rounded-full bg-green-500/10 px-2 py-0.5 text-xs font-medium text-green-400">
  <span className="size-1.5 rounded-full bg-green-400" />
  Active
</span>

{/* Outline */}
<span className="inline-flex items-center rounded-full border border-neutral-700 px-2 py-0.5 text-xs font-medium text-neutral-300">
  Draft
</span>
```

Use `inline-flex items-center` so dot + text align on baseline. The `/10` and `/15` opacity suffixes give the subtle tinted-background look against dark themes.

## Empty state

```tsx
<div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-neutral-800 p-12 text-center">
  <div className="flex size-12 items-center justify-center rounded-full bg-neutral-900">
    <Inbox className="size-6 text-neutral-400" />
  </div>
  <h3 className="mt-4 text-sm font-semibold">No items yet</h3>
  <p className="mt-1 max-w-sm text-sm text-neutral-400">
    Create your first item to get started.
  </p>
  <button className="mt-4 rounded-md bg-violet-500 px-3 py-1.5 text-sm font-medium text-white hover:bg-violet-600">
    Create item
  </button>
</div>
```

`flex flex-col items-center` is the centering trick that makes this work without `mx-auto` on each child — see SKILL R2.

## Loading skeleton

```tsx
{/* For a single line of text */}
<div className="h-4 w-32 animate-pulse rounded bg-neutral-800" />

{/* For a card */}
<div className="rounded-2xl border border-neutral-800 bg-neutral-900/30 p-6">
  <div className="size-10 animate-pulse rounded-xl bg-neutral-800" />
  <div className="mt-4 h-5 w-3/4 animate-pulse rounded bg-neutral-800" />
  <div className="mt-2 h-4 w-full animate-pulse rounded bg-neutral-800" />
  <div className="mt-1 h-4 w-5/6 animate-pulse rounded bg-neutral-800" />
</div>

{/* List of N skeletons */}
<div className="space-y-3">
  {Array.from({ length: 5 }).map((_, i) => (
    <div key={i} className="h-12 animate-pulse rounded-lg bg-neutral-900" />
  ))}
</div>
```

`animate-pulse` ships with Tailwind. The trick is matching the skeleton shape to the real content shape so the layout doesn't shift when data arrives.

## Loading spinner

```tsx
import { Loader2 } from "lucide-react";

<div className="flex items-center justify-center py-12">
  <Loader2 className="size-6 animate-spin text-neutral-400" />
</div>
```

## Inline metadata row

```tsx
<div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-neutral-500">
  <span className="flex items-center gap-1">
    <Calendar className="size-3" />
    Jan 12, 2026
  </span>
  <span className="flex items-center gap-1">
    <Clock className="size-3" />
    5 min read
  </span>
  <span className="flex items-center gap-1">
    <User className="size-3" />
    Fahim
  </span>
</div>
```

`flex-wrap` + `gap-x-* gap-y-*` is the universal "row that wraps on narrow viewports with even spacing in both axes" pattern.

## Description list

```tsx
<dl className="divide-y divide-neutral-800">
  {entries.map((entry) => (
    <div key={entry.label} className="grid grid-cols-1 gap-1 py-3 sm:grid-cols-3 sm:gap-4">
      <dt className="text-sm font-medium text-neutral-400">{entry.label}</dt>
      <dd className="text-sm sm:col-span-2">{entry.value}</dd>
    </div>
  ))}
</dl>
```

Stacks on mobile, two-column on desktop. Semantically correct (`<dl>`/`<dt>`/`<dd>`).

## Accordion

```tsx
{/* Vanilla — uses native <details>/<summary> */}
<div className="divide-y divide-neutral-800 rounded-lg border border-neutral-800">
  {items.map((item) => (
    <details key={item.q} className="group">
      <summary className="flex cursor-pointer items-center justify-between gap-4 px-4 py-3 text-sm font-medium hover:bg-neutral-900/50 [&::-webkit-details-marker]:hidden">
        <span>{item.q}</span>
        <ChevronDown className="size-4 shrink-0 transition-transform group-open:rotate-180" />
      </summary>
      <div className="px-4 pb-4 text-sm text-neutral-400">{item.a}</div>
    </details>
  ))}
</div>
```

Zero JavaScript, full keyboard support, screen-reader accessible. The `[&::-webkit-details-marker]:hidden` arbitrary selector hides the default disclosure triangle on Chrome/Safari. For Firefox, also add `list-none` to the summary.

For animated accordions (smooth height transition), Radix Accordion is the right tool — pure CSS height animation is messy.
