---
name: tree-man
description: >
  Generates the canonical page/route manifest (SITETREE.md) for a new project — a human-readable nested tree plus a machine-readable per-route table covering path, type, auth level, purpose, and nav parent, AND a Layout Architecture section assigning layout family, section sequence, above-fold requirements, section rhythm, and responsive intent to every page route. ALWAYS use right after Singularity commits BRAIN.md and before Council PRE-BUILD convenes — tree-man is Phase 2.5 of the PRE-build pipeline (Singularity → tree-man → Council PRE-BUILD → repo-maintainer → build). Trigger phrases: "tree-man", "sitemap", "route manifest", "page tree", "map the routes", "layout families", "section sequence", "what pages does this need", or whenever BRAIN.md was just committed and Council hasn't convened yet. For club sites, defer entirely to club-web-planner's own route output instead of re-deriving it — reformat, never duplicate. SITETREE.md becomes a fifth living doc kept in sync afterward by repo-maintainer's "update repo" trigger, not by tree-man. Do NOT use mid-build for one new page — that's a PLANNER.md edit via repo-maintainer, not a tree-man run. Downstream build skills (plainsight, cave-man, motion-hive) read the Layout Architecture section of SITETREE.md — never invent layout structure if it is already assigned here.
---

# Tree-Man

**Purpose:** produce one canonical, never-improvised page/route manifest before Council reviews the architecture — so Council critiques actual routes instead of a vague idea, and every later skill (plainsight, cave-man, motion-hive, Sentinel, Airborne, task-planner) has a single source of truth for what pages exist, who can see them, and how they should be structured.

**Not to be confused with `sitemap.xml` / `app/sitemap.ts`.** That is Airborne's job — a machine-readable file for search engines, listing only indexable public routes. SITETREE.md is a planning document for humans and Claude instances, covers every route including authenticated and admin ones, and exists before a single line of code is written. Airborne reads SITETREE.md as its starting route list when generating the actual `sitemap.xml` later — the two are related but never the same file.

---

## Position in the pipeline

```
Singularity (BRAIN.md) → tree-man (SITETREE.md) → Council PRE-BUILD → repo-maintainer → build begins
```

Runs once per project, immediately after BRAIN.md is committed. Does **not** run mid-build — adding one page later is a `repo-maintainer` edit to an existing SITETREE.md, not a tree-man re-run.

---

## Step 0 — Check for an existing route source

Before drafting anything:

- If this project came through **club-web-planner**, its Step 3 already produced a route list and a folder tree with route groups. Read that output directly. **Reformat it into SITETREE.md — do not re-derive routes from scratch.** Tree-man's job here is canonicalization into the standard format, not duplicate work. Still generate the Layout Architecture section from the reformatted routes.
- Otherwise, continue to Step 1.

---

## Step 1 — Draft the manifest from BRAIN.md

Read `BRAIN.md`. Singularity already extracted the target user, the core user action, and any locked decisions — use them to draft a first-pass route list without a multi-round interview. Cover at minimum:

- Every public-facing page (landing, pricing, auth screens)
- Every authenticated page the core user action actually requires
- Any admin/internal page — only if BRAIN.md implies one. Do not invent admin surfaces nobody asked for.

For each `page` route in the draft, also assign a **layout family** from the taxonomy in the Layout Architecture Reference section below. This is not a separate pass — do it while drafting the route list. Path patterns, auth level, and the BRAIN.md purpose field together determine the assignment unambiguously in most cases. When they don't, use the "When ambiguous" rule in the taxonomy table.

Show Fahim the draft as a flat list, one line per route: `path — purpose — auth level — layout-family`. Ask once: "Anything missing or wrong here?" This is a confirmation pass, not an interview.

**Project size is not an exemption.** A single-page utility tool with one API route still gets a SITETREE.md — even if it's two rows. The value isn't manifest length, it's that drafting it forces the architecture decision to get written down before code starts.

---

## Step 2 — Write SITETREE.md

Every route gets, at minimum:

| Field | Required | Notes |
|---|---|---|
| Path | yes | exact route, e.g. `/dashboard/settings` |
| Type | yes | `page` \| `route group` \| `API route` \| `layout` |
| Auth level | yes | `public` \| `authenticated` \| `admin` \| `role:[name]` — Sentinel later verifies this against actual code |
| Purpose | yes | one line |
| Parent | yes | nav/hierarchy parent path, or `—` for top-level |
| Status | yes | always `planned` at creation — repo-maintainer updates this as pages ship |

Output both halves into the same file:
1. A human-readable nested tree (markdown, indented by parent) at the top
2. The full route table below it
3. The Layout Architecture section — one entry per `page` route, in path order

API routes and `layout` type entries do **not** get a Layout Architecture entry. Page routes always do.

Commit `SITETREE.md` to repo root, alongside `BRAIN.md`.

API routes (backend endpoints) do **not** belong here — those stay in PLANNER.md's existing "API Routes" table. SITETREE.md is page/UI routes only.

### Layout Architecture section format

The Layout Architecture section has two parts: a project-level dials block written once at
the top, then one entry per `page` route below it.

**Project dials block (written once, at the top of the Layout Architecture section):**

```
## Layout Architecture

### Project dials

design-mode: soft | minimalist | brutalist | inferred
DESIGN_VARIANCE: [1–10]
MOTION_INTENSITY: [1–10]
VISUAL_DENSITY: [1–10]
```

Auto-derived from BRAIN.md during Step 1. See "Project dials derivation" in the Layout
Architecture Reference section for mapping rules. motion-hive BUILD reads MOTION_INTENSITY
to gate which motion gets wired. plainsight reads VISUAL_DENSITY for density defaults.
ui-ux-designer reads DESIGN_VARIANCE to calibrate critique tolerance. cave-man reads
MOTION_INTENSITY to decide between parallax and background on hero zones (score ≤ 3 → background).

**Per-page blocks (one per `page` route, in path order):**

```
### /path

layout-family: [one of the 8 families]
section-sequence: [ordered list with → separators]
above-fold: [what must be visible before scroll, one line]
density: [open | balanced | dense | mixed — with note if mixed]
rhythm: [alternation pattern down the page]
mobile: [design intent change at < 640px, not the CSS — one line]
tablet: [design intent change at 640–1024px, only if there's a meaningful intermediate state]
```

**Example output:**

```
### /

layout-family: marketing
section-sequence: hero → logo-wall → problem → feature-split(×3) → how-it-works → testimonials → pricing → faq → cta-band → footer
above-fold: value prop headline + primary CTA + one trust signal (logo strip)
density: open(hero, features) → dense(pricing) → open(faq, cta)
rhythm: dark(hero) → light → dark(testimonials) → light → dark(cta-band)
mobile: hero stacks text-above-visual, CTA stays above fold, logo wall becomes 2-row horizontal scroll
tablet: feature-split stays 2-col, pricing cards stay 3-col


### /dashboard

layout-family: dashboard
section-sequence: topbar → sidebar-nav → kpi-row(3-4 metrics) → primary-chart → data-table → action-panel
above-fold: kpi-row + primary-chart partial — daily workflow requires no scroll
density: dense
rhythm: uniform neutral — rhythm through card elevation and spacing only, no background swaps
mobile: sidebar collapses to bottom tab bar, kpi-row becomes horizontal scroll, chart drops to full-width


### /auth/login

layout-family: form-wizard
section-sequence: logo → centered-card → email-field → password-field → submit-cta → helper-links(forgot password, sign up)
above-fold: entire page — no scroll ever required on an auth screen
density: minimal
rhythm: single surface — no sections, no alternation
mobile: card loses border and shadow, full-width form, same layout intent
```

---

## Step 3 — Hand off to Council PRE-BUILD

Add one field to Singularity's Council context block: `SITEMAP: [path to SITETREE.md, route count, auth levels in use, layout families assigned]`. Council needs the route structure and layout architecture in front of it before it delivers a verdict.

---

## Layout Architecture Reference

This section defines the taxonomy, sequences, and rules tree-man uses to populate the Layout Architecture section of SITETREE.md. It is also read by downstream skills — plainsight, cave-man, and motion-hive — so assignments made here are locked in for the build. Do not invent a new layout family; choose the closest existing one.

---

### Layout family taxonomy

| Family | Assign when | Path signals |
|---|---|---|
| `marketing` | Public persuasion — landing, product pages, pricing overview | `/`, `/pricing`, `/about`, `/product/*` |
| `dashboard` | Authenticated data-heavy — analytics, home, activity feed | `/dashboard/*`, `/app/*`, auth=authenticated + data-centric purpose |
| `editorial` | Long-form reading — blog posts, docs, changelogs, legal | `/blog/*`, `/docs/*`, `/changelog`, `/legal/*` |
| `card-grid` | Equal-weight item collections — portfolio, listings, marketplace | `/work/*`, `/projects/*`, `/gallery/*`, `/marketplace/*` |
| `split-screen` | Feature showcases, comparisons — alternating image+copy pairs | `/features/*`, `/compare/*`, product sub-pages |
| `form-wizard` | Stepped or single-page forms — onboarding, checkout, auth, settings | `/auth/*`, `/onboarding/*`, `/checkout/*`, `/settings/*` |
| `bento` | Mixed-size grid cells on a public page — feature showcases with varied visual weight | `/features` (when grid-heavy), `/pricing` (when card-grid is the dominant element) |
| `minimal` | Single-action pages with no nav and no distraction | `/404`, `/maintenance`, `/confirm/*`, `/verify/*`, coming soon |

**When ambiguous**, resolve by BRAIN.md purpose field:
- "user sees their data" → `dashboard`
- "user is persuaded to sign up" → `marketing`
- "user reads content" → `editorial`
- "user completes a form" → `form-wizard`
- "user browses items" → `card-grid`

---

### Section sequence library

Canonical sequences per family. These are defaults — adjust only if BRAIN.md specifies something different, or if the confirmed route list from Step 1 implies a different structure.

**marketing (landing page)**
```
hero → logo-wall → problem → feature-split(×3) → how-it-works(3-step) → testimonials → pricing → faq → cta-band → footer
```
Notes: logo-wall belongs immediately below the hero fold — it is the trust signal that converts the hero's claim. Never put it in the footer. feature-split alternates image-left and image-right. how-it-works is always 3 steps, never 4 or 5.

**dashboard (authenticated home)**
```
topbar → sidebar-nav → kpi-row(3–4 metrics) → primary-chart → data-table → action-panel
```
Notes: kpi-row must be visible above fold — it is the first thing a returning user checks. sidebar-nav is persistent, not a toggle. Action-panel at the bottom only if the page requires a global action (bulk operations, export).

**editorial (blog post / doc page)**
```
breadcrumb → post-header(title + meta + read-time) → toc(if >5 headings) → body-content → related-posts → footer
```
Notes: table of contents only appears when there are more than 5 heading levels. Body content width caps at ~72ch — never full-bleed for reading text.

**card-grid (portfolio / listing)**
```
page-header → filter-bar → card-grid → pagination-or-load-more → footer
```
Notes: filter-bar is not optional — without filtering, a card-grid becomes unusable at scale. Cards are equal-weight; never mix card sizes in the same grid.

**form-wizard (auth / onboarding / checkout)**
```
logo → centered-card → form-fields → primary-cta → helper-links → footer-minimal
```
Notes: footer-minimal means copyright line only — no full nav, no distractions. The centered-card is the page. One primary action per screen — never two CTAs.

**settings page (sub-family of form-wizard)**
```
settings-sidebar-nav → section-header → field-groups(labeled) → save-action → danger-zone(if applicable)
```
Notes: danger-zone (delete account, revoke access) always at the bottom of its own section with a visual separator. Never inline with normal settings.

**split-screen**
```
split-hero(image-left or image-right) → alternating-feature-rows(×N) → cta-band
```
Notes: split-hero sets the alternation direction — if hero is image-right, first feature row is image-left. Never break alternation mid-page.

**bento**
```
bento-hero-cell(full-width or 2/3) → bento-grid(mixed sizes) → cta-band
```
Notes: hero cell always largest. No more than 2 sizes of bento cells in one grid. Each cell has one claim, not a list.

---

### Above-fold law

What must be visible before any scroll — non-negotiable per family. This is the `above-fold` field value.

| Family | Must be above the fold |
|---|---|
| `marketing` | Value prop headline + primary CTA + one trust signal (logo strip OR review count) |
| `dashboard` | Primary KPI metric(s) + navigation to all key sections + current state indicator |
| `editorial` | Article title + author + estimated read time |
| `card-grid` | Filter controls + at least 2 card items partially visible |
| `form-wizard` | The entire form — never require scroll to reach the first input |
| `bento` | Hero cell fully visible + at least one secondary cell partially visible |
| `split-screen` | Full hero split — both image and copy above the fold |
| `minimal` | The entire page — if it requires scrolling it is not a minimal page |

---

### Section rhythm rules

Rhythm is the alternation of visual weight, background tone, and density down the page. Four rules apply across all families.

**Rule 1: Never stack two heavy sections.** Pricing + testimonials back-to-back without separation = visual fatigue. Always separate two dense or high-drama sections with an open or neutral section between them.

**Rule 2: Dark sections anchor the page.** Hero and cta-band are the primary dark anchors — they bookend the page's narrative. Testimonials may be a third dark anchor if the page is long enough to warrant it. Everything else is light or neutral.

**Rule 3: Density requires breathing room.** Any section with a comparison table, feature matrix, or pricing tiers (dense) must have an open section — ample whitespace, single claim, minimal copy — directly before it and optionally after it.

**Rule 4: Dashboard family has no rhythm through backgrounds.** Visual rhythm in dashboard pages is achieved entirely through card elevation, spacing, and border weight — never through background color alternation. A dashboard that alternates dark and light sections is a marketing page that got lost.

Canonical rhythm shorthand per family:
- marketing: `dark(hero) → light → dark? → light → dark(cta-band)` — minimum two anchors
- dashboard: `uniform-neutral` — write exactly this, no alternation
- editorial: `uniform-light` — no dark sections; rhythm through heading hierarchy
- form-wizard: `single-surface` — no rhythm, single background throughout
- card-grid: `light-throughout` — page header + filter + grid + footer all share the same neutral surface
- split-screen: `light-with-dark-cta` — splits are light; only the closing cta-band goes dark
- bento: `dark-hero-cell, light-grid` or `light-throughout` depending on BRAIN.md palette

---

### Responsive intent

The `mobile` and `tablet` fields describe what changes about the **design intent** at each breakpoint — not which CSS properties change. Downstream skills derive the CSS from the intent; tree-man states the intent.

Rules for the most common layout changes:

- **Split-screen** always stacks at mobile. Stack order: on landing pages, image goes below copy. On feature pages where the image is the product demo, image goes above copy.
- **Dashboard sidebar** always collapses to a **bottom tab bar** at mobile — never a hamburger drawer. Primary navigation in a data app must be reachable with one tap, not two.
- **Marketing hero text** drops one size step at mobile. H1 never falls below 32px at any breakpoint.
- **Card grids** move 3-col → 2-col at tablet, 1-col at mobile.
- **Form-wizard** is already single-column — mobile intent is: card loses its border and shadow, padding reduces, but layout intent is unchanged. Write `mobile: card loses border, reduces padding — layout intent unchanged`.
- **Bento grids** collapse to a single-column vertical stack at mobile. Cell order: most visually dominant cell first, regardless of its grid position on desktop.
- **Editorial** is already reading-width-constrained — mobile intent is: remove side padding, text becomes full-bleed within safe area.
- **Minimal pages** have no responsive note — they are already single-column by definition.

---

### Which downstream skills read the Layout Architecture section

Once tree-man commits SITETREE.md, these skills treat the Layout Architecture section as locked structure:

- **plainsight** reads `layout-family` and `section-sequence` before building any page component. It never invents a layout structure for a route that already has one assigned. If the assigned section-sequence has 10 sections, plainsight builds all 10 — it does not abbreviate.
- **cave-man** reads `section-sequence` and `density` per route to classify image zones. marketing sections map to background images; card-grid sections map to inline images; editorial body maps to no images; dense dashboard sections map to KEEP-FLAT. Cave-man does not re-derive zone type if the section-sequence already makes it obvious.
- **motion-hive** reads `layout-family` and `rhythm` to decide where motion is appropriate. It never adds scroll-driven animation to `form-wizard` or `minimal` pages. Scroll parallax applies only to marketing and editorial hero sections. Dashboard pages get motion only in data transitions. motion-hive also reads the project-level `MOTION_INTENSITY` dial: score 1–3 = hover states only; 4–6 = entrance variants + reveals; 7–10 = parallax + gesture physics + route transitions.

---

### Project dials derivation

Auto-derive all three dials during Step 1 from BRAIN.md. Write them before drafting per-page entries.

**design-mode:**
- Professional tool (invoicing, analytics, developer tool) → `minimalist`
- Creative portfolio, agency, design studio → `soft` or `brutalist` depending on palette
- Consumer product with delight focus → `soft`
- High-contrast, Swiss-grid, experimental → `brutalist`
- Ambiguous → `inferred`

**DESIGN_VARIANCE (1–10):**
Enterprise / compliance-heavy → 2–3. Professional SaaS → 3–5. Creative portfolio → 6–8. Experimental → 8–10. Dark-first palette nudges +1. "Clean" or "minimal" in BRAIN.md nudges -1.

**MOTION_INTENSITY (1–10):**
Form-heavy / data tools → 2–4. Marketing for professional audiences → 4–6. Consumer marketing / portfolio → 6–8. Scroll-driven storytelling → 8–10. `form-wizard` and `minimal` pages always cap at 1.

**VISUAL_DENSITY (1–10):**
Storytelling marketing / portfolio → 2–4. Standard SaaS landing → 4–6. Dashboard / data app → 6–8. Dense admin / data tables → 8–10.

---

## Ownership after this point

Tree-man's job ends once SITETREE.md is committed and Council has reviewed it. From here on, **repo-maintainer** owns keeping SITETREE.md in sync — it is the fifth living doc, updated under the same "update repo" trigger that already maintains PLANNER.md, DESIGN_GUIDE.md, README.md, and AGENTS.md. Tree-man itself never re-runs mid-project.

---

## Notes

- No emoji anywhere in tree-man output.
- All output is plain markdown written to `SITETREE.md` — no artifact, no widget.
- If BRAIN.md does not exist yet, stop and say: "No BRAIN.md found — run Singularity first." Tree-man never substitutes for the Singularity interview.
- Layout family assignments are **binding decisions**. If Fahim disagrees with an assignment during the Step 1 confirmation pass, change it then. After SITETREE.md is committed and Council has reviewed it, changing a layout family is a repo-maintainer task that ripples through PLANNER.md and DESIGN_GUIDE.md.
