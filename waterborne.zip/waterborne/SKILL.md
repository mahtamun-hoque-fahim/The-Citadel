---
name: waterborne
description: >
  Project-wide emoji sweep for Fahim's codebases. Scans the ENTIRE project/repository for emojis and emoji-like pictographic characters and replaces each one with the correct lucide-react icon, an inline SVG, or plain text, never leaving an emoji behind. ALWAYS use when the user says "run Waterborne", "waterborne", "de-emoji", "remove emojis", "strip emojis", "no emojis", "clean the emojis", "replace emojis with icons", "emoji audit", or asks to enforce the no-emoji house rule across a repo. PRIMARY: compass STEP 1 — runs first, before motion-hive, valley-of-death, sentinel, and Airborne. SECONDARY: a scoped re-scan right after Airborne/Humanizer write new copy, since marketing prose can reintroduce emoji. Trigger proactively the moment Airborne or Humanizer completes, or before any "ready to ship/commit" moment. Tuned for Fahim's stack (Next.js App Router, TypeScript, Tailwind, lucide-react) but works on any framework.
---

# waterborne

> Run the whole codebase under water and rinse every emoji out.

Waterborne is a **deterministic sweep**, not a vibe check. It scans every text file in the project, finds every emoji, and replaces each one with the correct thing for where it lives: a `lucide-react` icon in rendered UI, an inline SVG where React is not available, or plain words / nothing in comments, logs, docs, and commits. When it finishes, re-running the scanner returns **zero** and the build still passes. That is the bar.

This skill exists so that a lower-capability model (Haiku, Sonnet) gets the same clean result Opus would: the hard parts — emoji detection and icon mapping — are shipped as a runnable script and a lookup table, so you never have to invent a Unicode regex or guess an icon name.

---

## When Waterborne Activates

| Run Waterborne | Skip Waterborne |
|---|---|
| Compass STEP 1 — start of the post-build pipeline, before motion-hive/VoD/sentinel/Airborne | Mid-feature, code still churning every minute |
| Scoped touch-up right after Airborne or Humanizer writes new copy | A single file you are actively editing (just don't type emojis) |
| Pre-commit / pre-ship final pass | A repo that is not yours to restyle |
| User says "remove emojis" / "no emojis" / "de-emoji" | Test fixtures that exist to test emoji handling (see `references/scope-and-safety.md`) |
| Inherited / migrated code that is full of emojis | i18n/user-content seeds where an emoji is real data (flag, ask first) |
| Enforcing the house rule before a release | |

**Chaining rule (priority).** Waterborne has two jobs, not one. **Primary:** it is STEP 1 of compass's post-build pipeline — a full-project sweep that runs *before* motion-hive, valley-of-death, sentinel, and Airborne, so every later step audits or writes against a codebase that is already clean. **Secondary:** Airborne ends a milestone by writing meta titles, JSON-LD, marketing copy, and roadmap content, and some of that copy can introduce new emojis. Once Airborne (and Humanizer) finish, run a scoped re-scan limited to the files they just touched: scan → replace → re-scan to zero → confirm build. Treat "Airborne/Humanizer complete" as an implicit "now run a scoped Waterborne pass" — this is a touch-up, not a re-run of the full-project sweep.

---

## The core principle

**Detection is mechanical. Replacement is contextual.**

- You never decide *what counts as an emoji* by eye — the script decides. Run `scripts/scan_emojis.py`; it prints every hit with file, line, column, the exact glyph, and the Unicode name of each code point.
- You *do* decide *what to replace it with*, and that decision is driven entirely by **where the emoji lives**. The same 🚀 becomes `<Rocket />` in JSX, the word "launch" in an aria-label, and nothing at all in a code comment.

Get those two ideas right and the rest is lookup.

---

## The Workflow

Run these phases **in order**. Do not skip the re-scan.

### Phase 0 — Scan the whole project

```bash
python scripts/scan_emojis.py --root .
```

The script walks the repo, ignores `node_modules`, `.git`, `.next`, build output, and lockfiles, reads only text files, and prints every emoji it finds. Exit code `1` means emojis were found; `0` means clean.

For a machine-readable inventory you can iterate over:

```bash
python scripts/scan_emojis.py --root . --json > emoji-report.json
```

**Do not start editing until you have the full scan output.** Editing file-by-file as you discover emojis leads to missed hits and duplicate icon imports. Get the complete list first.

### Phase 1 — Build the inventory

From the scan output, produce one table for the whole project:

```
| File | Line:Col | Emoji | Unicode name | Context (what the line does) |
|---|---|---|---|---|
| src/app/page.tsx | 12:19 | 🚀 | ROCKET | JSX text node in hero |
| src/lib/log.ts | 8:11 | ✅ | WHITE HEAVY CHECK MARK | console.log status |
| README.md | 1:11 | ❤️ | HEAVY BLACK HEART | doc heading decoration |
```

The "Context" column is what drives Phase 3. Note for each hit whether it is in: **rendered JSX/TSX**, a **plain string** in non-React code, a **code comment**, a **console/log call**, **Markdown/docs**, a **commit message**, an **alt/aria/meta attribute**, **config/JSON**, or a **CSS `content`** value.

### Phase 2 — Classify each hit (the decision table)

For every hit, pick exactly one strategy from this table. This is the heart of the skill.

| Where the emoji lives | Strategy | What you do |
|---|---|---|
| Rendered JSX/TSX (text node, button label, list bullet) | **Icon** | Replace with a `lucide-react` icon component. Add the import. |
| Rendered HTML (no React) | **SVG** | Inline the lucide SVG for that icon (copy from lucide.dev) or a `<span>` dot for bullets. |
| Bullet / list marker emoji (•-style decoration) | **SVG dot** | `<span className="inline-block size-1.5 rounded-full bg-current" />` — not an icon. |
| `alt=""`, `aria-label=""`, `title=""`, meta description/title | **Plain text** | Replace with a real word ("launch", "warning"). Never put an icon or emoji in an accessibility/SEO string. |
| Code comment (`//`, `/* */`, `#`) | **Delete** | Remove the emoji and tidy whitespace. Comments need no icon. |
| `console.log` / logger / debug output | **Delete** (or `[TAG]`) | Strip the emoji. If it was a status marker, use a text tag like `[ok]`, `[warn]`. |
| Markdown / docs prose | **Delete** | Remove decorative emojis. If it carried meaning, replace with a word. Keep headings clean. |
| Commit message / PR title (if you are writing one) | **Delete** | House rule: no emojis in commits, ever. Rewrite plainly. |
| `package.json` scripts, JSON config, `.env` example | **Delete** | Strip; these are not display surfaces. |
| CSS / Tailwind `content: "..."` | **SVG / unicode-free** | Replace with an SVG background or a lucide icon element; drop the emoji glyph. |
| Toast / notification / error string shown to users | **Icon (separate)** | Move the meaning into an icon prop on the toast, not inside the message text. |

Edge cases (intentional emoji fixtures, user-generated content, i18n data) → see `references/scope-and-safety.md` before touching them.

### Phase 3 — Map and replace

For every **Icon** and **SVG** hit, look up the glyph in `references/emoji-icon-map.md` to get the exact `lucide-react` component name. For the precise code transform per context (import placement, RSC vs client, dot bullets, SVG inlining), follow `references/replacement-patterns.md`.

Replace hits **file by file**, and when a file gets one or more lucide icons, add a single deduped import:

```tsx
import { Rocket, AlertTriangle, Check } from "lucide-react";
```

Never add a second `lucide-react` import line to a file that already has one — merge into the existing import.

### Phase 4 — Re-scan to zero (the gate)

```bash
python scripts/scan_emojis.py --root .
```

This must print `CLEAN: no emojis found.` and exit `0`. If anything remains, it appears in the output — go back to Phase 2 for those hits. **Do not declare done while the scanner is non-zero.**

### Phase 5 — Verify the build

Emoji removal can break things three ways: a missing/renamed lucide icon, an unbalanced JSX edit, or a now-unused import. Confirm:

```bash
npm run build      # or pnpm build / next build
```

If a lucide name does not exist (the library renames icons across versions), check the live name on lucide.dev and use the current export. Common gotchas are listed in `references/emoji-icon-map.md`.

### Phase 6 — Report

Deliver the structured report (format below). If you committed, the commit message itself must be emoji-free.

---

## Output Format

```
# Waterborne Sweep — [Project Name]

## 1. Summary
- Files scanned: N
- Emojis found: N across M files
- Replaced with icons: N  |  inline SVG: N  |  plain text: N  |  deleted: N
- Flagged for review (not auto-changed): N
- Final scan: CLEAN (exit 0)  |  Build: PASS

## 2. Changes by file
| File | Emoji | Strategy | Replacement |
|---|---|---|---|
| src/app/page.tsx | 🚀 | Icon | <Rocket className="size-5" /> + import |
| src/lib/log.ts | ✅ | Delete | removed from console.log |
| README.md | ❤️ | Delete | removed from heading |

## 3. New lucide-react imports added
| File | Icons imported |
|---|---|
| src/app/page.tsx | Rocket, AlertTriangle |

## 4. Flagged for review
Items where an emoji might be intentional data (i18n, fixtures, user content).
List each with file:line and why you did not auto-change it.

## 5. Verification
- Re-scan result: CLEAN
- Build result: PASS / FAIL (with error if any)
```

---

## Non-negotiable rules

1. **Scan first, edit second.** Never hand-hunt for emojis. The script is the source of truth for what exists. Hand-hunting misses ZWJ sequences and variation-selector glyphs every time.

2. **The re-scan gate is mandatory.** "Done" is defined as `scan_emojis.py` exiting `0`, not "I think I got them all."

3. **Context decides the replacement, not the glyph.** A 🚀 is an icon in JSX, a word in an aria-label, and nothing in a comment. Always classify by location (Phase 2) before substituting.

4. **Never put an icon or emoji in an accessibility or SEO string.** `alt`, `aria-label`, `title`, meta title, and meta description get plain words. An icon inside `alt=""` is worse than the emoji was.

5. **Icons are `lucide-react`, bullets are dots.** Use lucide components for meaningful glyphs; use `<span className="size-1.5 rounded-full bg-current" />` for decorative list bullets. Do not turn a bullet into a `Circle` icon.

6. **One merged `lucide-react` import per file.** Add to the existing import; never create a duplicate import line.

7. **Decorative emoji with no function gets deleted, not iconified.** 🎉 🥳 🙏 😄 carry no UI meaning — remove them and fix spacing. Do not invent a `PartyPopper` in production copy.

8. **Do not touch out-of-scope files.** `node_modules`, lockfiles, `.git`, build output, third-party vendor code, and intentional emoji test fixtures are off-limits. The scanner already ignores most; you ignore the rest (see `references/scope-and-safety.md`).

9. **Ambiguous = ask, don't guess.** If an emoji might be real data (a flag in an i18n file, a user's saved note, a seed row), flag it in the report and leave it. Do not silently delete user content.

10. **No emojis introduced while fixing.** The replacement, the report, and any commit message you write are themselves emoji-free. (Fahim-wide rule.)

11. **Build must pass.** A clean scan with a broken build is a failed sweep. Verify before reporting done.

---

## File routing

| Doing this | Open this |
|---|---|
| Running the scan / verifying / CI gate | `scripts/scan_emojis.py` |
| Picking the right lucide icon for a glyph | `references/emoji-icon-map.md` |
| Writing the exact code change for a context (import, SVG, bullet, RSC) | `references/replacement-patterns.md` |
| Deciding what NOT to touch / handling ambiguous emojis | `references/scope-and-safety.md` |

---

## Quick-Start Example (scoped touch-up pass)

User: "Just ran Airborne on Notably. Now run Waterborne before I commit."

1. **Phase 0 — Scan.** `python scripts/scan_emojis.py --root .` → 14 hits across 5 files (hero JSX, a toast string, two `console.log`s, the README, and a meta description Airborne just wrote).
2. **Phase 1 — Inventory.** Build the table; note each hit's context.
3. **Phase 2 — Classify.** Hero 🚀 and ⚠️ → Icon. Toast ✅ → move meaning to a toast icon, strip from text. `console.log` ✅/❌ → Delete. README 🎉 → Delete (decorative). Meta description 🔥 → Plain text ("fast").
4. **Phase 3 — Replace.** Add `import { Rocket, AlertTriangle } from "lucide-react";` to the hero (merged into its existing lucide import). Swap the toast to pass an icon prop. Clean the logs, README, and meta string.
5. **Phase 4 — Re-scan.** `scan_emojis.py` → `CLEAN`, exit 0.
6. **Phase 5 — Build.** `npm run build` → passes (caught one stale icon name, fixed via lucide.dev).
7. **Phase 6 — Report.** Deliver the sweep report. Commit message: "chore: remove emojis, replace with lucide icons" — no emoji.

The user commits a codebase that scans clean and builds green. That is the bar.
