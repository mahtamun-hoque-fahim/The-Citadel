---
name: next16-debugger
description: >
  Expert debugging methodology and reference for Next.js 16+ projects (Turbopack
  default, async request APIs, Cache Components, proxy.ts, React 19.2). ALWAYS
  use this skill when a user mentions Next.js 16, debugging a Next.js project,
  "params is a Promise", "cookies is now async", proxy.ts, middleware migration,
  Turbopack errors, Cache Components, cacheComponents, PPR, revalidateTag,
  updateTag, hydration mismatch in App Router, build failures after a Next.js
  upgrade, or any Next.js error message containing "sync-dynamic-apis",
  "blocking-route", "next-prerender-sync-headers", or "dynamic-server-error".
  Use proactively when a package.json shows next at version 16+ or symptoms
  match Next.js 16 breaking changes (sync access to params/cookies/headers,
  webpack-only loaders, middleware on Edge). Encodes a systematic debugging
  thinking pattern so any model can debug Next.js 16+ as reliably as Opus 4.7.
---

# Next.js 16+ Debugger

A debugging skill for Next.js 16+ projects. This skill exists because Next.js 16 made several **simultaneous structural changes** to the framework — Turbopack by default, async request APIs fully enforced, `middleware.ts` renamed to `proxy.ts`, Cache Components replacing the implicit caching model, React 19.2 — and most pre-2026 training data describes the *old* behavior. Following old patterns will produce broken code. This skill encodes both **what's actually true in Next.js 16+** and **the thinking pattern** needed to debug it without thrashing.

Stack context (Fahim's): Next.js (App Router) · TypeScript · Tailwind CSS · Neon (PostgreSQL) · Drizzle ORM · Vercel · Cloudflare Pages · Better Auth.

---

## Step 0 — Verify the version before anything else

The single most common debugging failure is reasoning about the wrong version of Next.js. Before forming any hypothesis:

1. **Read `package.json`** — note the exact `next` version (e.g. `16.2.4`).
2. **Check the bundler in scripts** — `next dev` and `next build` use Turbopack by default in 16+; `--webpack` opts out; `--turbopack` is now a no-op.
3. **Check `next.config.{ts,js,mjs}`** — note `turbopack`, `cacheComponents`, `reactCompiler`, `images.*`, and any `experimental.*` flags.
4. **Check for `proxy.ts` vs `middleware.ts`** at the project root or under `src/`.

If the version is 15 or below, this skill does not apply — defer to the mahtamun-fullstack skill (Next.js 14 patterns) or the official Next.js 15 docs. If 16+, proceed.

**Why this matters:** A "fix" that uses synchronous `cookies()` is correct in Next 14 and broken in Next 16. A pattern that works in webpack may fail under Turbopack. Knowing which world you're in is half the debugging.

---

## The debugging thinking pattern

This is the loop. Follow it in order. Lower-capability models tend to jump from symptom directly to a fix, which produces wrong answers when training data is stale. The discipline here is to **gather evidence before forming hypotheses**, and **verify before applying**.

### 1. Read the actual error, in full

Do not pattern-match on the first line. The full stack trace, the file path, the line number, and any framework hint (e.g. `next-prerender-sync-headers`, `sync-dynamic-apis`, `dynamic-server-error`) are diagnostic. The error code in the URL of a Next.js error page is the most specific signal you will get — search the official docs for it before guessing.

If the user gave you only the first line, ask for the rest. A truncated error wastes more time than a one-message round-trip.

### 2. Classify the failure surface

Every Next.js 16 bug lives in one of these buckets. Identify which, because the fix space is completely different per bucket:

- **Build-time** — `next build` fails. Often Turbopack vs webpack config, missing env vars at build time, parallel routes missing `default.js`, or type errors from async APIs.
- **Dev-only** — works in `next dev` but not `next build`, or vice versa. Often stale `.next/` cache, HMR artifact, or a feature behind `cacheComponents`.
- **Runtime, server** — Server Component throws, Route Handler errors, Server Action fails. Often async API not awaited, runtime mismatch (Edge vs Node), or DB driver mismatch.
- **Runtime, client** — Hydration mismatch, "use client" boundary issue, browser API used in render.
- **Deploy** — Builds locally, fails on Vercel/Cloudflare. Often env vars, runtime, image config, or Edge runtime incompatibility.

### 3. Reproduce minimally

Before suggesting any fix, confirm you can name:
- The file the error originates in
- The function or component
- The exact line, if available
- What the user changed last (most bugs are introduced by the last change)

If you don't have these, ask. Don't speculate.

### 4. Form a hypothesis tied to a known Next.js 16 behavior change

Match the symptom to a specific documented behavior (see the Quick Reference and Deep Dives below). The hypothesis should be of the form: *"Symptom X is caused by Behavior Y, which changed in Next.js 16 because Z."* If you can't articulate the "because Z," your hypothesis is shaky — keep gathering.

### 5. Prefer the codemod over manual edits

For any migration-shaped problem (sync APIs, `middleware` → `proxy`, `unstable_` prefix, `experimental_ppr`, `next lint`), the official codemod handles 80–90% of cases mechanically. Run it first; debug only the residue.

```bash
npx @next/codemod@canary upgrade latest
```

Specific codemods (run individually when needed):
- `next-async-request-api` — adds `await` to params/cookies/headers
- `next-lint-to-eslint-cli` — migrates `next lint` config

### 6. Apply the minimal fix and verify

After applying a fix, verify:
- The error message changes (or disappears) — if it's identical, the fix didn't take
- `.next/` was cleared if stale-cache was suspected (`rm -rf .next` before re-running)
- Both `next dev` AND `next build` succeed — many Next 16 bugs only surface at build time

### 7. Look one level wider

If you fixed *one* sync `cookies()` call, search the project for others. Breaking changes affect patterns, not individual lines. A useful sweep:

```bash
# Find sync access to async APIs
grep -rn "cookies()\." app/ src/ 2>/dev/null | grep -v "await"
grep -rn "headers()\." app/ src/ 2>/dev/null | grep -v "await"
grep -rn "params\." app/ src/ 2>/dev/null | grep -v "await\|Promise"
```

---

## What actually changed in Next.js 16 (the breaking surface)

Skim this every time. Most debugging traces back to one of these.

### Async Request APIs are now mandatory

In Next 15, sync access to `cookies()`/`headers()`/`draftMode()`/`params`/`searchParams` produced a warning. In **Next 16, it throws.** All of these return Promises and must be awaited.

```tsx
// Wrong (Next 14/15 pattern, broken in 16)
export default function Page({ params }: { params: { id: string } }) {
  const cookieStore = cookies()
  return <h1>{params.id}</h1>
}

// Right (Next 16)
export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const cookieStore = await cookies()
  return <h1>{id}</h1>
}
```

This applies in `layout.js`, `page.js`, `route.js`, `default.js`, `opengraph-image`, `twitter-image`, `icon`, `apple-icon`, `generateMetadata`, and `sitemap` (id is now async too).

**Type helper:** Run `npx next typegen` to generate `PageProps<'/blog/[slug]'>`, `LayoutProps<...>`, `RouteContext<...>` — these are the canonical typed wrappers for async props.

### Turbopack is the default bundler

`next dev` and `next build` use Turbopack with no flag. Webpack is opt-in via `--webpack`.

Implications:
- If `next build` fails with "webpack config detected," either remove the webpack config, migrate it to `turbopack.*`, or use `next build --webpack`.
- The `experimental.turbopack` config moved to top-level `turbopack` in `next.config.ts`.
- Sass `~` tilde imports don't work — drop the tilde or set `turbopack.resolveAlias: { '~*': '*' }`.
- Custom webpack loaders (legacy CSS-in-JS, module federation) need Turbopack-compatible alternatives or stay on `--webpack`.
- `resolve.fallback` for Node modules in client code becomes `turbopack.resolveAlias: { fs: { browser: './empty.ts' } }` — but the right fix is to stop importing Node modules in client code.

### `middleware.ts` is renamed to `proxy.ts` — and runs on Node.js

The file is renamed, the exported function is renamed, the runtime changes:

```ts
// Old: middleware.ts (Edge runtime by default)
export function middleware(request: NextRequest) { /* ... */ }

// New: proxy.ts (Node.js runtime, NOT configurable)
export function proxy(request: NextRequest) { /* ... */ }
```

Config flags rename too: `skipMiddlewareUrlNormalize` → `skipProxyUrlNormalize`.

**Critical for Cloudflare Pages deployments:** `proxy.ts` is Node.js-only. If your project needs the Edge runtime (Cloudflare Pages constraint), **keep using `middleware.ts`** — it's deprecated but still works. Don't blindly rename if you're on Cloudflare. The official guidance is to keep `middleware` for Edge use cases until further notice.

### Cache Components replaces implicit caching

The `experimental.ppr`, `experimental.dynamicIO`, `experimental.useCache`, and route-segment `experimental_ppr` are all gone. The replacement is one top-level flag:

```ts
// next.config.ts
const nextConfig: NextConfig = { cacheComponents: true }
```

With `cacheComponents`, **everything is dynamic by default**. You opt routes/components into caching via `"use cache"` directive, `cacheLife()`, and `cacheTag()` (now stable, drop the `unstable_` prefix on imports).

**`revalidateTag` now requires a second argument** — a `cacheLife` profile:
```ts
// Wrong (deprecated, TypeScript error)
revalidateTag('posts')

// Right
revalidateTag('posts', 'max')
```

For "show the user their write immediately" semantics, use the new `updateTag()` in Server Actions. For routing refresh after an action, use the new `refresh()`.

### `next/image` defaults tightened

Breaking defaults that will silently change behavior:
- `minimumCacheTTL`: `60s` → `4 hours` (14400s). Set back to 60 if you need frequent revalidation.
- `imageSizes`: `16` removed from the default array. Add it back if you serve 16px images.
- `qualities`: defaults to `[75]` only. Add other values explicitly if you use them.
- Local images with query strings now need `images.localPatterns: [{ pathname: '/assets/**', search: '?v=1' }]`.
- Local IPs blocked by default — set `images.dangerouslyAllowLocalIP: true` only for private networks.
- Max redirects: unlimited → 3. Adjust `images.maximumRedirects` if needed.
- `images.domains` is deprecated — use `images.remotePatterns`.

### Parallel routes require explicit `default.js`

All `@slot` parallel route folders now need a `default.tsx` file or the build fails:
```tsx
// app/@modal/default.tsx
export default function Default() { return null }
```

### Removed APIs

These are gone — if you see them, replace before anything else:
- `next/legacy/image` → `next/image`
- `serverRuntimeConfig` / `publicRuntimeConfig` → env vars (`NEXT_PUBLIC_*` for client-side)
- `next lint` command → use ESLint directly; `eslint` key in `next.config` is also gone
- `amp` config + `useAmp` hook
- `devIndicators.appIsrStatus`, `.buildActivity`, `.buildActivityPosition`
- `unstable_rootParams`

### Node.js / TypeScript minimums

- Node.js 20.9+ (Node 18 unsupported)
- TypeScript 5.1+
- Browsers: Chrome/Edge/Firefox 111+, Safari 16.4+

### `next dev` writes to `.next/dev`, `next build` to `.next`

They can run concurrently now. If you have tooling that reads `.next/` for traces, update the path to `.next/dev/trace-turbopack` for dev.

---

## Quick reference: error → cause → fix

| Error / symptom | Likely cause in Next 16 | Fix |
|---|---|---|
| `Route used cookies() inside a function that wasn't awaited` | Sync access to `cookies()` | `const c = await cookies()` |
| `Sync dynamic APIs` warning/error | Sync access to params/cookies/headers/searchParams | `await` it; codemod can fix |
| `params.id` is `undefined` | Treating params as object instead of Promise | `const { id } = await params` |
| `Uncached data was accessed outside of <Suspense>` | `cacheComponents` on, dynamic data not in Suspense | Wrap the dynamic component in `<Suspense fallback={...}>` |
| `DynamicServerError` at build time | `cookies()`/`headers()` called from inside `setTimeout`, `setInterval`, or unawaited promise | Move the call to the synchronous portion of the request; never call inside timers |
| `webpack configuration was found` build error | Default switched to Turbopack | `next build --webpack` to stay on webpack, or migrate the webpack config to `turbopack.*`, or remove if unused |
| `Module not found: Can't resolve 'fs'` (client-side) | Node module imported into client bundle, no longer silenced | Refactor to remove the import from client code; last-resort: `turbopack.resolveAlias: { fs: { browser: './empty.ts' } }` |
| `@import '~bootstrap/...'` fails | Turbopack doesn't support tilde Sass imports | Drop the `~`, or set `turbopack.resolveAlias: { '~*': '*' }` |
| `middleware` not running after upgrade | Renamed to `proxy.ts`, function must be `proxy` | Rename file and function; codemod handles this. Keep `middleware.ts` if you need Edge runtime |
| `proxy` doesn't have access to Edge APIs | `proxy.ts` runs on Node.js, not Edge | Keep `middleware.ts` for Edge; use `proxy.ts` for Node-only work |
| `revalidateTag` is a deprecated single-argument call | API now requires `cacheLife` profile | `revalidateTag('tag', 'max')` |
| `experimental_ppr` config error | PPR config moved | `cacheComponents: true` at top level |
| Parallel route build error: "default missing" | New requirement in 16 | Add `app/@slot/default.tsx` returning `null` or calling `notFound()` |
| `next lint: command not found` | `next lint` removed | Migrate via `npx @next/codemod@canary next-lint-to-eslint-cli .`; run ESLint directly |
| `next.config` `eslint` key error | Option removed | Delete the `eslint` block from `next.config` |
| Hydration mismatch after upgrade | React 19 throws instead of warning; PPR may be active | See Deep Dive: Hydration below |
| Image looks blurry / over-compressed | `blurDataURL` default behavior with new image pipeline | Disable `placeholder="blur"` on the affected image; verify `quality` is in `images.qualities` |
| `Local image source must use the relative URL` for image with `?v=1` | Local query-string images now need explicit pattern | Add `images.localPatterns: [{ pathname: '/path/**', search: '?v=1' }]` |
| `connect ECONNREFUSED` on Cloudflare deploy | Node-only DB driver on Edge | Use `@neondatabase/serverless` + `drizzle-orm/neon-http` |
| `process is not defined` at runtime | Server-only code shipped to client | Move logic to a Server Component / Route Handler; check for accidental `'use client'` |
| Build succeeds, runtime crashes with "config is undefined" | `serverRuntimeConfig`/`publicRuntimeConfig` removed | Replace with `process.env.*`; use `connection()` from `next/server` if you need runtime (not build-time) env reads |
| Server-rendered HTML shows code that doesn't exist in source | **Stale `.next/` build cache** (one of the most underdiagnosed) | `rm -rf .next && next dev` |

---

## Deep dive: Async Request APIs

This is the single largest source of post-upgrade bugs. The rule is simple — every "request-shaped" thing is now a Promise — but the implications spread across the codebase.

### Where the change applies

- `cookies()` and `headers()` from `next/headers` → both return Promises
- `draftMode()` from `next/headers` → returns a Promise
- `params` and `searchParams` props in `page.tsx`, `layout.tsx`, `route.ts`, `default.tsx`, `generateMetadata`, `opengraph-image`, `twitter-image`, `icon`, `apple-icon`
- `params` and `id` in dynamic image generation (`opengraph-image`, `twitter-image`, etc.)
- `id` in `sitemap.tsx` when generated via `generateSitemaps`

### Type helpers (use these, not handwritten generics)

```bash
npx next typegen
```

This emits `PageProps`, `LayoutProps`, `RouteContext` globally:

```tsx
export default async function Page(props: PageProps<'/blog/[slug]'>) {
  const { slug } = await props.params
  const search = await props.searchParams
  // ...
}
```

```tsx
export async function GET(_req: Request, ctx: RouteContext<'/api/users/[id]'>) {
  const { id } = await ctx.params
  // ...
}
```

### Common mistake: `setTimeout`/`setInterval` around request APIs

`cookies()` and `headers()` rely on async context that's bound to the current call stack. Calling them inside a timer breaks the binding:

```ts
// Wrong — async context is lost by the time the callback runs
export async function GET() {
  setTimeout(async () => {
    const c = await cookies() // throws DynamicServerError
  }, 100)
}

// Right — read first, then defer
export async function GET() {
  const c = await cookies()
  setTimeout(() => {
    // use c here
  }, 100)
}
```

### Common mistake: forgetting `await` in a child function

```ts
// Wrong
async function getSessionUser(cookieStore: ReadonlyRequestCookies) {
  return db.users.find({ where: { id: cookieStore.get('uid')?.value } })
}
export default async function Page() {
  const user = await getSessionUser(cookies()) // passing a Promise as if it were a value
}

// Right
export default async function Page() {
  const cookieStore = await cookies()
  const user = await getSessionUser(cookieStore)
}
```

---

## Deep dive: Cache Components & PPR

The mental model is **inverted from Next 14/15**: with `cacheComponents: true`, every component is dynamic unless you opt in to caching. Static parts must be wrapped or marked.

```ts
// next.config.ts
const nextConfig: NextConfig = { cacheComponents: true }
```

### Opting into caching

```tsx
// Mark a function or component as cached
'use cache'
export async function getAllProducts() {
  return db.products.findMany()
}
```

```tsx
import { cacheLife, cacheTag } from 'next/cache' // no unstable_ prefix in 16

async function getProduct(id: string) {
  'use cache'
  cacheLife('days')
  cacheTag(`product-${id}`)
  return db.products.findFirst({ where: { id } })
}
```

### The `<Suspense>` requirement

When `cacheComponents` is on, dynamic data accessed outside `<Suspense>` produces the error `Uncached data was accessed outside of <Suspense>`. The framework needs the Suspense boundary to know where to stream the dynamic part:

```tsx
// Wrong — dynamic data in a static-rendered page with no Suspense
export default async function Page() {
  const cookieStore = await cookies()
  return <div>Hello {cookieStore.get('name')?.value}</div>
}

// Right — wrap the dynamic part
export default function Page() {
  return (
    <div>
      <h1>Welcome</h1>
      <Suspense fallback={<span>Loading…</span>}>
        <Greeting />
      </Suspense>
    </div>
  )
}

async function Greeting() {
  const cookieStore = await cookies()
  return <>Hello {cookieStore.get('name')?.value}</>
}
```

### `revalidateTag` vs `updateTag` vs `refresh`

These were unified in Next 16 with clear semantics — pick the right one:

- `revalidateTag(tag, lifeProfile)` — stale-while-revalidate. Users see the old data while fresh data loads. Use for blog posts, catalogs, docs.
- `updateTag(tag)` — read-your-writes. Cache expires immediately, user sees their update on next render. Server Actions only. Use for forms, settings, anything interactive.
- `refresh()` — refresh the client router from a Server Action without invalidating cache tags.

### Debugging cache misses

When something seems "stuck on old data":
1. Check if the function has `'use cache'` — if so, it's cached
2. Check the `cacheTag` — is anything invalidating it?
3. Check `cacheLife` — is the profile too long?
4. Search for `revalidateTag(...)` calls — are they passing the right tag string?
5. Try `updateTag()` if the user expects to see their own write immediately

### `next build --debug-prerender`

When a build fails with an opaque "blocking-route" or "Uncached data" error and you can't tell which component, run:
```bash
next build --debug-prerender
```
This emits prerender stack traces naming the exact component.

---

## Deep dive: Turbopack vs Webpack

### When to opt back to webpack

`next build --webpack` is the escape hatch. Use it when:
- You have a custom webpack plugin with no Turbopack equivalent
- You're using a legacy CSS-in-JS library (Emotion v10-, styled-components v5-)
- You depend on module federation
- A loader is in the [known-incompatible list](https://nextjs.org/docs/app/api-reference/config/next-config-js/turbopack)

Don't use it as a habit — Turbopack is the future direction, and `next dev --webpack` runs noticeably slower.

### Config layout change

```ts
// Old (Next 15)
const nextConfig = { experimental: { turbopack: { /* options */ } } }

// New (Next 16) — top-level
const nextConfig = { turbopack: { /* options */ } }
```

### Sass

- `@import '~package/file.scss'` → `@import 'package/file.scss'` (drop the tilde)
- If you can't change imports: `turbopack: { resolveAlias: { '~*': '*' } }`

### Filesystem cache (beta)

For faster cold starts in dev:
```ts
const nextConfig: NextConfig = {
  experimental: { turbopackFileSystemCacheForDev: true },
}
```
Note this can roughly double memory usage in dev — disable if you hit OOM on a constrained machine.

### Common Turbopack error: `Module not found: Can't resolve 'fs'`

This means client-side code imports a module that uses Node built-ins. Webpack used to silence this with `resolve.fallback`; Turbopack surfaces it. The right fix is to stop importing the module in client code (move the logic to a Server Component or a Route Handler). The wrong-but-quick fix is:

```ts
turbopack: { resolveAlias: { fs: { browser: './empty.ts' } } }
```

Where `empty.ts` exports an empty default. Treat this as a marker that something needs refactoring.

---

## Deep dive: `middleware` → `proxy` migration

### When to migrate

If you don't need the Edge runtime, migrate. If you deploy to Cloudflare Pages, **don't** — `proxy.ts` is Node-only and Cloudflare Pages requires Edge.

### The mechanical migration

```bash
mv middleware.ts proxy.ts
```

Inside the file:
```ts
// Before
export function middleware(request: NextRequest) { /* ... */ }
export const config = { matcher: ['/protected/:path*'] }

// After
export function proxy(request: NextRequest) { /* ... */ }
export const config = { matcher: ['/protected/:path*'] }
```

In `next.config`:
```ts
// Before
const nextConfig = { skipMiddlewareUrlNormalize: true }

// After
const nextConfig = { skipProxyUrlNormalize: true }
```

The codemod handles all of the above.

### Conceptual shift

The rename also signals an intended split:
- `proxy.ts` — network-layer concerns: URL rewrites, header injection, geo-routing, A/B variant assignment via cookie
- Route handlers / layouts / Server Actions — auth checks, session validation, business logic

Auth in a layout or a wrapping Server Component is now the recommended pattern, not in `proxy.ts`.

### Better Auth context (Fahim's stack)

Better Auth recommends doing session validation in layouts or Server Components rather than in middleware/proxy. The `proxy.ts` runs on Node.js, so Better Auth's full server SDK works there — but the framework recommendation is to keep `proxy.ts` for routing concerns and put auth logic in the route boundary itself.

---

## Deep dive: Hydration errors in Next 16

React 19 (used by Next 16) **throws** on hydration mismatch instead of warning. The new dev overlay also shows a side-by-side server/client diff that points at the exact element — read it before guessing.

### The official five causes

1. Incorrect HTML nesting (`<a>` inside `<a>`, `<button>` inside `<button>`, `<p>` containing `<div>`)
2. `typeof window !== 'undefined'` checks in render
3. `window` / `localStorage` / `navigator` in render
4. `Date()` / `Math.random()` / `Date.now()` in render
5. Edge/CDN modifying the HTML response (Cloudflare Auto Minify, ad injectors)

### The sixth cause (the one to remember)

**Stale `.next/` cache.** When the server renders code that doesn't exist anywhere in your current source, the issue is the build cache, not your components. Fix:
```bash
rm -rf .next && next dev
```
This costs ~10 seconds and resolves the issue when it applies. Try it before re-reading your components.

### The seventh cause specific to Next 16

**PPR (`cacheComponents: true`) without `<Suspense>` boundaries.** The static shell ships without dynamic data; the client expects the data. Wrap dynamic components in `<Suspense>` with a fallback that matches the shape of the eventual content.

### Diagnostic checklist

In order:
1. Read the overlay — it usually names the element
2. Search the source for the server-rendered string. If not found → stale cache, run `rm -rf .next`
3. Check for timezone-dependent rendering (`toLocaleDateString` without a locale, `Date.now()` in render)
4. Check for `typeof window` guards in render paths
5. Check for unsanitized third-party scripts (ad networks, analytics) modifying the DOM before hydration
6. Check `<html>` and `<body>` for browser-extension-injected attributes (`suppressHydrationWarning` on `<html>` is acceptable for this)
7. If using PPR/`cacheComponents`, verify every dynamic-data branch is inside a `<Suspense>`

### Surgical `suppressHydrationWarning`

Apply at the leaf, never the root, unless you're handling `<html>`-level browser-extension noise:

```tsx
<span suppressHydrationWarning>{new Date().toLocaleString()}</span>
```

This suppresses the *error* without suppressing the underlying mismatch — the client will still re-render. It's a cosmetic fix; the real fix is to render the same content on server and client.

---

## Anti-patterns to avoid

These are mistakes that pattern-matching to old training data tends to produce. Notice when you're about to do one and pause:

1. **Suggesting `const cookieStore = cookies()` in Next 16.** That's the Next 14 pattern. The 16 pattern is `await cookies()`. If the error message says "sync dynamic APIs," this is what's happening.

2. **Renaming `middleware.ts` to `proxy.ts` on a Cloudflare Pages project.** `proxy.ts` is Node-only; Cloudflare needs Edge. Keep `middleware.ts`.

3. **Recommending `experimental.ppr: true`.** That flag is gone. The replacement is top-level `cacheComponents: true`.

4. **Calling `revalidateTag('tag')` with one argument.** Now requires a cacheLife profile, e.g. `revalidateTag('tag', 'max')`. Single-arg is a TypeScript error.

5. **Adding `images.domains: [...]` to fix a remote image.** Deprecated. Use `images.remotePatterns: [{ protocol: 'https', hostname: '...' }]`.

6. **Suggesting `next lint` or adding the `eslint` key to `next.config`.** Both removed. Use ESLint CLI directly.

7. **Treating `process.argv.includes('dev')` as truthy in `next.config`.** Next 16 no longer loads the config twice during `next dev`, so this returns `false`. Use `process.env.NODE_ENV === 'development'` or the `phase` argument.

8. **Importing from `'next/legacy/image'`.** Removed. Use `next/image`.

9. **Reaching for `unstable_cache` / `unstable_cacheLife` / `unstable_cacheTag`.** The stable versions exist now — drop the prefix on imports.

10. **Spreading `params` (`{...params}`) or iterating `headers()` directly.** Both count as sync access. Always `await` first.

11. **Guessing at config without reading `next.config.{ts,js,mjs}`.** The file tells you whether `cacheComponents`, `reactCompiler`, or other flags are on — without it your hypotheses are unanchored.

12. **Skipping `rm -rf .next` before declaring a "real bug."** Stale build artifacts are a common cause of weird, source-doesn't-match-output behavior. Try the clean build before deep investigation.

13. **Trusting that "it worked in 15" means "it works in 16."** Async APIs, image defaults, parallel route defaults, `next lint`, and the bundler all changed. Verify against this skill's tables.

---

## Checklist: pre-deploy after a Next.js 16 upgrade

Run through this list before pushing the upgrade to production:

- `package.json`: `next` is 16.x, `react`/`react-dom` are matching versions, Node engine is `>=20.9`
- Codemod has been run: `npx @next/codemod@canary upgrade latest`
- All `params`/`searchParams`/`cookies()`/`headers()`/`draftMode()` callsites are awaited
- `npx next typegen` has been run; `PageProps`/`LayoutProps`/`RouteContext` are in use
- `middleware.ts` is renamed to `proxy.ts` and exports `proxy` — OR kept as `middleware.ts` intentionally for Edge runtime (e.g. Cloudflare Pages)
- `next.config.ts`: `turbopack` is top-level (not under `experimental`), `cacheComponents` is set if using PPR, no `serverRuntimeConfig`/`publicRuntimeConfig`/`amp`/`eslint`
- All `revalidateTag(...)` calls have a second argument (cacheLife profile)
- All `@slot` parallel route folders have a `default.tsx`
- `next/legacy/image` imports removed
- `images.domains` migrated to `images.remotePatterns`
- `images.qualities` includes every quality your `next/image` components pass
- `images.localPatterns` includes any local images using query strings
- `next build` succeeds locally with a clean `.next/` (`rm -rf .next && next build`)
- Vercel/Cloudflare env vars include any new ones added during migration
- For Cloudflare Pages: verify Edge runtime still works (didn't accidentally introduce Node-only APIs); DB driver is `@neondatabase/serverless`

---

## Reference files

- `references/async-apis.md` — exhaustive catalog of async API call sites with before/after patterns
- `references/cache-components.md` — Cache Components recipes, `use cache` directive patterns, when to use `revalidateTag` vs `updateTag` vs `refresh`
- `references/turbopack-compat.md` — known incompatible loaders, common Turbopack errors, how to migrate webpack configs
- `references/proxy-vs-middleware.md` — deeper migration guide including Cloudflare/Edge runtime tradeoffs
- `references/hydration-deep-dive.md` — all known hydration causes with code-level diagnostics for each
