# Overlays

Modals, drawers, toasts, popovers, tooltips, alerts, banners. Anything that sits above the main content.

## Z-index scale

Pick a scale and stick to it across the project. Recommended:

| Layer | Class | Use for |
|---|---|---|
| Base | (none) | Normal content |
| Sticky UI | `z-30` | Sticky table headers, sticky section headings |
| Header / nav | `z-40` | Sticky/fixed navbar |
| Drawer / off-canvas | `z-40` or `z-50` | Mobile menu (above nav), regular drawer (above content) |
| Modal | `z-50` | Dialogs, alerts |
| Popover / dropdown | `z-50` | Menus, tooltips when not portaled |
| Toast | `z-[60]` | Above everything except modals' own toast layer |

The rule: anything that demands user attention beats anything sticky. Modals beat headers; toasts beat both.

## Modal — hand-rolled (only when you can't use Radix/shadcn)

For production, use Radix Dialog or shadcn Dialog. They handle focus trap, `inert` on background, ARIA attributes, ESC close, body scroll lock. Hand-rolled modals miss at least one of these by default.

If you must hand-roll:

```tsx
"use client";
import { useEffect } from "react";
import { X } from "lucide-react";

export default function Modal({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}) {
  // Body scroll lock
  useEffect(() => {
    if (!open) return;
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = original; };
  }, [open]);

  // ESC to close
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      {/* Backdrop — separate element so panel clicks don't trigger close */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        aria-hidden="true"
      />

      {/* Panel */}
      <div className="relative z-10 w-full max-w-md rounded-2xl border border-neutral-800 bg-neutral-950 shadow-2xl">
        <div className="flex items-center justify-between gap-4 border-b border-neutral-800 px-5 py-4">
          <h2 id="modal-title" className="text-lg font-semibold">{title}</h2>
          <button
            onClick={onClose}
            className="rounded p-1 text-neutral-400 hover:bg-neutral-900 hover:text-white"
            aria-label="Close"
          >
            <X className="size-4" />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}
```

What's NOT in this implementation but should be in production:

- **Focus trap**: when modal opens, focus moves into the modal; Tab stays inside; on close, focus returns to the trigger. Use `focus-trap-react` or Radix.
- **`inert` on background**: prevents screen readers and Tab from reaching the page underneath. Radix handles this.
- **Initial focus**: the first focusable element in the modal should receive focus on open (or a specifically nominated element like a Cancel button for destructive actions).

This is why "use Radix" is the recommendation. Reimplementing this correctly is a half-day of accessibility work.

## Modal — with shadcn (recommended)

```tsx
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

<Dialog>
  <DialogTrigger asChild>
    <button>Open</button>
  </DialogTrigger>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>Title</DialogTitle>
    </DialogHeader>
    <p>Content</p>
  </DialogContent>
</Dialog>
```

## Confirmation dialog (destructive action)

```tsx
<Dialog open={open} onOpenChange={setOpen}>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>Delete this item?</DialogTitle>
      <DialogDescription>
        This action cannot be undone. The item will be permanently removed.
      </DialogDescription>
    </DialogHeader>
    <DialogFooter className="gap-2 sm:gap-2">
      <button onClick={() => setOpen(false)} className="rounded-md border border-neutral-800 bg-neutral-900 px-4 py-2 text-sm hover:bg-neutral-800">
        Cancel
      </button>
      <button onClick={handleDelete} className="rounded-md bg-red-500 px-4 py-2 text-sm font-medium text-white hover:bg-red-600">
        Delete
      </button>
    </DialogFooter>
  </DialogContent>
</Dialog>
```

For destructive actions, the default-focused button should be Cancel, not Delete. Prevents accidental destruction from a stray Enter press.

## Side drawer / sheet

The mobile drawer pattern in `patterns/navigation.md` is the same primitive — adapt for any side, any width.

```tsx
{/* Right-side drawer for filters, details, edit panels */}
<div
  className={`fixed inset-y-0 right-0 z-50 w-96 max-w-[90vw] border-l border-neutral-800 bg-neutral-950 shadow-2xl transition-transform ${
    open ? "translate-x-0" : "translate-x-full"
  }`}
>
  {/* content */}
</div>
```

Same four requirements as modals: backdrop, scroll lock, ESC handler, focus management. For production, use Radix Dialog with custom positioning, or `vaul` library, or shadcn Sheet.

## Toast / notification

For production: `sonner` library or `react-hot-toast`. Both handle stacking, dismissal, accessibility.

Visual pattern of a single toast:

```tsx
<div
  role="status"
  className="pointer-events-auto flex w-full max-w-sm items-start gap-3 rounded-lg border border-neutral-800 bg-neutral-950 p-4 shadow-lg"
>
  <CheckCircle2 className="size-5 shrink-0 text-green-400" />
  <div className="flex-1 min-w-0">
    <p className="text-sm font-medium">Saved successfully</p>
    <p className="mt-1 text-xs text-neutral-400">Your changes are now live.</p>
  </div>
  <button className="shrink-0 rounded p-1 text-neutral-400 hover:bg-neutral-900 hover:text-white" aria-label="Dismiss">
    <X className="size-4" />
  </button>
</div>
```

Container for the toast stack (fixed position):

```tsx
<div
  className="pointer-events-none fixed inset-x-0 bottom-0 z-[60] flex flex-col items-end gap-2 p-4 sm:items-end"
  aria-live="polite"
  aria-atomic="false"
>
  {/* toasts */}
</div>
```

- `pointer-events-none` on the container so clicks pass through to the page when no toast is at that position; `pointer-events-auto` on each toast restores interactivity.
- `aria-live="polite"` so screen readers announce new toasts without interrupting.
- `z-[60]` above modals (modals are `z-50`).

## Inline alert / banner

```tsx
{/* Info */}
<div role="alert" className="flex gap-3 rounded-lg border border-blue-500/30 bg-blue-500/10 p-4">
  <Info className="size-5 shrink-0 text-blue-400" />
  <div className="text-sm text-blue-200">
    <p className="font-medium">Heads up</p>
    <p className="mt-1 text-blue-300/80">
      Something informational that doesn&apos;t block the user.
    </p>
  </div>
</div>

{/* Success */}
<div role="alert" className="flex gap-3 rounded-lg border border-green-500/30 bg-green-500/10 p-4">
  <CheckCircle2 className="size-5 shrink-0 text-green-400" />
  <p className="text-sm text-green-200">Changes saved.</p>
</div>

{/* Warning */}
<div role="alert" className="flex gap-3 rounded-lg border border-amber-500/30 bg-amber-500/10 p-4">
  <AlertTriangle className="size-5 shrink-0 text-amber-400" />
  <p className="text-sm text-amber-200">Your trial ends in 3 days.</p>
</div>

{/* Error */}
<div role="alert" className="flex gap-3 rounded-lg border border-red-500/30 bg-red-500/10 p-4">
  <AlertCircle className="size-5 shrink-0 text-red-400" />
  <p className="text-sm text-red-200">Something went wrong. Please try again.</p>
</div>
```

`shrink-0` on the icon so it doesn't compress when the message is long. `role="alert"` makes screen readers announce it on appearance.

## Top-of-page banner (announcement)

```tsx
<div className="relative bg-violet-500 text-white">
  <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-2.5 text-sm sm:px-6 lg:px-8">
    <div className="flex items-center gap-2">
      <span className="font-medium">New: Voice notes are live.</span>
      <a href="/changelog" className="underline underline-offset-2 hover:no-underline">
        See what&apos;s new →
      </a>
    </div>
    <button className="shrink-0 rounded p-1 hover:bg-white/10" aria-label="Dismiss">
      <X className="size-4" />
    </button>
  </div>
</div>
```

Place above the navbar in the layout. For dismissible banners, persist dismissal in `localStorage` (read inside `useEffect` to avoid hydration mismatch).

## Tooltip

Hand-rolled tooltips are fragile. Use Radix Tooltip or shadcn for anything that needs proper positioning (collision detection, edge avoidance).

Visual pattern of the tooltip itself:

```tsx
<div className="rounded-md bg-neutral-800 px-2 py-1 text-xs text-white shadow-lg">
  Helpful text
</div>
```

For a quick CSS-only tooltip on a button (no library, no positioning intelligence):

```tsx
<div className="group relative inline-block">
  <button className="rounded p-1.5 hover:bg-neutral-900">
    <Info className="size-4" />
  </button>
  <div className="pointer-events-none absolute bottom-full left-1/2 mb-2 -translate-x-1/2 whitespace-nowrap rounded-md bg-neutral-800 px-2 py-1 text-xs text-white opacity-0 shadow-lg transition-opacity group-hover:opacity-100">
    Helpful text
  </div>
</div>
```

Limitations: no edge collision detection (the tooltip will overflow on screen edges), no keyboard support. Fine for low-stakes hints; not fine for required information.

## Popover

Same story as tooltips and dropdowns — for production, use Radix Popover. It portals to `<body>`, handles positioning, click-outside, focus management.

Visual structure of a popover panel:

```tsx
<div className="w-72 rounded-lg border border-neutral-800 bg-neutral-950 p-4 shadow-xl">
  <h4 className="text-sm font-semibold">Filter by status</h4>
  <div className="mt-3 space-y-2">
    {/* checkboxes */}
  </div>
  <div className="mt-4 flex justify-end gap-2">
    <button className="text-sm text-neutral-400">Clear</button>
    <button className="rounded bg-violet-500 px-3 py-1 text-sm text-white">Apply</button>
  </div>
</div>
```

## Context menu (right-click)

```tsx
"use client";
import { useState, useRef, useEffect } from "react";

export default function ContextMenuArea({ children }: { children: React.ReactNode }) {
  const [menu, setMenu] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => {
    if (!menu) return;
    const close = () => setMenu(null);
    window.addEventListener("click", close);
    window.addEventListener("scroll", close, true);
    return () => {
      window.removeEventListener("click", close);
      window.removeEventListener("scroll", close, true);
    };
  }, [menu]);

  return (
    <div
      onContextMenu={(e) => {
        e.preventDefault();
        setMenu({ x: e.clientX, y: e.clientY });
      }}
    >
      {children}
      {menu && (
        <div
          className="fixed z-50 w-44 rounded-md border border-neutral-800 bg-neutral-900 py-1 shadow-xl"
          style={{ left: menu.x, top: menu.y }}
        >
          <button className="block w-full px-3 py-1.5 text-left text-sm hover:bg-neutral-800">Cut</button>
          <button className="block w-full px-3 py-1.5 text-left text-sm hover:bg-neutral-800">Copy</button>
          <button className="block w-full px-3 py-1.5 text-left text-sm hover:bg-neutral-800">Paste</button>
        </div>
      )}
    </div>
  );
}
```

Edge collision (menu near right/bottom of viewport overflows): clamp `menu.x` and `menu.y` against `window.innerWidth/innerHeight` minus menu dimensions. Or use Radix ContextMenu.

## Floating action button (FAB)

```tsx
<button
  className="fixed bottom-6 right-6 z-40 flex size-14 items-center justify-center rounded-full bg-violet-500 text-white shadow-lg hover:bg-violet-600"
  aria-label="New item"
>
  <Plus className="size-6" />
</button>
```

`z-40` puts it under modals (z-50) but above normal content. If the page has a sticky bottom bar, increase the `bottom-*` offset to clear it.
