# Vercel Deployment - Patterns and Gotchas

Vercel is the path of least resistance for Next.js. This reference covers
the few areas where it bites, especially when sharing a codebase with
Cloudflare.

## 1. Function Configuration

Vercel runs Next.js routes as either Serverless Functions (Node) or Edge
Functions (V8 isolate, Web APIs). Per-route override:

```ts
// app/api/heavy/route.ts
export const runtime = 'nodejs'    // Serverless, Node APIs allowed (default)
// or
export const runtime = 'edge'      // Edge Function, Web APIs only

export const maxDuration = 60      // Seconds, up to 300 on Pro/Ent
export const dynamic = 'force-dynamic'
```

### Timeout limits

| Plan | Default | Max configurable |
|---|---|---|
| Hobby | 10s | 60s |
| Pro | 15s | 300s |
| Enterprise | 15s | 900s |

A request that exceeds the limit returns a 504 with `FUNCTION_INVOCATION_TIMEOUT`.
Streaming responses (`new Response(stream)`) keep the connection open and don't
hit this until the stream ends, which is useful for long LLM completions.

### Edge bundle size

| Plan | Limit |
|---|---|
| Hobby | 1 MiB |
| Pro/Ent | 4 MiB |

If Cloudflare's bundle (3 MiB free, 10 MiB paid) accepts a build that
Vercel's Edge rejects, drop server-only deps from Edge routes or move them
to `runtime = 'nodejs'`.

## 2. Environment Variables

Three separate scopes in the dashboard:

- **Production** - applied to deploys from the production branch
- **Preview** - applied to deploys from all other branches and PRs
- **Development** - pulled by `vercel env pull` for local `.env.local`

A var added only to Production will be `undefined` in Preview deploys.
This is the single most common Vercel surprise. The pattern:

> "It works in prod but my PR preview is broken."

Always add new env vars to all three scopes unless you specifically want
divergence. Or use the "Apply to: All Environments" toggle when adding.

### Build-time vs runtime vars

`NEXT_PUBLIC_*` vars are inlined at build time. Changing one and redeploying
won't propagate unless the build re-runs - and Vercel's build cache may
skip the rebuild. Force a clean rebuild from the dashboard if a
`NEXT_PUBLIC_*` change doesn't appear.

Server-only vars (`DATABASE_URL`, etc.) are read at runtime per request -
changing them takes effect on next request, no rebuild needed.

### Pulling env locally

```sh
vercel env pull .env.local
```

Pulls Development env vars. For Preview or Production, pass `--environment`.

## 3. Build Cache

Vercel aggressively caches:
- `node_modules`
- `.next/cache`
- The full build output

When weird stale behavior appears after a code or env change:

1. Dashboard -> project -> Deployments -> most recent -> three-dot menu -> "Redeploy" -> uncheck "Use existing Build Cache"
2. Or push an empty commit: `git commit --allow-empty -m "force rebuild" && git push`

Build cache misses also happen automatically when:
- `package.json` changes
- `next.config.*` changes
- Node version changes

## 4. Region and Cold Starts

Default region: Washington, D.C. (`iad1`). Override per route or globally:

```ts
// app/api/foo/route.ts
export const preferredRegion = 'fra1' // Frankfurt
```

For dual-deploy with Cloudflare (which is everywhere by default), think
about which side a user hits and configure region accordingly. Vercel's
Edge Functions run in many regions automatically; Serverless Functions
do not.

Cold starts on Serverless: 200ms-2s for typical Next.js routes. Edge
Functions cold-start much faster (~10ms) but with the runtime constraints.

## 5. Preview Deploys

Every push to a non-production branch gets a unique URL. Useful for QA
before merging.

- Password protection: Pro feature, set in Project Settings -> Deployment Protection
- Custom domain on Preview: Pro/Ent, alias a domain to specific branches
- Authentication required by default: yes, requires Vercel team login unless protection is off

## 6. Analytics and Speed Insights

`@vercel/analytics` and `@vercel/speed-insights` work on Vercel deploys.
On Cloudflare they are no-ops (the script can't post back to the Vercel
endpoint reliably). Either:

- Accept this and use them as Vercel-only signals
- Replace with platform-agnostic alternatives (Plausible, PostHog, Umami)

```tsx
// app/layout.tsx
import { Analytics } from '@vercel/analytics/react'

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html>
      <body>
        {children}
        {process.env.VERCEL && <Analytics />}
      </body>
    </html>
  )
}
```

The `process.env.VERCEL` check prevents the script from loading on Cloudflare
deploys, which is a small but real bandwidth save.

## 7. Vercel-Specific Storage and Why to Avoid in Dual-Deploy

- `@vercel/postgres` - works only on Vercel. Use raw Neon or Supabase clients instead.
- `@vercel/kv` - works only on Vercel. Use Upstash Redis (HTTP-based, works on both) instead.
- `@vercel/blob` - works only on Vercel. Use Cloudflare R2 with the S3 API, or UploadThing.

If the project must use these, gate them:

```ts
const isVercel = !!process.env.VERCEL
if (isVercel) {
  const { kv } = await import('@vercel/kv')
  // ...
}
```

But the cleaner answer is: pick storage that works on both platforms.

## 8. `vercel.json` for Cross-Platform Sanity

```json
{
  "framework": "nextjs",
  "buildCommand": "next build",
  "installCommand": "pnpm install",
  "functions": {
    "app/api/heavy/route.ts": { "maxDuration": 60 }
  }
}
```

Pinning `framework: "nextjs"` prevents Vercel from misdetecting the project
as something else (rare, but happens with custom configs).

## 9. Common Vercel Errors

| Error / Symptom | Cause | Fix |
|---|---|---|
| `FUNCTION_INVOCATION_TIMEOUT` | Route exceeded plan timeout | Stream, paginate, or move to background |
| `EDGE_FUNCTION_INVOCATION_FAILED` | Edge runtime crash | Check `wrangler tail`-equivalent: Vercel logs in dashboard |
| `NO_DEPLOYMENT_AVAILABLE` | Domain points to a deleted deploy | Reassign domain in Project Settings |
| `BODY_NOT_A_STRING_FROM_FUNCTION` | Returned wrong type from a Function | Return `Response` or `NextResponse` consistently |
| Build OK but preview shows old content | Build cache | Redeploy without cache |
| `NEXT_PUBLIC_X is undefined` in browser | Var added after last build | Redeploy after adding |
| PR preview crashes, prod works | Env var missing from Preview scope | Add to Preview |
| `Module not found` after a refactor | Build cache holding stale `.next/cache` | Redeploy without cache |
