---
name: motion-hive
description: >
  Project-wide motion and microinteraction audit for Fahim's stack (Next.js App Router,
  Tailwind CSS, Framer Motion, shadcn/ui, Radix primitives, dark-first palette).
  ALWAYS run BEFORE Airborne as a mandatory pre-flight gate.
  Scans every component and page, identifies animation gaps and broken transitions,
  and applies principled motion mechanics using the actual stack in use.
  Trigger on: "run motion-hive", "motion audit", "polish animations", "fix transitions",
  "animate this", "add hover states", "microinteractions", "feels janky", "UI feels flat",
  "add motion", "make it feel alive", or any request about easing, responsiveness, or UI sensation.
  Also fires automatically when Airborne completes — motion-hive runs FIRST, Airborne runs SECOND.
---

# motion-hive

Motion audit and microinteraction polish for the full codebase. Finds every interactive
element, broken transition, missing hover state, and animation opportunity — then fixes
all of it using the project's actual stack.

---

## Workflow

### Step 0 — Read context first
Before scanning any code, read these files if they exist:
- `PLANNER.md` — understand routes, features, and component inventory
- `DESIGN_GUIDE.md` — understand the design system, palette, and brand personality
- `BRAIN.md` — understand the product's emotional target (is it crisp/professional, playful, premium?)

The product's personality determines motion defaults. A SaaS dashboard → crisp, fast, minimal.
A consumer-facing landing page → slightly more expressive. Never pick motion values without knowing the mood.

### Step 1 — Project scan
Recursively scan these directories (skip `node_modules`, `.next`, `dist`):
```
/app          → pages, layouts, route segments
/components   → UI primitives and feature components
/lib, /hooks  → animation utilities, custom hooks
/styles       → global CSS, Tailwind config, CSS variables
```

Build a complete component inventory. For each file found, record:
- **Component type**: button / modal / drawer / toast / tooltip / dropdown / card / nav / form / skeleton / marketing section
- **Current motion state**: `none` / `partial` / `broken` / `good`
- **Issues found**: list of specific violations (see Review Checklist)
- **Priority**: `high` (interactive primitives used everywhere) / `medium` (page-level) / `low` (decorative)

### Step 2 — Audit output
Print the full audit as a markdown table before touching any code:

| File | Component | Motion State | Issues | Priority |
|------|-----------|-------------|--------|----------|
| `components/ui/button.tsx` | Button | partial | `transition: all`, no `:active` scale | high |
| `components/ui/dialog.tsx` | Modal | broken | `scale(0)` entry, `ease-in` exit | high |
| `app/(dashboard)/page.tsx` | Card grid | none | No stagger on list render | medium |

Always print this table and wait — do not start applying fixes until you have shown the full audit.
If working autonomously (no pause), order fixes by priority: high → medium → low.

### Step 3 — Apply fixes
Work file by file. For every change made, output a Before/After table:

| Before | After | Why |
|--------|-------|-----|
| `transition: all 300ms` | `transition: transform 200ms, opacity 200ms` | Never use `all`; specify exact properties |
| `scale(0)` entry | `scale(0.95) + opacity: 0` | Nothing in reality appears from absolute nothing |
| `ease-in` on dropdown | `cubic-bezier(0.23, 1, 0.32, 1)` | `ease-in` starts slow — the exact moment users are watching |
| No `:active` state | `active:scale-[0.97]` (Tailwind) | Buttons must confirm the press |

### Step 4 — Summary report
After all fixes, print:
- Total files changed
- Components upgraded
- Anti-patterns removed
- Any components skipped and why (e.g., already `good`, or animation should be explicitly absent)
- Handoff note for Airborne: "motion-hive complete — Airborne is clear to run"

---

## Pipeline Position

```
[Build / Feature complete]
        ↓
  [Waterborne]       ← emoji sweep
        ↓
  [motion-hive]      ← motion audit  ← YOU ARE HERE
        ↓
  [valley-of-death]  ← spec vs code audit
        ↓
  [Airborne]         ← SEO pass
        ↓
  [Council]          ← final verdict
```

motion-hive must complete before Airborne. SEO content depends on pages being visually
finished — an unpolished page with broken transitions should not be crawled yet.

motion-hive also makes one more appearance, much later — a small scoped touch-up after
cave-man runs (just before Council POST). That pass is not a full re-audit, it only
applies skeleton-shimmer treatment to the handful of new `data-image-slot` placeholder
elements cave-man just inserted. Everything else on the page has already been audited
once and should not be re-checked.

---

## Core Philosophy

### Unseen details compound

Most details users never consciously notice. That is the point. When an interaction works
exactly as someone expects, they proceed without a second thought. The goal is not to impress
users with motion — it is to make them feel at ease without knowing why.

Every invisible-but-correct decision stacks. A button that scales on press. A modal that
eases out instead of in. A tooltip that skips its animation when one is already open. None
of these are noticed individually. Together, they produce an interface that feels alive.

### Beauty is leverage

In a market where everyone's SaaS has the same Tailwind cards and Inter font, micro-motion
is a differentiator. People select tools based on the overall experience, not just features.
Polish is not vanity — it is a competitive advantage.

### Motion has a mood

Match motion to the product's personality:
- **Dark SaaS dashboard** → crisp, fast (150-200ms), no bounce, custom `ease-out`
- **Consumer landing page** → slightly expressive, stagger on section reveals
- **Minimal/editorial** → almost no motion except essential feedback

Read `BRAIN.md § Visual Identity (Locked)` (or `DESIGN_GUIDE.md`) for the project palette before writing any motion code. Use CSS utility aliases (`bg-surface`, `text-accent`, `ring-accent/20`) — never `bg-[#131720]` or `ring-[#00e676]/20`. Motion should be tight and deliberate. Any animation that overstays its welcome undercuts the premium feel.

---

## The Animation Decision Framework

Before writing a single line of animation code, answer these four questions in order.

### 1 — Should this animate at all?

| Usage frequency | Decision |
|----------------|----------|
| 100+ times/day (command palette, keyboard nav, search toggle) | No animation. Ever. |
| Tens of times/day (hover states, list navigation, tab switches) | Remove or cut to ≤100ms |
| Occasional (modals, drawers, toasts, notifications) | Standard animation |
| Rare / first-time (onboarding, celebration, feedback) | Can add delight |

**Never animate keyboard-triggered actions.** Keyboard users repeat actions hundreds of
times per session. A 200ms modal open feels fine with a mouse click; it feels like lag
with `⌘K`. Detect keyboard intent and skip the animation:

```tsx
// Detect keyboard vs. pointer trigger
const [openedWithKeyboard, setOpenedWithKeyboard] = useState(false);

<Button
  onKeyDown={() => setOpenedWithKeyboard(true)}
  onMouseDown={() => setOpenedWithKeyboard(false)}
  onClick={() => setOpen(true)}
/>

// Pass to animation: duration 0 when keyboard
<motion.div
  animate={{ opacity: 1, scale: 1 }}
  transition={{ duration: openedWithKeyboard ? 0 : 0.15 }}
/>
```

### 2 — What is the purpose?

Every animation needs a clear answer to "why does this move?"

Valid purposes:
- **Spatial consistency** — toast enters/exits from the same edge, making swipe-to-dismiss intuitive
- **State indication** — a button morphs to a checkmark, confirming an action was received
- **Feedback** — scale on press tells the user the interface heard them
- **Orientation** — a drawer slides from the right, establishing it lives "to the right"
- **Prevention of jarring cuts** — elements appearing with no transition feel broken

If the only answer is "it looks cool" and the user sees it often: remove it.

### 3 — What easing should it use?

```
Is the element entering or leaving the screen?
  → ease-out  (starts fast, feels responsive)

Is the element moving or morphing while already on screen?
  → ease-in-out  (natural acceleration/deceleration)

Is it a hover state, color, or shadow change?
  → ease  (symmetric, smooth)

Is it constant motion (marquee, progress bar, spinner)?
  → linear

Default for UI interactions?
  → ease-out
```

**Never use `ease-in` on UI elements.** It starts slow — the exact moment the user is
watching most carefully. A 200ms dropdown with `ease-in` *feels* slower than a 200ms
dropdown with `ease-out` because the initial movement is delayed.

**Always use custom easing curves.** The CSS built-ins are too weak:

```css
:root {
  /* Strong ease-out for UI interactions — the default */
  --ease-out: cubic-bezier(0.23, 1, 0.32, 1);

  /* Strong ease-in-out for on-screen movement */
  --ease-in-out: cubic-bezier(0.77, 0, 0.175, 1);

  /* Drawer / bottom-sheet curve */
  --ease-drawer: cubic-bezier(0.32, 0.72, 0, 1);

  /* Subtle ease for hover color/shadow changes */
  --ease-subtle: cubic-bezier(0.4, 0, 0.2, 1);
}
```

In Tailwind config:
```js
// tailwind.config.ts
theme: {
  extend: {
    transitionTimingFunction: {
      'ui-out':    'cubic-bezier(0.23, 1, 0.32, 1)',
      'ui-inout':  'cubic-bezier(0.77, 0, 0.175, 1)',
      'drawer':    'cubic-bezier(0.32, 0.72, 0, 1)',
    },
  },
}
```

### 4 — How fast should it be?

| Element | Duration |
|---------|----------|
| Button press / active feedback | 100–160ms |
| Tooltips, small badges | 125–200ms |
| Dropdowns, selects, popovers | 150–250ms |
| Modals, sheets | 200–350ms |
| Drawers (bottom/side) | 280–450ms |
| Marketing / scroll reveal | Up to 600ms |

**Hard rule: UI interactions stay under 300ms.** If an interaction requires more than
300ms to feel natural, the problem is the easing, not the duration.

### Perceived performance

Speed in animation directly affects how users perceive the *entire app's* performance:
- A faster-spinning skeleton makes loading feel shorter even at identical load times
- A 180ms dropdown feels more capable than a 400ms dropdown
- `ease-out` at 200ms feels faster than `ease-in` at 200ms — initial movement is everything

---

## Stack Implementation

### Tailwind utility mapping

```tsx
// Button — press feedback
<button className="transition-transform duration-150 ease-out active:scale-[0.97]">

// Card — hover lift
<div className="transition-[transform,shadow] duration-200 ease-out hover:-translate-y-0.5 hover:shadow-lg">

// Fade + rise (content entering)
<div className="animate-in fade-in slide-in-from-bottom-2 duration-300">

// Fade + sink (content leaving)
<div className="animate-out fade-out slide-out-to-bottom-2 duration-200">
```

Use `tailwindcss-animate` (comes with shadcn/ui) for `animate-in` / `animate-out` utilities.

**Never use `transition-all`.** Always specify exact properties:
```tsx
// Bad
className="transition-all duration-300"

// Good
className="transition-[transform,opacity] duration-200 ease-out"
```

### Framer Motion patterns (Next.js App Router)

```tsx
// Page-level entrance (layout.tsx)
<motion.main
  initial={{ opacity: 0, y: 6 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
>
  {children}
</motion.main>

// List stagger
const container = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.05 }
  }
}
const item = {
  hidden: { opacity: 0, y: 8 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.25, ease: [0.23, 1, 0.32, 1] } }
}

<motion.ul variants={container} initial="hidden" animate="show">
  {items.map(i => (
    <motion.li key={i.id} variants={item}>{i.label}</motion.li>
  ))}
</motion.ul>
```

**Hardware acceleration caveat — critical for Framer Motion:**
Framer Motion's shorthand props (`x`, `y`, `scale`) use `requestAnimationFrame` on the
main thread. Under load (route transitions, data fetching), they drop frames.

```tsx
// Drops frames during Next.js route transitions
<motion.div animate={{ x: 100 }} />

// Hardware accelerated — stays smooth
<motion.div animate={{ transform: 'translateX(100px)' }} />
```

For elements that must stay smooth during page loads (navbar, sidebar, floating panels),
use CSS animations instead:
```css
.panel-enter {
  animation: panelIn 200ms cubic-bezier(0.23, 1, 0.32, 1) forwards;
}
@keyframes panelIn {
  from { opacity: 0; transform: translateY(6px); }
  to   { opacity: 1; transform: translateY(0); }
}
```

### Mouse-tracking with springs

For decorative mouse-following effects (hero cards, floating elements):
```tsx
import { useSpring, useMotionValue, useTransform } from 'framer-motion';

const mouseX = useMotionValue(0);
const mouseY = useMotionValue(0);

const rotateX = useSpring(useTransform(mouseY, [-0.5, 0.5], [8, -8]), {
  stiffness: 100, damping: 20
});
const rotateY = useSpring(useTransform(mouseX, [-0.5, 0.5], [-8, 8]), {
  stiffness: 100, damping: 20
});
```

Use springs only for decorative interactions. Never for functional UI state.

### shadcn/ui and Radix primitives

Radix exposes CSS variables for transform origins on all floating elements.
Always use them — they make popovers, dropdowns, and tooltips scale from their trigger:

```css
/* globals.css — add for every Radix floating element */
[data-radix-popper-content-wrapper] > * {
  transform-origin: var(--radix-popover-content-transform-origin);
}

/* Per-component overrides */
.dialog-content {
  /* Modals are the exception — they stay centered */
  transform-origin: center;
  animation: dialogIn 200ms cubic-bezier(0.23, 1, 0.32, 1);
}

@keyframes dialogIn {
  from { opacity: 0; transform: scale(0.96); }
  to   { opacity: 1; transform: scale(1); }
}

.popover-content,
.dropdown-content,
.select-content {
  transform-origin: var(--radix-popover-content-transform-origin,
                        var(--radix-dropdown-menu-content-transform-origin,
                        var(--radix-select-content-transform-origin)));
}
```

**shadcn/ui AnimatePresence pattern:**
```tsx
import { AnimatePresence, motion } from 'framer-motion';

<AnimatePresence>
  {open && (
    <motion.div
      key="dialog"
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.97 }}
      transition={{
        enter: { duration: 0.2, ease: [0.23, 1, 0.32, 1] },
        exit:  { duration: 0.15, ease: [0.77, 0, 0.175, 1] }
      }}
    />
  )}
</AnimatePresence>
```

### Dark-first palette specifics

Read palette tokens from `BRAIN.md § Visual Identity (Locked)` or `DESIGN_GUIDE.md` before writing any motion code. Use the CSS token utilities directly:
- `bg-bg` / `bg-surface` — not `bg-[#0a0a0a]` / `bg-[#131720]`
- `text-accent` / `ring-accent/20` / `border-accent/20` — not `text-[#00e676]` / `ring-[#00e676]/20`
- `border-border` / `border-white/5` is acceptable for neutral strokes when no `--color-border` token exists

**On dark surfaces, blur overlays need lower values.** Heavy blur on dark is expensive
in Safari and visually noisy:
```css
/* Backdrop on dark — keep blur under 12px */
.overlay-dark {
  backdrop-filter: blur(8px);
  background: rgba(10, 10, 10, 0.7);
}

/* Glow on accent elements — use box-shadow, not filter */
.glow-green {
  box-shadow: 0 0 16px rgba(0, 230, 118, 0.25);
  transition: box-shadow 200ms ease;
}
.glow-green:hover {
  box-shadow: 0 0 24px rgba(0, 230, 118, 0.4);
}
```

**Surface transitions on dark** look richer with a slight scale than with just opacity:
```tsx
<motion.div
  className="bg-surface rounded-xl"
  initial={{ opacity: 0, scale: 0.98 }}
  animate={{ opacity: 1, scale: 1 }}
  transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
/>
```

---

## Component Motion Patterns

### Buttons

Every clickable element must confirm the press:

```tsx
// Tailwind (preferred for simple buttons)
<button className="transition-transform duration-150 ease-out active:scale-[0.97]">

// Framer Motion (for complex state morphing)
<motion.button
  whileHover={{ scale: 1.02 }}
  whileTap={{ scale: 0.97 }}
  transition={{ duration: 0.15, ease: [0.23, 1, 0.32, 1] }}
>
```

Scale range: `0.95` to `0.98`. Never go below `0.95` — it looks like the element is
physically breaking. The press must feel light, like a physical key.

**Icon buttons** need the same treatment. lucide-react icons inside buttons scale with
the parent because `scale()` affects children too — this is correct behavior, not a bug.

### Modals and Dialogs

```tsx
const dialogVariants = {
  hidden: { opacity: 0, scale: 0.96, y: 4 },
  show:   { opacity: 1, scale: 1,    y: 0 },
  exit:   { opacity: 0, scale: 0.98, y: 2 },
}

<motion.div
  variants={dialogVariants}
  initial="hidden"
  animate="show"
  exit="exit"
  transition={{
    show: { duration: 0.2,  ease: [0.23, 1, 0.32, 1] },
    exit: { duration: 0.15, ease: [0.77, 0, 0.175, 1] }
  }}
  style={{ transformOrigin: 'center' }} // Always center for modals
/>
```

Exit is always faster than enter. Enter: ~200ms. Exit: ~150ms.
The backdrop fades separately:
```tsx
<motion.div
  className="fixed inset-0 bg-black/60"
  initial={{ opacity: 0 }}
  animate={{ opacity: 1 }}
  exit={{ opacity: 0 }}
  transition={{ duration: 0.15 }}
/>
```

### Bottom Drawers and Sheets

Use the drawer easing curve (`cubic-bezier(0.32, 0.72, 0, 1)`). This matches the
iOS sheet physics users have internalized:

```tsx
const drawerVariants = {
  hidden: { y: '100%' },
  show:   { y: 0 },
  exit:   { y: '100%' },
}

<motion.div
  variants={drawerVariants}
  initial="hidden"
  animate="show"
  exit="exit"
  transition={{ duration: 0.35, ease: [0.32, 0.72, 0, 1] }}
  drag="y"
  dragConstraints={{ top: 0 }}
  dragElastic={{ top: 0.1 }}
  onDragEnd={(_, info) => {
    const velocity = Math.abs(info.velocity.y);
    if (info.offset.y > 80 || velocity > 500) onClose();
  }}
/>
```

Use `translateY(100%)` not `translateY(${height}px)` — percentage adapts to content height.

### Toasts

Toasts must use **CSS transitions, not keyframes**. Toasts are added rapidly and need
to retarget smoothly:

```css
.toast {
  transition: transform 400ms ease, opacity 400ms ease, height 300ms ease;
}

/* Entry from bottom */
.toast[data-state="entering"] {
  @starting-style {
    opacity: 0;
    transform: translateY(100%);
  }
}

/* Exit upward */
.toast[data-state="exiting"] {
  opacity: 0;
  transform: translateY(-100%);
  transition-duration: 200ms; /* Exit faster than enter */
}
```

For Sonner configuration:
```tsx
<Toaster
  toastOptions={{
    classNames: {
      toast: 'transition-[transform,opacity] duration-300 ease-out',
    }
  }}
/>
```

### Tooltips

Tooltips have two distinct behaviors that must be implemented separately:
1. **First tooltip**: delay ~400ms, then animate in (prevents accidental activation)
2. **Subsequent tooltips** (while one is open): instant, no animation

```tsx
const tooltipVariants = {
  hidden: { opacity: 0, scale: 0.96, y: 2 },
  show:   { opacity: 1, scale: 1,    y: 0 },
}

<Tooltip delayDuration={isAnyTooltipOpen ? 0 : 400}>
  <TooltipContent asChild>
    <motion.div
      variants={tooltipVariants}
      initial="hidden"
      animate="show"
      transition={{
        duration: isAnyTooltipOpen ? 0 : 0.12,
        ease: [0.23, 1, 0.32, 1]
      }}
      style={{
        transformOrigin: 'var(--radix-tooltip-content-transform-origin)'
      }}
    />
  </TooltipContent>
</Tooltip>
```

### Dropdowns and Menus

Always bloom from the trigger. Never from center:

```tsx
<DropdownMenuContent
  className="data-[state=open]:animate-in data-[state=closed]:animate-out
             data-[state=open]:fade-in-0 data-[state=closed]:fade-out-0
             data-[state=open]:zoom-in-95 data-[state=closed]:zoom-out-95
             data-[side=bottom]:slide-in-from-top-2
             data-[side=top]:slide-in-from-bottom-2"
  style={{
    transformOrigin: 'var(--radix-dropdown-menu-content-transform-origin)'
  }}
/>
```

Duration: 150–200ms. Dropdowns are used frequently — keep them fast.

### Cards

Cards on hover get a lift — subtle upward translate + shadow:
```tsx
<motion.div
  className="bg-surface rounded-xl border border-border"
  whileHover={{
    y: -2,
    boxShadow: '0 8px 24px rgba(0, 0, 0, 0.4)',
    borderColor: 'rgba(255,255,255,0.1)'
  }}
  transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
/>
```

Keep lift to `y: -2` to `y: -4`. Anything more looks like the card is floating off the page.

### Navigaton and Sidebar

Active state transitions should use a background pill that slides, not instant color swaps:

```tsx
<AnimatePresence>
  {isActive && (
    <motion.div
      layoutId="nav-active-pill"
      className="absolute inset-0 bg-white/5 rounded-md"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.15 }}
    />
  )}
</AnimatePresence>
```

`layoutId` makes the pill animate between nav items as the user navigates. This creates
the feeling of the selection physically moving, which is much richer than color toggling.

### Form inputs

Focus state transitions should be on `box-shadow` (GPU-composited), not `border-color`:

```tsx
<input
  className="
    rounded-md bg-surface border border-border px-3 py-2 text-sm
    transition-[box-shadow,border-color] duration-150 ease-out
    focus:outline-none focus:border-white/20 focus:ring-2 focus:ring-accent/20
  "
/>
```

The `ring` with a transparent version of the accent at low opacity creates a soft glow
on focus — appropriate for the dark-first palette.

### Skeleton loaders

Skeletons should pulse with a shimmer, not just opacity:

```css
@keyframes shimmer {
  from { background-position: -200% 0; }
  to   { background-position:  200% 0; }
}

.skeleton {
  background: linear-gradient(
    90deg,
    rgba(255,255,255,0.04) 25%,
    rgba(255,255,255,0.08) 50%,
    rgba(255,255,255,0.04) 75%
  );
  background-size: 200% 100%;
  animation: shimmer 1.8s ease-in-out infinite;
}
```

Faster shimmer (1.2s) makes the app feel like it loads faster. Slower shimmer (2.5s+)
makes waiting feel longer.

---

## Spring Animations

Springs simulate real physics. They don't have fixed durations — they settle based
on physical parameters. Use them for:
- Drag interactions with momentum
- Elements that should feel "alive" (floating panels, cursor followers)
- Gestures that can be interrupted mid-animation

```tsx
// Spring configuration — Apple's approach (easier to reason about)
{ type: 'spring', duration: 0.5, bounce: 0.2 }

// Traditional physics (more control)
{ type: 'spring', mass: 1, stiffness: 120, damping: 14 }
```

Keep `bounce` between `0.1` and `0.3`. Avoid bounce in most SaaS UI — it reads as playful,
not premium. Use it only for drag-to-dismiss and deliberate delight moments.

**Springs are interruptible.** When a user triggers a new animation mid-spring, the
spring continues from its current velocity. CSS animations and keyframes restart from
zero. For any element users might trigger rapidly (toggles, accordions), springs feel
significantly more natural.

---

## CSS Transform Mastery

### translateY with percentages

Percentage values in `translate()` are relative to the element's own size.
`translateY(100%)` moves an element by its own height regardless of actual dimensions.
Always use percentages for hide/show drawer and sheet animations:

```css
/* Works regardless of drawer height — content can change */
.drawer-hidden { transform: translateY(100%); }
.drawer-open   { transform: translateY(0); }
```

Never hardcode pixel values for position animations on dynamic-height elements.

### scale() affects children

Unlike `width`/`height`, `scale()` affects all children proportionally.
When a card scales up on hover, text, icons, and images inside scale too.
This is correct behavior — embrace it. The whole component feels like a physical object.

### 3D depth without JavaScript

```css
.card-wrapper {
  transform-style: preserve-3d;
  perspective: 800px;
}

.card-face {
  transition: transform 400ms cubic-bezier(0.23, 1, 0.32, 1);
}

.card-wrapper:hover .card-face {
  transform: rotateY(5deg) rotateX(2deg);
}
```

### clip-path reveals

`clip-path: inset()` is one of the most powerful animation tools in CSS.
Use it for button fill effects, image reveals, and progress indicators:

```css
/* Hold-to-confirm button fill */
.confirm-overlay {
  clip-path: inset(0 100% 0 0);
  background: var(--accent-green);
  transition: clip-path 200ms ease-out;
}

.confirm-button:active .confirm-overlay {
  clip-path: inset(0 0 0 0);
  transition: clip-path 2s linear; /* Slow fill = deliberate action */
}

/* Image reveal on scroll */
.image-hidden {
  clip-path: inset(0 0 100% 0);
}
.image-visible {
  clip-path: inset(0 0 0 0);
  transition: clip-path 500ms cubic-bezier(0.23, 1, 0.32, 1);
}
```

---

## Gesture and Drag

### Momentum dismissal

Never require dragging past a fixed threshold. Calculate velocity — a fast flick
should dismiss regardless of distance:

```tsx
onDragEnd={(_, info) => {
  const velocity = Math.abs(info.velocity.y);
  if (info.offset.y > 80 || velocity > 500) {
    onClose();
  }
}}
```

### Resistance at boundaries

When a user drags past the natural boundary (drawer pulled higher than its max),
apply resistance. Use `dragElastic`:

```tsx
<motion.div
  drag="y"
  dragConstraints={{ top: 0, bottom: 0 }}
  dragElastic={{ top: 0.15, bottom: 0.05 }} // More resistance going up
/>
```

### Pointer capture

Set pointer capture when a drag begins. This ensures dragging continues smoothly
even if the pointer leaves the element bounds mid-gesture:

```tsx
onPointerDown={(e) => {
  e.currentTarget.setPointerCapture(e.pointerId);
  setDragging(true);
}}
```

---

## Performance Rules

### Only animate transform and opacity

`transform` and `opacity` run on the GPU compositor — they skip layout and paint.
Animating `padding`, `margin`, `height`, `width`, or `top/left` triggers full layout recalculation.

```
GPU (fast): transform, opacity, filter
Layout (slow): width, height, padding, margin, top, left
```

### CSS variables — do not animate via custom props on parents

Updating a CSS variable on a parent element triggers style recalculation for all children.
In a component tree with many children, this causes expensive cascading recalculations:

```tsx
// Expensive — recalculates styles for every child
containerRef.current.style.setProperty('--progress', `${value}`);

// Cheap — only affects this element
containerRef.current.style.transform = `scaleX(${value})`;
```

### Framer Motion hardware acceleration rule

Shorthand props (`x`, `y`, `scale`, `rotate`) use `requestAnimationFrame` on the main thread.
The full `transform` string uses the GPU compositor:

```tsx
// Main thread — drops frames during data loads or route transitions
animate={{ x: 100, y: 50 }}

// GPU compositor — stays smooth always
animate={{ transform: 'translate(100px, 50px)' }}
```

For Next.js App Router: route transitions cause the main thread to be busy. Any Framer
Motion component using shorthand props will drop frames during navigation. Either use
`transform` strings, or use CSS `@keyframes` for elements that must stay smooth during
route changes (navbar, sidebar, persistent panels).

### Web Animations API for performant programmatic animation

When you need JavaScript control with CSS-level performance:

```ts
element.animate(
  [
    { clipPath: 'inset(0 0 100% 0)', opacity: 0 },
    { clipPath: 'inset(0 0 0 0)',    opacity: 1 }
  ],
  {
    duration: 400,
    fill: 'forwards',
    easing: 'cubic-bezier(0.23, 1, 0.32, 1)'
  }
);
```

Hardware-accelerated, interruptible, no library required.

---

## Accessibility

### prefers-reduced-motion

Reduced motion means *fewer and gentler* animations, not zero. Keep opacity and color
transitions that aid comprehension. Remove positional movement:

```css
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

In Framer Motion:
```tsx
import { useReducedMotion } from 'framer-motion';

const reduce = useReducedMotion();
const variants = reduce
  ? { hidden: { opacity: 0 }, show: { opacity: 1 } }
  : { hidden: { opacity: 0, y: 8 }, show: { opacity: 1, y: 0 } };
```

### Gate hover animations on pointer devices

Touch screens trigger hover on tap, causing false positives and sticky hover states.
Always gate movement-based hover effects:

```css
@media (hover: hover) and (pointer: fine) {
  .card:hover {
    transform: translateY(-2px);
  }
}
```

Simple opacity and color hovers are fine to leave ungated.

---

## Stagger Animations

When multiple items enter together, stagger creates a cascade that feels
natural. Everything appearing at once looks like a render dump.

```tsx
const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.04 } }
}
const item = {
  hidden: { opacity: 0, y: 8 },
  show: {
    opacity: 1, y: 0,
    transition: { duration: 0.25, ease: [0.23, 1, 0.32, 1] }
  }
}
```

**Stagger rules:**
- Delays: 30–80ms between items. Longer reads as slow and self-important.
- Max items to stagger: 8. After that, the last item waits too long.
- Never block interaction during stagger — items are interactive immediately.
- Lead with primary content. Secondary/decorative elements stagger after.

---

## Asymmetric Enter / Exit

Entries can be slightly more expressive. Exits must always be fast.
The system responding should never make the user wait:

```tsx
// Enter: 220ms — the content is arriving
// Exit:  150ms — the system is responding to the user's dismiss

<AnimatePresence>
  {show && (
    <motion.div
      initial={{ opacity: 0, scale: 0.96, y: 4 }}
      animate={{ opacity: 1, scale: 1,    y: 0,
        transition: { duration: 0.22, ease: [0.23, 1, 0.32, 1] } }}
      exit={{   opacity: 0, scale: 0.98, y: 2,
        transition: { duration: 0.15, ease: [0.77, 0, 0.175, 1] } }}
    />
  )}
</AnimatePresence>
```

---

## Review Checklist

Run this mentally on every component. If any row is "yes", fix it:

| Issue | Fix |
|-------|-----|
| `transition: all` or `transition-all` | Specify exact properties |
| `scale(0)` or `scale-0` on entry | Start from `scale(0.95)` + `opacity: 0` |
| `ease-in` on any UI element | Switch to `ease-out` or `--ease-out` custom curve |
| `transform-origin: center` on a popover | Use Radix CSS variable; keep `center` only for modals |
| Animation on a keyboard-triggered action | Remove animation or set `duration: 0` on keyboard intent |
| Duration > 300ms on interactive UI | Reduce to 150–250ms range |
| Hover animation without `@media (hover: hover)` | Gate behind the media query |
| `@keyframes` on rapidly-triggered element (toasts, counters) | Use `transition` for interruptibility |
| Framer Motion `x`/`y` shorthand under route transitions | Use `transform` string for hardware acceleration |
| Symmetric enter/exit timing | Exit should be 30–50% faster than enter |
| List items appearing all at once | Add stagger (30–80ms between items, max 8 items) |
| Spinner too slow | Speed it up — faster spinner = faster perceived load |
| `transition-all` on form focus | Use `transition-[box-shadow,border-color]` |
| Drawer animation using pixel heights | Use `translateY(100%)` — percentage adapts to content |
| Missing `prefers-reduced-motion` | Add CSS media query or `useReducedMotion()` |
| Glow as `filter: drop-shadow` | Use `box-shadow` — filters are expensive on dark surfaces |
| CSS variable updated on parent for animation | Update `transform` directly on the element |

---

## Modern CSS Entry Animations

### @starting-style — no JavaScript required

The modern CSS way to animate element entry without `useEffect` or `data-mounted` hacks:

```css
.toast {
  opacity: 1;
  transform: translateY(0);
  transition: opacity 300ms ease-out, transform 300ms ease-out;

  @starting-style {
    opacity: 0;
    transform: translateY(12px);
  }
}
```

`@starting-style` defines the style *before* the first paint. The browser transitions
from those values to the element's normal styles automatically. No `mounted` state,
no `setTimeout`, no layout jank.

Browser support: Chrome 117+, Safari 17.5+, Firefox 129+. For projects that need
broader support, keep the `useEffect` / `data-mounted` fallback:

```tsx
// Fallback pattern — still valid
const [mounted, setMounted] = useState(false);
useEffect(() => { setMounted(true); }, []);

<div data-mounted={mounted} className="
  opacity-0 translate-y-2 transition-[opacity,transform] duration-300 ease-out
  data-[mounted=true]:opacity-100 data-[mounted=true]:translate-y-0
" />
```

### blur to mask imperfect crossfades

When two states crossfade and you can see both states overlapping — adjust easing,
adjust timing, still looks off — add `filter: blur(2px)` at the transition midpoint.

Without blur, the eye sees two distinct objects during a crossfade. Blur bridges the
visual gap, making the browser perceive a single smooth transformation rather than
two elements swapping:

```css
.button-label {
  transition: filter 150ms ease-out, opacity 150ms ease-out;
}

.button-label.is-transitioning {
  filter: blur(2px);
  opacity: 0.6;
}
```

Rules:
- Keep blur under `4px` for small elements, `8px` for larger surfaces
- Never exceed `20px` — heavy blur is expensive, especially in Safari on dark backgrounds
- Remove blur when `prefers-reduced-motion` is active — it can cause nausea

---

## Debugging Animations

### Slow-motion testing

Temporarily multiply all durations by 5 in development:

```tsx
// utils/motion.ts
export const DEV_SLOW = process.env.NODE_ENV === 'development' ? 5 : 1;

// Usage
transition={{ duration: 0.2 * DEV_SLOW }}
```

Or use Chrome DevTools → Animations panel → set playback rate to 10%.

Things to look for at 10% speed:
- Two distinct states visible during a crossfade? Add blur or adjust easing.
- Element snapping at start or end? Easing curve is wrong.
- `transform-origin` in the wrong place? The scale pivot reveals itself.
- Multiple properties (opacity + transform) out of sync? Stagger them slightly.

### Frame-by-frame inspection

Chrome DevTools → Animations panel → click any animation → use the scrubber
to step frame by frame. Reveals timing mismatches invisible at full speed.

### Real device testing for gestures

Drawer and swipe interactions must be tested on a physical device.
Simulators do not accurately reproduce touch velocity, momentum, or multi-touch:

1. Connect phone via USB
2. Enable USB debugging (Android) or Web Inspector (iOS)
3. Visit `http://[local-ip]:3000` from the device
4. Use Chrome Remote Devices (Android) or Safari → Develop → [device] (iOS)

Real hardware reveals: gesture velocity thresholds that feel off, rubber-banding that
looks wrong, and animations that drop frames under thermal throttling.

---

## Installation Checklist

Before motion-hive can apply fixes, verify these are in the project:

### Required packages

```bash
# Animation library
npm install framer-motion

# shadcn/ui animation utilities (includes tailwindcss-animate)
npx shadcn@latest init

# If using Radix primitives directly (without shadcn)
npm install @radix-ui/react-dialog @radix-ui/react-popover \
            @radix-ui/react-dropdown-menu @radix-ui/react-tooltip
```

### tailwind.config.ts additions

```ts
import type { Config } from 'tailwindcss';
import animate from 'tailwindcss-animate'; // from shadcn/ui

const config: Config = {
  theme: {
    extend: {
      transitionTimingFunction: {
        'ui-out':   'cubic-bezier(0.23, 1, 0.32, 1)',
        'ui-inout': 'cubic-bezier(0.77, 0, 0.175, 1)',
        'drawer':   'cubic-bezier(0.32, 0.72, 0, 1)',
        'subtle':   'cubic-bezier(0.4, 0, 0.2, 1)',
      },
      transitionDuration: {
        '80':  '80ms',
        '160': '160ms',
        '220': '220ms',
        '350': '350ms',
        '450': '450ms',
      },
      keyframes: {
        shimmer: {
          from: { backgroundPosition: '-200% 0' },
          to:   { backgroundPosition:  '200% 0' },
        },
        'fade-up': {
          from: { opacity: '0', transform: 'translateY(8px)' },
          to:   { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-down': {
          from: { opacity: '0', transform: 'translateY(-8px)' },
          to:   { opacity: '1', transform: 'translateY(0)' },
        },
        'scale-in': {
          from: { opacity: '0', transform: 'scale(0.95)' },
          to:   { opacity: '1', transform: 'scale(1)' },
        },
      },
      animation: {
        shimmer:    'shimmer 1.6s ease-in-out infinite',
        'fade-up':  'fade-up 0.25s cubic-bezier(0.23, 1, 0.32, 1) forwards',
        'fade-down':'fade-down 0.25s cubic-bezier(0.23, 1, 0.32, 1) forwards',
        'scale-in': 'scale-in 0.2s cubic-bezier(0.23, 1, 0.32, 1) forwards',
      },
    },
  },
  plugins: [animate],
};

export default config;
```

### globals.css additions

```css
/* Motion easing tokens */
:root {
  --ease-out:    cubic-bezier(0.23, 1, 0.32, 1);
  --ease-in-out: cubic-bezier(0.77, 0, 0.175, 1);
  --ease-drawer: cubic-bezier(0.32, 0.72, 0, 1);
  --ease-subtle: cubic-bezier(0.4, 0, 0.2, 1);
}

/* Radix floating element origin — applies globally */
[data-radix-popper-content-wrapper] > * {
  transform-origin: var(--radix-popper-transform-origin);
}

/* Reduced motion — kill all movement, keep opacity/color */
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```

---

## Motion Token Quick Reference

Copy-paste cheat sheet for the most common patterns:

### Easing curves

```css
--ease-out:    cubic-bezier(0.23, 1, 0.32, 1)      /* UI interactions — default */
--ease-in-out: cubic-bezier(0.77, 0, 0.175, 1)     /* On-screen movement */
--ease-drawer: cubic-bezier(0.32, 0.72, 0, 1)      /* Bottom sheets, drawers */
--ease-subtle: cubic-bezier(0.4, 0, 0.2, 1)        /* Hover color/shadow */
```

### Durations by element

```
button press      100–160ms
tooltip           125–175ms
dropdown          150–200ms   (enter)  /  120ms (exit)
popover           150–220ms   (enter)  /  130ms (exit)
modal             200–300ms   (enter)  /  150ms (exit)
drawer            300–400ms   (enter)  /  250ms (exit)
page entrance     180–250ms
stagger interval  30–60ms per item (max 8 items)
marketing reveal  400–600ms
```

### Framer Motion presets

```tsx
// Fade up — most common content entrance
initial={{ opacity: 0, y: 6 }}
animate={{ opacity: 1, y: 0 }}
transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}

// Scale in — modals and dialogs
initial={{ opacity: 0, scale: 0.96 }}
animate={{ opacity: 1, scale: 1 }}
exit={{    opacity: 0, scale: 0.98 }}

// Slide from bottom — drawers
initial={{ y: '100%' }}
animate={{ y: 0 }}
exit={{    y: '100%' }}
transition={{ duration: 0.35, ease: [0.32, 0.72, 0, 1] }}

// Stagger container
variants={{ hidden: {}, show: { transition: { staggerChildren: 0.05 } } }}

// Stagger item
variants={{
  hidden: { opacity: 0, y: 8 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.25, ease: [0.23, 1, 0.32, 1] } }
}}
```

### Tailwind quick classes

```tsx
// Button press
"transition-transform duration-150 ease-out active:scale-[0.97]"

// Card hover lift
"transition-[transform,box-shadow] duration-200 ease-out
 hover:-translate-y-0.5 hover:shadow-xl"

// Fade-up on mount (tailwindcss-animate)
"animate-in fade-in slide-in-from-bottom-2 duration-300"

// Fade-out on unmount
"animate-out fade-out slide-out-to-bottom-2 duration-150"

// Form focus glow (dark palette — uses accent token)
"transition-[box-shadow,border-color] duration-150 ease-out
 focus:ring-2 focus:ring-accent/20 focus:border-white/20"

// Skeleton shimmer
"animate-shimmer bg-[length:200%_100%] bg-gradient-to-r
 from-white/[0.04] via-white/[0.08] to-white/[0.04]"
```

---

## Handoff Protocol

When motion-hive finishes, it must print this block before handing off:

```
────────────────────────────────────────
motion-hive complete
────────────────────────────────────────
Files scanned:    [N]
Components fixed: [N]
Issues resolved:  [N]
Issues skipped:   [N] (list reasons)

Anti-patterns removed:
  - [list each class of issue fixed]

Airborne is clear to run.
────────────────────────────────────────
```

If running in a pipeline (Waterborne → motion-hive → valley-of-death → Airborne),
the handoff note automatically signals the next skill to proceed.
If running standalone, the note confirms the codebase is motion-complete.
