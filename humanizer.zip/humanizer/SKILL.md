---
name: humanizer
description: >
  Remove signs of AI-generated writing to make text sound natural and
  human-written. Use whenever the user asks to humanize, de-AI, naturalize,
  rewrite, edit, or strip AI-tells from any piece of writing (essays, blog
  posts, emails, articles, social posts, marketing copy). Also use
  proactively when the user shares text and complains it "sounds like AI"
  or "sounds generic." Based on Wikipedia's "Signs of AI writing" guide.
  Covers the major patterns Claude itself tends to produce: significance
  inflation, promotional language, superficial -ing analyses, vague
  attributions, em dash overuse, rule of three, AI vocabulary, negative
  parallelisms, hyphenated word pairs, sycophantic preambles, and filler
  hedging.
---

# Humanizer (Lean)

Goal: take text that sounds AI-generated and rewrite it so it reads like a human wrote it. Two things matter: removing the AI tells, and putting voice back in. Clean text without voice is just clean slop.

**Pipeline note:** Humanizer is the natural follow-up to **Airborne**. Airborne optimises copy for search signals and structure, which routinely produces AI-patterned prose. After Airborne delivers its SEO report, run Humanizer on: hero text, page body copy, CTAs, and any blog or guide content. Skip it for meta titles, JSON-LD schema values, and robots.txt — those are machine-read and benefit from precision over voice.

## Workflow

1. Read the input carefully and identify which patterns from the catalog below appear.
2. Write a first-pass rewrite that removes the tells.
3. Critique your own draft — what still reads AI? Note 2-4 remaining tells in 1-2 sentences each.
4. Do a second pass that fixes those tells and injects voice (see "Putting voice back in" below).
5. Present the final version. If the user asked for it, include a short bullet list of what changed.

Don't ask for permission between steps. Run all four in one response.

## Putting voice back in

Removing AI patterns gets you to "clean and dead." Voice gets you to "human." Without this step, the output is just a more compact version of the same problem.

How to add voice:
- **Vary rhythm.** Short sentences. Then longer ones that take their time. Don't make every sentence the same shape.
- **Have a take.** Real humans react, not just report. "I keep coming back to..." or "the strange part is..." signals a person thinking.
- **Acknowledge mess.** Mixed feelings, half-formed thoughts, the bit where the writer isn't sure — these are human signals.
- **Be specific about feelings or stakes.** Not "this is concerning" but the actual concrete thing that's concerning.
- **First person is fine** when it fits the genre. "I" is not unprofessional.

Don't force voice where it doesn't belong (technical docs, legal copy, neutral reference text). Match the tone the piece is supposed to have.

## Pattern catalog

The 25 patterns below come from Wikipedia's "Signs of AI writing" guide. Each has a problem statement and a before/after.

### Content patterns

**1. Significance inflation.** Words: stands as, serves as, is a testament, pivotal, key moment, evolving landscape, indelible mark, deeply rooted, marking a shift.
Before: "The institute was established in 1989, marking a pivotal moment in the evolution of regional statistics."
After: "The institute was established in 1989 to collect regional statistics independently from the national office."

**2. Notability puffery.** Vague claims about media coverage, expert status, social following.
Before: "Her views have been cited in the New York Times, BBC, Financial Times, and The Hindu. She maintains an active social media presence with over 500,000 followers."
After: "In a 2024 New York Times interview, she argued that AI regulation should focus on outcomes rather than methods."

**3. Superficial -ing analyses.** -ing tails that add fake depth: highlighting, underscoring, reflecting, contributing to, symbolizing, fostering, ensuring.
Before: "The temple uses blue, green, and gold, symbolizing Texas bluebonnets, the Gulf of Mexico, and the diverse Texan landscapes, reflecting the community's deep connection to the land."
After: "The temple uses blue, green, and gold — chosen to reference local bluebonnets and the Gulf coast."

**4. Promotional language.** Words: boasts, vibrant, rich (figurative), nestled, in the heart of, breathtaking, must-visit, stunning, groundbreaking.
Before: "Nestled within the breathtaking region of Gonder, Alamata Raya Kobo stands as a vibrant town with a rich cultural heritage."
After: "Alamata Raya Kobo is a town in the Gonder region, known for its weekly market and 18th-century church."

**5. Vague attributions.** "Industry reports," "experts argue," "observers have cited," "some critics."
Before: "Experts believe it plays a crucial role in the regional ecosystem."
After: "It supports several endemic fish species, according to a 2019 survey by the Chinese Academy of Sciences."

**6. Formulaic "Challenges and Future" sections.** "Despite challenges... continues to thrive."
Before: "Despite its prosperity, the town faces challenges including congestion and water scarcity. Despite these challenges, it continues to thrive."
After: "Traffic congestion increased after 2015 when three new IT parks opened. A stormwater drainage project began in 2022."

### Language and grammar patterns

**7. AI vocabulary.** Words appearing far more often in post-2023 text: additionally, align with, crucial, delve, emphasizing, enduring, enhance, fostering, garner, highlight, interplay, intricate, key (adjective), landscape (abstract), pivotal, showcase, tapestry, testament, underscore, valuable, vibrant.

**8. Copula avoidance.** "Serves as," "stands as," "represents," "boasts," "features" — substitutes for "is" / "are" / "has".
Before: "The gallery serves as LAAA's exhibition space and boasts over 3,000 square feet."
After: "The gallery is LAAA's exhibition space. It has 3,000 square feet."

**9. Negative parallelism.** "Not just X; it's Y." "Not only... but also."
Before: "It's not just a song, it's a statement."
After: "The song is also a statement."

**10. Rule of three.** Forcing ideas into groups of three.
Before: "Attendees can expect innovation, inspiration, and industry insights."
After: "The event has talks, panels, and time to mingle." (only use three when you actually have three.)

**11. Synonym cycling.** "Protagonist... main character... central figure... hero" all in one paragraph.
Fix: just use the same noun. Repetition is fine.

**12. False ranges.** "From X to Y" where X and Y aren't on a scale.
Before: "From the singularity of the Big Bang to the enigmatic dance of dark matter."
After: "The book covers the Big Bang, star formation, and current theories about dark matter."

### Style patterns

**13. Em dash overuse.** LLMs use — far more than humans.
Fix: replace most with commas, periods, or parentheses. Keep maybe one per long piece.

**14. Mechanical bold.** Bolding key terms in every sentence.
Before: "It blends **OKRs**, **KPIs**, and **the Business Model Canvas**."
After: "It blends OKRs, KPIs, and the Business Model Canvas."

**15. Inline-header lists.** "**Performance:** It's faster. **Security:** It's safer."
Fix: rewrite as prose.

**16. Title Case Headings.** "Strategic Negotiations And Global Partnerships" → "Strategic negotiations and global partnerships."

**17. Decorative emojis.** 🚀 on every bullet, 💡 next to every insight.
Fix: remove all decorative emojis. Keep only emojis that are part of the actual content.

**18. Curly quotation marks.** Replace " " with " " unless the publication style requires curly.

### Communication patterns

**19. Chatbot artifacts.** "Great question!", "I hope this helps!", "Let me know if you'd like me to expand on any section!"
Fix: delete entirely.

**20. Knowledge-cutoff disclaimers.** "As of my last training update," "While specific details are limited."
Fix: delete or replace with a specific source.

**21. Sycophancy.** "Great question! You're absolutely right that..."
Fix: delete the validation, keep the substance.

### Filler and hedging

**22. Filler phrases.**
- "In order to" → "to"
- "Due to the fact that" → "because"
- "At this point in time" → "now"
- "Has the ability to" → "can"

**23. Stacked hedging.** "It could potentially possibly be argued that the policy might have some effect."
Fix: pick one hedge or none. "The policy may affect outcomes."

**24. Generic positive endings.** "The future looks bright. Exciting times lie ahead."
Fix: end with a concrete fact or a real conclusion, or just stop.

**25. Mechanical hyphenation.** "Cross-functional, data-driven, decision-making" — AI hyphenates compound modifiers with perfect consistency. Humans don't.
Fix: drop hyphens from the common ones unless you're consistently using a style guide that requires them.

## Worked example

**Input:**
> AI-assisted coding serves as an enduring testament to the transformative potential of large language models, marking a pivotal moment in the evolution of software development. These groundbreaking tools — nestled at the intersection of research and practice — are reshaping how engineers ideate, iterate, and deliver, underscoring their vital role in modern workflows.
>
> In conclusion, the future looks bright. Exciting times lie ahead.

**Pass 1 — tells removed:**
> AI coding assistants can speed up some kinds of work. They are good at boilerplate (config files, test scaffolding, repetitive refactors) and bad at knowing when they are wrong. Studies on actual productivity show mixed results.

**Critique:** still reads slightly tidy. The rhythm is even, and "studies show mixed results" is vague.

**Pass 2 — voice in:**
> AI coding assistants are great at the boring parts. Not everything. Definitely not architecture.
>
> They're good at boilerplate — config files, test scaffolding, repetitive refactors. They're also good at sounding right while being wrong. I've accepted suggestions that compiled, passed lint, and still missed the point because I stopped paying attention.
>
> The productivity numbers are slippery. Acceptance rate isn't correctness; correctness isn't value. If you don't have tests, you're guessing either way.

## Reference

Patterns come from [Wikipedia: Signs of AI writing](https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing). The list is updated by Wikipedia editors based on observations across thousands of edits flagged as AI-generated.
