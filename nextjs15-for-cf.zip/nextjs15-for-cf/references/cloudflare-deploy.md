# Cloudflare Deployment - Deep Dive

Read this when the user's issue is Cloudflare-specific: build failing on
Cloudflare but not Vercel, runtime errors in Cloudflare logs, wrangler config
problems, or choosing between adapters.

## Table of Contents

1. Adapter decision tree
2. `@opennextjs/cloudflare` (Workers) - full setup and gotchas
3. `@cloudflare/next-on-pages` (Pages) - full setup and gotchas
4. ISR / caching on Cloudflare
5. Bindings (KV, R2, D1, Durable Objects) in Next.js code
6. Diagnosing build vs runtime errors
7. Migration from next-on-pages to OpenNext

---

## 1. Adapter Decision Tree

```
New project, dual-deploying to Vercel + Cloudflare?
  -> @opennextjs/cloudflare (Workers). Use this.

Existing project on @cloudflare/next-on-pages and working?
  -> Keep it for now if it's working. Plan migration to OpenNext within 6 months.
     next-on-pages is in maintenance mode; new Next.js features land in OpenNext.

Need ISR or after()?
  -> OpenNext. next-on-pages doesn't support either.

Need image optimization through Next.js?
  -> Neither works out of the box. Use a custom loader with Cloudflare Images
     on both, or set `images.unoptimized: true` and serve from your own CDN.

Project must run on Cloudflare Pages specifically (not Workers)?
  -> next-on-pages. (Note: OpenNext now also has Pages support in newer
     versions, but Workers is the smoother path.)
```

---

## 2. OpenNext (`@opennextjs/cloudflare`)

### Required files

**`wrangler.toml`** (or `wrangler.jsonc`):

```toml
name = "my-app"
main = ".open-next/worker.js"
compatibility_date = "2024-09-23"
compatibility_flags = ["nodejs_compat"]

[assets]
directory = ".open-next/assets"
binding = "ASSETS"

# Example bindings - only include what you use
[[kv_namespaces]]
binding = "CACHE"
id = "your-kv-namespace-id"

[[r2_buckets]]
binding = "MEDIA"
bucket_name = "my-app-media"
```

The `compatibility_date` of `2024-09-23` or later and the `nodejs_compat`
flag are **non-negotiable**. Without them, the build produces a Worker that
fails at startup with module resolution errors.

**`open-next.config.ts`** (project root):

```ts
import { defineCloudflareConfig } from '@opennextjs/cloudflare'

export default defineCloudflareConfig({
  // Optional: enable incremental cache (for ISR) backed by KV
  // incrementalCache: kvIncrementalCache,
})
```

Without this file, `opennextjs-cloudflare build` uses defaults that may not
match the user's bindings.

**`next.config.ts`**:

```ts
import type { NextConfig } from 'next'
import { initOpenNextCloudflareForDev } from '@opennextjs/cloudflare'

initOpenNextCloudflareForDev()

const nextConfig: NextConfig = {
  // Cross-platform safe defaults
  images: { unoptimized: true },
}

export default nextConfig
```

`initOpenNextCloudflareForDev()` makes `wrangler dev` behave like the deployed
Worker - bindings work, env vars resolve from `.dev.vars`. Without it, local
dev under Wrangler will disagree with production.

### Build script

```json
{
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "cf:build": "opennextjs-cloudflare build",
    "cf:preview": "opennextjs-cloudflare preview",
    "cf:deploy": "opennextjs-cloudflare deploy"
  }
}
```

Note: `opennextjs-cloudflare deploy` wraps `wrangler deploy`. You can also
call `wrangler deploy` directly after `cf:build`.

### Vercel still builds normally

Vercel detects Next.js and runs `next build` - it ignores `wrangler.toml`,
`open-next.config.ts`, and the `cf:*` scripts. The same repo deploys cleanly
to both.

### Common OpenNext errors

| Error in `wrangler dev` or runtime | Cause |
|---|---|
| `Cannot find module 'node:fs'` or similar | `nodejs_compat` flag missing |
| `Compatibility date must be 2024-09-23 or later` | Self-explanatory |
| `Worker exceeded resource limits` | Bundle > 3 MiB (free) / 10 MiB (paid) |
| `env.DATABASE_URL is undefined` in worker | Var added to Pages env, not Worker env - use `wrangler secret put` |
| `ENOENT: no such file or directory, open '...'` | Trying to read a file at runtime; bundle the data as an import instead |

### Env vars and secrets

OpenNext deploys to Workers. Env vars there are managed via:

- **Public/non-secret**: `[vars]` section in `wrangler.toml`
- **Secret**: `wrangler secret put DATABASE_URL` (one-time CLI step per env)
- **Local dev**: `.dev.vars` file (gitignored), same KEY=value format as `.env`

```toml
# wrangler.toml
[vars]
NEXT_PUBLIC_SITE_URL = "https://example.com"
```

```sh
# Set a secret
echo "postgres://..." | wrangler secret put DATABASE_URL
```

Do **not** put secrets in `wrangler.toml`. It's committed.

### Local dev parity

```sh
pnpm cf:build && wrangler dev
```

This runs the actual Worker bundle locally with `.dev.vars` populated. Use
this to reproduce production bugs that don't show up under `next dev`.

---

## 3. next-on-pages (`@cloudflare/next-on-pages`)

### Required files

**`next.config.js`**:

```js
const nextConfig = {
  images: { unoptimized: true },
}

if (process.env.NODE_ENV === 'development') {
  const { setupDevPlatform } = require('@cloudflare/next-on-pages/next-dev')
  setupDevPlatform().catch(() => {})
}

module.exports = nextConfig
```

The `setupDevPlatform` call makes bindings (KV, R2, env) available in
`next dev` via `getRequestContext()`.

### Build

In the Cloudflare Pages dashboard:

- Framework preset: `Next.js`
- Build command: `npx @cloudflare/next-on-pages@1`
- Output directory: `.vercel/output/static`
- Compatibility flag: `nodejs_compat` (set in Pages settings, both Production and Preview)

The `.vercel/output/static` output dir is correct - despite the name,
next-on-pages writes there because it consumes the same intermediate format
Vercel uses.

### Every server route must be Edge

```ts
// Required on every page.tsx, layout.tsx, route.ts that does server work
export const runtime = 'edge'
```

Missing this on any one file fails the build with:

```
The following routes were not configured to run with the Edge Runtime:
  - /api/foo
```

### Bindings access

```ts
import { getRequestContext } from '@cloudflare/next-on-pages'

export const runtime = 'edge'

export async function GET() {
  const { env } = getRequestContext()
  const value = await env.MY_KV.get('key')
  return Response.json({ value })
}
```

### eslint-plugin-next-on-pages

Catches Edge incompat issues at lint time before they bite at build:

```sh
pnpm add -D eslint-plugin-next-on-pages
```

```js
// eslint.config.mjs
import nextOnPages from 'eslint-plugin-next-on-pages'
export default [
  { plugins: { 'next-on-pages': nextOnPages } },
  { rules: { 'next-on-pages/no-unsupported-configs': 'error' } },
]
```

### Common next-on-pages errors

| Error | Cause | Fix |
|---|---|---|
| `Module not found: 'fs'` | Node API in dep tree | Trace with `pnpm why`, replace dep |
| Route missing `runtime = 'edge'` | Default node runtime | Add the export to every server file |
| `nodejs_compat` flag not set in Pages settings | Some deps need polyfills | Set in dashboard, redeploy |
| ISR-related errors | next-on-pages doesn't support ISR | Make route static or fully dynamic |
| `after()` callback never fires | Not supported | Move to a queue or remove |

---

## 4. ISR / Caching on Cloudflare

### next-on-pages

No ISR. Period. `export const revalidate = 60` is ignored. The route is
either fully static (SSG, generated at build) or dynamic (SSR every request).
Plan accordingly.

### OpenNext - incremental cache

Configure the cache backend in `open-next.config.ts`:

```ts
import { defineCloudflareConfig } from '@opennextjs/cloudflare'
import kvIncrementalCache from '@opennextjs/cloudflare/overrides/incremental-cache/kv-incremental-cache'

export default defineCloudflareConfig({
  incrementalCache: kvIncrementalCache,
})
```

Add the binding to `wrangler.toml`:

```toml
[[kv_namespaces]]
binding = "NEXT_INC_CACHE_KV"
id = "..."
```

Now `export const revalidate = 60` works, and `revalidateTag()` / `revalidatePath()` propagate.

R2 is also supported as a backend for larger payloads:

```ts
import r2IncrementalCache from '@opennextjs/cloudflare/overrides/incremental-cache/r2-incremental-cache'

export default defineCloudflareConfig({ incrementalCache: r2IncrementalCache })
```

---

## 5. Bindings in Application Code

```ts
// Works in OpenNext and next-on-pages (with respective imports)
import { getRequestContext } from '@cloudflare/next-on-pages' // for next-on-pages
// OR
import { getCloudflareContext } from '@opennextjs/cloudflare' // for OpenNext

export const runtime = 'edge' // required for next-on-pages, optional for OpenNext

export async function GET() {
  const ctx = await getCloudflareContext() // or getRequestContext() on next-on-pages
  const value = await ctx.env.MY_KV.get('key')
  const obj = await ctx.env.MEDIA.get('logo.png') // R2
  return Response.json({ value })
}
```

On Vercel, these bindings don't exist - any code that uses them must be
gated behind a build-time env check:

```ts
const isCloudflare = !!process.env.CF_PAGES || !!process.env.CLOUDFLARE_WORKERS
if (isCloudflare) {
  const { getCloudflareContext } = await import('@opennextjs/cloudflare')
  // ...
}
```

Better: design the app so platform-specific storage is behind an interface
and only one platform is the source of truth.

---

## 6. Diagnosing Build vs Runtime Errors

### Build error symptoms

- Error appears in Cloudflare Pages "Deployments" log or Wrangler CLI output
- Mentions module resolution, missing files, unsupported syntax
- No request needed to trigger

### Runtime error symptoms

- Visible in `wrangler tail` or Cloudflare dashboard "Logs"
- Triggered by hitting a URL
- Often includes a stack trace from the deployed Worker

### How to fetch runtime logs

```sh
# Live tail of the deployed Worker
wrangler tail

# Filter to errors only
wrangler tail --status error
```

For Pages, logs are in the Cloudflare dashboard under the project's "Functions"
tab. Real-time logs there are only available in newer Pages projects.

### Local repro of a production bug

For OpenNext:
```sh
pnpm cf:build && wrangler dev
```

For next-on-pages:
```sh
npx @cloudflare/next-on-pages
npx wrangler pages dev .vercel/output/static
```

If the bug repros locally under Wrangler, you can iterate fast. If it only
appears in deploy, it's usually env var or binding config drift.

---

## 7. Migrating next-on-pages -> OpenNext

When the user is ready. Outline:

1. Install: `pnpm add @opennextjs/cloudflare && pnpm add -D wrangler`
2. Uninstall: `pnpm remove @cloudflare/next-on-pages eslint-plugin-next-on-pages`
3. Create `wrangler.toml` with `nodejs_compat` and `compatibility_date = "2024-09-23"` minimum
4. Create `open-next.config.ts`
5. Update `next.config.ts` - swap `setupDevPlatform` for `initOpenNextCloudflareForDev`
6. Remove `export const runtime = 'edge'` from every route - OpenNext defaults to Node, which is faster and more compatible
7. Replace `getRequestContext()` with `getCloudflareContext()` everywhere
8. Move env vars from Pages settings to `wrangler.toml` / `wrangler secret put`
9. Cloudflare dashboard: create a new Worker (or keep Pages but use OpenNext's Pages target)
10. Set up GitHub Action or manual deploy with `wrangler deploy`
11. Update DNS / custom domain to point to the new Worker
12. Decommission the Pages project once the Worker is verified

`npx diverce migrate` automates much of this but always review the PR it creates.
