# Fixer protocol

Rules for editing existing code when fixing a layout bug. The goal is the smallest patch that solves the symptom without churning unrelated code.

## Principle: minimum viable patch

When a user says "fix this", they mean: keep everything else, just fix the thing. Rewriting the whole component to apply the patterns from `patterns/` is wrong unless the user explicitly asks for a rewrite.

The hierarchy of edits, from least invasive to most:

1. **Add a class** to an existing element (`mx-auto`, `min-w-0`, `shrink-0`)
2. **Change a class** on an existing element (`text-center` → `mx-auto max-w-2xl text-center`)
3. **Wrap an element** in one additional `<div>` with the right classes
4. **Restructure nesting** within a section (move children between parents)
5. **Replace the section** with the correct pattern from `patterns/`
6. **Rewrite the file** — only when explicitly requested

Default to step 1. Escalate only when the lower step can't solve it.

## The diagnosis loop

Before writing any patch:

1. **Get the symptom in one sentence.** "The subtitle is left-aligned" — not "the section looks weird".
2. **Look it up in `symptoms.md`.** If the symptom is there, the cause and fix are too.
3. **Verify the cause by reading the existing code.** Don't guess. The patch only works if the diagnosis is correct.
4. **Apply the minimum patch.**
5. **Mentally re-render.** Walk through the change: does it actually solve the symptom without introducing a new one?

## How to read existing code defensively

Before patching, scan for:

- **The Tailwind version** in `package.json` — affects which CSS syntax is in `globals.css`
- **The styling library** — plain Tailwind, shadcn/ui, custom design system. Determines whether to use `bg-neutral-950` or `bg-background`
- **The component library** — Radix, Headless UI, custom. Determines whether modals/dropdowns already have accessibility baked in
- **The router** — App Router (`app/` directory) or Pages Router (`pages/`). This skill assumes App Router; flag a mismatch
- **Custom design tokens** — search for color variables in `globals.css` and `tailwind.config.ts`. Match the project's palette in your patch
- **Existing patterns in the file** — if the rest of the file uses `clsx` or `cn`, use the same. If everything is inline strings, use inline strings

The patch should look like it belongs in the file. Don't introduce `cn` if nothing else in the file uses it. Don't introduce shadcn imports if it's not a shadcn project.

## Adapting patterns to project conventions

The patterns in `patterns/` use Tailwind's neutral palette and standalone HTML elements. Real projects usually have:

| Their pattern | Adapt to |
|---|---|
| `bg-neutral-950 text-neutral-100` | `bg-background text-foreground` (shadcn), or `bg-zinc-950 text-zinc-100` (custom scale), etc. |
| `<button className="...">` | `<Button variant="..." size="...">` if shadcn Button exists |
| `border-neutral-800` | `border-border` or the project's border color |
| `bg-violet-500` (accent) | The project's primary brand color — `bg-primary`, `bg-brand`, etc. |
| Hand-rolled Dialog | Project's existing `<Dialog>` if one exists |
| Inline icon SVGs | The icon library the project uses (`lucide-react`, `react-icons`, `@heroicons/react`) |

Read 3-5 existing components in the project before patching. Match their style.

## When to refactor vs. patch

Refactor (replace a section with a pattern from `patterns/`) only when:

- The user explicitly asked to refactor or rewrite
- The existing code has 3+ failure modes simultaneously (rare; usually means starting over is faster)
- The existing code is a copy-paste of broken AI output that doesn't match anything in the project
- The user is mid-build and welcomes structural feedback (they just said "I'm building X")

Patch (minimal change) when:

- The user said "fix" — they want to keep their work
- The existing code is mostly fine with one or two specific issues
- The component is used in many places (a refactor would force changes elsewhere)
- The project has conventions you'd break by replacing

## Communicating the fix

When presenting a fix, structure the response:

1. **Name the bug.** "Your subtitle is left-aligned because it has `max-w-md` without `mx-auto`."
2. **Show the patch.** Just the changed lines, with the old and new visible.
3. **Briefly say why.** One sentence on the rule. Don't lecture.
4. **Stop.** Don't rewrite the whole component to "also improve" things the user didn't ask about.

Example of a good response:

> Your subtitle is left-aligned because `max-w-md` constrains the width without centering the block. Change:
>
> ```tsx
> <p className="max-w-md text-lg">
> ```
>
> to:
>
> ```tsx
> <p className="mx-auto max-w-md text-lg">
> ```
>
> `text-center` on the parent only centers text *inside* the box; the box itself needs `mx-auto`.

Example of a bad response:

> I noticed your whole section needs work. Let me rewrite it: [...500 lines of new code...]

The bad version replaces working code, introduces unrelated changes, and forces the user to re-verify everything. Don't do that unless asked.

## When the diagnosis is uncertain

Sometimes you can't tell from a description whether the bug is:
- Centering lies vs. flex misalignment
- Overflow ancestor vs. wrong z-index
- Hydration vs. fundamentally broken markup

Ask one targeted question, not a list:

> Is the dropdown getting cut off by a card edge (visible up to the card boundary then clipped), or is it appearing in the wrong position (rendering somewhere unexpected)?

The answer narrows the fix from two candidates to one. Don't ask three questions when one will do.

## Diagnosing from a screenshot

When the user shares a screenshot of the bug:

1. **Identify the failure mode** from the twelve in `SKILL.md`. Most bugs are one of those twelve.
2. **Sanity check against `symptoms.md`** — confirm the visual signature matches what you think it is.
3. **Ask for the relevant code** if not provided. Don't guess at code from a screenshot; the patch needs the actual class strings.
4. **Apply the minimum patch.**

Multiple bugs in one screenshot is common. Fix them in priority order:
- Layout failures first (hero, grid, centering) — these block other diagnoses
- Component-level failures next (clipping, overflow, sticky)
- Cosmetic and polish last (spacing, hover states, animations)

## When the fix breaks something else

Sometimes the right patch surfaces a second bug that was hidden by the first.

Example: removing `overflow-hidden` from a card to fix a dropdown clipping bug now causes the card's rounded corners to not clip an inner image.

Acknowledge it, explain, and offer the fix:

> Removing `overflow-hidden` fixes the dropdown but now the inner image overflows the card's rounded corners. Two options:
> - Add `rounded-2xl` to the inner image so it clips itself
> - Portal the dropdown to `<body>` (use Radix DropdownMenu) and put `overflow-hidden` back

Give the user the choice. Don't unilaterally pick one.

## Anti-patterns when fixing

**Don't:**

- Rewrite a component to fix one class
- Introduce a new library to fix a layout bug
- Change the project's color palette while fixing structure
- Suggest "best practices" the user didn't ask about (security, performance, naming) when they asked about layout
- Replace inline styles with `cn()` calls if the rest of the file uses inline styles
- Add `"use client"` to a working server component because your patch uses a hook (find a server-side fix)
- Wrap working content in unnecessary `<div>`s just to apply a class
- Add comments explaining the fix in the patched code itself — explain in the response, not the code

**Do:**

- Make the smallest possible change
- Match existing project conventions
- State your diagnosis confidently when you're sure
- Ask one question when you're not sure
- Mentally re-render before claiming the fix works
- Verify the fix against `symptoms.md` if it matches a known pattern
