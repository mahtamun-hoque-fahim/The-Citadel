---
name: sentinel
description: >
  Deep security audit for Fahim's stack — OWASP Top 10:2025 + STRIDE adapted
  specifically for BetterAuth, Drizzle ORM, Cloudinary, Lemon Squeezy webhooks,
  and Upstash Redis. Always scans the existing codebase first (retrofit mode)
  — finds exact files, greps for real patterns, checks installed dependency
  versions against known CVEs, then produces a CRITICAL/HIGH/MEDIUM/LOW report
  with file:line evidence and a one-line fix per finding. Read-only — never
  edits code. ALWAYS use when Fahim says "sentinel", "run sentinel", "security
  audit", "security check", "audit security", "OWASP audit", "STRIDE", "pen
  test", "check for vulnerabilities", "is this safe to ship", "is this
  secure", "check my auth", "webhook security", "before launch security
  check", or whenever auth, payments, webhooks, file uploads, or rate limiting
  need a security pass before shipping. Trigger even on casual phrasing like
  "can someone hack this" or "is my upload endpoint safe."
---

# Sentinel

Finds exploitable gaps before someone else does. Scans the real codebase,
classifies every finding with a severity, an OWASP Top 10:2025 category, and
a STRIDE letter, and hands back exact `file:line` evidence with a fix —
never vague advice, never a vibes-based "looks secure."

**Position in Fahim's pipeline:**
```
Waterborne → motion-hive → valley-of-death → sentinel → Airborne → Humanizer → Council POST
```

Sentinel runs after Valley of Death (so it's auditing a codebase that already
matches spec, not a moving target) and before Council POST — the Architect
persona's security pass in Council should read Sentinel's report rather than
re-deriving findings from scratch.

### Quick reference: STRIDE

| Letter | Means | Plain English |
|---|---|---|
| **S** | Spoofing | Pretending to be someone/something else |
| **T** | Tampering | Modifying data or code without authorization |
| **R** | Repudiation | No trail proving who did what |
| **I** | Information Disclosure | Data exposed to who shouldn't see it |
| **D** | Denial of Service | Availability degraded or killed |
| **E** | Elevation of Privilege | Gaining access beyond what's authorized |

This skill uses **OWASP Top 10:2025** (the list OWASP finalized in January
2026 — it replaced the 2021 list: Broken Access Control and Security
Misconfiguration moved up, Software Supply Chain Failures and Mishandling of
Exceptional Conditions are new, and SSRF folded into Broken Access Control).
If you're cross-referencing older material that cites "A06:2021 Vulnerable
Components," that's now **A03:2025 Software Supply Chain Failures**.

---

## Phase 0 — Retrofit Scan & Surface Detection (always runs first)

Never assume a clean slate. Detect what's actually wired up, then scope the
audit to it — running the Lemon Squeezy section against a project with no
billing wastes time and produces noise.

```bash
# 1. Anchor to spec if present
cat BRAIN.md 2>/dev/null
cat PLANNER.md 2>/dev/null

# 2. Detect installed surfaces from package.json
cat package.json | grep -E "better-auth|drizzle-orm|cloudinary|lemonsqueezy|@upstash"

# 3. Locate the real files per surface
find . -path ./node_modules -prune -o -name "auth.ts" -print
find . -path ./node_modules -prune -o -name "schema.ts" -print
grep -rl "cloudinary" --include="*.ts" --include="*.tsx" app/ lib/ 2>/dev/null
grep -rl "X-Signature\|x-signature" --include="*.ts" app/ 2>/dev/null
grep -rl "@upstash/ratelimit\|@upstash/redis" --include="*.ts" lib/ app/ 2>/dev/null
grep -rl "formData()\|multipart/form-data\|req\.formData\|: File\b" --include="*.ts" --include="*.tsx" app/ lib/ 2>/dev/null

# 4. Env hygiene baseline
cat .gitignore | grep -E "\.env"
ls .env.local .env.example 2>/dev/null

# 5. Dependency audit
npm audit --omit=dev 2>&1 | tail -40
```

### Known-CVE check

Cross-check installed versions against advisories already known to affect
this stack:

| Package | Vulnerable range | Patched | Issue |
|---|---|---|---|
| `drizzle-orm` | ≤0.45.1, ≤1.0.0-beta.19 | 0.45.2 / 1.0.0-beta.20 | **CVE-2026-39356** — `sql.identifier()` / `.as()` don't escape embedded quote delimiters when fed untrusted input (dynamic sorting, dynamic alias names). Enables SQL injection. CVSS 7.5 (High). |

If the installed `drizzle-orm` version is in the vulnerable range, grep for
`sql.identifier(` and `.as(` calls. If either receives anything other than a
literal string or a value from a hardcoded allowlist (e.g. `req.query.sort`
flowing in directly), rate **CRITICAL**. If the version is vulnerable but no
such call exists in the codebase, rate **MEDIUM** — latent risk, recommend
the version bump anyway since new code could introduce it later.

This table will go stale. For any core package (`next`, `better-auth`,
`drizzle-orm`, `@neondatabase/serverless`) that `npm audit` doesn't flag but
hasn't been bumped in a while, web-search `<package> CVE` to catch anything
published after this skill was last updated.

### Scan summary format

Print before starting the checklist:

```
SENTINEL — [Project] — [date]
─────────────────────────────────────────
SPEC      : BRAIN.md [found/missing] | PLANNER.md [found/missing]
SURFACES  : BetterAuth [y/n] · Drizzle [y/n] · Cloudinary [y/n] ·
            Lemon Squeezy [y/n] · Upstash [y/n] · File upload (any provider) [y/n]
DEPS      : npm audit — N critical, N high, N moderate, N low
KNOWN CVE : drizzle-orm @[version] — [vulnerable/patched]
─────────────────────────────────────────
Running sections: A, B, C, D, [E if LS] [F1-F4 if any file upload] [F5-F8 if Cloudinary] [G if Upstash], H, I
```

Sections E (Lemon Squeezy) and G (Upstash) are skipped entirely — not
marked N/A in the report — when Phase 0 finds no trace of that integration.
Section F splits: F1–F4 run on **any** detected file-upload surface
regardless of storage provider; F5–F8 run only if Cloudinary specifically
is detected. A project with raw `formData()` handling and no Cloudinary
still gets F1–F4 — that gap (file uploads with no named storage provider
attached) is exactly the kind of surface that used to fall through
entirely.

For exact copy-paste grep commands per domain — useful once a finding needs
deeper confirmation than the one-liners in the checklist below — read
`references/checks.md`.

---

## Severity Scale

Matches the Architect persona in `council` — use these definitions exactly
so findings carry the same weight across skills.

| Severity | Criteria |
|---|---|
| **CRITICAL** | Exploitable right now, no auth required, leads to account takeover, data breach, or payment/entitlement bypass |
| **HIGH** | Exploitable with a precondition (must be authenticated, must know a non-secret detail) or high blast radius even if conditional |
| **MEDIUM** | Real weakness, not immediately exploitable, or requires unusual circumstances — defense-in-depth gap |
| **LOW** | Best-practice deviation with minimal real-world exploitability |
| **PASS** | Check satisfied |

---

## Checklist

### A — Secrets, Env & Supply Chain
*[OWASP A02:2025 Security Misconfiguration · A03:2025 Software Supply Chain Failures · A04:2025 Cryptographic Failures]* · STRIDE: I

1. No literal secret values committed anywhere in tracked files — grep for
   connection strings (`postgres://...:...@`), `sk_live_`, `AKIA`, and any
   `const ... = "..."` assignment to a variable named like a secret.
2. `.gitignore` covers `.env`, `.env.local`, `.env*.local`.
3. No variable that holds a real secret is prefixed `NEXT_PUBLIC_` — that
   prefix bundles it into client-side JS. Grep `NEXT_PUBLIC_` across `.env.example`
   and cross-check each one is genuinely meant to be public.
4. `BETTER_AUTH_SECRET` is 32+ random characters, loaded from env, never
   hardcoded as a fallback (a pattern like `secret: process.env.BETTER_AUTH_SECRET || "dev-secret"`
   is common and dangerous — the fallback ships to production).
5. `npm audit` CRITICAL/HIGH findings — list each with package name and fix
   (`npm audit fix` or manual bump).
6. Known-CVE table above — report drizzle-orm status explicitly.

> **If a grep in this section actually matches a real secret value** — do
> not print the value in the report. Show `file:line` only, write
> `[REDACTED]` in place of the value, and tell Fahim to rotate it
> immediately. This matches the standing rule across all of Fahim's repos.

---

### B — Authentication & Session (BetterAuth)
*[OWASP A07:2025 Authentication Failures · A04:2025 Cryptographic Failures]* · STRIDE: S, E

1. `lib/auth.ts` loads the secret from `process.env.BETTER_AUTH_SECRET` —
   no hardcoded fallback (cross-ref A4 above).
2. `trustedOrigins` is set to the real production domain(s) — not left at
   default if the app is served from a custom domain, and never set to a
   wildcard.
3. `disableCSRFCheck` and `disableOriginCheck` are not set to `true`
   anywhere in the config. Either one being true is an immediate CRITICAL —
   both disable origin validation and open the door to CSRF and open
   redirects.
4. `useSecureCookies` — confirm cookies are secure in production (Better
   Auth defaults to secure-in-production, but verify `baseURL`/`BETTER_AUTH_URL`
   is actually `https://`, since the secure-cookie logic keys off that).
5. `crossSubDomainCookies` is disabled unless Fahim explicitly needs shared
   auth across subdomains — if enabled, confirm the `domain` value is scoped
   correctly (leading dot, exact subdomain set) and not unnecessarily broad.
6. `session.expiresIn` / `updateAge` are reasonable (7-day expiry, daily
   refresh is Fahim's standard — flag anything open-ended or absent).
7. Sign-in and sign-up routes have rate limiting in front of them (cross-ref
   Section G) — brute-force protection on auth endpoints specifically,
   not just global API rate limiting.

---

### C — Authorization & Access Control
*[OWASP A01:2025 Broken Access Control]* · STRIDE: E

1. Every protected route (`/dashboard`, `/admin`, `/admin/*`, any
   role-gated page) calls `auth.api.getSession()` **server-side** at the top
   of the page or layout — a client-only check (`useSession()` driving a
   conditional render) is decoration, not a gate, and rates CRITICAL if it's
   the only check present.
2. Role checks happen server-side. If `PLANNER.md` defines roles
   (`student`/`staff`/`admin` or project-specific), confirm the role
   comparison happens in the Server Component or Route Handler, not just in
   the UI.
3. **IDOR check** — for every API route that takes a resource ID
   (`/api/mockups/[id]`, `/api/notes/[id]`, etc.), confirm the handler
   verifies the resource's owner matches the requesting session's user ID
   before returning or mutating it. A route that fetches by ID alone without
   an ownership `WHERE` clause lets any authenticated user read or edit
   anyone else's data — CRITICAL.
4. `proxy.ts` (Next.js 16) or `middleware.ts` (Next.js 15) `matcher` config
   actually covers every sensitive path — check for typos or missing
   trailing wildcards (`/admin` without `/admin/:path*` only protects the
   exact route, not its children).
5. Admin/mod routes are absent from public nav, footer, and `sitemap.ts`
   (the SEO file Airborne generates) — this overlaps with Valley of Death's
   scope check, but here the question is whether the route is *reachable
   without authorization*, not whether it's *linked*. A route can be unlinked
   and still unguarded.
6. **If `SITETREE.md` exists** (tree-man's page manifest, not `sitemap.ts`),
   read its Auth column and treat it as the intended baseline: every route
   marked `authenticated`/`admin`/`role:[x]` must have a matching server-side
   guard in the code, and every route marked `public` must not have a
   surprise gate blocking it. Flag `CRITICAL — auth level mismatch:
   SITETREE.md declares [X], code enforces [Y]` for any gap. This turns this
   section from inference into verification — use it whenever the file is
   present rather than re-deriving intended access levels from scratch.

---

### D — Injection & Data Layer (Drizzle)
*[OWASP A05:2025 Injection]* · STRIDE: T

1. Grep for `sql.raw(`. Any call where the argument is built from a template
   literal containing an interpolated variable is CRITICAL — `sql.raw()` has
   zero injection protection by design.
2. Grep for `sql.identifier(` and `.as(` — cross-reference against the
   known-CVE check in Phase 0.
3. Confirm ordinary query-builder methods (`.where(eq(...))`,
   `.where(and(...))`) are used for anything touching user input — Drizzle's
   standard methods and the `sql` template tag both auto-parameterize, so
   this is a spot-check, not an exhaustive one.
4. Grep for manual string concatenation building a query before it reaches
   `db.execute()` — even outside `sql.raw()`, string-built SQL handed to
   the execute call defeats parameterization.
5. Grep for `dangerouslySetInnerHTML`. Confirm any user-generated content
   rendered this way is sanitized (DOMPurify or equivalent) before it
   reaches the prop — unsanitized is a stored-XSS CRITICAL if the content
   is shared with other users, HIGH if it's self-only.

---

### E — Webhook & Payment Integrity (Lemon Squeezy)
*Runs only if Phase 0 detected a Lemon Squeezy webhook route.*
*[OWASP A08:2025 Software or Data Integrity Failures]* · STRIDE: S, T, R

1. The webhook route reads the **raw body** (`await request.text()`) and
   verifies the signature against that raw text — not against a re-stringified
   parsed body, which re-serializes with different whitespace/key-order and
   will desync from what Lemon Squeezy actually signed.
2. `X-Signature` header is verified via HMAC-SHA256 against
   `LEMONSQUEEZY_WEBHOOK_SECRET` (or equivalently named env var) — confirm
   the secret isn't hardcoded.
3. The comparison uses `crypto.timingSafeEqual()`, not `===` or `.includes()`
   on the hex strings — string equality on a signature is timing-attackable.
   `timingSafeEqual` requires equal-length buffers, so confirm there's a
   length check before the call (mismatched lengths throw, not return false).
4. **Idempotency** — the handler checks whether this event ID has already
   been processed before granting/extending an entitlement. Lemon Squeezy
   retries on non-2xx responses; without dedup, a transient 500 followed by
   a retry double-grants whatever the event triggers.
5. No internal route exists that grants/upgrades entitlements based on
   client-supplied plan or price data — the webhook payload (post-signature-
   verification) should be the only path that mutates billing state.

---

### F — File Upload Integrity
*F1–F4 run on any detected file-upload surface — `formData()`, `multipart/form-data`, a `File`/`Blob` handler, or an upload route — regardless of storage provider. F5–F8 run only if Phase 0 detected Cloudinary specifically.*
*[OWASP A02:2025 Security Misconfiguration · A06:2025 Insecure Design · A08:2025 Software or Data Integrity Failures · A10:2025 Mishandling of Exceptional Conditions]* · STRIDE: T, D

**F1–F4 — any file-upload surface, regardless of storage provider:**

1. File size is validated against the actual received buffer/stream
   length, not only trusted from a client-sent `Content-Length` header or
   filename — and the limit is enforced before the full file is read into
   memory, where the runtime allows streaming.
2. If the code parses the uploaded file's own internal structure (binary
   headers, length-prefixed fields, embedded size/offset values — font
   files, archives, images with custom containers, anything with a custom
   binary format), every size/offset/length field read **from inside the
   untrusted file itself** is bounds-checked against the actual remaining
   buffer before it's used in an allocation, a `slice`, or a loop counter.
   A crafted file that declares an oversized internal length and flows
   straight into `Buffer.alloc()`, `new Array(n)`, or an unbounded loop is
   a Denial of Service vector — the HTTP-layer size cap doesn't catch this,
   because the dangerous value lives inside an otherwise-small file, not in
   its total byte count.
3. Parsing failures on malformed input return a clean 4xx, not an
   unhandled exception that crashes the function or leaks a stack trace —
   confirm the parsing path fails closed inside a try/catch.
4. Temp files, if written to disk, are cleaned up in a `finally` block on
   both the success and error paths, not only on success.

**F5–F8 — only if Cloudinary is detected:**

5. Identify signed vs. unsigned upload usage. Unsigned uploads aren't
   inherently broken — Cloudinary's own guidance is that the worst case is
   quota abuse, not data tampering — but confirm it's a deliberate choice
   for genuinely public, low-stakes uploads, not used for anything tied to
   a paid feature or account-linked asset.
6. If unsigned, the upload preset restricts folder, format, and max file
   size (`Upload Presets` config) — an unrestricted unsigned preset lets
   anyone burn through Cloudinary quota.
7. `CLOUDINARY_API_SECRET` never appears in any client-bundled file — grep
   for it outside `lib/`, `app/api/`, and other server-only paths, and
   confirm it's not `NEXT_PUBLIC_`-prefixed (cross-ref Section A).
8. If signed uploads are used, the signature is generated server-side per
   request — never pre-generated and reused, which would let one signature
   authorize unlimited uploads until its timestamp expires.

---

### G — Rate Limiting & Resilience (Upstash)
*Runs only if Phase 0 detected `@upstash/ratelimit` or `@upstash/redis`.*
*[OWASP A06:2025 Insecure Design · A10:2025 Mishandling of Exceptional Conditions]* · STRIDE: D

1. Rate limiting is present on auth routes (sign-in, sign-up, password
   reset) and any public-facing mutation endpoint, not just on one global
   middleware path that other routes silently bypass.
2. The key used to identify a caller is a trusted value, not a raw,
   client-controlled header. Reading `x-forwarded-for` without taking the
   correct trusted hop is spoofable — an attacker sets their own header
   value and gets a fresh bucket on every request. On Vercel, prefer the
   platform-provided IP rather than parsing the header manually.
3. Check the failure mode when Redis is unreachable. `ratelimit.limit()`
   has a `timeout` option that, when it fires, **fails open** by default
   (reason `'timeout'`) — meaning an outage silently disables the rate
   limiter instead of blocking traffic. Confirm this is an explicit decision
   for this route, not an accident — auth endpoints should generally fail
   closed; less sensitive endpoints failing open is a reasonable tradeoff.
4. `UPSTASH_REDIS_REST_TOKEN` is never sent to the client (cross-ref
   Section A) — the REST token is a bearer credential, full read/write to
   the database if leaked.

---

### H — Headers & Transport
*[OWASP A02:2025 Security Misconfiguration]* · STRIDE: T, I

1. No hardcoded `http://` asset or API URLs that would trigger mixed-content
   issues on an otherwise-HTTPS deploy.
2. `next.config` defines a `headers()` function setting at minimum
   `X-Content-Type-Options: nosniff` and a `Referrer-Policy`. A
   `Content-Security-Policy` is a stronger bar — flag its absence as MEDIUM,
   not CRITICAL, since most of Fahim's projects don't yet set one.
3. No API route sets `Access-Control-Allow-Origin: *` on anything that reads
   session cookies or returns user-specific data — wildcard CORS on an
   authenticated endpoint lets any origin read the response if a browser
   ever sends credentials there.

---

### I — Logging, Errors & Information Disclosure
*[OWASP A09:2025 Security Logging & Alerting Failures · A10:2025 Mishandling of Exceptional Conditions]* · STRIDE: R, I

1. No `console.log` of session tokens, full user objects, passwords, or
   webhook secrets — distinct from Valley of Death's general console.log
   sweep, this specifically flags logs that leak something exploitable if
   captured (Vercel logs, error trackers).
2. Production error responses return a generic message, not a raw stack
   trace or file path — confirm `error.tsx` / API error handlers don't
   forward `error.message` or `error.stack` directly to the client in
   production.
3. Catch blocks around security-relevant checks fail closed, not open — a
   webhook signature check, an auth guard, or a permission check that throws
   should result in a rejection, never a caught exception that falls through
   to "process anyway."

---

## Deliverable Format

```
SENTINEL — [Project Name] — [Date]
═══════════════════════════════════════════════════════════════

SCAN SUMMARY
  Surfaces detected : BetterAuth · Drizzle · [+ any of Cloudinary/LS/Upstash]
  npm audit          : N critical, N high, N moderate
  Known CVE          : drizzle-orm @X.X.X — [vulnerable/patched]

─────────────────────────────────────────────────────────────────
FINDINGS
─────────────────────────────────────────────────────────────────

A. SECRETS, ENV & SUPPLY CHAIN
  [CRITICAL/HIGH/MEDIUM/LOW/PASS] A1 — <evidence file:line> — <fix>
  ...

B. AUTHENTICATION & SESSION
  [severity] B1 — <evidence> — <fix>
  ...

C. AUTHORIZATION & ACCESS CONTROL
  ...

D. INJECTION & DATA LAYER
  ...

E. WEBHOOK & PAYMENT INTEGRITY        (omitted if no Lemon Squeezy)
  ...

F. FILE UPLOAD INTEGRITY              (F1-F4 omitted only if no upload surface at all; F5-F8 omitted if no Cloudinary)
  ...

G. RATE LIMITING & RESILIENCE         (omitted if no Upstash)
  ...

H. HEADERS & TRANSPORT
  ...

I. LOGGING & INFORMATION DISCLOSURE
  ...

─────────────────────────────────────────────────────────────────
PRIORITY ORDER (most exploitable first)
─────────────────────────────────────────────────────────────────
  1. [CRITICAL] <description> — file:line
  2. [HIGH] ...
  ...

─────────────────────────────────────────────────────────────────
Propose fixes above. Awaiting approval before changing any code.
```

---

## Operating Rules

- **Read-only.** Sentinel audits and reports — it never edits, creates, or
  deletes a file. Fixes happen only after Fahim reviews and approves.
- **Evidence required.** Every finding above PASS needs `file:line`. No
  finding gets reported on suspicion alone — confirm by reading the actual
  code.
- **Never print a real secret value.** If a grep surfaces an actual key,
  token, or connection string, redact it in the report, cite the location,
  and tell Fahim to rotate it immediately — this is non-negotiable and holds
  regardless of how the finding was reached.
- **Scope to what's detected.** Don't run Section E/F/G checks — or invent
  findings for them — on a project that doesn't use that integration.
- **Severity is calibrated, not inflated.** Reserve CRITICAL for things
  exploitable today with no special access. A theoretical weakness that
  needs three preconditions to matter is MEDIUM at most, even if it sounds
  scary in the abstract.
- **Most exploitable first.** The Priority Order section ranks by real
  risk, not by checklist position.
- **Ask before fixing.** Every report ends with the same line Valley of
  Death uses: awaiting approval before any code changes.

---

## Relationship to other skills

| Skill | Relation to sentinel |
|---|---|
| **valley-of-death** | Runs before sentinel — confirms the codebase matches spec so sentinel audits a stable target, not a moving one. Some overlap (console.log, route reachability) is intentional; each checks it from a different angle. |
| **tree-man** | Runs at project start, long before sentinel — writes SITETREE.md's Auth column. Sentinel's Section C reads it as the intended baseline rather than guessing access levels from scratch. |
| **council** (Architect persona) | Architect's POST-BUILD security pass should read sentinel's report rather than re-deriving findings — sentinel does the file:line work, Architect synthesizes into the five-persona verdict. |
| **waterborne** | Runs earlier in the pipeline — irrelevant to security findings, but a clean codebase is easier to audit. |
| **task-planner** | After sentinel delivers findings and Fahim approves fixes, task-planner can turn the Priority Order list into atomic, verifiable tasks. |
| **next15builder / next16builder** | Reference for what "correct" looks like when proposing a fix for an auth or routing finding. |
