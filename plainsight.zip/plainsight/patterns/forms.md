# Forms

Inputs, labels, validation states, multi-step forms, file upload, search, auth screens, action bars.

## Field stack (label + input + helper/error)

The atomic unit. Every form field follows this exact pattern.

```tsx
<div className="space-y-1.5">
  <label htmlFor="email" className="block text-sm font-medium text-neutral-200">
    Email
  </label>
  <input
    id="email"
    name="email"
    type="email"
    autoComplete="email"
    required
    className="block w-full rounded-md border border-neutral-800 bg-neutral-900 px-3 py-2 text-sm placeholder:text-neutral-500 focus:border-violet-500 focus:outline-none focus:ring-2 focus:ring-violet-500/20 aria-[invalid=true]:border-red-500 aria-[invalid=true]:focus:ring-red-500/20"
    placeholder="you@example.com"
  />
  <p className="text-xs text-neutral-500">We&apos;ll never share your email.</p>
</div>
```

Non-negotiables:
- `<label htmlFor="...">` matches `<input id="...">` — clickable label, screen-reader compatible.
- `autoComplete` set correctly for browser autofill (`email`, `current-password`, `new-password`, `name`, `tel`, `street-address`, etc.).
- `focus:outline-none focus:ring-2` — never remove focus indication without replacing it. Removed focus rings without a replacement is an accessibility failure.
- `aria-[invalid=true]:` styling for error state, toggled via the `aria-invalid` prop.

## Error state

```tsx
<div className="space-y-1.5">
  <label htmlFor="email" className="block text-sm font-medium text-neutral-200">Email</label>
  <input
    id="email"
    aria-invalid={!!error}
    aria-describedby={error ? "email-error" : undefined}
    className="block w-full rounded-md border border-neutral-800 bg-neutral-900 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20 aria-[invalid=true]:border-red-500 aria-[invalid=true]:focus:ring-red-500/20"
  />
  {error && (
    <p id="email-error" className="text-xs text-red-400">{error}</p>
  )}
</div>
```

- `aria-invalid` triggers the red border via the Tailwind selector.
- `aria-describedby` points to the error message id, so screen readers announce it.
- Error message text is `text-xs`, color `red-400` (legible against dark backgrounds; use `red-600` on light themes).

## Password input with show/hide

```tsx
"use client";
import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";

export default function PasswordInput() {
  const [visible, setVisible] = useState(false);
  return (
    <div className="space-y-1.5">
      <label htmlFor="password" className="block text-sm font-medium text-neutral-200">Password</label>
      <div className="relative">
        <input
          id="password"
          type={visible ? "text" : "password"}
          autoComplete="current-password"
          className="block w-full rounded-md border border-neutral-800 bg-neutral-900 px-3 py-2 pr-10 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20"
        />
        <button
          type="button"
          onClick={() => setVisible((v) => !v)}
          className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-neutral-400 hover:text-white"
          aria-label={visible ? "Hide password" : "Show password"}
        >
          {visible ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
        </button>
      </div>
    </div>
  );
}
```

`type="button"` on the toggle is critical — without it, clicking the toggle submits the form (default button type inside a form is `submit`).

## Field row (label and input side-by-side)

```tsx
<div className="grid grid-cols-1 items-start gap-2 sm:grid-cols-3 sm:gap-4">
  <label htmlFor="name" className="text-sm font-medium text-neutral-200 sm:pt-2">
    Display name
  </label>
  <div className="sm:col-span-2">
    <input
      id="name"
      className="block w-full rounded-md border border-neutral-800 bg-neutral-900 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20"
    />
    <p className="mt-1 text-xs text-neutral-500">
      This is the name others will see.
    </p>
  </div>
</div>
```

Stacks on mobile, side-by-side from `sm` up. `items-start` keeps the label aligned with the input's first line. `sm:pt-2` nudges the label down to match the input's text baseline (depends on padding; adjust).

## Textarea

```tsx
<textarea
  id="message"
  rows={4}
  className="block w-full resize-y rounded-md border border-neutral-800 bg-neutral-900 px-3 py-2 text-sm placeholder:text-neutral-500 focus:outline-none focus:ring-2 focus:ring-violet-500/20"
  placeholder="Write a message..."
/>
```

`resize-y` allows vertical resize only. `resize-none` to disable. Setting `rows` gives a sensible initial height.

## Select

```tsx
<select
  id="role"
  className="block w-full appearance-none rounded-md border border-neutral-800 bg-neutral-900 bg-[url('data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 20 20%22 fill=%22%23737373%22><path d=%22M5 7l5 5 5-5z%22/></svg>')] bg-[position:right_0.5rem_center] bg-no-repeat px-3 py-2 pr-9 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20"
>
  <option value="">Select a role</option>
  <option value="admin">Admin</option>
  <option value="member">Member</option>
</select>
```

`appearance-none` removes the native arrow; the inline SVG background paints a custom one. For complex selects (search, multi-select), use a library — Radix Select, Headless UI Listbox, or shadcn's wrapper.

## Checkbox and radio

```tsx
{/* Checkbox */}
<label className="flex items-start gap-2.5">
  <input
    type="checkbox"
    className="mt-0.5 size-4 shrink-0 rounded border-neutral-700 bg-neutral-900 text-violet-500 focus:ring-2 focus:ring-violet-500/20 focus:ring-offset-0"
  />
  <span className="text-sm text-neutral-200">
    I agree to the <a href="/terms" className="text-violet-400 underline">terms</a>
  </span>
</label>

{/* Radio group */}
<fieldset className="space-y-2">
  <legend className="text-sm font-medium text-neutral-200">Plan</legend>
  {["Free", "Pro", "Team"].map((plan) => (
    <label key={plan} className="flex items-center gap-2.5">
      <input
        type="radio"
        name="plan"
        value={plan}
        className="size-4 border-neutral-700 bg-neutral-900 text-violet-500 focus:ring-2 focus:ring-violet-500/20 focus:ring-offset-0"
      />
      <span className="text-sm">{plan}</span>
    </label>
  ))}
</fieldset>
```

`shrink-0` on the checkbox prevents it from compressing when the label wraps. `mt-0.5` nudges the box down to align with the text's first line.

## Switch / toggle

For accessibility-critical UI, use Radix Switch. The visual pattern:

```tsx
"use client";
import { useState } from "react";

export default function Switch() {
  const [on, setOn] = useState(false);
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={() => setOn((o) => !o)}
      className={`relative inline-flex h-6 w-11 shrink-0 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:ring-offset-2 focus:ring-offset-neutral-950 ${
        on ? "bg-violet-500" : "bg-neutral-700"
      }`}
    >
      <span
        className={`inline-block size-5 translate-y-0.5 rounded-full bg-white shadow transition-transform ${
          on ? "translate-x-[1.375rem]" : "translate-x-0.5"
        }`}
      />
    </button>
  );
}
```

## Action bar (form footer)

The row with Cancel/Save buttons at the bottom of a form.

```tsx
<div className="flex flex-col-reverse gap-2 border-t border-neutral-800 pt-4 sm:flex-row sm:justify-end">
  <button
    type="button"
    className="rounded-md border border-neutral-800 bg-neutral-900 px-4 py-2 text-sm hover:bg-neutral-800"
  >
    Cancel
  </button>
  <button
    type="submit"
    className="rounded-md bg-violet-500 px-4 py-2 text-sm font-medium text-white hover:bg-violet-600 disabled:opacity-50"
  >
    Save changes
  </button>
</div>
```

- `flex-col-reverse` on mobile so the primary action sits on TOP (closer to the thumb) and Cancel is below.
- `sm:flex-row sm:justify-end` on desktop so primary sits on the RIGHT (Western convention).
- `type="button"` on Cancel; without it, it would submit the form.
- `type="submit"` is implicit but worth declaring.

## Loading button (pending state)

```tsx
<button
  type="submit"
  disabled={pending}
  className="inline-flex items-center justify-center gap-2 rounded-md bg-violet-500 px-4 py-2 text-sm font-medium text-white hover:bg-violet-600 disabled:opacity-70"
>
  {pending && <Loader2 className="size-4 animate-spin" />}
  {pending ? "Saving..." : "Save"}
</button>
```

`disabled` while pending prevents double-submission. `Loader2` from lucide-react is the universal spinner icon; `animate-spin` is built into Tailwind.

For Server Actions, use `useFormStatus` to get `pending` automatically:

```tsx
"use client";
import { useFormStatus } from "react-dom";

export function SubmitButton() {
  const { pending } = useFormStatus();
  return <button disabled={pending}>{pending ? "Saving..." : "Save"}</button>;
}
```

## Multi-step / wizard form

```tsx
"use client";
import { useState } from "react";

const steps = ["Account", "Profile", "Confirm"];

export default function Wizard() {
  const [step, setStep] = useState(0);
  return (
    <div className="mx-auto max-w-xl space-y-8">
      {/* Step indicator */}
      <ol className="flex items-center gap-2">
        {steps.map((label, i) => (
          <li key={label} className="flex items-center gap-2">
            <div
              className={`flex size-7 items-center justify-center rounded-full text-xs font-medium ${
                i < step
                  ? "bg-violet-500 text-white"
                  : i === step
                  ? "bg-violet-500/20 text-violet-300 ring-1 ring-violet-500"
                  : "bg-neutral-900 text-neutral-500"
              }`}
            >
              {i + 1}
            </div>
            <span className={i === step ? "text-sm text-white" : "text-sm text-neutral-500"}>
              {label}
            </span>
            {i < steps.length - 1 && <span className="mx-2 h-px w-8 bg-neutral-800" />}
          </li>
        ))}
      </ol>

      {/* Step content */}
      <div>
        {step === 0 && <AccountStep />}
        {step === 1 && <ProfileStep />}
        {step === 2 && <ConfirmStep />}
      </div>

      {/* Nav */}
      <div className="flex justify-between">
        <button
          type="button"
          onClick={() => setStep((s) => Math.max(0, s - 1))}
          disabled={step === 0}
          className="rounded-md border border-neutral-800 bg-neutral-900 px-4 py-2 text-sm hover:bg-neutral-800 disabled:opacity-50"
        >
          Back
        </button>
        <button
          type="button"
          onClick={() => setStep((s) => Math.min(steps.length - 1, s + 1))}
          className="rounded-md bg-violet-500 px-4 py-2 text-sm font-medium text-white hover:bg-violet-600"
        >
          {step === steps.length - 1 ? "Submit" : "Continue"}
        </button>
      </div>
    </div>
  );
}
```

## File upload (drag and drop)

```tsx
"use client";
import { useState, useRef } from "react";
import { Upload } from "lucide-react";

export default function FileDrop() {
  const [dragging, setDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        if (e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]);
      }}
      onClick={() => inputRef.current?.click()}
      className={`flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed p-8 text-center transition cursor-pointer ${
        dragging ? "border-violet-500 bg-violet-500/5" : "border-neutral-800 hover:border-neutral-700"
      }`}
    >
      <Upload className="size-6 text-neutral-400" />
      <p className="text-sm text-neutral-300">
        {file ? file.name : "Drop a file or click to browse"}
      </p>
      <p className="text-xs text-neutral-500">PNG, JPG up to 10MB</p>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => e.target.files?.[0] && setFile(e.target.files[0])}
      />
    </div>
  );
}
```

`e.preventDefault()` on `onDragOver` is non-negotiable — without it, the browser opens the dropped file in a new tab and your `onDrop` never fires.

## Search bar (with submit)

```tsx
<form className="relative" role="search">
  <label htmlFor="q" className="sr-only">Search</label>
  <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-neutral-500" />
  <input
    id="q"
    name="q"
    type="search"
    placeholder="Search..."
    className="w-full rounded-md border border-neutral-800 bg-neutral-900 py-2 pl-9 pr-3 text-sm placeholder:text-neutral-500 focus:border-violet-500 focus:outline-none focus:ring-2 focus:ring-violet-500/20"
  />
</form>
```

`sr-only` on the label keeps it for screen readers without visual weight. `role="search"` is the landmark.

## Login form (assembled)

```tsx
<form className="space-y-4">
  <div className="space-y-1.5">
    <label htmlFor="email" className="block text-sm font-medium">Email</label>
    <input id="email" type="email" autoComplete="email" required className="block w-full rounded-md border border-neutral-800 bg-neutral-900 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20" />
  </div>

  <div className="space-y-1.5">
    <div className="flex items-center justify-between">
      <label htmlFor="password" className="text-sm font-medium">Password</label>
      <a href="/forgot" className="text-xs text-violet-400 hover:underline">Forgot?</a>
    </div>
    <input id="password" type="password" autoComplete="current-password" required className="block w-full rounded-md border border-neutral-800 bg-neutral-900 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20" />
  </div>

  <button type="submit" className="w-full rounded-md bg-violet-500 px-4 py-2 text-sm font-medium text-white hover:bg-violet-600">
    Sign in
  </button>

  <div className="relative">
    <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-neutral-800" /></div>
    <div className="relative flex justify-center text-xs">
      <span className="bg-neutral-950 px-2 text-neutral-500">or continue with</span>
    </div>
  </div>

  <div className="grid grid-cols-2 gap-2">
    <button type="button" className="inline-flex items-center justify-center gap-2 rounded-md border border-neutral-800 bg-neutral-900 px-3 py-2 text-sm hover:bg-neutral-800">
      Google
    </button>
    <button type="button" className="inline-flex items-center justify-center gap-2 rounded-md border border-neutral-800 bg-neutral-900 px-3 py-2 text-sm hover:bg-neutral-800">
      GitHub
    </button>
  </div>
</form>
```

The "or continue with" divider pattern uses absolute positioning to draw the line behind the text. `bg-neutral-950` on the text matches the page background so it appears to cut the line.
