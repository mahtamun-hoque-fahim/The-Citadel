---
name: mahtamun-fullstack
description: >
  Full-stack reference for Fahim's Next.js 14 App Router stack — TypeScript,
  Tailwind, Neon (PostgreSQL), Drizzle ORM, Better Auth, Vercel, and Cloudflare Pages.
  SCOPE: Next.js 14 ONLY. For Next.js 15 projects use next15builder / next15debugger /
  nextjs15-for-cf. For Next.js 16 projects use next16builder / next16-debugger /
  nextjs16-for-cf. Use this skill for: foundational stack patterns (Neon drivers,
  Drizzle config, Better Auth setup, lazy-getDb, DATABASE_URL split), and for any
  project that explicitly targets Next.js 14. Do NOT use when the project's package.json
  shows next@15.x or next@16.x — those projects need version-specific skills that
  have the correct async APIs and updated patterns.
---

# Mahtamun Full-Stack

> **Version scope: Next.js 14 App Router only.** If `package.json` shows `next@15.x` or `next@16.x`, stop and use the correct skill: `next15builder`/`next15debugger`/`nextjs15-for-cf` for v15, or `next16builder`/`next16-debugger`/`nextjs16-for-cf` for v16. Patterns here (synchronous `cookies()`, `middleware.ts`, single-arg `revalidateTag`) are v14-correct and will break on v15/v16.

Fahim's stack: **Next.js 14 App Router · TypeScript · Tailwind CSS · Neon (PostgreSQL) · Drizzle ORM · Better Auth · Vercel · Cloudflare Pages**

Context to assume:
- GitHub → Vercel auto-deploy. No local dev environment.
- Two deployments: Vercel (primary) + Cloudflare Pages (secondary).
- Dark theme; accent: read from `BRAIN.md § Visual Identity` or `DESIGN_GUIDE.md` tokens — never assume `#00e676`; fonts Syne / Onest / JetBrains Mono.
- Migrating from legacy split-cookie auth (auth-token + staff-token) to Better Auth for new projects.

When solving a problem, always: identify the error class, apply the standard fix from the table, then verify with the checklist before declaring done.

## Error → Fix lookup

| Error | Likely cause | Fix |
|---|---|---|
| `ReferenceError: process is not defined` | Node API used on Edge Runtime | Switch to `@neondatabase/serverless` neon-http driver |
| `connect ECONNREFUSED` | Using `pg` (node-postgres) on Edge | Same — switch to `neon-http` |
| `too many connections` | Not using pooling | Use `DATABASE_URL` (pooled), not unpooled |
| `relation does not exist` | Migration not run | `npx drizzle-kit migrate` against prod Neon |
| `column X does not exist` | Schema out of sync | Regenerate + run migration |
| `SSL required` | Missing SSL in connection string | Add `?sslmode=require` to URL |
| `cookies() was called outside a request scope` | Used in Client Component | Move to Server Component, Route Handler, or Server Action |
| `hydration mismatch` | Server/client render diff | Wrap in `useEffect`, `<Suspense>`, or `suppressHydrationWarning` |
| `ESLint: Parsing error` | Flat config + legacy config conflict | Remove `.eslintrc.*`; keep only `eslint.config.mjs` |
| `DATABASE_URL is required` (build time) | Missing env var | Add to Vercel/Cloudflare dashboards; add build-time guard in `lib/env.ts` |
| `Module not found` after refactor | Import path changed | Check barrel exports + tsconfig paths |
| `Edge runtime does not support Node.js 'crypto'` | Better Auth crypto on Edge | Move auth route to Node runtime: `export const runtime = 'nodejs'` |

## Deploy & build failures (Highest priority)

### Vercel

ESLint config conflicts — the most common build failure. `eslint.config.mjs` (flat) and `.eslintrc.*` (legacy) cannot coexist. Keep flat. Delete legacy.

Framework detection — if Vercel deploys wrong, set `framework: "nextjs"` in `vercel.json` or check repo root for stray config.

Env vars — `.env.local` must never be committed (rotate immediately if it leaks). In Vercel dashboard, Production / Preview / Development envs are separate. Add to all three. Missing env at build time causes silent `undefined` bugs — guard against this in `lib/env.ts`:

```ts
// lib/env.ts
const required = ['DATABASE_URL', 'DATABASE_URL_UNPOOLED', 'BETTER_AUTH_SECRET']
required.forEach(key => {
  if (!process.env[key]) throw new Error(`Missing env: ${key}`)
})
```

Production branch — if wrong branch deploys, check "Production Branch" in Vercel project settings.

### Cloudflare Pages

Edge Runtime is the recurring pain point. Node APIs (`fs`, `crypto`, `Buffer`, `pg`) are NOT available. Rules:

- Never use `pg` (node-postgres) — uses Node TCP, not supported on Edge.
- Use `@neondatabase/serverless` neon-http driver everywhere.
- Cookie reads in middleware must use Edge-compatible APIs.
- Better Auth's session validation can run on Edge if configured with `neon-http`; password hashing routes need Node runtime.

Build config:
- Framework preset: `Next.js`
- Build command: `npx @cloudflare/next-on-pages`
- Output directory: `.vercel/output/static`

`next.config.js` for Cloudflare:
```js
const nextConfig = {
  images: { unoptimized: true }, // Cloudflare doesn't run Next image optimization
}
module.exports = nextConfig
```

## Lazy getDb pattern (always use)

Build-time evaluation breaks when env vars are absent. Always lazy:

```ts
// lib/db/index.ts — Edge-compatible
import { neon } from '@neondatabase/serverless'
import { drizzle } from 'drizzle-orm/neon-http'
import * as schema from './schema'

export function getDb() {
  if (!process.env.DATABASE_URL) return null as any
  return drizzle(neon(process.env.DATABASE_URL), { schema })
}
```

Call site:
```ts
const db = getDb()
if (!db) return Response.json({ error: 'DB unavailable' }, { status: 503 })
```

For Node-only routes that need transactions, use the pool driver in a separate file (`lib/db/node.ts`). See `references/neon-drizzle.md`.

## Server vs Client boundary

```
app/
  page.tsx          Server Component by default (can be async)
  layout.tsx        Server Component by default
  components/
    ServerComp.tsx  No 'use client' — can fetch DB directly
    ClientComp.tsx  'use client' at top — no direct DB access
```

Rules:
- `useState` / `useEffect` / `onClick` → add `'use client'`
- `cookies()` / `headers()` → Server Component, Route Handler, or Server Action only
- Importing a Client Component into a Server Component: fine
- Importing a Server Component into a Client Component: not allowed (boundary violation)

## Better Auth (current default)

For new projects and the LearnDE migration. Replaces the legacy split-cookie pattern.

Setup:
```ts
// lib/auth.ts
import { betterAuth } from 'better-auth'
import { drizzleAdapter } from 'better-auth/adapters/drizzle'
import { getDb } from './db'

export const auth = betterAuth({
  database: drizzleAdapter(getDb(), { provider: 'pg' }),
  emailAndPassword: { enabled: true },
  session: {
    expiresIn: 60 * 60 * 24 * 7, // 7 days
    updateAge: 60 * 60 * 24,     // refresh once per day
  },
})
```

Middleware:
```ts
// middleware.ts
import { NextResponse } from 'next/server'
import { auth } from '@/lib/auth'

export async function middleware(req) {
  const session = await auth.api.getSession({ headers: req.headers })
  const isProtected = req.nextUrl.pathname.startsWith('/dashboard') ||
                      req.nextUrl.pathname.startsWith('/admin')
  if (isProtected && !session) {
    return NextResponse.redirect(new URL('/sign-in', req.url))
  }
  return NextResponse.next()
}

export const config = {
  matcher: ['/dashboard/:path*', '/admin/:path*'],
}
```

Required env vars:
```
BETTER_AUTH_SECRET=    # 32+ random chars (openssl rand -base64 32)
BETTER_AUTH_URL=       # e.g. https://learnde.com
```

See `references/better-auth.md` for: role-based routes (student vs staff), session refresh, OAuth providers, migration from legacy cookies.

For LearnDE specifically (legacy `auth-token` 7-day student + `staff-token` 8-hour staff): see `references/learnde-migration.md` for the file-by-file migration playbook.

## Neon + Drizzle (essentials)

Two env vars, two uses:
- `DATABASE_URL` — pooled. App code uses this.
- `DATABASE_URL_UNPOOLED` — direct. `drizzle.config.ts` uses this. Migrations only.

```ts
// drizzle.config.ts
import { defineConfig } from 'drizzle-kit'
export default defineConfig({
  schema: './lib/db/schema.ts',
  out: './drizzle',
  dialect: 'postgresql',
  dbCredentials: { url: process.env.DATABASE_URL_UNPOOLED! },
})
```

Migration workflow:
```bash
npx drizzle-kit generate    # after schema change
npx drizzle-kit migrate     # apply to Neon
npx drizzle-kit push        # dev only — bypasses migration files
```

Type inference from schema (never duplicate types manually):
```ts
import { type InferSelectModel, type InferInsertModel } from 'drizzle-orm'
import { users } from '@/lib/db/schema'
type User = InferSelectModel<typeof users>
type NewUser = InferInsertModel<typeof users>
```

For deeper Drizzle patterns (relations, joins, transactions): `references/neon-drizzle.md`.

## Tailwind gotchas

Dynamic classes don't work — Tailwind purges what it can't see in source:

```tsx
// Will be purged — Tailwind can't detect the constructed class
const color = 'green'
<div className={`text-${color}-500`} />

// Works — full class names exist in source
const cls = condition ? 'text-green-500' : 'text-red-500'
<div className={cls} />
```

Dark mode — needs both:
1. `darkMode: 'class'` in `tailwind.config.ts`
2. `<html class="dark">` on the root element

Custom fonts via `next/font`:
```tsx
// app/layout.tsx
import { Syne } from 'next/font/google'
const syne = Syne({ subsets: ['latin'], variable: '--font-syne' })
export default function RootLayout({ children }) {
  return <html className={syne.variable}>...</html>
}
```

Then in `tailwind.config.ts`:
```ts
fontFamily: { syne: ['var(--font-syne)'] }
```

## Pre-deploy checklist

Before every push to main:
- [ ] No `.env*` committed (`git status` clean)
- [ ] All new env vars added to BOTH Vercel and Cloudflare dashboards
- [ ] No `console.log` with sensitive data
- [ ] Server-only imports not in Client Components
- [ ] Drizzle migrations run against production Neon
- [ ] `DATABASE_URL_UNPOOLED` in `drizzle.config.ts`, pooled URL in app code
- [ ] Better Auth secret rotated if env was ever exposed
- [ ] Build passes locally (or in Vercel preview) before promoting

## File structure convention

```
app/
  (auth)/             route group for auth layout
  (dashboard)/        protected dashboard routes
  api/                Route Handlers (including auth/[...all]/route.ts)
components/
  ui/                 primitives (button, input, dialog)
  sections/           page-level sections
lib/
  auth.ts             Better Auth setup
  auth-client.ts      Better Auth client for components
  db/
    index.ts          getDb() — Edge-compatible
    node.ts           getNodeDb() — Node runtime only
    schema.ts         Drizzle schema
  env.ts              env validation
  utils.ts
drizzle/              generated migrations
drizzle.config.ts
middleware.ts         Better Auth protection
```

## Reference files

- `references/better-auth.md` — Full Better Auth patterns: roles, OAuth, refresh, sign-out.
- `references/learnde-migration.md` — Migration from legacy `auth-token`/`staff-token` to Better Auth, file by file.
- `references/neon-drizzle.md` — Drizzle query patterns, joins, transactions, migration recovery.
- `references/nextjs-patterns.md` — App Router deep patterns: parallel routes, intercepting routes, generateMetadata.
