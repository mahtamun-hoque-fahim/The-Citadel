# AGENTS.md Template

AGENTS.md is an open, cross-tool standard (OpenAI Codex, Cursor, Windsurf,
Factory, Kilo Code, and others) — a lean "README for agents," not a
changelog. Keep the static sections under ~60 lines total; that's the
ceiling other tools converge on, and it's why the file stays worth reading
in full every session. The Session Log at the bottom is this skill's one
addition to the standard — capped at 10 entries, newest first, oldest
dropped on overflow.

Also create `CLAUDE.md` alongside it as a one-line pointer — Claude Code
reads CLAUDE.md specifically, not AGENTS.md:
```
See AGENTS.md for agent instructions, conventions, and the session log.
```

---

```markdown
# [Project Name]

[One sentence: what it does and who it's for.]

## Git Identity (Session Start — run before any commit, every session)

```
git config user.name "mahtamun-hoque-fahim"
git config user.email "mahtamunhoquefahim@gmail.com"
```

Execute automatically at the start of every session, before the first commit — never ask, never skip, never commit as Claude. This applies across every Claude account/session working this repo.

> Note: these two literal values get committed into every new project's
> public repo via this template. Fine for solo use on Fahim's own
> projects; parameterize before reusing this template for anyone else.

## Setup & Commands

- Install: `npm install`
- Dev server: `npm run dev`
- Build: `npm run build`
- Type check: `npx tsc --noEmit`
- DB push (dev only): `npx drizzle-kit push`
- DB migrate (production): `npx drizzle-kit generate` then `npx drizzle-kit migrate`

## Conventions & Non-Negotiables

- No emojis anywhere in code or UI — lucide-react icons or inline SVG only
- Dual deploy target: Vercel (primary) + Cloudflare Workers via `@opennextjs/cloudflare`
  (secondary) — every route must stay Edge Runtime compatible
- Auth: Better Auth — session checked server-side via `auth.api.getSession()`,
  never client-only
- [Add project-specific conventions that diverge from generic framework
  defaults — only what an agent can't infer from the codebase alone]

## Security Gotchas

- `.env.local` is never committed — if a secret leaks into git history or
  chat, rotate it immediately, don't just remove it going forward
- [Project-specific: webhook secret handling, signed-upload requirements,
  rate-limit-sensitive routes, etc.]

## Session Log

(Newest first. Maximum 10 entries — drop the oldest when an 11th is added.
Three to four lines per entry, not a paragraph. This section updates
automatically at the end of any session with substantive work, independent
of whether "update repo" was said.)

### [YYYY-MM-DD]
- Did: [what got built or fixed, one line]
- Decided: [any non-obvious call and the reason, if there was one — omit this line if nothing non-obvious happened]
- Next: [what's queued for the next session]
```
