# Neon + Drizzle — Deep Patterns

## Two drivers, two runtimes

```ts
// lib/db/index.ts — Edge-compatible (Cloudflare Pages, Vercel Edge functions, middleware)
import { neon } from '@neondatabase/serverless'
import { drizzle } from 'drizzle-orm/neon-http'
import * as schema from './schema'

export function getDb() {
  if (!process.env.DATABASE_URL) return null as any
  return drizzle(neon(process.env.DATABASE_URL), { schema })
}
```

```ts
// lib/db/node.ts — Node.js only (transactions, long-running queries)
import { Pool } from '@neondatabase/serverless'
import { drizzle } from 'drizzle-orm/neon-serverless'
import * as schema from './schema'

let pool: Pool | null = null

export function getNodeDb() {
  if (!process.env.DATABASE_URL) return null as any
  if (!pool) pool = new Pool({ connectionString: process.env.DATABASE_URL })
  return drizzle(pool, { schema })
}
```

Use `getNodeDb()` in Route Handlers with `export const runtime = 'nodejs'`. Use `getDb()` everywhere else.

## Schema patterns

```ts
// lib/db/schema.ts
import { pgTable, serial, text, timestamp, integer, boolean, pgEnum, uuid, decimal } from 'drizzle-orm/pg-core'
import { relations } from 'drizzle-orm'

export const statusEnum = pgEnum('status', ['draft', 'published', 'archived'])

export const projects = pgTable('projects', {
  id: uuid('id').primaryKey().defaultRandom(),
  ownerId: text('owner_id').notNull(),
  name: text('name').notNull(),
  status: statusEnum('status').default('draft'),
  budget: decimal('budget', { precision: 10, scale: 2 }),
  createdAt: timestamp('created_at').defaultNow(),
})

export const tasks = pgTable('tasks', {
  id: uuid('id').primaryKey().defaultRandom(),
  projectId: uuid('project_id').references(() => projects.id, { onDelete: 'cascade' }),
  title: text('title').notNull(),
  done: boolean('done').default(false),
})

// Relations — for query API
export const projectsRelations = relations(projects, ({ many }) => ({
  tasks: many(tasks),
}))

export const tasksRelations = relations(tasks, ({ one }) => ({
  project: one(projects, { fields: [tasks.projectId], references: [projects.id] }),
}))
```

## Common queries

```ts
// Simple select
const all = await db.select().from(projects)

// With where
import { eq, and, desc } from 'drizzle-orm'
const mine = await db.select().from(projects).where(eq(projects.ownerId, userId))

// Insert with returning
const [created] = await db.insert(projects).values({ ownerId, name: 'New' }).returning()

// Update
await db.update(projects).set({ status: 'published' }).where(eq(projects.id, id))

// Delete
await db.delete(projects).where(eq(projects.id, id))

// Join via query API (uses relations)
const withTasks = await db.query.projects.findMany({
  with: { tasks: true },
  where: eq(projects.ownerId, userId),
  orderBy: desc(projects.createdAt),
})
```

## Transactions (Node only)

`neon-http` doesn't support transactions. Use `getNodeDb()`:

```ts
import { getNodeDb } from '@/lib/db/node'

export const runtime = 'nodejs'

export async function POST() {
  const db = getNodeDb()
  await db.transaction(async (tx) => {
    const [project] = await tx.insert(projects).values({ ... }).returning()
    await tx.insert(tasks).values({ projectId: project.id, title: 'Setup' })
  })
}
```

If the closure throws, the whole transaction rolls back.

## Migration workflow

```bash
# After every schema.ts change
npx drizzle-kit generate

# Apply to Neon (production-safe)
npx drizzle-kit migrate

# Dev shortcut — push schema directly, no migration file
npx drizzle-kit push

# Inspect current state
npx drizzle-kit introspect
```

`drizzle.config.ts`:
```ts
import { defineConfig } from 'drizzle-kit'

export default defineConfig({
  schema: './lib/db/schema.ts',
  out: './drizzle',
  dialect: 'postgresql',
  dbCredentials: { url: process.env.DATABASE_URL_UNPOOLED! },
  verbose: true,
  strict: true,
})
```

Always use the **unpooled** URL for migrations. The pooled URL drops long-running connections.

## Common Neon errors

| Error | Cause | Fix |
|---|---|---|
| `connect ECONNREFUSED` | Wrong driver on Edge | Use `@neondatabase/serverless` neon-http |
| `too many connections` | Unpooled URL in app code | Use `DATABASE_URL` (pooled) |
| `idle_in_transaction_session_timeout` | Long transaction on pooled URL | Use Node runtime + unpooled |
| `relation "x" does not exist` | Migration not run on prod | `npx drizzle-kit migrate` against prod |
| `column "x" does not exist` | Schema and migrations diverged | Regenerate from schema, apply |
| `password authentication failed` | Rotated DB password, env not updated | Update env in dashboards, redeploy |
| `SSL required` | URL missing SSL param | Append `?sslmode=require` |

## Migration recovery

If migrations get out of sync (rare but painful):

```bash
# 1. Introspect actual DB state
npx drizzle-kit introspect

# 2. Compare to drizzle/*.sql — find divergence
# 3. If safe, drop the meta journal and start fresh:
#    DROP TABLE __drizzle_migrations; (Neon dashboard SQL editor)
# 4. Regenerate from current schema
npx drizzle-kit generate
# 5. Mark as applied without running:
#    INSERT INTO __drizzle_migrations VALUES ...
```

Only do this if you understand exactly what each migration would do. Otherwise, restore from Neon's branch backups.

## Type inference (always use)

Never duplicate types from schema:

```ts
import { type InferSelectModel, type InferInsertModel } from 'drizzle-orm'
import { projects } from '@/lib/db/schema'

type Project = InferSelectModel<typeof projects>
type NewProject = InferInsertModel<typeof projects>

// In Server Action
export async function createProject(input: NewProject) {
  const [p] = await db.insert(projects).values(input).returning()
  return p satisfies Project
}
```
