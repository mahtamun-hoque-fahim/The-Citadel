# Stack Reference Notes

Ready-to-paste patterns for the default club-site stack. Read the section that matches what you're generating.

## Neon + Drizzle

### Two drivers, two runtimes
```ts
// lib/db/index.ts — Edge-compatible (Cloudflare Pages, Vercel Edge middleware)
import { neon } from '@neondatabase/serverless'
import { drizzle } from 'drizzle-orm/neon-http'
import * as schema from './schema'

export function getDb() {
  if (!process.env.DATABASE_URL) return null as any
  return drizzle(neon(process.env.DATABASE_URL), { schema })
}
```

```ts
// lib/db/node.ts — Node.js only (transactions, Better Auth password hashing)
import { Pool } from '@neondatabase/serverless'
import { drizzle } from 'drizzle-orm/neon-serverless'
import * as schema from './schema'

let pool: Pool | null = null
export function getNodeDb() {
  if (!process.env.DATABASE_URL) return null as any
  if (!pool) pool = new Pool({ connectionString: process.env.DATABASE_URL })
  return drizzle(pool, { schema })
}
```

### drizzle.config.ts
```ts
import { defineConfig } from 'drizzle-kit'

export default defineConfig({
  schema: './lib/db/schema.ts',
  out: './drizzle',
  dialect: 'postgresql',
  dbCredentials: { url: process.env.DATABASE_URL_UNPOOLED! },
  verbose: true,
  strict: true,
})
```

### Migration commands
```bash
npx drizzle-kit generate    # after schema change
npx drizzle-kit migrate     # apply to Neon
npx drizzle-kit push        # dev only
```

### Env vars
```
DATABASE_URL=             # pooled — use in app code
DATABASE_URL_UNPOOLED=    # direct — use ONLY in drizzle.config.ts
```

### Common errors
| Error | Cause | Fix |
|---|---|---|
| `connect ECONNREFUSED` | `pg` on Edge | Use `@neondatabase/serverless` neon-http |
| `too many connections` | Unpooled URL in app code | Use `DATABASE_URL` (pooled) |
| `relation does not exist` | Migration not run | `npx drizzle-kit migrate` |
| `SSL required` | Missing SSL param | Add `?sslmode=require` |

---

## Better Auth

### Install
```bash
npm install better-auth
```

### Setup (`lib/auth.ts`)
```ts
import { betterAuth } from 'better-auth'
import { drizzleAdapter } from 'better-auth/adapters/drizzle'
import { getDb } from './db'

export const auth = betterAuth({
  database: drizzleAdapter(getDb(), { provider: 'pg' }),
  emailAndPassword: { enabled: true },
  session: {
    expiresIn: 60 * 60 * 24 * 7,  // 7 days
    updateAge: 60 * 60 * 24,      // refresh once per day
  },
})
```

### Catch-all route (`app/api/auth/[...all]/route.ts`)
```ts
import { auth } from '@/lib/auth'
import { toNextJsHandler } from 'better-auth/next-js'

export const { POST, GET } = toNextJsHandler(auth)
```

If on Cloudflare, force Node runtime for the auth route:
```ts
export const runtime = 'nodejs'
```

### Client (`lib/auth-client.ts`)
```ts
import { createAuthClient } from 'better-auth/react'

export const authClient = createAuthClient({
  baseURL: process.env.NEXT_PUBLIC_APP_URL!,
})

export const { signIn, signOut, signUp, useSession } = authClient
```

### Required schema additions
```ts
import { pgTable, text, timestamp, boolean, pgEnum } from 'drizzle-orm/pg-core'

export const roleEnum = pgEnum('role', ['member', 'admin'])

export const user = pgTable('user', {
  id: text('id').primaryKey(),
  email: text('email').notNull().unique(),
  emailVerified: boolean('email_verified').default(false),
  name: text('name').notNull(),
  image: text('image'),
  role: roleEnum('role').default('member').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
})

export const session = pgTable('session', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => user.id, { onDelete: 'cascade' }),
  expiresAt: timestamp('expires_at').notNull(),
  token: text('token').notNull().unique(),
  ipAddress: text('ip_address'),
  userAgent: text('user_agent'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
})

export const account = pgTable('account', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => user.id, { onDelete: 'cascade' }),
  providerId: text('provider_id').notNull(),
  accountId: text('account_id').notNull(),
  password: text('password'),
  createdAt: timestamp('created_at').defaultNow(),
})

export const verification = pgTable('verification', {
  id: text('id').primaryKey(),
  identifier: text('identifier').notNull(),
  value: text('value').notNull(),
  expiresAt: timestamp('expires_at').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
})
```

### proxy.ts with role gates (Next.js 16 — lightweight redirect only)
```ts
// proxy.ts — network layer only; real auth validation happens in layouts/DAL
import { NextRequest, NextResponse } from 'next/server'

export function proxy(req: NextRequest) {
  const hasSession = req.cookies.has('better-auth.session_token')
  const path = req.nextUrl.pathname

  if (!hasSession && (path.startsWith('/dashboard') || path.startsWith('/admin'))) {
    const url = new URL('/sign-up', req.url)
    url.searchParams.set('callbackURL', path)
    return NextResponse.redirect(url)
  }

  return NextResponse.next()
}

export const config = {
  matcher: ['/dashboard/:path*', '/admin/:path*'],
}
```

> **Note:** In Next.js 16, `proxy.ts` runs on Node.js (not Edge). Do NOT call `auth.api.getSession()` here — that's expensive. Use lightweight cookie presence checks only. Put real session/role validation in a Data Access Layer (DAL) called from Server Components (see below).

### Server-side session (DAL pattern)
```tsx
import { auth } from '@/lib/auth'
import { headers } from 'next/headers'

export default async function DashboardPage() {
  // In Next.js 16, headers() is async
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session) return null // proxy.ts caught this
  return <div>Hi {session.user.name}</div>
}
```

### Client-side session
```tsx
'use client'
import { useSession, signOut } from '@/lib/auth-client'

export function UserMenu() {
  const { data: session, isPending } = useSession()
  if (isPending) return null
  if (!session) return null
  return (
    <div>
      <span>{session.user.email}</span>
      <button onClick={() => signOut()}>Sign out</button>
    </div>
  )
}
```

### Required env vars
```
BETTER_AUTH_SECRET=    # 32+ chars: openssl rand -base64 32
BETTER_AUTH_URL=       # full production URL (e.g. https://clubsite.com)
NEXT_PUBLIC_APP_URL=   # same as above, client-readable
```

### Runtime notes (Next.js 16)
Better Auth's password hashing uses `crypto` (Node). The catch-all auth route needs `export const runtime = 'nodejs'`. In Next.js 16, `proxy.ts` runs on Node.js by default (no `runtime = 'edge'` needed). Keep session validation in Server Components via the DAL, not in proxy.ts.

---

## Cloudflare Workers (via OpenNext)

### Setup
```bash
npm install --save-dev @opennextjs/cloudflare wrangler
```

`wrangler.jsonc`:
```jsonc
{
  "main": ".open-next/worker.js",
  "name": "club-site",
  "compatibility_date": "2024-12-30",
  "compatibility_flags": ["nodejs_compat", "global_fetch_strictly_public"],
  "assets": { "directory": ".open-next/assets", "binding": "ASSETS" }
}
```

`open-next.config.ts`:
```ts
import { defineCloudflareConfig } from '@opennextjs/cloudflare'
export default defineCloudflareConfig({})
```

`package.json` scripts:
```json
{
  "build:cf": "opennextjs-cloudflare build",
  "preview:cf": "opennextjs-cloudflare preview",
  "deploy:cf": "opennextjs-cloudflare deploy"
}
```

### next.config.ts
```ts
import { initOpenNextCloudflareForDev } from '@opennextjs/cloudflare'
initOpenNextCloudflareForDev()
const nextConfig = {
  images: { unoptimized: true }, // unless using Cloudflare Images
}
export default nextConfig
```

### Runtime rules (Workers)
`nodejs_compat` flag is required — enables Node APIs. Without it, runtime fails with cryptic stream/buffer errors.

---

## Next.js App Router patterns

### Server Action (form submit)
```tsx
'use server'
import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { getDb } from '@/lib/db'
import { revalidatePath } from 'next/cache'

export async function joinEvent(formData: FormData) {
  const session = await auth.api.getSession({ headers: headers() })
  if (!session) return { error: 'Unauthorized' }

  const eventId = formData.get('eventId') as string
  const db = getDb()
  await db.insert(rsvps).values({ userId: session.user.id, eventId })

  revalidatePath(`/events/${eventId}`)
  return { success: true }
}
```

### Route group layouts
```
app/
  (public)/     marketing layout — header + footer
    layout.tsx
    page.tsx
    events/page.tsx
  (auth)/       minimal layout — no chrome
    layout.tsx
    sign-in/page.tsx
    sign-up/page.tsx
  (member)/     authenticated layout — sidebar
    layout.tsx
    dashboard/page.tsx
  (admin)/      admin layout — different sidebar
    layout.tsx
    admin/
      payments/page.tsx
```

### Countdown hydration fix
Date math in render causes hydration mismatch (server time ≠ client time):

```tsx
'use client'
import { useEffect, useState } from 'react'

export function Countdown({ targetDate }: { targetDate: string }) {
  const [mounted, setMounted] = useState(false)
  const [remaining, setRemaining] = useState('')

  useEffect(() => {
    setMounted(true)
    const interval = setInterval(() => {
      const ms = new Date(targetDate).getTime() - Date.now()
      if (ms <= 0) return setRemaining('Started')
      const d = Math.floor(ms / 86400000)
      const h = Math.floor((ms % 86400000) / 3600000)
      const m = Math.floor((ms % 3600000) / 60000)
      setRemaining(`${d}d ${h}h ${m}m`)
    }, 1000)
    return () => clearInterval(interval)
  }, [targetDate])

  if (!mounted) return <span className="opacity-0">--d --h --m</span> // reserve space
  return <span>{remaining}</span>
}
```

---

## Resend (transactional email)

### Install
```bash
npm install resend
```

### Setup (`lib/email.ts`)
```ts
import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY!)

export async function sendPaymentConfirmation(to: string, eventName: string) {
  await resend.emails.send({
    from: 'Club <noreply@yourclub.com>',
    to,
    subject: `You're registered for ${eventName}`,
    html: `<p>Your payment has been verified. See you at the event.</p>`,
  })
}
```

### Env vars
```
RESEND_API_KEY=          # from resend.com dashboard
```

### Domain verification
Resend requires DNS verification before sending. For development, use `onboarding@resend.dev` as `from` — only sends to the account email.

---

## Duplicate submission guard (payment system)

Before inserting a new `payment_submissions` row:

```ts
const existing = await db
  .select()
  .from(paymentSubmissions)
  .where(and(
    eq(paymentSubmissions.userId, session.user.id),
    eq(paymentSubmissions.contextId, contextId),
    eq(paymentSubmissions.status, 'pending')
  ))
  .limit(1)

if (existing.length > 0) {
  return { error: 'You already have a pending submission for this event.' }
}
```

This prevents a user from submitting twice while the first is still pending review. After admin rejects, they're free to resubmit.
