# Better Auth — Deep Patterns

## Schema additions

Better Auth needs its own tables. Add to `lib/db/schema.ts`:

```ts
import { pgTable, text, timestamp, boolean, pgEnum } from 'drizzle-orm/pg-core'

export const roleEnum = pgEnum('role', ['student', 'staff', 'admin'])

export const user = pgTable('user', {
  id: text('id').primaryKey(),
  email: text('email').notNull().unique(),
  emailVerified: boolean('email_verified').default(false),
  name: text('name').notNull(),
  image: text('image'),
  role: roleEnum('role').default('student').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
})

export const session = pgTable('session', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => user.id, { onDelete: 'cascade' }),
  expiresAt: timestamp('expires_at').notNull(),
  token: text('token').notNull().unique(),
  ipAddress: text('ip_address'),
  userAgent: text('user_agent'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
})

export const account = pgTable('account', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => user.id, { onDelete: 'cascade' }),
  providerId: text('provider_id').notNull(),
  accountId: text('account_id').notNull(),
  password: text('password'),
  accessToken: text('access_token'),
  refreshToken: text('refresh_token'),
  idToken: text('id_token'),
  expiresAt: timestamp('expires_at'),
  createdAt: timestamp('created_at').defaultNow(),
})

export const verification = pgTable('verification', {
  id: text('id').primaryKey(),
  identifier: text('identifier').notNull(),
  value: text('value').notNull(),
  expiresAt: timestamp('expires_at').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
})
```

## Catch-all auth route

```ts
// app/api/auth/[...all]/route.ts
import { auth } from '@/lib/auth'
import { toNextJsHandler } from 'better-auth/next-js'

export const { POST, GET } = toNextJsHandler(auth)
```

## Client setup

```ts
// lib/auth-client.ts
import { createAuthClient } from 'better-auth/react'

export const authClient = createAuthClient({
  baseURL: process.env.NEXT_PUBLIC_APP_URL!,
})

export const { signIn, signOut, signUp, useSession } = authClient
```

## Role-based protection

Single matcher, role check inside:

```ts
// middleware.ts
import { NextResponse } from 'next/server'
import { auth } from '@/lib/auth'

export async function middleware(req) {
  const session = await auth.api.getSession({ headers: req.headers })
  const path = req.nextUrl.pathname

  // Unauthenticated → sign-in
  if (!session && (path.startsWith('/dashboard') || path.startsWith('/staff'))) {
    return NextResponse.redirect(new URL('/sign-in', req.url))
  }

  // Authenticated student trying to access staff routes
  if (session?.user.role === 'student' && path.startsWith('/staff')) {
    return NextResponse.redirect(new URL('/dashboard', req.url))
  }

  // Authenticated staff trying to access student dashboard (optional — usually allowed)
  // Add specific rules here if needed.

  return NextResponse.next()
}

export const config = {
  matcher: ['/dashboard/:path*', '/staff/:path*', '/admin/:path*'],
}
```

## Server-side session access

```ts
// In a Server Component
import { auth } from '@/lib/auth'
import { headers } from 'next/headers'

export default async function DashboardPage() {
  const session = await auth.api.getSession({ headers: headers() })
  if (!session) return null // middleware should have caught this

  return <div>Welcome, {session.user.name}</div>
}
```

## Client-side session

```tsx
'use client'
import { useSession } from '@/lib/auth-client'

export function UserMenu() {
  const { data: session, isPending } = useSession()
  if (isPending) return <Skeleton />
  if (!session) return null
  return <span>{session.user.email}</span>
}
```

## OAuth providers (Google example)

```ts
// lib/auth.ts
import { betterAuth } from 'better-auth'

export const auth = betterAuth({
  database: drizzleAdapter(getDb(), { provider: 'pg' }),
  emailAndPassword: { enabled: true },
  socialProviders: {
    google: {
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    },
  },
})
```

Client call:
```tsx
await signIn.social({ provider: 'google', callbackURL: '/dashboard' })
```

## Sign-out

```tsx
await signOut({ fetchOptions: { onSuccess: () => router.push('/') } })
```

## Common pitfalls

- **Better Auth on Cloudflare Edge**: password hashing uses `crypto` (Node). Move the auth route to Node runtime: `export const runtime = 'nodejs'`. Session validation in middleware works on Edge fine.
- **Cookie domain mismatch**: in production, set `BETTER_AUTH_URL` to the exact production URL or cookies won't stick.
- **CORS in dev**: if Next runs on a different port from your testing tool, set `trustedOrigins` in betterAuth config.
- **Schema migration**: after adding the four tables above, run `npx drizzle-kit generate && npx drizzle-kit migrate`. Forgetting this gives `relation "user" does not exist`.
