---
name: nextjs15-for-cf
description: >
  Expert debugging and best-practice guidance for Next.js 15.x projects deployed
  to Cloudflare (Workers via OpenNext) AND Vercel from one codebase. SCOPE:
  Next.js 15.x ONLY — if package.json shows next@16.x, stop and use
  nextjs16-for-cf instead (v16 uses proxy.ts, wrangler.jsonc,
  open-next.config.ts). ALWAYS use when the user mentions Next.js 15, App
  Router, async cookies/headers/params, server actions, Edge runtime, OpenNext,
  @opennextjs/cloudflare, @cloudflare/next-on-pages, wrangler.toml,
  nodejs_compat, Vercel deploy errors, Cloudflare deploy errors, build failures,
  hydration mismatches, middleware bugs, fetch caching changes, React 19 issues,
  Turbopack problems, or any error that "works on Vercel but breaks on
  Cloudflare" (or vice versa). Also use proactively when writing new Next.js 15
  code for both platforms. Do NOT use for next@16.x.
---

# Next.js 15 for Cloudflare (and Vercel)

> **Scope: Next.js 15.x only.** If `package.json` shows `next@16.x`, stop here and use **nextjs16-for-cf** instead. v16 switched `middleware.ts` → `proxy.ts`, uses `wrangler.jsonc`, `open-next.config.ts`, and Cache Components — the platform integration differs enough that this skill will mislead you on v16 projects.

This skill exists to make debugging Next.js 15 dual-deployed apps **deliberate**
instead of pattern-matched. Most Next.js bugs on Cloudflare/Vercel are not
bugs in Next.js - they are misunderstandings about which runtime is executing,
which Next.js version's defaults apply, or which platform is doing the build.
Slow down, identify the environment, then fix.

The stack assumed:
- Next.js 15 (App Router, React 19)
- TypeScript
- Deployed to **both** Vercel and Cloudflare (Pages via `@cloudflare/next-on-pages`, or Workers via `@opennextjs/cloudflare`) from one repo
- Neon Postgres + Drizzle is the typical DB layer, but the skill applies broadly

---

## 0. The Diagnostic Protocol - Run This Before Any Fix

When the user reports a bug, do **not** jump to a code change. Walk these four
questions explicitly in your reply (one short line each is enough):

1. **Where does it fail?** Build time, runtime, or in the browser?
   - Build time = stack trace in CI logs, no request involved
   - Runtime = error appears in server logs when a request hits
   - Browser = console error, hydration warning, network 500 with a server stack
2. **Which platform?** Vercel only, Cloudflare only, or both?
   - "Works on Vercel, fails on Cloudflare" almost always means a Node-only API hit the Edge runtime
   - "Works on Cloudflare, fails on Vercel" is rare - usually a bundle size or memory issue
   - "Fails on both" = code bug or a Next.js 15 breaking change
3. **Which runtime?** Node.js or Edge?
   - Check the file for `export const runtime = 'edge'` or `'nodejs'`
   - Middleware is **always** Edge
   - Cloudflare Pages (`@cloudflare/next-on-pages`) forces Edge for all server routes
   - Cloudflare Workers (`@opennextjs/cloudflare`) supports Node.js compat - much less restrictive
   - Vercel defaults to Node.js but Edge can be opted in per route
4. **Is this a Next.js 15 behavior change?** Cross-reference against Section 1 below before assuming the code is wrong. The async-API change in v15 trips up almost every migration.

State the answers, then propose a fix. If any question can't be answered from
the info given, ask for the specific missing piece (a build log line, the
runtime export, the failing platform) before guessing.

---

## 1. Next.js 15 Breaking Changes - Check These First

Most "weird" Next.js 15 errors trace back to one of these. When the user shows
code that "used to work," scan for these patterns before anything else.

### 1.1 Async Request APIs (the biggest one)

`cookies()`, `headers()`, `draftMode()`, and the `params` / `searchParams`
props are **all async now**. They return Promises.

```ts
// v14 (broken in v15)
const cookieStore = cookies()
const token = cookieStore.get('auth')?.value

// v15 (correct)
const cookieStore = await cookies()
const token = cookieStore.get('auth')?.value
```

```tsx
// v14 page (broken in v15)
export default function Page({ params }: { params: { id: string } }) {
  return <div>{params.id}</div>
}

// v15 page (correct)
export default async function Page({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  return <div>{id}</div>
}
```

**Symptoms** of forgetting: TypeScript yells about `cookies().get` not existing,
or runtime says `params.id` is undefined, or hydration mismatch because the
sync version returned a Promise that React tried to render.

Codemod exists: `npx @next/codemod@canary next-async-request-api .`

### 1.2 Caching Defaults Flipped

- `fetch()` is **no longer cached by default**. v14 defaulted to `force-cache`, v15 defaults to `no-store`.
- GET Route Handlers are **no longer cached by default**.
- Client Router Cache no longer caches Page components by default (`staleTime: 0`).

```ts
// v15: opt back into caching explicitly
const res = await fetch('https://api.example.com/data', {
  cache: 'force-cache',
  next: { revalidate: 3600 },
})
```

**Symptoms**: pages that used to be fast now hit upstream on every request,
or data that used to be stale is now always fresh and bills go up. The fix
is not to "make caching work" - it's to opt in where you want it.

### 1.3 React 19

Next.js 15 ships React 19 by default. Watch for:
- Third-party libraries pinned to React 18 may break peer dep resolution - check `npm ls react`
- The new `use()` hook works in client components for unwrapping promises
- `useFormState` is renamed to `useActionState` (deprecated alias still works)
- Refs as props: `forwardRef` is no longer needed for most cases

### 1.4 `unstable_after` / `after()`

`import { after } from 'next/server'` schedules work to run after the response
is sent. Useful for logging, analytics, cache warming. On Cloudflare Workers
via OpenNext this works; on `@cloudflare/next-on-pages` it does **not** -
the request lifecycle ends with the response.

### 1.5 Turbopack Dev Stable

`next dev --turbo` is stable in v15. Doesn't affect prod builds (Webpack/SWC
still). If a dev-only error appears with Turbopack but not without, that's
the diff.

---

## 2. Cloudflare Deployment - The Hard Constraints

The Cloudflare side is where most dual-deploy pain originates. Two adapters
exist; identify which one the project uses before reasoning about errors.

### 2.1 Which Adapter?

| Signal in project | Adapter |
|---|---|
| `wrangler.toml` or `wrangler.jsonc`, `@opennextjs/cloudflare` in deps, deploys to **Workers** | **OpenNext** (preferred for new projects) |
| `@cloudflare/next-on-pages` in deps, output `.vercel/output/static`, deploys to **Pages** | **next-on-pages** (legacy, Edge-only) |

**OpenNext** supports the Node.js runtime via `nodejs_compat` and is the
Cloudflare-recommended path as of 2025. It handles SSR, ISR, middleware,
and most Next.js features.

**next-on-pages** forces every server route to Edge runtime. You will see
`export const runtime = 'edge'` everywhere in such projects. Node APIs are
hard-banned.

If the user's project uses both, treat it as `next-on-pages` for the
constraint floor.

### 2.2 The Edge Runtime Constraint (next-on-pages)

Banned at runtime: `fs`, `child_process`, `net`, `tls`, raw `Buffer` usage,
`pg` (node-postgres), most native modules, anything that opens a TCP socket
directly. Allowed: Web standard APIs (`fetch`, `Request`, `Response`,
`crypto.subtle`, `URL`, `TextEncoder`).

Patterns that come up constantly:

```ts
// BAD on Edge
import { Pool } from 'pg'
const pool = new Pool({ connectionString: process.env.DATABASE_URL })

// GOOD on Edge - use HTTP-based driver
import { neon } from '@neondatabase/serverless'
import { drizzle } from 'drizzle-orm/neon-http'
const sql = neon(process.env.DATABASE_URL!)
const db = drizzle(sql)
```

```ts
// BAD on Edge
import fs from 'node:fs'
const data = fs.readFileSync('./data.json', 'utf-8')

// GOOD on Edge - import as ES module at build time
import data from './data.json' // bundled, no fs needed
```

### 2.3 OpenNext (`@opennextjs/cloudflare`) Specifics

Required setup signals - check `wrangler.toml` / `wrangler.jsonc`:

```toml
compatibility_date = "2024-09-23"  # or later
compatibility_flags = ["nodejs_compat"]
```

Without `nodejs_compat`, OpenNext fails at runtime with cryptic module
resolution errors. Compat date earlier than 2024-09-23 is also unsupported.

`next.config.js` / `next.config.ts` should include:

```ts
import { initOpenNextCloudflareForDev } from '@opennextjs/cloudflare'
initOpenNextCloudflareForDev()
```

This is for `wrangler dev` parity with prod. Without it, local dev under
Wrangler diverges from the deployed Worker.

Build script pattern (in `package.json`):

```json
{
  "scripts": {
    "build": "next build",
    "cf:build": "opennextjs-cloudflare build",
    "cf:preview": "pnpm cf:build && opennextjs-cloudflare preview",
    "cf:deploy": "pnpm cf:build && wrangler deploy"
  }
}
```

Vercel still calls `next build` directly via its detection. Cloudflare
needs the `opennextjs-cloudflare build` wrapper.

### 2.4 Bundle Size Limit

Cloudflare Workers: **3 MiB** compressed on free, **10 MiB** on paid.
Going over silently fails the deploy with a size error in Wrangler output.

Common offenders: bundling Node polyfills you don't need, importing all of
`lodash` instead of `lodash/get`, large JSON data files, server-only deps
accidentally bundled into client code.

Check with: `wrangler deploy --dry-run --outdir=./dist` and inspect `dist/`.

### 2.5 Image Optimization

`next/image` optimization does **not** work on Cloudflare Pages (next-on-pages)
or Workers without explicit Cloudflare Images integration.

```ts
// next.config.ts - for Cloudflare-only or as a safe default
const nextConfig = {
  images: { unoptimized: true },
}
```

If you need optimization on Cloudflare, wire `next/image` to Cloudflare
Images via a custom loader. On Vercel, optimization just works. If
deploying to both, either accept unoptimized everywhere or use a custom
loader that does the right thing per platform.

### 2.6 ISR and `revalidate`

- `next-on-pages`: no ISR support. `revalidate` is ignored. Pages are either
  static (SSG) or dynamic (SSR per request).
- OpenNext: ISR works, backed by R2 or KV depending on `open-next.config.ts`.
  Requires configuration; see `references/cloudflare-deploy.md`.
- Vercel: ISR works out of the box.

If a route needs ISR and the project deploys to both, target OpenNext, not
next-on-pages.

---

## 3. Vercel Deployment - The Quieter Constraints

Vercel mostly "just works" with Next.js 15, but a few things bite:

- **Function timeout**: Hobby = 10s, Pro = 60s default (configurable to 300s
  on Pro/Enterprise). Long-running `await` in a Server Component or Route
  Handler will time out before Cloudflare ever does. Use streaming or
  background jobs.
- **Edge bundle size**: 1 MiB on Hobby, 4 MiB on Pro/Ent. Smaller than
  Cloudflare's paid tier. If Cloudflare deploys clean but Vercel rejects,
  this is usually why.
- **Env vars per environment**: Production, Preview, Development are
  separate scopes in the Vercel dashboard. A var added only to Production
  will be `undefined` on Preview deploys - a common source of "works in
  prod, breaks on PR preview" reports.
- **Build cache**: Vercel aggressively caches. After a `next.config` change
  or env var change, trigger a redeploy with cache cleared from the
  dashboard if behavior seems stale.

---

## 4. Dual-Deploy Patterns - Write Once, Run on Both

Code that ships to both Vercel and Cloudflare must respect the **stricter**
of the two runtimes for any given route. Practical patterns:

### 4.1 Pick a DB Driver That Works on Both

For Neon Postgres, `@neondatabase/serverless` + `drizzle-orm/neon-http` works
in Node and Edge runtimes. Use that uniformly and stop maintaining two
drivers unless you genuinely need session-based queries.

### 4.2 Avoid Module-Top-Level Side Effects

```ts
// BAD - runs at module load, may execute at build time on Vercel,
// crashes on Cloudflare if env vars aren't there at build
const db = drizzle(neon(process.env.DATABASE_URL!))

// GOOD - lazy, only runs when called
let _db: ReturnType<typeof drizzle> | null = null
export function getDb() {
  if (!_db) {
    if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL missing')
    _db = drizzle(neon(process.env.DATABASE_URL))
  }
  return _db
}
```

This pattern also fixes the Cloudflare build issue where env vars aren't
available during the build step (they're injected at deploy/runtime).

### 4.3 Don't Lean on Node APIs in Shared Code

If a utility is imported by both `app/api/*` routes (might be Node on Vercel)
and middleware (always Edge on both), it must use Web standard APIs only.

```ts
// BAD in shared utility
import crypto from 'node:crypto'
export function hash(s: string) {
  return crypto.createHash('sha256').update(s).digest('hex')
}

// GOOD - Web Crypto, works in both runtimes
export async function hash(s: string) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s))
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('')
}
```

### 4.4 Middleware: Always Edge, Always Both

`middleware.ts` runs at the Edge on both Vercel and Cloudflare. No exceptions.
Read cookies for auth, redirect, rewrite - that's it. Don't try to query a
database in middleware unless using an HTTP-based driver (Neon HTTP, Upstash).

```ts
// middleware.ts
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export async function middleware(req: NextRequest) {
  const token = req.cookies.get('auth-token')?.value
  if (!token && req.nextUrl.pathname.startsWith('/admin')) {
    return NextResponse.redirect(new URL('/login', req.url))
  }
  return NextResponse.next()
}

export const config = {
  matcher: ['/admin/:path*'],
}
```

### 4.5 Per-Platform Branching Only When Truly Necessary

If something genuinely can't be unified (e.g. image loader, KV store), branch
on a build-time env var, not a runtime check:

```ts
// next.config.ts
const isCloudflare = process.env.DEPLOY_TARGET === 'cloudflare'
export default {
  images: isCloudflare ? { unoptimized: true } : { /* normal config */ },
}
```

Set `DEPLOY_TARGET=cloudflare` in Cloudflare's env, leave unset on Vercel.

---

## 5. Quick Error Lookup

| Error | Most likely cause | Fix |
|---|---|---|
| `cookies().get is not a function` | Forgot `await` on Next.js 15 async API | `const c = await cookies()` |
| `params.id is undefined` in a v15 page | `params` is a Promise now | `const { id } = await params` |
| `ReferenceError: process is not defined` | Node API in Edge runtime | Switch to Web API or move route to Node runtime |
| `Module not found: Can't resolve 'fs'` (Cloudflare build) | Node-only import in Edge bundle | Replace with Web alternative or bundle the data |
| `Worker exceeded resource limits` (Cloudflare) | Bundle > 3 MiB free / 10 MiB paid | Trim deps, inspect with `wrangler deploy --dry-run --outdir` |
| `connect ECONNREFUSED` on Cloudflare | Using `pg` (Node TCP) on Edge | Switch to `@neondatabase/serverless` |
| Fetch returns stale data after v14 → v15 upgrade | Default cache changed to `no-store` | Add `{ cache: 'force-cache' }` or `next.revalidate` |
| Fetch hits upstream every request after upgrade | Same as above | Same as above |
| Hydration mismatch only on Cloudflare | Locale/date diff between build region and runtime | Format dates with explicit locale/TZ, use `suppressHydrationWarning` only as last resort |
| `nodejs_compat` flag errors (OpenNext) | Missing compat flag or old compat date | Set `compatibility_date = "2024-09-23"` minimum + `compatibility_flags = ["nodejs_compat"]` |
| Vercel build OK, Cloudflare build fails | Edge-incompatible dep transitively imported | Run `pnpm why <pkg>`, replace or move usage to Node runtime if on OpenNext |
| Cloudflare build OK, Vercel build fails | Usually env var missing in that Vercel env scope | Check Production / Preview / Development env tabs |
| `useFormState is deprecated` warning | React 19 rename | Use `useActionState` from `react` |
| Hydration mismatch with browser extensions | Extension injects DOM before React hydrates | `<html suppressHydrationWarning>` on root |

For longer error tables and full migration mappings see `references/error-lookup.md`.

---

## 6. Reference Files

When the user's issue needs depth beyond this main file, read the relevant
reference:

- `references/nextjs15-migration.md` - full v14 -> v15 changelist with codemods
- `references/cloudflare-deploy.md` - OpenNext vs next-on-pages deep dive, wrangler config, ISR setup, R2/KV bindings
- `references/vercel-deploy.md` - Vercel-specific patterns, function config, edge config
- `references/dual-deploy-patterns.md` - longer worked examples of code that ships to both
- `references/error-lookup.md` - extended error -> cause -> fix table

---

## 7. Style Rules for Code You Produce in This Stack

- No emojis in code, commit messages, UI text, or documentation. Ever.
- No `as any`. Use proper types, `satisfies`, or type narrowing.
- Lazy-init DB clients and other heavy singletons - never instantiate at module top level.
- Always specify `runtime` explicitly on Route Handlers and Pages that need it:
  `export const runtime = 'edge'` or `'nodejs'`. Don't rely on defaults silently.
- Env var access goes through a single validated module (e.g. `lib/env.ts`), not scattered `process.env.X` calls.
- Migrations use the **unpooled** Neon URL; app code uses the **pooled** URL.
- When in doubt about a Cloudflare/Vercel divergence, write the version that works on Cloudflare - it will work on Vercel, but not the reverse.
