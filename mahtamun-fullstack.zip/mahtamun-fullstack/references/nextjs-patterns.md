# Next.js 14 App Router — Deep Patterns

## Route Handler shape

```ts
// app/api/projects/route.ts
import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { getDb } from '@/lib/db'
import { projects } from '@/lib/db/schema'

export async function GET() {
  const session = await auth.api.getSession({ headers: headers() })
  if (!session) return Response.json({ error: 'Unauthorized' }, { status: 401 })

  const db = getDb()
  const rows = await db.select().from(projects).where(eq(projects.ownerId, session.user.id))
  return Response.json(rows)
}

export async function POST(req: Request) {
  const session = await auth.api.getSession({ headers: headers() })
  if (!session) return Response.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const db = getDb()
  const [created] = await db.insert(projects).values({
    ownerId: session.user.id,
    name: body.name,
  }).returning()
  return Response.json(created, { status: 201 })
}
```

## Server Actions (preferred for form submits)

```tsx
// app/projects/actions.ts
'use server'
import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { getDb } from '@/lib/db'
import { projects } from '@/lib/db/schema'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'

export async function createProject(formData: FormData) {
  const session = await auth.api.getSession({ headers: headers() })
  if (!session) redirect('/sign-in')

  const name = formData.get('name') as string
  if (!name) return { error: 'Name required' }

  const db = getDb()
  await db.insert(projects).values({ ownerId: session.user.id, name })

  revalidatePath('/projects')
  return { success: true }
}
```

Call from a Client Component:
```tsx
'use client'
import { createProject } from './actions'
import { useTransition } from 'react'

export function NewProjectForm() {
  const [isPending, startTransition] = useTransition()

  function handleSubmit(e) {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    startTransition(async () => {
      const result = await createProject(formData)
      if (result.error) alert(result.error)
    })
  }

  return (
    <form onSubmit={handleSubmit}>
      <input name="name" />
      <button disabled={isPending}>Create</button>
    </form>
  )
}
```

## Route groups for layouts

```
app/
  (marketing)/        public layout (header + footer)
    layout.tsx
    page.tsx
    about/page.tsx
  (app)/              authenticated layout (sidebar)
    layout.tsx
    dashboard/page.tsx
    settings/page.tsx
  (auth)/             minimal layout (no chrome)
    layout.tsx
    sign-in/page.tsx
    sign-up/page.tsx
```

`(marketing)`, `(app)`, `(auth)` don't appear in URLs — they only scope which `layout.tsx` applies.

## Loading and error boundaries

```tsx
// app/dashboard/loading.tsx — automatic Suspense boundary
export default function Loading() {
  return <div className="animate-pulse">Loading...</div>
}

// app/dashboard/error.tsx — automatic error boundary
'use client'
export default function Error({ error, reset }: { error: Error; reset: () => void }) {
  return (
    <div>
      <p>{error.message}</p>
      <button onClick={reset}>Try again</button>
    </div>
  )
}

// app/dashboard/not-found.tsx — for notFound() calls
export default function NotFound() {
  return <div>Project not found.</div>
}
```

## Metadata and SEO

```ts
// app/blog/[slug]/page.tsx
import type { Metadata } from 'next'

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const post = await getPost(params.slug)
  if (!post) return { title: 'Not found' }
  return {
    title: post.title,
    description: post.excerpt,
    openGraph: {
      title: post.title,
      description: post.excerpt,
      images: [{ url: post.coverUrl, width: 1200, height: 630 }],
    },
    twitter: { card: 'summary_large_image' },
  }
}
```

Static OG image generation:
```tsx
// app/blog/[slug]/opengraph-image.tsx
import { ImageResponse } from 'next/og'

export const runtime = 'edge'
export const size = { width: 1200, height: 630 }
export const contentType = 'image/png'

export default async function OGImage({ params }) {
  const post = await getPost(params.slug)
  return new ImageResponse(
    <div style={{ display: 'flex', fontSize: 60 }}>{post.title}</div>,
    { ...size }
  )
}
```

## Static generation with dynamic routes

```ts
// app/blog/[slug]/page.tsx
export async function generateStaticParams() {
  const db = getDb()
  const posts = await db.select({ slug: posts.slug }).from(posts)
  return posts.map(p => ({ slug: p.slug }))
}

export default async function PostPage({ params }: { params: { slug: string } }) {
  const post = await getPost(params.slug)
  if (!post) notFound()
  return <article>{post.body}</article>
}
```

## Streaming with Suspense

```tsx
// app/dashboard/page.tsx
import { Suspense } from 'react'

export default function Dashboard() {
  return (
    <div>
      <h1>Dashboard</h1>
      <Suspense fallback={<ProjectsSkeleton />}>
        <ProjectsList />
      </Suspense>
      <Suspense fallback={<ActivitySkeleton />}>
        <RecentActivity />
      </Suspense>
    </div>
  )
}

async function ProjectsList() {
  const db = getDb()
  const projects = await db.select().from(projectsTable)
  return <ul>{projects.map(p => <li key={p.id}>{p.name}</li>)}</ul>
}
```

Both async components fetch in parallel; each streams in independently.

## Parallel and intercepting routes

Parallel — render two routes side-by-side in one layout slot:
```
app/
  dashboard/
    @analytics/page.tsx
    @team/page.tsx
    layout.tsx        // receives both slots
```

Intercepting — open a route as a modal over another:
```
app/
  feed/page.tsx
  photo/[id]/page.tsx        // full page
  feed/(..)photo/[id]/page.tsx  // intercepts when navigated from feed
```

Use for image modals, profile previews, and "look but stay on the list" UX.

## Hydration mismatch fixes

Common causes:
- Browser extensions injecting attributes on `<body>` → add `suppressHydrationWarning` on body
- `Math.random()` or `Date.now()` in render → move to `useEffect` or pre-compute on server
- Date formatting that differs between server timezone and client → use consistent UTC or `Intl.DateTimeFormat` with explicit locale

```tsx
// Safe pattern for client-only content
'use client'
import { useEffect, useState } from 'react'

export function ClientOnly({ children }) {
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])
  if (!mounted) return null
  return children
}
```
