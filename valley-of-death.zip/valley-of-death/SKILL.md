---
name: valley-of-death
description: >
  Find where code and spec disagree. Runs a deep, end-to-end audit of Fahim's
  Next.js projects — reads PLANNER.md, DESIGN_GUIDE.md, README.md, and
  AGENTS.md first to establish the intended product, then cross-validates
  every route, auth gate, data wire, brand rule, and user-facing copy claim
  (hero text, footer, README stack description) against the actual
  codebase — catching stack pivots where code moved on but the words
  describing it didn't. Produces a prioritized PASS/FAIL/PARTIAL report
  with file:line evidence and one-line fixes. Does NOT change any code —
  audit only.
  ALWAYS use when Fahim says "valley of death", "run the audit", "spec vs
  code check", "pre-council audit", or asks for a full project health check
  before a final council call. Runs just after Waterborne (emoji sweep) and
  just before the last Council call.
---

# Valley of Death

**Purpose:** Find every place where the code and the spec disagree. No fixes —
audit and report only. Propose fixes, then ask before touching anything.

**Position in Fahim's pipeline:**
```
Waterborne → Valley of Death → Council (final call)
```

---

## Phase 0 — Anchor to the Spec

Read these five files first. They define the **intended product**. Confirm they
are internally consistent and not contradicting each other before proceeding.

```
BRAIN.md          → source-of-truth: locked decisions, product positioning,
                    "What It Must Never Become", palette, constraints, and
                    the Singularity interview record. If present, this outranks
                    all other docs — locked decisions in BRAIN.md cannot be
                    contradicted by anything in PLANNER.md or DESIGN_GUIDE.md.
PLANNER.md        → authoritative tech blueprint (routes, tables, roles, flows)
DESIGN_GUIDE.md   → design system, component rules, color tokens, font choices
README.md         → developer guide (env vars, scripts, deployment notes)
AGENTS.md         → agent-facing setup/conventions + rolling session log —
                    surfaces recent decisions and gotchas a prior session
                    already hit
```

If `BRAIN.md` exists, extract and record:
- **Locked decisions** — flag any code that contradicts them as `FAIL — violates locked decision`
- **What It Must Never Become** — flag any feature, pattern, or copy that drifts toward this
- **Visual Identity (Locked)** — spot-check 3–5 components against the palette tokens

If any doc is missing, note it as `FAIL — doc missing` and continue with what
exists. If the docs contradict each other, flag it as a `SPEC CONFLICT` at the
top of the report.

---

## Phase 1 — Scope Survey

Before auditing, enumerate what actually exists:

| Category        | Action |
|-----------------|--------|
| Pages/routes    | List every file under `app/` (or `pages/`) |
| API routes      | List every `route.ts` / `route.js` |
| Auth config     | Find `lib/auth.ts`, `auth-client.ts`, `api/auth/[...all]`, `proxy.ts` |
| DB schema       | Find Drizzle schema files under `db/` or `lib/db/` |
| Nav/footer      | Find layout files and link lists |
| Components      | Note any UI that renders lists, tables, or cards (data-binding suspects) |

Print scope counts at the top of the report (e.g. "12 pages, 8 API routes,
3 roles").

---

## Audit Checklist

For each item: mark **PASS**, **FAIL**, or **PARTIAL** and include `file:line`
evidence. One-line fix for every FAIL.

---

### A — Routing & Links

1. Every page reachable from nav, footer, or in-app links — no dead hrefs.
2. No orphan pages except intentionally-unlinked staff routes (`/admin`,
   `/mod` — these MUST NOT appear in the public footer or main nav).
3. `/dashboard` link visible only when the user is logged in — check the
   conditional rendering logic.
4. All dynamic routes (`[id]`, `[slug]`) have a matching data-fetch; no route
   that renders `undefined` silently.

---

### B — Auth & Gating

1. Better Auth is wired: confirm `lib/auth.ts` exports the auth instance,
   `auth-client.ts` exports `authClient`, `app/api/auth/[...all]/route.ts`
   exists and calls the handler, `proxy.ts` (Next.js 16) or `middleware.ts`
   (Next.js 15) is present.
2. `/dashboard`, `/admin`, `/admin/*`, `/mod` all enforce session **and**
   correct role server-side (check `auth()` / `requireAdmin()` / role guard
   calls at the top of the page/layout Server Component).
3. Zero Clerk references anywhere (`@clerk/`, `useAuth`, `SignIn`, `UserButton`,
   `clerkMiddleware`) — grep the entire `src/` and `app/` tree.
4. No client-only auth guards on sensitive routes (role check must be
   server-side; client check is decoration only).

---

### C — Data Wiring

For each major flow defined in PLANNER.md, verify:

1. **API route exists** — the `route.ts` file is present.
2. **UI calls the route** — `fetch`, `axios`, server action, or tRPC call found
   in the relevant component/page.
3. **Route reads/writes the right Drizzle table** — import and query confirmed.
4. **No placeholder/mock data** — flag any `const data = [{ id: 1, ... }]`
   hardcoded arrays, `TODO: wire this`, or `Math.random()` stand-ins that ship
   to the user. **Exception:** a `data-image-slot` div with an `IMAGE-BRIEF:`
   comment tag above it is cave-man's intentional pending-art placeholder,
   not mock data — do not flag it here.

Flows to check (adapt to what PLANNER.md actually lists; these are Fahim's
common patterns):

- User auth (sign up / sign in / sign out)
- Admin content management (create / edit / delete)
- Public content fetch (list + detail views)
- Approval / moderation queue (if present)
- Any real-time or subscription feature (Ably, SSE)

---

### D — Scope / Count Parity

Compare PLANNER.md's stated route/table/role list against what actually exists
in the codebase. Report:

- Routes in spec but missing from code
- Routes in code but undocumented in spec
- DB tables in schema but not referenced by any query
- Roles defined but never enforced

---

### E — Brand Quality

1. **Zero emojis in `src/`** — grep for Unicode emoji ranges and any literal
   emoji characters in `.tsx`, `.ts`, `.css`, `.json` under the project root.
   (Waterborne should have run first; this is a confirmation gate.)
2. Design tokens used correctly: background, surface, accent colors match
   DESIGN_GUIDE.md values (spot-check 3–5 components).
3. Font families match DESIGN_GUIDE.md — no stray system-font fallbacks used
   as the primary font.
4. No `console.log` / debug output left in production paths.

---

### F — Copy Accuracy

Distinct from Section A (routing) and Section E (brand polish): this checks
whether rendered, user-facing text makes claims the code doesn't back up.
A route existing and a component rendering aren't enough — what the words
say has to be true. This is the check that catches a stack pivot (library
swapped, approach changed) that got reflected in the code but never in the
copy describing it.

1. Grep user-facing copy — hero text, feature lists, footer, marketing
   sections, button labels, toast/error messages — for technology, vendor,
   or capability names ("powered by X", "uses Y", "Z-secured", a named
   library or service). For each match, confirm that name is actually
   present and wired up in the code path it describes, not a leftover from
   an earlier architecture.
2. Cross-check README.md's "Stack" and "Deploy" sections against
   PLANNER.md's Architecture table and the actual imports in the relevant
   route/component — a mismatch here (docs describe a process the code no
   longer runs, e.g. a server-side subprocess that's been replaced by a
   client-side or WASM approach) is a FAIL even if the feature itself works
   correctly end-to-end.
3. Any deployment caveat documented (e.g. "X must run on platform Y because
   of Z API") is re-verified against current code — if the blocking API (Z)
   cited in the caveat is no longer used, the caveat is stale and may now
   be actively wrong rather than just outdated, potentially ruling out a
   deployment target that would actually work.
4. Numbers, formats, and limits stated in copy (file size limits, supported
   format lists, timing claims like "in N seconds") match the actual
   validation logic, not just what was true at an earlier draft.

---

### G — Build

Run with dummy env vars so secrets aren't needed:

```bash
# Create a .env.local with safe dummy values, then:
npm run build 2>&1 | tail -60
```

Report: **PASS** (exit 0, no errors), **FAIL** (non-zero exit or TypeScript
errors), **PARTIAL** (builds but with warnings that indicate real issues).

Capture the first error line and the file:line it points to.

---

## Deliverable Format

```
VALLEY OF DEATH — [Project Name] — [Date]
==========================================

SPEC INTEGRITY
  BRAIN.md      : PASS / FAIL / MISSING
  PLANNER.md    : PASS / FAIL / MISSING
  DESIGN_GUIDE  : PASS / FAIL / MISSING
  README.md     : PASS / FAIL / MISSING
  AGENTS.md     : PASS / FAIL / MISSING
  Locked decisions violated : [list or "none"]
  Conflicts     : [list or "none"]

SCOPE COUNTS
  Pages: N  |  API routes: N  |  Tables: N  |  Roles: N

─────────────────────────────────────────────────────────
CHECKLIST
─────────────────────────────────────────────────────────

A. ROUTING & LINKS
  [PASS/FAIL/PARTIAL] A1 — <evidence>  →  <fix>
  ...

B. AUTH & GATING
  [PASS/FAIL/PARTIAL] B1 — <evidence>  →  <fix>
  ...

C. DATA WIRING  (per flow)
  Flow: User Auth
    [PASS/FAIL/PARTIAL] API route — <evidence>  →  <fix>
    [PASS/FAIL/PARTIAL] UI call   — <evidence>  →  <fix>
    [PASS/FAIL/PARTIAL] DB table  — <evidence>  →  <fix>
  Flow: Admin Content
    ...

D. SCOPE / COUNT PARITY
  [PASS/FAIL/PARTIAL] <evidence>  →  <fix>

E. BRAND QUALITY
  [PASS/FAIL/PARTIAL] E1 Emojis   — <evidence>  →  <fix>
  ...

F. COPY ACCURACY
  [PASS/FAIL/PARTIAL] F1 — <evidence>  →  <fix>
  ...

G. BUILD
  [PASS/FAIL/PARTIAL] — exit code N — <first error line>  →  <fix>

─────────────────────────────────────────────────────────
PRIORITY ISSUES  (most impactful first)
─────────────────────────────────────────────────────────
  1. [FAIL] <short description> — file:line
  2. ...

─────────────────────────────────────────────────────────
Propose fixes above. Awaiting approval before changing any code.
```

---

## Operating Rules

- **Read-only.** Do not edit, create, or delete any project file during the
  audit. Only `grep`, `cat`, `find`, `npm run build`.
- **Evidence required.** Every FAIL must cite `file:line`. No speculation.
- **One-line fix.** Keep fix descriptions actionable and short — full
  implementation happens only after Fahim approves.
- **Most important first.** Auth bypasses and broken data wires rank above
  cosmetic issues.
- **Ask before fixing.** End every report with the block:
  `"Propose fixes above. Awaiting approval before changing any code."`
