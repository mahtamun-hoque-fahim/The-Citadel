---
name: apple-design
description: >
  Apple's approach to interface design and fluid, physical motion, translated for the web.
  Use when building or reviewing gesture-driven UI, spring animations, drag/swipe/sheet
  interactions, momentum and interruptible transitions, translucent materials and depth,
  typography (optical sizing, tracking, leading), reduced-motion, or the design foundations
  (feedback, spatial consistency, restraint) behind Apple-style interfaces. Knowledge comes
  from Apple's WWDC design talks — chiefly Designing Fluid Interfaces (WWDC 2018) —
  distilled into the web platform (CSS, Pointer Events, requestAnimationFrame, Framer Motion).
  Trigger on: "make this feel like iOS", "fluid gestures", "Apple-quality motion",
  "interruptible animations", "velocity handoff", "momentum", "translucent surface",
  "materials", "rubber-banding", "bottom sheet", "spring physics", "design foundations",
  or any request to match the tactile quality of native Apple interfaces.
---

# Apple Design

The through-line: **an interface feels alive when motion starts from the current on-screen value, inherits the user's velocity, projects momentum forward, and can be grabbed and reversed at any instant.** Springs are the tool that makes this natural — they are inherently interruptible and velocity-aware.

Apple frames design as serving four human needs: safety/predictability, understanding, achievement, and joy.

---

## 1. Response — kill latency

Lag causes the feeling of directness to "fall off a cliff." Response is the foundation.

- Respond on pointer-down, not release. Highlight a button the instant it's pressed.
- Feedback must be continuous during the interaction. For drag/slider/drawer, update 1:1 with the pointer the whole way through.
- Be vigilant about every latency: debounces, artificial timers, the ~300ms tap delay.

```css
.button:active {
  transform: scale(0.97);
  transition: transform 100ms ease-out;
}
```

---

## 2. Direct manipulation — 1:1 tracking

When the user drags something, it stays glued to the finger, respecting the offset from where they grabbed it. Use `setPointerCapture` so tracking continues when the pointer leaves the element's bounds. Track a short velocity/position history (last few `pointermove` events) — you'll need velocity at release.

```js
el.addEventListener('pointerdown', (e) => {
  el.setPointerCapture(e.pointerId)
  const grabOffset = e.clientY - el.getBoundingClientRect().top
})
```

---

## 3. Interruptibility — the single most important principle

Every animation must be interruptible at any moment. A user must be able to grab a moving element mid-flight and reverse it.

- Never lock out input during a transition.
- Always animate from the **presentation (current) value**, never the target value. On interrupt, read the element's live on-screen transform and start from there.
- Avoid CSS transitions and `@keyframes` for gesture-driven motion — they can't be smoothly reversed mid-flight. Springs animate from current value by default.
- When a gesture reverses, blend velocity — don't hard-cut it. A "brick wall" velocity discontinuity at reversal breaks fluidity.
- Decompose 2D motion into independent X and Y springs. A single spring on a 2D distance desyncs when X and Y have different velocities.

---

## 4. Springs — behavior over animation

Pre-scripted fixed-duration animations can't respond to new input. Springs can.

**Think in two parameters, not mass/stiffness/damping:**
- **Damping ratio** — controls overshoot. `1.0` = critically damped, no bounce. Below 1.0 = overshoots. Lower = bouncier.
- **Response** — how quickly the value reaches the target, in seconds. Not duration — a spring has no fixed duration; settle time emerges from parameters.

**Defaults:**
- Start most UI at damping `1.0` (critically damped) — graceful, non-distracting.
- Add bounce (damping ~`0.8`) **only when the gesture carried momentum** (a flick, a throw). Overshoot on a menu that faded in feels wrong; overshoot on a card you flicked feels right.

**Apple's concrete values:**

| Interaction | Damping | Response |
|---|---|---|
| Move / reposition (e.g. PiP) | 1.0 | 0.4 |
| Rotation | 0.8 | 0.4 |
| Drawer / sheet | 0.8 | 0.3 |

**Framer Motion mapping:**

```tsx
// Critically damped default (no overshoot)
animate(el, { y: 0 }, { type: 'spring', bounce: 0, duration: 0.4 })

// Momentum interaction — slight bounce because a flick preceded it
animate(el, { y: target }, { type: 'spring', bounce: 0.2, duration: 0.4 })
```

---

## 5. Velocity handoff — no seam between drag and animation

When a gesture ends, the animation must continue at the finger's exact velocity.

Pass release velocity as the spring's initial velocity. Some APIs want **relative** velocity — normalize by remaining distance:

```
relativeVelocity = gestureVelocity / (targetValue − currentValue)
```

Framer Motion / Motion take absolute px/s velocity directly via the `velocity` option.

---

## 6. Momentum projection — animate to where the gesture is going

Don't snap to the nearest boundary from the release point. Project the resting position using velocity, then snap to the nearest target from that projection.

Apple's exact projection function:

```js
function project(initialVelocity, decelerationRate = 0.998) {
  return (initialVelocity / 1000) * decelerationRate / (1 - decelerationRate)
}

const projectedEndpoint = currentPosition + project(releaseVelocity)
const target = nearestSnapPoint(projectedEndpoint)
animateSpringTo(target, { velocity: releaseVelocity })
```

---

## 7. Spatial consistency

- Enter and exit along the same path. A panel that slides in from the right must dismiss to the right.
- Anchor interactions to their source. A menu, popover, or sheet should originate from the element that triggered it — `transform-origin` set to the trigger.
- Mirror easing on reversible transitions so the outbound path matches the return path.

---

## 8. Rubber-banding — soft boundaries

At an edge, resist progressively instead of stopping hard. A hard stop reads as "frozen"; continuous resistance reads as "responsive, but there's nothing more here."

```js
function rubberband(overshoot, dimension, constant = 0.55) {
  return (overshoot * dimension * constant) / (dimension + constant * Math.abs(overshoot))
}
```

---

## 9. Gesture checklist

- **Tap:** highlight on touch-down (instant), commit on touch-up. ~10px hit padding, cancel-by-dragging-away allowed.
- **Drag:** ~10px hysteresis threshold before committing direction, then track 1:1.
- **Detect all plausible gestures in parallel** from the first move, then cancel the losers once intent is clear. Avoid recognizers that only report a final state.
- **Minimize disambiguation delays.** Double-tap detection delays single taps — only pay that cost where double-tap truly exists.

---

## 10. Materials and depth — translucency conveys hierarchy

- Build nav/toolbars/sheets as translucent layers (`backdrop-filter: blur()` + semi-transparent bg) with content scrolling underneath.
- Never stack a light translucent surface on another — legibility collapses.
- Bigger surfaces: stronger blur + deeper shadow than small chips.
- For glass/blur surfaces, animate blur radius and scale together on enter/exit — it reads as a real material arriving, not a plain fade.

```css
.toolbar {
  background: rgba(255, 255, 255, 0.6);
  backdrop-filter: blur(20px) saturate(180%);
  border-top: 1px solid rgba(255, 255, 255, 0.4);
}
```

---

## 11. Reduced motion — three signals, not one

```css
@media (prefers-reduced-motion: reduce) {
  .sheet { transition: opacity 200ms ease; transform: none !important; }
}
@media (prefers-reduced-transparency: reduce) {
  .toolbar { background: white; backdrop-filter: none; }
}
@media (prefers-contrast: more) {
  /* near-solid backgrounds, defined contrasting borders */
}
```

Reduced motion means gentler, not zero. Keep opacity/color changes that aid comprehension. Drop slides, springs, and parallax.

---

## 12. Typography — optical sizing

- **Tracking is size-specific.** Large display text wants negative tracking; small text wants slightly positive. Never one value for all sizes.
- **Leading tracks size inversely.** Tight on large headings (`line-height: 1.05–1.15`), looser on body copy (`1.5–1.7`).
- **Hierarchy from weight + size + leading as a set** — not size alone.
- **Default to system font** before a custom face.

```css
.display {
  font-size: clamp(2rem, 5vw, 4rem);
  line-height: 1.05;
  letter-spacing: -0.02em;
  font-optical-sizing: auto;
}
```

---

## 13. The 8 Design Principles

1. **Purpose.** Make with intention. Every feature asks for the user's time, attention, and trust — spend only where it pays off.
2. **Agency.** Keep people in control. Easy undo for slips. Confirmation dialogs only for genuinely irreversible, destructive actions — overusing trains people to click through.
3. **Responsibility.** Act in the user's interest. Privacy: ask at the right moment, only for what's needed. Safety: anticipate misuse and harm.
4. **Familiarity.** Build on what people already know. Things that look the same must behave the same. Only break a familiar pattern if you can prove it's better.
5. **Flexibility.** Design for different contexts, devices, and abilities. Adapt to the platform. When no single layout fits, let people personalize.
6. **Simplicity — not minimalism.** Strip the unnecessary so the core purpose shines. Be concise and clear. Show the common path first, advanced options one level deeper. Sometimes adding context simplifies.
7. **Craft.** Uncompromising attention to detail builds trust. Nothing is random — every spacing, timing, and alignment value is a deliberate choice. Jittery scroll and misaligned icons read as carelessness.
8. **Delight.** The result of getting the other seven right, not confetti tacked on top.

---

## Quick Reference

| Need | Technique | Value |
|---|---|---|
| Default UI spring | Critically damped | `bounce: 0`, `duration: 0.3–0.4` |
| Momentum / flick spring | Under-damped | `bounce: 0.2`, `duration: 0.3–0.4` |
| Gesture → spring velocity | Hand off release velocity | `gestureVelocity` raw (Framer) or normalized |
| Flick landing point | Project momentum | `current + (v/1000)·d/(1−d)`, `d ≈ 0.998` |
| Interrupt cleanly | Start from live (presentation) value | Read on-screen transform |
| Avoid reversal "brick wall" | Carry velocity through re-target | Spring that blends velocity |
| 1:1 drag | Pointer Events + capture | Respect the grab offset |
| Feedback | On pointer-down, continuous | Never only at the end |
| Boundary | Rubber-band, don't hard-stop | Progressive resistance |
| Translucent chrome | `backdrop-filter` layer | Content scrolls under |
| Type tracking | Size-specific, never fixed | Tighten large (`-0.02em`), body near `0` |
| Reduced motion | Cross-fade, not slide/spring | `@media (prefers-reduced-motion)` |
