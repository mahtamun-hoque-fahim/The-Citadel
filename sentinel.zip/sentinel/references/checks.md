# Sentinel — Extended Check Reference

Supplement to `SKILL.md`. The main file covers what to check and why; this
file has the exact copy-paste grep commands per domain, for when a finding
needs deeper confirmation than a single grep line. Section letters match
`SKILL.md` exactly (A–I).

## Contents
- [B — BetterAuth](#b--betterauth-extended-checks)
- [D — Drizzle / Neon](#d--drizzle--neon-extended-checks)
- [E — Lemon Squeezy](#e--lemon-squeezy-extended-checks)
- [F — Cloudinary](#f--cloudinary-extended-checks)
- [G — Upstash Redis](#g--upstash-redis-extended-checks)
- [OWASP Top 10:2025 quick map](#owasp-top-102025-quick-map)

---

## B — BetterAuth Extended Checks

```bash
# Full auth config dump
cat lib/auth.ts | grep -A 5 -B 2 "session\|expiresIn\|updateAge\|trustedOrigins\|disableCSRFCheck\|disableOriginCheck"

# Confirm no Clerk remnants — common artifact on projects migrated from Clerk
# (several of Fahim's older repos made this exact migration)
grep -rn "@clerk\|useAuth\|SignIn\|UserButton\|clerkMiddleware" . \
  --include="*.ts" --include="*.tsx" 2>/dev/null

# Find every place a session is read server-side
grep -rn "auth\.api\.getSession\|auth()" app/ \
  --include="*.tsx" --include="*.ts" 2>/dev/null | grep -v node_modules

# Find every place a role is checked
grep -rn "\.role\s*===\|role:\s*[\"']admin" app/ lib/ \
  --include="*.tsx" --include="*.ts" 2>/dev/null
```

**What to look for:**
- `trustedOrigins` set to the real production URL only — not `["*"]`, not missing on a custom domain
- `disableCSRFCheck` / `disableOriginCheck` absent or explicitly `false`
- Every admin-gated path calls `auth.api.getSession()` server-side, not only inside a shared client layout
- No Clerk remnants — if the project history includes a Clerk migration, confirm the old SDK is fully gone, not just unused-but-present (a stray `clerkMiddleware()` still wired into `middleware.ts` would run alongside Better Auth)

---

## D — Drizzle / Neon Extended Checks

```bash
# Find all raw SQL and identifier construction
grep -rn "sql\.raw(\|sql\.identifier(\|\.as(" . \
  --include="*.ts" --include="*.tsx" 2>/dev/null | grep -v node_modules

# Confirm installed drizzle-orm version (cross-check against CVE-2026-39356
# table in SKILL.md — vulnerable: <=0.45.1, <=1.0.0-beta.19)
cat package.json | grep "drizzle-orm"

# Find insert/update/delete calls and check each has a session check nearby
grep -n "db\.insert\|db\.update\|db\.delete" app/api/*/route.ts 2>/dev/null

# Confirm DB connection strings never reach a NEXT_PUBLIC_ var or client file
grep -rn "NEXT_PUBLIC.*DATABASE\|NEXT_PUBLIC.*NEON" . 2>/dev/null

# Spot-check input validation exists ahead of the query layer
grep -rn "z\.object\|z\.string\|safeParse" app/api/ \
  --include="*.ts" 2>/dev/null | head -20
```

**What to look for:**
- `sql.raw()` with any interpolated variable — zero protection by design
- `sql.identifier()` / `.as()` fed non-literal input on a vulnerable `drizzle-orm` version — CVE-2026-39356
- INSERT/UPDATE/DELETE route handlers that don't call `auth.api.getSession()` before touching the DB
- `DATABASE_URL` / `DATABASE_URL_UNPOOLED` never inside a `"use client"` file or `NEXT_PUBLIC_`-prefixed var

---

## E — Lemon Squeezy Extended Checks

```bash
# Find the webhook route
find app/api -name "route.ts" | xargs grep -l "lemon\|lemonsqueezy" 2>/dev/null

# Confirm signature verification is present and uses the right primitives
grep -n "X-Signature\|createHmac\|timingSafeEqual\|WEBHOOK_SECRET" \
  app/api/webhooks/*/route.ts 2>/dev/null

# Confirm raw body is read before parsing (required for HMAC to match)
grep -n "request\.text()\|req\.text()\|rawBody" \
  app/api/webhooks/*/route.ts 2>/dev/null

# Confirm idempotency / dedup logic exists
grep -n "eventId\|idempotency\|alreadyProcessed\|webhookId" \
  app/api/webhooks/*/route.ts 2>/dev/null
```

**Correct verification pattern (reference — Lemon Squeezy signs with HMAC-SHA256
over the raw body and sends the hex digest in `X-Signature`):**
```typescript
const rawBody = await request.text();
const signature = Buffer.from(request.headers.get("X-Signature") ?? "", "hex");
const secret = process.env.LEMONSQUEEZY_WEBHOOK_SECRET!;
const expected = Buffer.from(
  createHmac("sha256", secret).update(rawBody).digest("hex"),
  "hex"
);
if (
  expected.length !== signature.length ||
  !timingSafeEqual(expected, signature)
) {
  return new Response("Unauthorized", { status: 401 });
}
const payload = JSON.parse(rawBody);
```
Note the explicit length check before `timingSafeEqual` — mismatched buffer
lengths throw rather than returning `false`, so an unguarded call can crash
the handler instead of rejecting cleanly.

---

## F — Cloudinary Extended Checks

```bash
# Find all upload call sites
grep -rn "cloudinary\.uploader\|v2\.uploader\.upload\|upload_preset" . \
  --include="*.ts" --include="*.tsx" 2>/dev/null

# Check for unsigned preset usage
grep -rn "unsigned.*true\|signed:\s*false" . \
  --include="*.ts" --include="*.tsx" 2>/dev/null

# Confirm the Cloudinary SDK (which needs api_secret) isn't imported into a
# Client Component
grep -rln "\"use client\"" app/ --include="*.tsx" 2>/dev/null | xargs grep -l "cloudinary" 2>/dev/null
```

**What to look for:**
- `upload_preset` used unsigned for anything tied to a paid feature or account-linked asset, rather than genuinely public low-stakes uploads
- The Cloudinary server SDK imported into a file marked `"use client"` — that pulls `api_secret` toward the client bundle
- No `max_file_size` / `allowed_formats` restriction configured on the preset

---

## G — Upstash Redis Extended Checks

```bash
# Find all rate limiter usage
grep -rln "@upstash/ratelimit\|Ratelimit(" . \
  --include="*.ts" --include="*.tsx" 2>/dev/null | grep -v node_modules

# Find auth-adjacent routes and confirm each has a matching ratelimit.limit() call
grep -rln "sign-in\|sign-up\|/auth/" app/api/ --include="*.ts" 2>/dev/null

# Confirm Redis credentials never reach a NEXT_PUBLIC_ var
grep -rn "NEXT_PUBLIC.*UPSTASH\|NEXT_PUBLIC.*REDIS" . 2>/dev/null

# Check how the caller's IP/key is derived — flag raw header parsing
grep -rn "x-forwarded-for\|X-Forwarded-For" . \
  --include="*.ts" 2>/dev/null
```

**Minimum routes that should carry rate limiting:**
- Sign-in / sign-up — brute-force and spam-account protection
- Password reset request — enumeration protection
- Any route proxying to a paid external API (LLM calls, email sends)
- Any route doing heavy computation or generating a file

---

## OWASP Top 10:2025 quick map

For traceability when writing up findings. Matches the categories cited in
`SKILL.md` exactly — this is the list OWASP finalized in January 2026, not
the 2021 list still floating around in older material.

| OWASP 2025 | Sentinel section(s) |
|---|---|
| A01 Broken Access Control (now includes SSRF) | C |
| A02 Security Misconfiguration | A, F, H |
| A03 Software Supply Chain Failures | A |
| A04 Cryptographic Failures | A, B |
| A05 Injection | D |
| A06 Insecure Design | G |
| A07 Authentication Failures | B |
| A08 Software or Data Integrity Failures | E, F |
| A09 Security Logging & Alerting Failures | I |
| A10 Mishandling of Exceptional Conditions | G, I |

### SSRF check (now part of A01:2025 — folded into Section C)

Run if the project fetches URLs based on user input (link previews, OG
image scrapers, webhook relays):

```bash
grep -rn "fetch(\s*req\.\|fetch(\s*body\.\|fetch(\s*params\." app/ \
  --include="*.ts" 2>/dev/null
```

Any hit: confirm the target URL is validated against an allowlist (or at
minimum blocks internal/private IP ranges) before the fetch executes.
