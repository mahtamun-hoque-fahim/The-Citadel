---
name: plainsight
description: >
  IMPLEMENTATION skill for Next.js (App Router) + Tailwind CSS. Write and fix
  code — not critique. For design critique or accessibility audits, use
  ui-ux-designer first, then come back here to implement. "Review and fix" =
  ui-ux-designer critique pass THEN plainsight, never both at once. Use for:
  building pages, dashboards, forms, navigation, modals, tables, marketing
  sites, auth screens, admin panels, or fixing broken layouts. Two modes:
  BUILD (generate from patterns) and FIX (diagnose and minimally patch).
  Catches: centering lies, hero void, CTA drift, grid collapse, marquee
  clipping, sticky failures, dropdown clipping, modal z-index wars, table
  overflow, hydration mismatches, Tailwind v3-vs-v4 mixing, Next 15+ async
  params errors, unnecessary use-client directives.
---

# plainsight

A universal fixer and builder for any Next.js + Tailwind project. Two modes:

- **BUILD** — generating a new page, section, or component. Start from `patterns/` and apply rules from the start.
- **FIX** — patching an existing broken layout. Start from `symptoms.md`, then apply the minimal change from `fixer-protocol.md`.

This skill assumes nothing about the project's aesthetic, color palette, or component library. The code patterns use Tailwind's default neutral palette (`bg-neutral-950`, `text-neutral-100`, etc.); swap for the project's tokens (`bg-background`, `text-foreground`, shadcn variables, or custom colors) without changing the structure. The structural rules are universal.

## Scope — implementation only

Plainsight writes and fixes code. It does not critique designs, audit UX, or produce feedback reports. If you need critique, use **ui-ux-designer** first; once you have prioritised fixes, come back here to implement them.

**"Review and fix this UI"** is a two-step task:
1. **ui-ux-designer** → critique pass (WCAG, Fitts, layout issues, token violations)
2. **plainsight** → implementation pass (apply the fixes in code)

Running plainsight alone on a "review" request will produce a refactored layout without any guarantee the underlying UX problems are solved — or worse, it will introduce new problems while fixing the visible ones.

---

## Choose your mode

**BUILD mode** — when generating something new:
1. Identify the section/component type (hero, navbar, table, modal, etc.)
2. Open the matching file in `patterns/`
3. Copy the CORRECT example, adapt content and colors
4. Run `checklist.md` § Build before declaring done

**FIX mode** — when patching something broken:
1. Describe the visual symptom in one sentence
2. Look it up in `symptoms.md`
3. Apply the minimal patch from `fixer-protocol.md`
4. Run `checklist.md` § Fix before declaring done

## The twelve failure modes

These are the bugs you ship by default unless you actively prevent them. Each is preventable; each has a named symptom in `symptoms.md`.

1. **Centering lies.** `text-center` on a parent does nothing if the child has its own `max-w-*` and no `mx-auto`. The text reads centered in your head; it renders left-aligned in a narrow column anchored to the left edge.
2. **Hero void.** `min-h-screen flex items-center` plus a fixed header centers the hero in the *full* viewport, leaving a header-sized void above the fold.
3. **CTA drift.** Buttons written inline after a paragraph (`<p>...</p><a/><a/>`) inherit the paragraph's text flow and land beside the last line instead of stacking below it.
4. **Grid collapse.** `grid grid-cols-4` looks right in code but renders 1-column on every viewport when the parent is a `flex flex-col items-center` with no width, or when responsive prefixes are missing.
5. **Marquee clipping.** A scrolling ticker without duplicated content and matching animation math clips characters at one or both edges.
6. **Sticky failures.** `sticky top-0` does nothing when any ancestor has `overflow-hidden`, `overflow-auto`, or `overflow-scroll`. The element silently scrolls away.
7. **Dropdown clipping.** A dropdown menu mounted inside a card with `overflow-hidden` gets cut off at the card edge. The menu opens, you just can't see most of it.
8. **Modal stacking.** Backdrop without `fixed inset-0`, body scroll not locked, z-index lower than a sticky header, or no focus trap. Pick any one and the modal is broken.
9. **Card-height ragged.** Cards in a grid with different content lengths produce a ragged bottom edge. Cause: missing `h-full` on the card or `items-stretch` on the grid (which is default but easy to override).
10. **Text overflow blowout.** Long usernames, URLs, or filenames push their container wider than intended, breaking the whole row. Cause: no `truncate`, no `min-w-0` on flex children, no `break-words`.
11. **Sidebar/main mismatch.** Fixed sidebar + main with no left padding/margin = sidebar overlaps content. Or sidebar without mobile collapse strategy = sidebar covers everything on phones.
12. **Hydration mismatch.** Server-rendered HTML differs from first client render — `Date.now()`, `Math.random()`, browser-extension attributes on `<body>`, or `localStorage` reads outside `useEffect`.

## Non-negotiable rules

**R1. Every section has a container.** A `<section>` handles vertical rhythm and background; an inner `<div className="mx-auto max-w-* px-*">` handles horizontal bounds. Never collapse them.

**R2. Centering requires three things together.** Block-level centering needs `mx-auto` AND `max-w-*`. Text wrap inside needs `text-center`. Forgetting any of the three is the #1 cause of "looks broken" generations.

**R3. Button groups are flex containers.** Never write `<p>subtitle</p><a/><a/>` as siblings. Always wrap CTAs in `<div className="flex flex-col sm:flex-row gap-3 ...">`. Same for any group of buttons, links, or controls that should sit together.

**R4. Overflow ancestors break sticky and dropdowns.** Before adding `sticky` or a popover/menu, audit ancestors for `overflow-*`. If any ancestor has it, sticky won't stick and the menu will clip. Either remove the overflow, change positioning to `fixed`, or portal the menu to `<body>`.

**R5. Modals need four things.** `fixed inset-0` backdrop, `z-50` (above all sticky/fixed UI), body scroll lock while open, focus trap. If using shadcn/Radix Dialog, all four are handled. If hand-rolling, do all four explicitly.

**R6. Flex children that can shrink need `min-w-0`.** Flex items default to `min-width: auto`, which means they refuse to shrink below their content size. Long text inside a flex child breaks layouts. Add `min-w-0` to any flex child containing text that might be long, plus `truncate` on the text element itself.

**R7. Grid cards stretch by default; protect it.** Use `h-full` on the card root so even if a parent overrides `items-stretch`, the card fills its grid track. Combine with `flex flex-col` inside the card to push footers (buttons, metadata) to the bottom with `mt-auto`.

**R8. Server is default; client is opt-in.** Add `"use client"` only when the file uses `useState`, `useEffect`, event handlers, refs, or browser APIs. Hero sections, feature grids, footers, tables of static data, and marketing copy are server components.

**R9. Tailwind v3 or v4 — pick one, check `package.json` first.** v4 uses `@import "tailwindcss"` and `@theme`; v3 uses three `@tailwind` directives and `tailwind.config.ts`. Mixing the two produces an unstyled page with no error.

**R10. No emojis. Anywhere.** Code, UI, comments, commit messages, button labels, marquee items. Use `lucide-react` for icons; use `<span className="size-1 rounded-full bg-*">` for bullets.

## File routing

| Doing this | Open this |
|---|---|
| Building a hero, section, app shell, dashboard, auth page | `patterns/layouts.md` |
| Building a navbar, sidebar, mobile drawer, tabs, breadcrumbs, dropdown menu | `patterns/navigation.md` |
| Building inputs, validation, multi-step forms, search, auth forms, action bars | `patterns/forms.md` |
| Building tables, lists, cards, stats, badges, pagination, empty states | `patterns/data-display.md` |
| Building modals, drawers, toasts, popovers, tooltips, alerts, banners | `patterns/overlays.md` |
| Adding interactivity, Server Actions, async params, fonts, metadata | `nextjs-rules.md` |
| Fixing a visual symptom in existing code | `symptoms.md` |
| Deciding how much to refactor when fixing | `fixer-protocol.md` |
| Before declaring anything done | `checklist.md` |

## Color palette assumption

Patterns use Tailwind's neutral palette as a safe default. To adapt:

- **shadcn/ui project**: swap `bg-neutral-950` → `bg-background`, `text-neutral-100` → `text-foreground`, `border-neutral-800` → `border-border`, `bg-neutral-900` → `bg-card`, accent colors → `bg-primary` / `text-primary-foreground`
- **Custom palette**: search-and-replace neutral shades for your scale (e.g. `slate-*`, `zinc-*`, `stone-*`) and accent colors for your brand color
- **Light theme**: invert the neutral scale (`bg-neutral-50`, `text-neutral-900`, `border-neutral-200`)

Structure does not change. Colors do.
