---
name: compass
description: >
  Scenario router for every stage of a project. When you do not know which
  skill to run — or Claude needs to self-route — compass answers by phase
  and symptom: new idea, active build, debugging, drifting, ready to ship,
  ready to deploy. Includes the full post-build launch sequence (Waterborne
  ⛔ → motion-hive AUDIT → valley-of-death ⛔ → sentinel ⛔ → Airborne →
  Humanizer → cave-man → motion-hive touch-up → Council POST → gh-meta
  RELEASE → ticket-checker) and active-build tools (task-planner for
  session-start execution plans, navigator for TDD discipline, oracle for
  mid-build decisions, motion-hive BUILD for Framer architecture after
  plainsight scaffolds a page) — with gate rules and Grandpa Report format.
  Key changes: tree-man now produces a Layout Architecture section in
  SITETREE.md (layout-family, section-sequence, above-fold, rhythm, responsive
  intent per page); motion-hive has two modes — BUILD (during active build,
  after plainsight, generates MOTION.md) and AUDIT (post-build pipeline,
  Step 2); cave-man classifies image zones into 5 types with a 4-field brief
  format; plainsight and ui-ux-designer both have command vocabulary.
  Trigger on: "compass", "which skill", "what should I run", "what is next",
  "I am stuck", "ready to ship", "ready to deploy", "new project", or any
  moment where the right skill is unclear. First skill to install.
  First skill to consult.
---

# Compass

Two questions answer everything:

1. **What phase are you in?**
2. **What is the symptom or goal?**

Find your phase below.

---

## Phase 0 — New Project

| Scenario | Skill | Notes |
|---|---|---|
| New idea, starting fresh | **singularity** | Interview → Phase 1.5 palette → BRAIN.md → **tree-man** → Council PRE → repo-maintainer |
| Club or society website | **club-web-planner** | Still routes through Singularity → tree-man → Council — not a shortcut |
| Existing project, no BRAIN.md | **singularity** retroactive | Say "fetch brain" — reads existing docs, reconstructs BRAIN.md |

After BRAIN.md is committed, **tree-man** writes SITETREE.md before Council PRE-BUILD convenes. SITETREE.md now has two halves: the route manifest (path, type, auth level, purpose, parent, status) AND a Layout Architecture section assigning `layout-family`, `section-sequence`, `above-fold` requirements, `density`, `rhythm`, and responsive intent to every page route. Council reviews actual routes and structure — not a vague idea. plainsight, cave-man, and motion-hive all read the Layout Architecture section before doing their work. After Singularity + tree-man + Council PRE + repo-maintainer: **gh-meta INIT mode** seeds the About section, LICENSE file, and README badges — then **task-planner** generates the first session's atomic task list, sourcing pages from SITETREE.md, and build begins.

---

## Phase 1 — Active Build

### Starting a Session

| Scenario | Skill |
|---|---|
| Beginning a build session, need the next atomic steps | **task-planner** — scans the codebase, reads PLANNER.md, generates a session task list with file paths and verification steps |
| About to write new logic — a feature, route, or Server Action | **navigator** — RED-GREEN-REFACTOR, test written before the implementation |

### Scaffolding & Layout

| Scenario | Skill |
|---|---|
| New pages, routes, Server Components — v15 | **next15builder** |
| New pages, routes, Server Components — v16 | **next16builder** |
| Next.js 14 project | **mahtamun-fullstack** |
| Writing or fixing layout code | **plainsight** BUILD mode — reads SITETREE.md `section-sequence` as the required build order |
| Wiring motion architecture on a page (first time) | **motion-hive BUILD mode** — run after plainsight scaffolds the page; generates Framer variant families, spring presets, scroll hooks, MOTION.md |
| Animation gaps, microinteractions, polish mid-build | **motion-hive AUDIT mode** — audits what exists, does not generate from scratch |
| "Review and fix this UI" | **ui-ux-designer** critique first → **plainsight** to implement — never simultaneously |
| UX or accessibility audit only | **ui-ux-designer** |
| Quick slop-check on AI-generated output | **ui-ux-designer** → `detect [page]` — AI tells detector only, no full audit |
| Emojis appeared in code | **waterborne** — do not wait for post-build |
| Text sounds AI-generated | **humanizer** — do not wait for post-build |

**Shorthand commands available mid-build:**
- `plainsight` → `polish [target]` · `typeset [target]` · `distill [target]`
- `ui-ux-designer` → `audit [target]` · `typeset [target]` · `distill [target]` · `detect [target]`

### Decisions Mid-Build

| Scenario | Skill |
|---|---|
| Stuck between two technical approaches, architecture trade-off | **oracle** — implementation-level decision support, not a SaaS/product verdict (that's council) |
| Writing auth, payment, webhook, or file-upload code | **sentinel** — security gut-check mid-build, does not need to wait for the post-build pipeline |
| A pivot just got decided and code already changed — the old approach was already written into PLANNER.md, README.md, or UI copy | **valley-of-death** — re-check docs and rendered copy against the new code in the same session, before the old description has a chance to go stale |

### Which version do I have?

```bash
cat package.json | grep '"next"'
```

| Result | Use these skills |
|---|---|
| `next@14.x` | mahtamun-fullstack |
| `next@15.x` | next15builder · next15debugger · nextjs15-for-cf |
| `next@16.x` | next16builder · next16-debugger · nextjs16-for-cf |

---

## Phase 2 — Stuck

### Runtime & Build Errors

| Symptom | Skill |
|---|---|
| Any Next.js error — v15 project | **next15debugger** |
| Any Next.js error — v16 project | **next16-debugger** |
| Works on Vercel, breaks on Cloudflare — v15 | **nextjs15-for-cf** |
| Works on Vercel, breaks on Cloudflare — v16 | **nextjs16-for-cf** |
| Auth, DB, or stack-level issue — v14 | **mahtamun-fullstack** |

> Always check `package.json` first. Using a v15 skill on a v16 project gives wrong advice. Skills enforce this — if you land on the wrong one, it tells you to stop.

### Spec Confusion

| Symptom | Skill |
|---|---|
| Code and spec feel out of sync | **valley-of-death** — audit only, no code changes |
| Not sure if a feature was agreed on | **singularity** → "fetch brain" |

---

## Phase 3 — Drifting

Claude is rabbit-holing, over-engineering a side branch, or has lost the main thread.

| Trigger | Action |
|---|---|
| Context lost, Claude going off-track | **singularity** → "fetch brain" |
| Major decision changed or feature descoped | **singularity** → "update brain" |
| Palette was never locked | **singularity** Phase 1.5 — run retroactively |
| Docs are stale after a sprint | **repo-maintainer** → "update repo" |

Signs you are drifting: Claude suggests a pattern not in PLANNER.md, argues against a locked decision, or proposes tech not in the stack.

---

## Phase 4 — Post-Build (Ready to Ship)

> Build is done. Feature list is locked. Now earn the right to ship.

Run in order. No skipping. No reordering.

```
STEP 1 — waterborne                          ⛔ GATE
  Sweep every file for emojis.
  Replace all with lucide-react or plain text.
  PASS: zero emojis in codebase. Proceed.
  FAIL: fix all. Re-run step 1.

STEP 2 — motion-hive AUDIT
  Post-build animation audit. Reads BRAIN.md palette and MOTION.md
  (if motion-hive BUILD already ran during the build phase, AUDIT
  checks its output; if not, AUDIT generates from scratch in retrofit
  mode). Uses token utilities (bg-surface, ring-accent/20).
  No gate — deliver report, continue.

STEP 3 — valley-of-death                     ⛔ GATE
  Reads BRAIN.md + PLANNER.md + DESIGN_GUIDE.md + README.md + AGENTS.md.
  Validates every route, auth gate, data wire, locked decision.
  PASS: all items PASS or PARTIAL with documented reason.
  FAIL: list every failure. Fix all. Re-run step 3.

STEP 4 — sentinel                             ⛔ GATE
  OWASP:2025 + STRIDE audit — BetterAuth, Drizzle, Cloudinary,
  Lemon Squeezy, Upstash. Retrofit scan first, scopes to what's detected.
  PASS: zero CRITICAL findings. HIGH allowed only with written
  acknowledgment from Fahim.
  FAIL: any unresolved CRITICAL. Fix all. Re-run step 4.

STEP 5 — airborne
  Reads BRAIN.md constraints + "What It Must Never Become" first.
  Writes copy only for routes VoD just confirmed.
  Produces: meta titles, H1s, OG, JSON-LD, sitemap.xml, robots.txt.

STEP 6 — humanizer
  Polishes Airborne prose: hero text, body copy, CTAs.
  Skips: meta titles, JSON-LD, robots.txt — machine-read, leave as-is.

STEP 7 — cave-man
  Visual-opportunity audit on the now-final page set. Reads the Layout
  Architecture section of SITETREE.md (tree-man output) first — the
  section-sequence and density fields drive zone classification so type
  assignments are architectural, not guesswork. Also reads BRAIN.md /
  DESIGN_GUIDE.md for palette tokens and product mood.
  Classifies every zone: verdict (NEEDS-ART / HAS-ART / KEEP-FLAT)
  AND image type (inline / background / overlay / texture / parallax).
  For NEEDS-ART zones: inserts a placeholder with a 4-field brief tag
  (IMAGE-TYPE, IMAGE-BRIEF, IMAGE-OVERLAY, IMAGE-RESPONSIVE) plus a
  skeleton comment showing the integration structure when art arrives.
  Never generates the artwork itself. Runs last so nothing it briefs
  can still be invalidated by a later copy or spec change.
  No gate — deliver report, continue.

STEP 8 — motion-hive touch-up
  Scoped, not a full re-audit. Only treats the new `data-image-slot`
  elements cave-man just inserted — skeleton-shimmer, nothing else
  re-checked. No gate — deliver report, continue.

STEP 9 — council POST-BUILD
  Sees everything: clean code, motion audited, spec confirmed,
  security audited, copy polished, visual gaps briefed.
  Full 5-persona review — Architect's security pass reads sentinel's
  report rather than re-deriving it. Verdict: SHIP / HOLD / KILL.

STEP 10 — gh-meta RELEASE
  Version bump, changelog from git log, npm version patch/minor/major,
  git push --follow-tags, gh release create, About description sync.
  No gate — must complete before ticket-checker runs.

STEP 11 — ticket-checker
  Final pre-deploy QA. Walks every route, auth gate, payment flow,
  API endpoint — automated + clearly labelled manual steps.
  Produces DEPLOY TICKET: READY TO SHIP or BLOCKED with exact reasons.
```

### Why this order

| Wrong swap | Why it breaks |
|---|---|
| cave-man before Airborne/Humanizer | Would brief zones whose copy or layout might still change — wasted design work for Fahim |
| motion-hive touch-up before cave-man | Nothing new to treat yet — the touch-up only exists to catch cave-man's placeholders |
| Airborne before VoD | Writes copy for routes VoD might invalidate — wasted work |
| Sentinel before VoD | Audits a codebase that might still change — findings could go stale before the spec is even confirmed |
| Council before Airborne | Should evaluate polished copy, not raw code |
| Waterborne last | Airborne writes copy for pages that still have emojis |
| motion-hive after Airborne | Better to fix animation before SEO copy references page feel |

### Gate rules

**GATE 1 — Waterborne:** any emoji found = blocked. If Fahim says "skip it" — decline.

**GATE 2 — Valley of Death:** any `FAIL` = blocked. `PARTIAL` allowed with a documented one-line reason. `MISSING` doc = blocked unless Fahim acknowledges in writing. If Fahim says "skip it" — list every FAIL first, then ask once more. Do not proceed silently.

**GATE 3 — Sentinel:** any `CRITICAL` finding = blocked, no exceptions — this covers account takeover, data breach, and payment-bypass-class issues. `HIGH` may proceed only with Fahim's written acknowledgment of the specific risk. `MEDIUM`/`LOW` never block. If Fahim says "skip it" on a CRITICAL — decline, same as Waterborne.

### Grandpa Report

After all 11 steps complete, produce this consolidated output:

```
╔══════════════════════════════════════════════╗
║              GRANDPA REPORT                  ║
║         [Project Name] — [Date]              ║
╠══════════════════════════════════════════════╣
║  STEP 1  waterborne       CLEAN         ✓    ║
║  STEP 2  motion-hive      AUDITED       ✓    ║
║  STEP 3  valley-of-death  PASS          ✓    ║
║  STEP 4  sentinel         CLEAN         ✓    ║
║  STEP 5  airborne         DONE          ✓    ║
║  STEP 6  humanizer        DONE          ✓    ║
║  STEP 7  cave-man         BRIEFED       ✓    ║
║  STEP 8  motion-hive t/u  AUDITED       ✓    ║
║  STEP 9  council POST     SHIP          ✓    ║
║  STEP 10 gh-meta          RELEASED      ✓    ║
║  STEP 11 ticket-checker   READY         ✓    ║
╠══════════════════════════════════════════════╣
║  VERDICT:  DEPLOY / HOLD / KILL              ║
╚══════════════════════════════════════════════╝
```

If blocked by a gate:

```
╔══════════════════════════════════════════════╗
║         GRANDPA REPORT — BLOCKED             ║
╠══════════════════════════════════════════════╣
║  STEP 1  waterborne       CLEAN         ✓    ║
║  STEP 2  motion-hive      AUDITED       ✓    ║
║  STEP 3  valley-of-death  BLOCKED       ⛔   ║
║  STEP 4  sentinel         PENDING            ║
║  STEP 5  airborne         PENDING            ║
║  STEP 6  humanizer        PENDING            ║
║  STEP 7  cave-man         PENDING            ║
║  STEP 8  motion-hive t/u  PENDING            ║
║  STEP 9  council POST     PENDING            ║
║  STEP 10 gh-meta          PENDING            ║
║  STEP 11 ticket-checker   PENDING            ║
╠══════════════════════════════════════════════╣
║  FIX REQUIRED:                               ║
║  [every FAIL from VoD listed here]           ║
╚══════════════════════════════════════════════╝
```

Once a SHIP verdict is reached, see **Phase 5** below — Council saying SHIP
is not the same as it being safe to actually deploy yet.

---

## Phase 5 — Final Deploy Check

> Council POST said SHIP. Two things happen before `git push` to production.

**First — gh-meta RELEASE mode**

Version bump, changelog generation, GitHub release creation, About section sync.

```
gh-meta handles in order:
  0. licenseInfo check        → if public repo + no license, flag it (retrofit gate, not blocking)
  1. git describe --tags        → read current version
  2. git log [tag]..HEAD        → generate changelog entry
  3. npm version patch/minor/major  → bump + commit + tag
  4. git push --follow-tags     → push code and tag together
  5. gh release create          → publish GitHub release
  6. gh repo edit               → sync About description if Airborne changed it
```

For a **routine hotfix** (not a feature release): gh-meta SYNC mode only —
update About if needed, skip version bump, skip release creation.

**Then — ticket-checker**

Walks every route, auth gate, payment flow, and API endpoint with a mix of
automated checks (curl, build, grep) and clearly-labeled manual steps Fahim
runs himself (real checkout flows, visual review), then produces a `DEPLOY TICKET`
that's either `READY TO SHIP` or `BLOCKED` with exact reasons.

For a routine update or hotfix to something already shipped, the full
Phase 4 pipeline every time is overkill — ticket-checker works standalone
in that case, scoped to what changed. Reserve the full nine-step
sequence for first launches and major versions.

---

## Anytime

| Skill | When |
|---|---|
| **waterborne** | Any emoji spotted — do not wait for post-build |
| **humanizer** | Any copy that sounds AI-generated — not just after Airborne |
| **valley-of-death** | Quick spec check mid-build — read-only, no code changes |
| **valley-of-death** | A mid-build architecture or stack pivot just happened (swapped a library, dropped a dependency, changed the data flow) — run it before the session ends, don't wait for POST. A pivot is exactly what leaves PLANNER.md/README.md/UI copy describing the old approach while the code has already moved on |
| **sentinel** | Security gut-check mid-build — does not need to wait for the post-build pipeline |
| **singularity** fetch brain | Claude drifting, long break, context lost |
| **singularity** update brain | Major decision changed, feature descoped, pivot |
| **airborne** | Single-route SEO — does not need to be a full-site run |
| **ui-ux-designer** | Any design review — always before plainsight for fix tasks |
| **task-planner** | Start of every build session, not only the first one |
| **navigator** | Any time new feature logic is about to be written, in any project — not only a fresh repo |
| **oracle** | Stuck on a decision — tech, architecture, business, or personal — that is not a SaaS/product verdict (that's council) |

---

## Full Skill Map

| Skill | Phase | Role |
|---|---|---|
| **singularity** | PRE · ANYTIME | Interview → BRAIN.md → Council context · re-anchor when drifting |
| **tree-man** | PRE | Writes SITETREE.md — route manifest + Layout Architecture section (layout-family, section-sequence, above-fold, rhythm, responsive intent per page) — right after BRAIN.md, before Council PRE-BUILD. plainsight, cave-man, and motion-hive all read it. |
| **club-web-planner** | PRE | Club/society site planner — routes through Singularity |
| **council** | PRE · POST | PRE: plan verdict · POST: ship verdict |
| **repo-maintainer** | PRE · ANYTIME | Scaffold + maintain PLANNER, DESIGN_GUIDE, README, AGENTS |
| **task-planner** | BUILD · ANYTIME | Atomic execution plan from PLANNER.md — start of every session |
| **next15builder** | BUILD | Scaffold — v15 only |
| **next16builder** | BUILD | Scaffold — v16 only |
| **mahtamun-fullstack** | BUILD | Stack patterns — v14 only |
| **navigator** | BUILD · ANYTIME | TDD discipline — RED-GREEN-REFACTOR for new feature work |
| **oracle** | BUILD · ANYTIME | Multi-persona decision council — tech/architecture/business/life calls, not SaaS eval (that's council) |
| **plainsight** | BUILD | Write + fix layout code — not critique. Reads SITETREE.md section-sequence as build order. Runs AI tells detector against own output. Commands: `polish` · `typeset` · `distill` |
| **ui-ux-designer** | BUILD | Critique + audit — not implementation. 20-tell AI tells detector. Reads SITETREE.md layout-family before auditing. Commands: `audit` · `typeset` · `distill` · `detect` |
| **cave-man** | POST | Visual-opportunity audit, runs last (after Airborne/Humanizer) — classifies by verdict (NEEDS-ART / HAS-ART / KEEP-FLAT) AND image type (inline / background / overlay / texture / parallax); 4-field brief format |
| **motion-hive** | BUILD · POST | Two modes: BUILD (during active build, after plainsight — generates Framer variants, spring presets, MOTION.md) · AUDIT (post-build Step 2 — quality gate, reads MOTION.md if BUILD ran, retrofits if not) |
| **next15debugger** | STUCK | Debug — v15 only |
| **next16-debugger** | STUCK | Debug — v16 only |
| **nextjs15-for-cf** | STUCK | Vercel + Cloudflare cross-platform — v15 only |
| **nextjs16-for-cf** | STUCK | Vercel + Cloudflare cross-platform — v16 only |
| **valley-of-death** | STUCK · POST | Spec vs code audit — read-only |
| **sentinel** | POST · ANYTIME | OWASP:2025 + STRIDE security audit — retrofit scan first |
| **waterborne** | BUILD · POST · ANYTIME | Emoji sweep |
| **airborne** | POST · ANYTIME | SEO copy — after VoD confirms routes |
| **humanizer** | POST · ANYTIME | De-AI prose |
| **gh-meta** | PRE · POST · DEPLOY | INIT: About + LICENSE + README badges, right after repo-maintainer · RELEASE: version bump · changelog · release creation — after Council POST, before ticket-checker |
| **ticket-checker** | DEPLOY | Final pre-deploy QA — ship-time only, never mid-build |
| **compass** | ALWAYS | This file |
