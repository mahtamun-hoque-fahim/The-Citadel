# Schema Markup Library

Copy-paste JSON-LD for every schema type Airborne uses. Schema is leverage — correctly applied, it unlocks rich snippets and AI Overview citations that move CTR by 20–40% at the same ranking position.

All examples below use schema.org vocabulary and JSON-LD format (Google's recommended). Insertion pattern for Next.js App Router is at the end of this file.

---

## Schema Selection — Pick the Right Type

| Page type | Primary schema | Optional adds |
|---|---|---|
| Homepage | `Organization` + `WebSite` | `SearchAction` if site has search |
| About | `AboutPage` + `Organization` | — |
| Blog post | `Article` (or `BlogPosting`) | `BreadcrumbList` |
| Tutorial / guide | `HowTo` | `Article` |
| FAQ section | `FAQPage` | — |
| Product page | `Product` | `Offer`, `AggregateRating` (only if real reviews) |
| Software / app | `SoftwareApplication` | `Offer` |
| Course | `Course` | `CourseInstance`, `Offer` |
| Local business | `LocalBusiness` | `OpeningHoursSpecification` |
| Event | `Event` | `Offer` |
| Recipe | `Recipe` | — |
| Person profile | `Person` | — |
| Research study | `Article` + `Dataset` | `ScholarlyArticle` |

---

## Organization (homepage, every site)

```json
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "LearnDE",
  "url": "https://learnde.com",
  "logo": "https://learnde.com/logo.png",
  "description": "Native-tutor-built prep for DELF, DSH, and TestDaF exams.",
  "sameAs": [
    "https://twitter.com/learnde",
    "https://www.linkedin.com/company/learnde",
    "https://github.com/learnde"
  ],
  "contactPoint": {
    "@type": "ContactPoint",
    "contactType": "customer support",
    "email": "support@learnde.com",
    "availableLanguage": ["English", "Bengali", "French", "German"]
  }
}
```

---

## WebSite + SearchAction (homepage)

```json
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "name": "LearnDE",
  "url": "https://learnde.com",
  "potentialAction": {
    "@type": "SearchAction",
    "target": {
      "@type": "EntryPoint",
      "urlTemplate": "https://learnde.com/search?q={search_term_string}"
    },
    "query-input": "required name=search_term_string"
  }
}
```

---

## Article / BlogPosting

```json
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "How to Pass DELF B2: Score 16/20 in 8 Weeks",
  "description": "An 8-week DELF B2 study plan with mock exams, writing templates, and tutor-reviewed sample answers.",
  "image": ["https://learnde.com/blog/delf-b2-guide/cover.jpg"],
  "datePublished": "2026-05-20T08:00:00+06:00",
  "dateModified": "2026-05-23T08:00:00+06:00",
  "author": {
    "@type": "Person",
    "name": "Fahim Mahtab",
    "url": "https://learnde.com/team/fahim"
  },
  "publisher": {
    "@type": "Organization",
    "name": "LearnDE",
    "logo": {
      "@type": "ImageObject",
      "url": "https://learnde.com/logo.png"
    }
  },
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://learnde.com/blog/pass-delf-b2-8-weeks"
  }
}
```

---

## BreadcrumbList (every nested page)

```json
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://learnde.com"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Blog",
      "item": "https://learnde.com/blog"
    },
    {
      "@type": "ListItem",
      "position": 3,
      "name": "How to Pass DELF B2",
      "item": "https://learnde.com/blog/pass-delf-b2-8-weeks"
    }
  ]
}
```

---

## FAQPage (use anywhere there's a real Q&A block)

```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "How long is the DELF B2 exam?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "The DELF B2 exam runs approximately 2 hours and 30 minutes total, split across listening (30 min), reading (60 min), writing (60 min), and a separate oral exam (20 min preparation + 20 min interview)."
      }
    },
    {
      "@type": "Question",
      "name": "What is the passing score for DELF B2?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "You need 50/100 overall to pass DELF B2, with a minimum of 5/25 in each of the four sections."
      }
    }
  ]
}
```

Only include FAQPage schema if the questions and answers are **actually visible on the page**. Fabricated FAQ schema is a Google penalty.

---

## HowTo (tutorials)

```json
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Deploy Next.js to Cloudflare Pages",
  "description": "Step-by-step guide to deploying a Next.js 14 App Router site to Cloudflare Pages with edge runtime.",
  "totalTime": "PT20M",
  "tool": [
    { "@type": "HowToTool", "name": "Wrangler CLI" },
    { "@type": "HowToTool", "name": "GitHub" }
  ],
  "step": [
    {
      "@type": "HowToStep",
      "name": "Install Wrangler",
      "text": "Run npm install -g wrangler in your terminal."
    },
    {
      "@type": "HowToStep",
      "name": "Configure next.config.js",
      "text": "Add export const runtime = 'edge' to each route that runs on Cloudflare."
    }
  ]
}
```

---

## Course

```json
{
  "@context": "https://schema.org",
  "@type": "Course",
  "name": "DELF B2 Complete Prep Course",
  "description": "8-week structured prep for the DELF B2 exam, with weekly mocks, tutor feedback, and writing templates.",
  "provider": {
    "@type": "Organization",
    "name": "LearnDE",
    "sameAs": "https://learnde.com"
  },
  "hasCourseInstance": {
    "@type": "CourseInstance",
    "courseMode": "online",
    "courseWorkload": "PT40H"
  },
  "offers": {
    "@type": "Offer",
    "price": "4999",
    "priceCurrency": "BDT",
    "category": "Paid",
    "availability": "https://schema.org/InStock"
  }
}
```

---

## Product

```json
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "DELF B2 Mock Exam Bundle",
  "description": "5 full-length DELF B2 mock exams with detailed scoring and sample answers.",
  "image": "https://learnde.com/products/delf-b2-mocks.jpg",
  "brand": { "@type": "Brand", "name": "LearnDE" },
  "offers": {
    "@type": "Offer",
    "url": "https://learnde.com/store/delf-b2-mocks",
    "priceCurrency": "BDT",
    "price": "1499",
    "availability": "https://schema.org/InStock",
    "priceValidUntil": "2026-12-31"
  }
}
```

`AggregateRating` is **only** valid if real, verifiable reviews exist on the page. Do not fake.

---

## SoftwareApplication (for apps and tools)

```json
{
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  "name": "LearnDE",
  "operatingSystem": "Web, iOS, Android",
  "applicationCategory": "EducationalApplication",
  "offers": {
    "@type": "Offer",
    "price": "0",
    "priceCurrency": "BDT"
  }
}
```

For free tools use `applicationCategory: "UtilityApplication"` and `offers.price: "0"`.

---

## Dataset (research / study pages with downloadable data)

```json
{
  "@context": "https://schema.org",
  "@type": "Dataset",
  "name": "Bangladesh Remote Work Survey 2026",
  "description": "Survey of 1,200 Bangladeshi remote workers covering income, tools, and burnout.",
  "url": "https://learnde.com/research/remote-work-2026",
  "creator": {
    "@type": "Organization",
    "name": "LearnDE Research"
  },
  "license": "https://creativecommons.org/licenses/by/4.0/",
  "distribution": {
    "@type": "DataDownload",
    "encodingFormat": "CSV",
    "contentUrl": "https://learnde.com/research/remote-work-2026/data.csv"
  }
}
```

---

## Next.js App Router Insertion Pattern

The cleanest place to inject JSON-LD is inside the page or layout component:

```tsx
// app/blog/[slug]/page.tsx
export default async function BlogPost({ params }: { params: { slug: string } }) {
  const post = await getPost(params.slug);

  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: post.title,
    description: post.description,
    datePublished: post.publishedAt,
    dateModified: post.updatedAt,
    author: { "@type": "Person", name: post.author.name },
    publisher: {
      "@type": "Organization",
      name: "LearnDE",
      logo: { "@type": "ImageObject", url: "https://learnde.com/logo.png" },
    },
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }}
      />
      <article>{/* page content */}</article>
    </>
  );
}
```

For per-page metadata (title, description, OG, Twitter), use the `generateMetadata` export — not JSON-LD.

> **Version note:** the example below uses Next.js 14 syntax (sync `params`). On Next.js 15 and 16, `params` is a Promise and must be awaited. See `references/nextjs-versions.md` for all three versions.

```tsx
// Next.js 14 syntax (sync params)
import type { Metadata } from "next";

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const post = await getPost(params.slug);
  return {
    title: `${post.title} | LearnDE`,
    description: post.description,
    openGraph: {
      title: post.title,
      description: post.description,
      url: `https://learnde.com/blog/${post.slug}`,
      images: [{ url: post.coverImage }],
      type: "article",
    },
    twitter: {
      card: "summary_large_image",
      title: post.title,
      description: post.description,
      images: [post.coverImage],
    },
    alternates: {
      canonical: `https://learnde.com/blog/${post.slug}`,
    },
  };
}
```

---

## Multiple Schemas on One Page

Put each schema in its own `<script type="application/ld+json">` block, OR combine them in a `@graph` array:

```json
{
  "@context": "https://schema.org",
  "@graph": [
    { "@type": "Organization", "name": "LearnDE", "url": "https://learnde.com" },
    { "@type": "WebSite", "url": "https://learnde.com", "name": "LearnDE" },
    {
      "@type": "BreadcrumbList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://learnde.com" }
      ]
    }
  ]
}
```

Both approaches are valid. `@graph` is slightly cleaner; separate scripts are easier to debug.

---

## Validation

Before declaring a schema block done, validate:

1. **Schema Markup Validator:** https://validator.schema.org/
2. **Google Rich Results Test:** https://search.google.com/test/rich-results

Both should show zero errors. Warnings are usually safe but worth reading.

---

## Common Schema Mistakes Airborne Avoids

- Faking `AggregateRating` (Google penalty)
- Adding `FAQPage` for questions not visible on the page
- Marking up content that doesn't exist on the page
- Mismatched dates (`datePublished` after `dateModified`)
- Missing required properties (`headline`, `author`, `datePublished` for Article)
- Using `@type: WebPage` when a more specific type exists
- Stuffing `keywords` field with terms not relevant to the page
