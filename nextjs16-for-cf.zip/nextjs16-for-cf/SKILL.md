---
name: nextjs16-for-cf
description: >
  Debugging and best practices for Fahim's Next.js 16 projects deployed
  simultaneously to Cloudflare (Workers via OpenNext) AND Vercel. ALWAYS use
  this skill whenever the user mentions Next.js 16, "next 16", proxy.ts,
  middleware-to-proxy migration, async cookies/headers/params/searchParams,
  Cache Components, "use cache", Turbopack, OpenNext, @opennextjs/cloudflare,
  next-on-pages deprecation, wrangler.jsonc, open-next.config.ts, React 19
  inside Next, View Transitions, Activity, useEffectEvent, React Compiler,
  Build Adapters API, updateTag, revalidateTag, Better Auth in Next 16,
  LearnDE auth migration, OR when debugging any deploy/build/runtime issue
  on a Next.js 16 codebase hosted on Vercel or Cloudflare. Use proactively
  when writing new features in a Next.js 16 codebase to apply correct patterns
  from the start. Trigger even if the user only says "next 16" casually, or
  shows an error message that mentions proxy.ts, "use cache", Turbopack,
  cookies() must be awaited, or OpenNext.
---

# Nextjs16-for-CF Skill

Fahim's Next.js 16 dual-deploy stack: **Next.js 16 App Router · React 19 · TypeScript 5.1+ · Tailwind CSS · Neon (PostgreSQL) · Drizzle ORM · Better Auth · Vercel (primary) · Cloudflare Workers via OpenNext (secondary)**

Active project this is most often used on: **LearnDE**. Same repo, same code, two deploys.

This skill exists because Next.js 16 broke five fundamental assumptions baked into Next.js 14/15 codebases. If you read no other section, read section 1.

---

## 1. The Five Breakages You Will Hit (15 -> 16)

Every Next.js 16 migration trips on at least three of these. Memorize them.

| # | Breakage | What changed | Fix |
|---|---|---|---|
| 1 | `middleware.ts` -> `proxy.ts` | File and exported function renamed; default runtime is now Node.js, not Edge | Run `npx @next/codemod@canary middleware-to-proxy`. Move auth checks OUT of proxy into layouts/DAL |
| 2 | Async Request APIs | `cookies()`, `headers()`, `draftMode()`, `params`, `searchParams` are now async-only. Synchronous access throws at runtime | `await cookies()`, `await params`, etc. Codemod available |
| 3 | `@cloudflare/next-on-pages` deprecated | Cloudflare officially recommends `@opennextjs/cloudflare` deployed to Workers, not Pages | Migrate to OpenNext + `wrangler.jsonc`. Old `output: 'standalone'` config still applies but build command changes |
| 4 | Node 20.9+, TypeScript 5.1+ | Node 18 dropped entirely | Bump `engines.node` in package.json; update Vercel/Cloudflare runtime; bump `typescript` |
| 5 | `next lint` removed | `next build` no longer runs lint | Run `eslint` or `biome` directly in CI; add `lint` script |

There is also a quieter sixth: **Turbopack is now the default bundler**. Webpack is opt-in via `--webpack`. Most projects are fine, but some webpack plugins and css-in-js patterns break silently.

---

## 2. middleware.ts -> proxy.ts (CRITICAL for LearnDE Better Auth)

This is the largest single change. It is NOT just a rename — the semantics and runtime have shifted.

### Why it changed

CVE-2025-29927 was a real auth-bypass vulnerability in Next.js Middleware. Vercel responded by:
- Renaming the file/function to make its limited purpose explicit (network boundary only)
- Moving the default runtime from Edge to Node.js
- Telling developers loudly: **do not put auth logic in proxy.ts**

### The rename itself (mechanical part)

Run the codemod:
```bash
npx @next/codemod@canary middleware-to-proxy
```

This renames the file and the function. Manually, the change is:
```ts
// proxy.ts (was middleware.ts)
import { NextRequest, NextResponse } from 'next/server'

// function name MUST be 'proxy', not 'middleware'
export function proxy(request: NextRequest) {
  return NextResponse.next()
}

export const config = {
  matcher: ['/dashboard/:path*', '/staff/:path*'],
}
```

### The architecture part (this is what trips people up)

**proxy.ts is no longer the place for auth checks.** Treat it as a thin network layer: redirects, rewrites, header injection, locale routing. Move authentication into:

1. **Layouts and pages** (server components — call `auth()` directly)
2. **Data Access Layer (DAL)** — a single `requireUser()` / `requireStaff()` helper called from every server action and route handler
3. **Route Handlers** — for API endpoints that need auth

### LearnDE pattern (Better Auth + dual-runtime)

```ts
// lib/auth/session.ts — Data Access Layer
import { cache } from 'react'
import { headers } from 'next/headers'
import { auth } from '@/lib/auth'  // Better Auth instance
import { redirect } from 'next/navigation'

export const getSession = cache(async () => {
  // headers() is now async in Next 16
  const h = await headers()
  return auth.api.getSession({ headers: h })
})

export const requireStudent = cache(async () => {
  const session = await getSession()
  if (!session?.user || session.user.role !== 'student') redirect('/login')
  return session
})

export const requireStaff = cache(async () => {
  const session = await getSession()
  if (!session?.user || session.user.role !== 'staff') redirect('/staff/login')
  return session
})
```

Then in any protected page:
```tsx
// app/dashboard/page.tsx
import { requireStudent } from '@/lib/auth/session'

export default async function DashboardPage() {
  const session = await requireStudent()
  return <Dashboard user={session.user} />
}
```

**proxy.ts** just handles redirects for unauthenticated users hitting protected URL patterns — it does NOT validate sessions:

```ts
// proxy.ts — thin layer only
import { NextRequest, NextResponse } from 'next/server'

export function proxy(request: NextRequest) {
  // Lightweight cookie presence check, NOT validation
  const hasSession = request.cookies.has('better-auth.session_token')
  const isProtected = request.nextUrl.pathname.startsWith('/dashboard') ||
                      request.nextUrl.pathname.startsWith('/staff')

  if (isProtected && !hasSession) {
    return NextResponse.redirect(new URL('/login', request.url))
  }
  return NextResponse.next()
}

export const config = {
  matcher: ['/dashboard/:path*', '/staff/:path*'],
}
```

Real validation happens in `requireStudent()`/`requireStaff()`. The proxy is just a fast redirect for the obvious unauthenticated case.

### The "Logout Loop" bug

If after migration users can't log out, the cause is almost always: a Server Action sets a cookie clear, but proxy.ts intercepts the response and rebuilds headers without that cookie. Fix: ensure proxy returns `NextResponse.next()` early when the response should pass through untouched, and never reconstruct headers from scratch.

### When to keep middleware.ts (rarely)

`middleware.ts` still works in 16 but is deprecated and Edge-only. Keep it ONLY if you genuinely need Edge runtime and have a workload that can't run on Node.js. For LearnDE, the answer is always: use `proxy.ts`.

---

## 3. Async Request APIs (every page, layout, route, action)

In 16, these throw at runtime if accessed synchronously:

```ts
// BROKEN in 16
const c = cookies()
const token = c.get('session')

// CORRECT in 16
const c = await cookies()
const token = c.get('session')
```

The full list:
- `cookies()` -> `await cookies()`
- `headers()` -> `await headers()`
- `draftMode()` -> `await draftMode()`
- `params` in layouts/pages/route handlers -> `await params`
- `searchParams` in pages -> `await searchParams`
- Same applies in `opengraph-image`, `twitter-image`, `icon`, `apple-icon`, `default.js`

### New page props pattern

```tsx
// app/blog/[slug]/page.tsx — new pattern
export default async function Page(props: PageProps<'/blog/[slug]'>) {
  const { slug } = await props.params
  const query = await props.searchParams
  return <h1>Blog: {slug}</h1>
}
```

Note the new `PageProps<'/path/[param]'>` typed helper — it gives full type safety for route params.

### Codemod

```bash
npx @next/codemod@canary next-async-request-api .
```

It handles 90% of cases. Verify remaining sync access manually.

---

## 4. Deploying to Cloudflare with Next.js 16 (OpenNext)

**Most important fact:** `@cloudflare/next-on-pages` is deprecated. New deploys use `@opennextjs/cloudflare`, which targets **Cloudflare Workers** (not Pages), runs on the **Node.js runtime** (not Edge), and supports nearly every Next.js feature.

### Setup

```bash
npm install --save-dev @opennextjs/cloudflare wrangler
```

`wrangler.jsonc` at repo root:
```jsonc
{
  "$schema": "node_modules/wrangler/config-schema.json",
  "main": ".open-next/worker.js",
  "name": "learnde",
  "compatibility_date": "2024-12-30",
  "compatibility_flags": ["nodejs_compat", "global_fetch_strictly_public"],
  "assets": {
    "directory": ".open-next/assets",
    "binding": "ASSETS"
  }
  // Optional: KV for ISR cache
  // "kv_namespaces": [{ "binding": "NEXT_CACHE_WORKERS_KV", "id": "..." }]
  // Optional: R2 for incremental cache
}
```

`open-next.config.ts` at repo root:
```ts
import { defineCloudflareConfig } from '@opennextjs/cloudflare'
import kvIncrementalCache from '@opennextjs/cloudflare/kv-cache'

export default defineCloudflareConfig({
  incrementalCache: kvIncrementalCache,  // or r2 if using R2
})
```

`next.config.ts` — add the dev initializer so local dev sees Cloudflare bindings:
```ts
import type { NextConfig } from 'next'
import { initOpenNextCloudflareForDev } from '@opennextjs/cloudflare'

const nextConfig: NextConfig = {
  // images: { unoptimized: true }  // only if not using Cloudflare Images
}

initOpenNextCloudflareForDev()
export default nextConfig
```

package.json scripts:
```json
{
  "scripts": {
    "build:cf": "opennextjs-cloudflare build",
    "preview:cf": "opennextjs-cloudflare preview",
    "deploy:cf": "opennextjs-cloudflare deploy"
  }
}
```

### Compatibility flags — non-negotiable

- `nodejs_compat` — required, this is what enables Node.js APIs
- Compatibility date must be `2024-09-23` or later (`2024-12-30` is current safe default)
- Without `nodejs_compat`, builds succeed and deploys fail at runtime with cryptic stream/buffer errors

### What's different from old next-on-pages

| Aspect | next-on-pages (deprecated) | OpenNext (current) |
|---|---|---|
| Runtime | Edge only | Node.js (full APIs) |
| Output dir | `.vercel/output/static` | `.open-next/` |
| Build cmd | `npx @cloudflare/next-on-pages` | `opennextjs-cloudflare build` |
| `export const runtime = 'edge'` | Required on every route | Not needed |
| Node APIs (fs, crypto) | NOT available | Available |
| `pg` driver | Forbidden | Works (but Neon HTTP still better) |
| ISR/PPR | Limited | Full support via KV/R2 |
| Image optimization | Not supported | Via Cloudflare Images |

### Why this is good news for LearnDE

The old constraint — "use Neon HTTP driver because Edge can't do TCP" — is gone on the Workers runtime. You CAN now use `pg` or `@neondatabase/serverless`'s Pool. **However**, Neon HTTP is still the right default because (a) it works identically on Vercel Edge if you ever want it, (b) it has lower cold-start cost, and (c) one less migration target if you go back to dual-runtime later.

---

## 5. Deploying to Vercel with Next.js 16

Vercel handles 16 transparently in most cases. The things that actually need attention:

### Build settings

- Framework preset: `Next.js` (auto-detects 16)
- Build command: `next build` (default; do NOT override)
- Node.js version: 20.x or 22.x in project settings
- Install command: `npm ci` (or `pnpm i --frozen-lockfile`)

### Runtime selection

In 16, `runtime` per-route can be `'nodejs'` (default) or `'edge'`. Vercel respects both. Prefer `'nodejs'` unless you have a specific reason for Edge — Cache Components, file streams, and most npm packages assume Node.

```ts
// app/api/heavy/route.ts
export const runtime = 'nodejs'  // default, but explicit is good for dual-deploy clarity
```

### Cache Components on Vercel

Cache Components and `"use cache"` work natively. Vercel's edge cache picks up tagged responses automatically. Use `updateTag()` to refresh cache for a tag, and `revalidateTag()` (now refined) to invalidate. See section 7.

### Build Adapters

Next.js 16 ships a Build Adapters API (alpha). Vercel's adapter is automatic. You only touch this if you're writing a custom adapter (you probably aren't).

### ESLint

Since `next build` no longer lints:
```json
{
  "scripts": {
    "build": "next build",
    "lint": "eslint . --max-warnings=0",
    "ci": "npm run lint && npm run build"
  }
}
```
Set Vercel's build command to `npm run ci` if you want lint to block deploys.

---

## 6. Maintaining Dual Vercel + Cloudflare Deploys

This is the actual hard part and where most production problems come from. Keep the deploys behaviorally identical.

### Runtime discipline

- Default to `runtime = 'nodejs'` everywhere (works on both)
- Never use `runtime = 'edge'` unless you've verified it works on OpenNext
- Avoid Node-only APIs in code paths that DON'T need them — keeps options open

### Database driver

Use Neon's HTTP driver as the default for cross-runtime safety:
```ts
// lib/db/index.ts
import { neon } from '@neondatabase/serverless'
import { drizzle } from 'drizzle-orm/neon-http'
import * as schema from './schema'

export function getDb() {
  if (!process.env.DATABASE_URL) return null as any
  return drizzle(neon(process.env.DATABASE_URL), { schema })
}
```

For long-running operations (migrations, batch jobs), use the Pool driver in a Node-only path:
```ts
// lib/db/node.ts — only call from scripts or Node-runtime routes
import { Pool } from '@neondatabase/serverless'
import { drizzle } from 'drizzle-orm/neon-serverless'
import * as schema from './schema'

export function getNodeDb() {
  return drizzle(new Pool({ connectionString: process.env.DATABASE_URL }), { schema })
}
```

### Environment variables — sync BOTH dashboards

Every env var added to Vercel must also be added to Cloudflare via `wrangler secret put` or the Workers dashboard. A missing env var on one side produces "works on Vercel, broken on Cloudflare" bugs that are painful to diagnose.

Build-time validation helps:
```ts
// lib/env.ts
const required = ['DATABASE_URL', 'DATABASE_URL_UNPOOLED', 'BETTER_AUTH_SECRET', 'BETTER_AUTH_URL']
required.forEach(key => {
  if (!process.env[key]) throw new Error(`Missing env: ${key}`)
})
```

### Image optimization

Vercel does it for free. Cloudflare needs Cloudflare Images (paid) OR `images: { unoptimized: true }` in `next.config.ts`. For dual-deploy:
```ts
// next.config.ts
const isCloudflare = process.env.CF_PAGES === '1' || process.env.WORKERS_CI === '1'

const nextConfig: NextConfig = {
  images: isCloudflare ? { unoptimized: true } : {},
}
```

### ISR / Cache Components

Vercel handles ISR transparently. Cloudflare needs a KV or R2 binding for ISR to work properly — without it, `revalidate` silently no-ops on CF. Configure via `open-next.config.ts`.

### Where they will diverge

| Concern | Vercel | Cloudflare (OpenNext) |
|---|---|---|
| Cold start | ~50-100ms | ~5-20ms |
| Max execution | 60s (hobby) / 300s+ (pro) | 30s wall / 30s CPU |
| Image optim | Built-in, free | Needs Cloudflare Images |
| ISR | Automatic | Needs KV/R2 binding |
| Background jobs | Vercel Cron | Cloudflare Cron Triggers (separate worker) |
| Env vars | Dashboard | `wrangler.jsonc` + `wrangler secret put` |
| Logging | Vercel dashboard | `wrangler tail` |

---

## 7. Cache Components and "use cache"

The new caching model. Mental shift: **everything is request-time by default; caching is opt-in.**

### The basics

```tsx
// app/products/page.tsx
async function getProducts() {
  'use cache'  // function-level
  const db = getDb()
  return db.select().from(productsTable)
}

export default async function ProductsPage() {
  const products = await getProducts()
  return <ProductList products={products} />
}
```

You can also cache at the component level:
```tsx
async function ProductGrid() {
  'use cache'
  // ...
}
```

Or page-level — put `'use cache'` at the top of the page component.

### updateTag vs revalidateTag

- `revalidateTag(tag)` — marks tag as stale; next request rebuilds (lazy)
- `updateTag(tag)` — actively rebuilds and replaces cached value (eager)

```ts
import { revalidateTag, updateTag } from 'next/cache'

// After mutation
await db.insert(projects).values({ ... })
revalidateTag('projects')  // most cases
// or
await updateTag('projects')  // when you need fresh value immediately
```

### Tagging

```tsx
async function getProject(id: string) {
  'use cache'
  cacheTag(`project-${id}`)
  return db.query.projects.findFirst({ where: eq(projects.id, id) })
}
```

### Gotcha: caching pages with auth

Don't `'use cache'` a page that depends on the logged-in user — you'll cache one user's data and serve it to everyone. Cache the data fetching helpers that don't depend on session, and call them from session-aware pages.

### Memory warning (Cloudflare)

Cache Components can double memory usage on cold workers. On Cloudflare's 128MB-ish Worker limit, large caches can OOM. Tune `cacheLife` aggressively or skip caching for big result sets on the Cloudflare deploy.

---

## 8. Turbopack (now default)

`next dev` and `next build` both use Turbopack by default in 16. Fast — 5-10x faster Fast Refresh, 2-5x faster builds.

### Opt back into webpack

```bash
next dev --webpack
next build --webpack
```

### Common Turbopack-specific issues

- **CSS imports must come from `app/` or `src/`** — imports from `node_modules` outside expected paths can fail
- **Custom webpack plugins don't transfer** — `next.config.ts` `webpack: (config) => {...}` is ignored under Turbopack
- **`require()` in client components** — Turbopack is stricter about CJS in ESM contexts; use `import()` instead
- **File system caching** is stable and on by default — clears live in `.next/cache/turbopack/`; delete this dir if you see stale compile errors

If a webpack-only feature is essential, run `--webpack` for that build until you migrate.

---

## 9. React 19 inside Next.js 16

Next 16 ships with React 19.2. Worth knowing:

### View Transitions

```tsx
import { unstable_ViewTransition as ViewTransition } from 'react'

<ViewTransition name="product-card">
  <ProductCard />
</ViewTransition>
```
Smooth animated route changes — great for the dashboard navigation in LearnDE.

### Activity

```tsx
import { unstable_Activity as Activity } from 'react'

<Activity mode={isVisible ? 'visible' : 'hidden'}>
  <ExpensiveComponent />
</Activity>
```
Keeps a subtree mounted but inactive — useful for tab panels where you don't want to lose state.

### useEffectEvent

Stable now. Removes the "stale closure in useEffect" trap:
```tsx
const onMessage = useEffectEvent((message) => {
  // always sees latest props/state
  doSomethingWith(message, props.value)
})

useEffect(() => {
  socket.on('message', onMessage)
  return () => socket.off('message', onMessage)
}, [socket])  // onMessage doesn't need to be in deps
```

### React Compiler (stable)

Built-in. Enable in `next.config.ts`:
```ts
const nextConfig: NextConfig = {
  experimental: { reactCompiler: true },
}
```
Auto-memoizes components and hooks. You can remove most manual `useMemo`/`useCallback` afterwards. Test thoroughly — it occasionally over-memoizes things that shouldn't be cached.

---

## 10. Neon + Drizzle on Next.js 16

Drizzle works identically. Two adjustments:

### Connection — same patterns, but `'use cache'` interacts with queries

A `'use cache'`-marked function that queries Neon will cache the result. Good for read-heavy paths (listing pages). Bad for personalized data — tag it carefully or skip caching.

```ts
async function getRecentLessons() {
  'use cache'
  cacheLife({ revalidate: 60 })  // 60s stale-while-revalidate
  cacheTag('lessons')
  const db = getDb()
  return db.select().from(lessonsTable).orderBy(desc(lessonsTable.createdAt)).limit(20)
}
```

### Migrations — unchanged

```ts
// drizzle.config.ts — same as before
import { defineConfig } from 'drizzle-kit'
export default defineConfig({
  schema: './lib/db/schema.ts',
  out: './drizzle',
  dialect: 'postgresql',
  dbCredentials: { url: process.env.DATABASE_URL_UNPOOLED! },
})
```

Still use `DATABASE_URL_UNPOOLED` for migrations, `DATABASE_URL` (pooled) for app queries.

---

## 11. Quick Reference: Error -> Fix

| Error / Symptom | Cause | Fix |
|---|---|---|
| `cookies() must be awaited` | Sync access to async API | `await cookies()` everywhere |
| `params is not a Promise` | Old sync params pattern | `const { id } = await params` |
| `proxy is not exported` | Function still named `middleware` | Rename `middleware` -> `proxy` |
| Auth works on Vercel, fails on Cloudflare | Missing `nodejs_compat` flag | Add to `wrangler.jsonc` compat flags |
| `Cannot find module 'fs'` on Cloudflare | Compat flag missing OR using next-on-pages | Switch to OpenNext + `nodejs_compat` |
| Build succeeds, deploys 404 on CF | Wrong `main` path in wrangler.jsonc | Should be `.open-next/worker.js` |
| Stale data after mutation | Cache Components caching too aggressively | `revalidateTag()` or `updateTag()` after mutation |
| Logout loop after migration | proxy.ts overwriting Set-Cookie | Return `NextResponse.next()` for pass-through |
| `next lint` not found | Removed in 16 | Use `eslint` or `biome` directly |
| Turbopack fails on webpack-only plugin | Plugin not Turbopack-compatible | Build with `--webpack` until alternative found |
| ISR not working on Cloudflare | No KV/R2 binding | Add `NEXT_CACHE_WORKERS_KV` in wrangler.jsonc |
| Hydration mismatch after upgrade | React 19 strictness | Ensure no `Math.random()`/`Date.now()` in initial render |
| `process is not defined` | Edge runtime + Node API | Set `runtime = 'nodejs'` or move to a Node-runtime route |
| Cache memory OOM on Workers | Cache Components retaining too much | Reduce `cacheLife`, prune tags, or skip caching big sets |
| Auth state lost between requests | Cookie not set with correct `domain`/`path` | Verify Better Auth cookie config matches deployed domain |
| Env var missing on one platform only | Forgot to sync to other dashboard | Mirror env vars in BOTH Vercel and Cloudflare |

---

## 12. Migration Checklist (15 -> 16, dual-deploy)

Run in order:

- [ ] Bump Node to 20.9+ locally; bump runtime in Vercel + Cloudflare project settings
- [ ] Bump TypeScript to 5.1+
- [ ] Run `npx @next/codemod@canary upgrade latest`
- [ ] Run `npx @next/codemod@canary middleware-to-proxy`
- [ ] Run `npx @next/codemod@canary next-async-request-api .`
- [ ] Search codebase for sync `cookies()`/`headers()`/`params`/`searchParams` the codemod missed
- [ ] Remove `export const runtime = 'edge'` from routes that don't need it
- [ ] Refactor auth: move validation OUT of proxy, into DAL helpers (`requireStudent`, `requireStaff`)
- [ ] Add `lint` script (since `next build` no longer lints)
- [ ] If using next-on-pages: uninstall it, install `@opennextjs/cloudflare`, create `open-next.config.ts`, create/migrate `wrangler.jsonc`
- [ ] Set `compatibility_flags: ["nodejs_compat"]` in wrangler.jsonc
- [ ] Set compatibility_date to `2024-09-23` or later
- [ ] Update package.json scripts for OpenNext (`build:cf`, `preview:cf`, `deploy:cf`)
- [ ] Add KV namespace for ISR caching on Cloudflare if you use revalidation
- [ ] Test locally with both `next dev` AND `npm run preview:cf`
- [ ] Verify env vars are mirrored in Vercel AND Cloudflare dashboards
- [ ] Push to a preview branch first; verify both Vercel preview AND Cloudflare preview before merging to main
- [ ] After merge, verify logout/login works end-to-end on BOTH deployments
- [ ] Watch logs for "cookies() must be awaited" and similar in first 24h

---

## 13. File Structure Conventions (Next.js 16)

```
project/
├── app/
│   ├── (auth)/             route groups
│   ├── (student)/          student-facing routes
│   ├── (staff)/            staff-facing routes
│   ├── api/                Route Handlers
│   └── layout.tsx
├── components/
│   ├── ui/
│   └── sections/
├── lib/
│   ├── auth/
│   │   ├── index.ts        Better Auth instance
│   │   └── session.ts      DAL: getSession, requireStudent, requireStaff
│   ├── db/
│   │   ├── index.ts        Neon HTTP (default; works everywhere)
│   │   ├── node.ts         Neon Pool (Node-runtime only)
│   │   └── schema.ts
│   ├── env.ts              build-time env validation
│   └── utils.ts
├── drizzle/                generated migrations
├── drizzle.config.ts
├── proxy.ts                <-- NEW (was middleware.ts)
├── next.config.ts
├── open-next.config.ts     <-- NEW for Cloudflare
├── wrangler.jsonc          <-- NEW for Cloudflare
└── package.json
```

---

## 14. When in doubt

1. Default to Node.js runtime (works on both deploys)
2. Default to Neon HTTP driver (works on both runtimes)
3. Default to `'use cache'` opt-in, not on-by-default
4. Keep auth validation in the DAL, not in proxy.ts
5. Mirror every env var across BOTH platforms
6. Test on Cloudflare preview before every merge to main — Vercel will always work, Cloudflare is where surprises live
