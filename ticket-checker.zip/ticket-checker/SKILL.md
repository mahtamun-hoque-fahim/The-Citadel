---
name: ticket-checker
description: >
  Final pre-deploy QA checklist — fires only at ship time, never mid-build.
  Walks every route, every auth gate, every payment flow, and every API
  endpoint with a mix of automated checks (curl, build, grep) and clearly
  labeled manual steps Fahim runs himself (checkout flows, visual review),
  then produces a DEPLOY TICKET that's either READY TO SHIP or BLOCKED with
  exact reasons. Retrofit mode: always scans the actual codebase and route
  tree first. ALWAYS use when Fahim says "ticket-checker", "ready to deploy",
  "about to ship", "final check before launch", "pre-launch QA", "is this
  ready to go live", "deploy checklist", "pushing to production", or
  "checking the ticket". Do NOT trigger this mid-build or for a routine code
  review — that's valley-of-death's job. This is the last gate before the
  deploy button gets pressed.
---

# Ticket Checker

The last thing that happens before `git push` to production. Not a spec
audit (valley-of-death), not a security audit (sentinel) — a functional
QA pass that asks one question per item: **does this actually work, right
now, the way a user would hit it?**

**Position in Fahim's pipeline:**
```
... → Council POST (GO verdict) → gh-meta → ticket-checker → deploy
```

`gh-meta` runs first: version bump, changelog, GitHub release creation, About sync.
Ticket-checker then verifies the fully-versioned, release-tagged build actually works.

### Recommended preconditions (soft, not a hard gate)

For a **first production launch** or a major version, confirm
`valley-of-death`, `sentinel`, Council POST's GO/CONDITIONAL GO, and
`gh-meta` (version bumped, GitHub release created) have already run —
ticket-checker assumes the spec-compliance, security, and versioning work
is done and focuses purely on "does it function."

For a **routine update or hotfix** to something already shipped, running the
full pipeline every time is overkill. Ticket-checker works standalone in
that case — scope it to what changed.

### Automated vs. Manual — read this before running

Some of what's below, Claude can check directly (`curl`, `npm run build`,
`grep`). Some of it genuinely can't be verified without a human clicking
through a real checkout or eyeballing a rendered page — Lemon Squeezy test
purchases need a real card-entry interaction, and "does this look right"
needs eyes. Every section below is split into **Automated** (Claude runs it
now) and **Manual** (Claude gives Fahim the exact steps, Fahim runs them,
Fahim reports the result back). Never report a manual item as passing
without Fahim's confirmation — guessing "this probably works" defeats the
entire point of a ship-time gate.

If a browser-automation tool (Claude in Chrome or similar) is connected in
the session, manual visual/click-through items can run through it instead
of by hand — offer this, don't assume it.

---

## Phase 0 — Retrofit Scan (always runs first)

```bash
# 1. Full doc context
cat BRAIN.md 2>/dev/null
cat PLANNER.md
cat DESIGN_GUIDE.md 2>/dev/null

# 2. Enumerate every route
find app -name "page.tsx" | sort

# 3. Enumerate every API route
find app/api -name "route.ts" | sort

# 4. Find the auth gate config
cat proxy.ts 2>/dev/null || cat middleware.ts 2>/dev/null

# 5. Detect payment integration (same signal sentinel uses)
grep -rl "X-Signature\|lemonsqueezy\|lemon-squeezy" app/api --include="*.ts" 2>/dev/null

# 6. Confirm a dev server is reachable, start one if not
curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/ || (npm run dev & sleep 5)
```

### Scan summary format

```
TICKET CHECKER — [Project] — [date]
─────────────────────────────────────────
ROUTES    : N pages found
API       : N route handlers found
AUTH GATE : proxy.ts/middleware.ts [found/missing] — N paths in matcher
PAYMENTS  : Lemon Squeezy [detected/not detected]
DEV SERVER: [reachable/started/unreachable]
─────────────────────────────────────────
Running sections: A, B, [C if payments detected], D, E, F
```

---

## A — Routes

**Automated**
1. For every page found in the scan, `curl -s -o /dev/null -w "%{http_code}"`
   it — every public route should return `200`. A `404`/`500` on a route
   that's supposed to exist is BLOCKED, not a warning.
2. For every dynamic route segment (`[id]`, `[slug]`), hit it with an
   obviously-invalid value and confirm a clean 404 response, not a 500 —
   an unhandled lookup miss crashing instead of rendering `not-found.tsx`
   is a common gap.
3. Confirm `loading.tsx` and/or `error.tsx` exist alongside any route that
   fetches data server-side — their absence isn't always BLOCKED, but flag
   it (a slow query with no loading state reads as a frozen page).

**Manual**
4. Open each route in a real browser. Confirm it renders the expected
   content — not a blank shell, not a hydration-mismatch warning in the
   console. A 200 status code with a broken render still fails this check.
5. Resize to a phone width on at least the homepage and one core feature
   page — layout shouldn't collapse or clip.

---

## B — Auth Gates

**Automated**
1. `curl` every protected route **without** a session cookie — expect a
   redirect (`302`/`307`) to the sign-in page, not `200`. A protected page
   that returns its real content to an unauthenticated request is CRITICAL
   and BLOCKED — ship-stopping, not a nitpick.
2. Cross-check the auth gate's `matcher` config against the full route list
   from Phase 0 — every path that should be protected actually appears in
   it, including nested paths (`/admin` without `/admin/:path*` only
   catches the exact route).

**Manual**
3. Sign in as a real test account, confirm every protected route now
   renders correctly.
4. Sign out, then try to revisit a protected route directly (not via
   in-app nav) — confirm it redirects again immediately, not a flash of
   stale content before redirecting.
5. If roles exist, sign in as a lower-privilege account and confirm
   role-gated routes/actions are blocked, not just visually hidden.

---

## C — Payment Flows (Lemon Squeezy)
*Runs only if Phase 0 detected a Lemon Squeezy webhook route.*

This checks that the flow **works**, not that it's secure — sentinel
already covers signature verification, raw-body handling, and idempotency.
Here the question is purely: does a real checkout actually grant access.

**Automated**
1. `curl` the webhook endpoint with no `X-Signature` header — expect `401`,
   confirming the rejection sentinel verified structurally also holds
   functionally.
2. Time the webhook response (`curl -w "%{time_total}"`). Lemon Squeezy
   retries on slow/non-2xx responses — a handler doing heavy synchronous
   work before responding risks duplicate retries even when the logic is
   correct.

**Manual**
3. Switch the Lemon Squeezy dashboard to test mode if it isn't already.
4. Run a full checkout using the success test card `4242 4242 4242 4242`,
   any future expiry date, any 3-digit CVC. Confirm: the webhook fires
   (check the Lemon Squeezy dashboard's webhook log), the entitlement is
   actually granted in the DB, and the UI reflects the upgraded state
   without a manual refresh-and-pray.
5. Run a decline scenario — check
   `docs.lemonsqueezy.com/help/getting-started/test-mode` for the current
   decline test card, since the exact number has changed before. Confirm
   no entitlement is granted and the user sees a clear, non-scary error.
6. If subscriptions are involved, test cancellation — confirm the webhook
   revokes the entitlement on the correct schedule (immediately vs. end of
   billing period, whichever the business logic intends).

---

## D — API Endpoints

**Automated**
1. For every `route.ts` found in Phase 0, send a malformed or empty body
   to any handler expecting one — expect `400`, not an unhandled `500`.
2. For every handler that should require auth, `curl` it without a session
   — expect `401`/`403`, not the real response.
3. For any rate-limited endpoint, fire requests past the configured
   threshold in a tight loop — confirm a `429` actually shows up, not just
   that the limiter is present in code (sentinel checked the code; this
   checks the behavior).
4. Spot-check that response status codes are meaningful across the board —
   a route that returns `200` with `{ error: "..." }` in the body instead
   of a real `4xx`/`5xx` status makes client-side error handling unreliable.

**Manual**
5. Anything stateful and hard to script cleanly (file upload endpoints,
   multi-step flows) — exercise it once by hand and confirm the response.

---

## E — Deployment Configuration

**Automated**
1. `npm run build` — must exit `0`. A build that only works in dev mode is
   not shippable.
2. Diff every `process.env.X` reference in the codebase against
   `.env.example` — anything referenced but undocumented there is a future
   "works on my machine" bug waiting to happen.
3. If the project deploys to both Vercel and Cloudflare, confirm
   `wrangler.jsonc` / `open-next.config.ts` exist and aren't stale relative
   to the current route set.

**Manual**
4. Confirm every required env var is actually set in the Vercel dashboard
   across Production, Preview, *and* Development — Claude can't see the
   dashboard, this has to be eyeballed. Missing-at-build-time env vars fail
   silently as `undefined`, not as a build error.
5. Same check for Cloudflare secrets if dual-deployed.
6. If a custom domain is involved, confirm it resolves and SSL is valid.

---

## F — Final Smoke Test & Sign-off

**Manual — walk this end to end as a real user would**
1. Full happy path in one sitting: sign up → do the core action the
   product exists for → sign out → sign back in → confirm state persisted.
2. Visit a nonexistent route — confirm a real, on-brand 404 page, not the
   framework default.
3. Favicon and Open Graph image are both present (check a link preview,
   not just the file existing in `/public`).
4. Open the browser console on the homepage and one core feature page —
   confirm no red errors. Warnings are a judgment call; errors are not.

---

## Deliverable Format

```
DEPLOY TICKET — [Project Name] — [Date]
═══════════════════════════════════════════════════════
SCOPE: N routes · N auth gates · [N payment flows ·] N API endpoints

[x] A. ROUTES                  N/N passed
[x] B. AUTH GATES               N/N passed
[~] C. PAYMENT FLOWS            N/N passed — 1 awaiting manual confirm
[ ] D. API ENDPOINTS            not yet run
[x] E. DEPLOYMENT CONFIG        N/N passed
[ ] F. FINAL SMOKE TEST         not yet run

─────────────────────────────────────────────────────────
BLOCKED — must resolve before shipping
─────────────────────────────────────────────────────────
  1. [B2] /admin/users — unauthenticated request returns 200
     instead of redirect. app/admin/users/page.tsx:1 — missing
     server-side session check.
  ...

─────────────────────────────────────────────────────────
AWAITING MANUAL CONFIRMATION
─────────────────────────────────────────────────────────
  - C4: Run the success-card checkout, confirm entitlement grant.
  ...

═══════════════════════════════════════════════════════
STATUS: BLOCKED  /  READY TO SHIP
═══════════════════════════════════════════════════════
```

`STATUS` only reads **READY TO SHIP** when every section is `[x]` and the
BLOCKED list is empty. A single unresolved CRITICAL item keeps the whole
ticket BLOCKED regardless of how many other sections passed.

---

## Operating Rules

- **No status is reported without evidence.** An automated check needs the
  actual `curl`/build output; a manual check needs Fahim's explicit
  confirmation, not an assumption that it's "probably fine."
- **Manual items stay open until confirmed.** Never mark a manual checklist
  item `[x]` on Claude's own judgment — it goes in "Awaiting Manual
  Confirmation" until Fahim reports back.
- **BLOCKED beats everything.** One CRITICAL finding (auth bypass, broken
  payment grant, build failure) keeps `STATUS: BLOCKED` even if 50 other
  checks passed.
- **Ship-time only.** If this gets invoked mid-build, say so — point to
  valley-of-death for a mid-build spec check instead, and ask whether the
  project is actually ready for a final pass.
- **Don't re-litigate security.** If sentinel already confirmed signature
  verification or auth config, ticket-checker checks that the *behavior*
  matches, not the code structure again — different angle, not duplicate
  work.
- **Scope to what changed, for routine updates.** A hotfix doesn't need
  every route re-walked — confirm the changed surface plus the smoke test
  in Section F.

---

## Relationship to other skills

| Skill | Relation to ticket-checker |
|---|---|
| **valley-of-death** | Spec-vs-code, runs earlier. Ticket-checker doesn't re-check spec compliance — it checks live behavior. |
| **sentinel** | Security structure, runs earlier. Ticket-checker's payment/auth checks confirm sentinel's findings hold up in actual behavior, not just in code. |
| **council** | POST-BUILD GO verdict happens before ticket-checker — ticket-checker is the literal last gate after Council has already said yes. |
| **gh-meta** | Runs immediately before ticket-checker. gh-meta owns version bump, changelog, GitHub release creation, and About sync. Ticket-checker verifies one item: "gh-meta ran, version bumped, release created" — if not, BLOCKED. |
| **task-planner** | If ticket-checker finds BLOCKED items, task-planner can turn the BLOCKED list into atomic fix tasks before re-running. |
