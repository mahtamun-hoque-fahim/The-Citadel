# Extended Error Lookup

Search this file by error text when SKILL.md's short table didn't cover it.
Grouped by category.

## Build Errors

### `Module not found: Can't resolve 'fs'` (or 'net', 'tls', 'child_process', etc.)
**Where**: Cloudflare next-on-pages build
**Cause**: A dep is importing Node built-ins inside code that's bundled for Edge
**Diagnosis**:
```sh
pnpm why <suspect-package>   # find what brought it in
```
Common culprits: older versions of `pg`, `bcrypt`, `sharp`, `nodemailer`, anything that calls `fs.readFile` at module top level.
**Fix**:
- Replace with Edge-compatible alternative (`@neondatabase/serverless` for `pg`, `bcryptjs` for `bcrypt`, etc.)
- Or move the route to OpenNext with `nodejs_compat`
- Or isolate to a `runtime = 'nodejs'` route on Vercel and skip that route on Cloudflare

### `Type error: Property 'X' does not exist on type 'Promise<{...}>'`
**Where**: TypeScript build, any platform
**Cause**: Forgot to `await` an async API in Next.js 15
**Fix**: Add `await` - covered in `nextjs15-migration.md` section 1

### `ESLint: Parsing error: ...`
**Where**: Any build
**Cause**: `eslint.config.mjs` (flat) and `.eslintrc.*` both present
**Fix**: Delete one. Use flat config (`eslint.config.mjs`) for Next.js 15.

### `Error: Failed to load next.config.js`
**Where**: Any build
**Cause**: Often a typo or invalid TS in `next.config.ts`, or a missing dep referenced in it
**Fix**: Run `node -e "require('./next.config.js')"` (or `tsx next.config.ts`) locally to surface the real error

### `Worker exceeded resource limits` / bundle too large
**Where**: `wrangler deploy` output
**Cause**: Compressed bundle > 3 MiB (free) or 10 MiB (paid)
**Diagnosis**:
```sh
wrangler deploy --dry-run --outdir=./dist
du -sh dist/*
```
**Fix**:
- Tree-shake (`import _ from 'lodash'` -> `import get from 'lodash/get'`)
- Move heavy server-only deps off the request path
- Audit `node_modules` for accidentally-bundled large libs
- Use dynamic imports for code paths used in few requests

### `Compatibility date must be 2024-09-23 or later`
**Where**: OpenNext build
**Cause**: `wrangler.toml` compat date too old
**Fix**: Update `compatibility_date = "2024-09-23"` minimum

### `nodejs_compat flag is required`
**Where**: OpenNext build or runtime
**Fix**: Add to `wrangler.toml`:
```toml
compatibility_flags = ["nodejs_compat"]
```
For Pages, set the flag in dashboard under Settings -> Functions -> Compatibility flags, for both Production and Preview environments.

---

## Runtime Errors

### `ReferenceError: process is not defined`
**Where**: Cloudflare Edge runtime, sometimes Vercel Edge Functions
**Cause**: Trying to access `process` in pure Edge runtime (no Node compat)
**Fix**:
- Use `globalThis.process?.env?.X` defensively, or
- Move to OpenNext with `nodejs_compat`, or
- Use platform-specific binding access (`getRequestContext().env.X`)

### `connect ECONNREFUSED` to a database
**Where**: Cloudflare Edge runtime
**Cause**: Using a TCP-based driver (`pg`, `mysql2`) on Edge
**Fix**: Switch to HTTP-based driver (`@neondatabase/serverless`, `@planetscale/database`)

### `cookies() was called outside a request scope`
**Where**: Both platforms
**Cause**: Calling `cookies()` in a module top-level or in a Client Component
**Fix**: Only call inside Server Components, Route Handlers, Server Actions, or middleware

### Hydration mismatch warnings in browser console
**Common causes** (check each):
- Browser extension injects DOM (Grammarly, dark-mode extensions, etc.) -> `<html suppressHydrationWarning>` on the `<html>` element
- `Date.now()` or `Math.random()` in render -> compute in `useEffect` or pass from server
- Different locale/timezone server vs client -> use `Intl` with explicit locale, or render dates inside a Client Component
- Conditional rendering based on `typeof window !== 'undefined'` -> use `useEffect` instead

### `Error: Dynamic server usage: cookies` during build
**Where**: Vercel or Cloudflare build, when statically generating
**Cause**: A page used `cookies()` but Next.js tried to statically render it
**Fix**: Mark the page dynamic:
```ts
export const dynamic = 'force-dynamic'
```
Or refactor to read cookies only in a Server Action or Route Handler that's reached on demand.

### `FUNCTION_INVOCATION_TIMEOUT` (Vercel)
**Cause**: Request exceeded plan's max duration
**Fix**:
- For LLM/long generation: stream the response (works as long as chunks keep flowing)
- For batch work: queue with a background system (Inngest, Trigger, QStash)
- For data export: paginate or generate offline and link

### Cookies not being set after Server Action
**Common cause**: Mutating cookies in a Server Action without calling `revalidatePath` or `redirect`. Next.js needs a navigation trigger to flush the Set-Cookie header in some cases.
**Fix**: End the action with `redirect('/somewhere')` or `revalidatePath('/...')`. If you can't navigate, return a value and trigger a router refresh client-side:
```tsx
'use client'
import { useRouter } from 'next/navigation'
const router = useRouter()
// After action completes:
router.refresh()
```

### `getRequestContext()` / `getCloudflareContext()` returns undefined
**Where**: Cloudflare local dev under `next dev`
**Cause**: `setupDevPlatform()` (next-on-pages) or `initOpenNextCloudflareForDev()` (OpenNext) not called in `next.config`
**Fix**: Add the appropriate init call. See `cloudflare-deploy.md` sections 2-3.

### `Cannot read properties of undefined (reading 'get')` on `params`
**Where**: Next.js 15
**Cause**: Tried `params.id` when `params` is now a Promise
**Fix**: `const { id } = await params`

### Middleware redirects in a loop
**Common causes**:
- Matcher includes the redirect target (e.g. matcher `/:path*` redirects to `/login` which then matches `/:path*` again)
- Cookie set in middleware doesn't propagate to the redirected request (`NextResponse.redirect` should be returned, not navigated to)
**Fix**: Exclude the auth route from the matcher:
```ts
export const config = {
  matcher: ['/((?!login|api|_next/static|_next/image|favicon.ico).*)'],
}
```

### Fetch always returns stale or always returns fresh after upgrade to v15
**Cause**: Default cache behavior flipped to `no-store`
**Fix**: Add explicit cache option:
```ts
fetch(url, { cache: 'force-cache' })            // always cache
fetch(url, { next: { revalidate: 60 } })        // ISR-style
fetch(url, { next: { tags: ['posts'] } })       // tag-based
```

---

## Deploy/CI Errors

### Vercel: build OK, Preview deploy throws `X is undefined` for an env var
**Cause**: Env var added only to Production scope
**Fix**: Add to Preview scope in Vercel dashboard

### Cloudflare: build OK on push, then fails on next push with same code
**Common causes**:
- Cloudflare upgraded their build image and broke a dep
- A peer dep released a breaking minor without proper version bound
**Fix**: Pin Node version in `package.json` `engines` field and commit `pnpm-lock.yaml` / `package-lock.json`. Use the build image override in Cloudflare settings if needed.

### `Error: ENOENT: no such file or directory, open './data.json'`
**Where**: Runtime, often Cloudflare
**Cause**: Trying to `fs.readFile` at runtime; the file isn't in the bundle
**Fix**: Import as a module so it's bundled at build:
```ts
import data from './data.json' // bundled, no fs needed
```
If the file is too large to bundle, store in R2 / Blob and fetch at runtime.

### `Error: ERR_REQUIRE_ESM`
**Cause**: Mixing CommonJS and ESM, often a dep that went ESM-only
**Fix**: Update Next.js config to ESM (`next.config.mjs` or `next.config.ts`), or pin the dep to the last CJS version. Node 20+ handles most of this gracefully in Next.js builds, but some setups still hit it.

---

## React 19 / Hydration

### `Error: Hydration failed because the server rendered HTML didn't match the client`
Most common causes in order of frequency:
1. Browser extension injecting markup -> `suppressHydrationWarning` on `<html>`
2. Time-based output (`new Date().toLocaleString()`) -> render in `useEffect`
3. Locale-based output without explicit locale
4. Conditional render based on `typeof window`
5. Whitespace or text nodes around interpolated values (rare, usually a Prettier/format issue)

### `useFormState is deprecated`
**Fix**: Rename to `useActionState`:
```ts
// Before
import { useFormState } from 'react-dom'
const [state, action] = useFormState(fn, initialState)

// After
import { useActionState } from 'react'
const [state, action, isPending] = useActionState(fn, initialState)
```

### `forwardRef` warnings under React 19
React 19 lets function components accept `ref` as a normal prop. Most
`forwardRef` calls still work, but library code that does `ref.current` on
a Server Component reference will error.
**Fix**: Migrate component to accept `ref` directly, drop `forwardRef`.

---

## Database / Drizzle

### `relation "X" does not exist`
**Cause**: Migration not applied to the target Neon branch
**Fix**:
```sh
DATABASE_URL_UNPOOLED=... pnpm drizzle-kit migrate
```
Note: migrations use the **unpooled** URL, not the pooled one.

### `too many connections for role`
**Cause**: Code is using `DATABASE_URL_UNPOOLED` (direct) for app queries
**Fix**: App code should use `DATABASE_URL` (pooled). Only migrations use unpooled.

### Drizzle types out of sync with DB
**Cause**: Schema file edited but migration not generated/applied
**Fix**:
```sh
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```
Then restart TS server in your editor.

### `SSL required` on Neon connection
**Fix**: Add `?sslmode=require` to the connection string

---

## When None of This Helps

If the error doesn't match anything here and you've walked the diagnostic
protocol in SKILL.md section 0:

1. Get the **exact** error text and line number, not a paraphrase
2. Reproduce locally if possible (`wrangler dev` for Cloudflare, `next dev` for Vercel)
3. Check the changelog for the Next.js version, the Cloudflare adapter version, and any major dep that bumped recently
4. If it's a Cloudflare-only issue, `wrangler tail` gives the deployed Worker's runtime logs in real time
5. Post the diagnostic protocol answers (Where? Which platform? Which runtime? v15 breaking change?) along with the error - this alone resolves most cases without further code reading
