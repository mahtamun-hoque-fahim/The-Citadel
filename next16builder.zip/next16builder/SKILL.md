---
name: next16builder
description: >
  Authoritative blueprint for building Next.js 16 / 16.x projects end-to-end
  without runtime crashes. ALWAYS use this skill when starting a new Next.js
  project, scaffolding pages, writing Server Components, Server Actions,
  Route Handlers, layouts, params/searchParams handlers, cookies/headers
  access, proxy (formerly middleware), next/image usage, caching with
  revalidateTag / updateTag / refresh, Cache Components / PPR, or
  configuring next.config for Turbopack. Also use proactively for ANY task
  in a Next.js 16+ codebase, even when the user does not say "Next.js 16"
  explicitly — because the v15→v16 breaking changes (fully async request
  APIs, middleware→proxy rename, revalidateTag signature, image defaults,
  parallel route default.js requirement, removed runtime config) cause
  silent failures that only surface at runtime. This skill encodes the
  decision patterns Opus uses so lower-capability models can ship Next.js
  16 code that builds, types, and runs on the first try.
---

# Next16Builder

A precision blueprint for building Next.js 16 projects. Every rule here exists because the v15 → v16 breaking changes cause **silent runtime crashes** if followed by muscle memory from older versions. Read top-to-bottom on first use; thereafter, jump to the section that matches the task.

**Stack assumed (Fahim's defaults):** Next.js 16 App Router · TypeScript · Tailwind v4 · Neon (PostgreSQL) · Drizzle ORM · Better Auth · Vercel.

**Hard rule:** No emojis anywhere in generated code, UI text, commit messages, or documentation.

---

## 0. The Opus Mental Model (read this first)

Lower-capability models fail at Next.js 16 for **four reasons**. Internalize these before writing any code.

1. **Async-everything.** In v16, `cookies()`, `headers()`, `draftMode()`, `params`, and `searchParams` are **Promises**. Synchronous access is fully removed (no warning — it throws). If you write `const { slug } = params`, the build types may pass but it crashes at runtime. **Always `await`.**
2. **Turbopack is the default builder.** No `--turbopack` flag needed. A custom `webpack` config in `next.config` **fails the build** unless you explicitly opt out with `next build --webpack`.
3. **`middleware.ts` is renamed to `proxy.ts`.** The edge runtime is **not** supported in proxy. If you need edge, keep using middleware (deprecated path).
4. **Cache primitives changed shape.** `revalidateTag('x')` is deprecated — use `revalidateTag('x', 'max')` or the new `updateTag('x')` (Server Actions only, read-your-writes). PPR's `experimental_ppr` segment flag is gone; opt in with top-level `cacheComponents: true`.

**The decision tree for every file you write:**

```
Am I writing a page/layout/route file?
   ├─ Does it read params / searchParams?            → mark function `async`, `await` them
   ├─ Does it call cookies() / headers() / draftMode()? → mark function `async`, `await` them
   └─ Does it have a parallel route slot (@modal etc)? → create default.js (notFound() or null)

Am I writing a component?
   ├─ Does it use useState / useEffect / onClick / browser API? → 'use client' at top
   └─ Otherwise → leave it as a Server Component (default), make it async if it fetches

Am I writing a Server Action?
   ├─ 'use server' at top of file OR inline at top of function
   ├─ Mutation that user must see immediately?       → updateTag('tag')
   ├─ Mutation where stale-while-revalidate is OK?   → revalidateTag('tag', 'max')
   └─ Just need to refresh client router?            → refresh()

Am I writing request-intercepting logic (auth, redirects, rewrites)?
   ├─ Node runtime OK?       → proxy.ts (the new default)
   └─ Need edge runtime?     → middleware.ts (deprecated but still works for now)
```

---

## 1. Pre-flight (do this before any other action)

When the user asks you to build, modify, or debug a Next.js project, **verify these first**. Do not skip.

```bash
node --version              # must be >= 20.9.0 (v18 unsupported)
cat package.json | grep '"next"'    # check version
cat package.json | grep '"react"'   # must be 19.x for App Router
```

| Check | Required | If wrong |
|---|---|---|
| Node.js | `>= 20.9.0` (LTS) | Tell user to upgrade Node; v18 is no longer supported in Next 16 |
| TypeScript | `>= 5.1.0` | `npm install -D typescript@latest` |
| React | `19.x` (matches Next 16 canary track) | `npm install react@latest react-dom@latest` |
| `next` package | `16.x` | `npm install next@latest` |
| `package.json` scripts | `next dev` / `next build` (no `--turbopack` flag) | Remove the flag; Turbopack is default |
| `next.config` | `turbopack` at top level, **not** under `experimental` | Move `experimental.turbopack` → `turbopack` |

If `next.config` has a `webpack` function and you're on v16, **the build will fail**. Either remove the webpack config, migrate to Turbopack equivalents, or add `--webpack` to the build script.

---

## 2. New Project Bootstrap

Use this exact sequence. Do not skip any step.

```bash
# 1. Create
npx create-next-app@latest my-app \
  --typescript --tailwind --app --src-dir --import-alias "@/*" --use-npm

cd my-app

# 2. Verify it's v16
cat package.json | grep '"next"'
# Should show: "next": "16.x.x"

# 3. Run typegen to get PageProps / LayoutProps / RouteContext helpers
npx next typegen

# 4. Install Fahim's standard stack
npm install drizzle-orm @neondatabase/serverless
npm install -D drizzle-kit
npm install better-auth

# 5. (Optional) Enable React Compiler — stable in v16
npm install -D babel-plugin-react-compiler
```

Then in `next.config.ts`:

```ts
import type { NextConfig } from 'next'

const nextConfig: NextConfig = {
  // React Compiler (stable in v16, not enabled by default)
  reactCompiler: true,

  // PPR successor — opt into Cache Components if needed
  // cacheComponents: true,

  images: {
    // images.domains is DEPRECATED — use remotePatterns
    remotePatterns: [
      { protocol: 'https', hostname: 'example.com' },
    ],
  },

  // If you have custom turbopack config, it's now top-level (was experimental)
  // turbopack: { ... },
}

export default nextConfig
```

**Update `package.json` scripts:**

```json
{
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "typegen": "next typegen"
  }
}
```

Do NOT include `--turbopack` (it's the default) and do NOT include `next lint` (that command was removed in v16; use `eslint` or `biome` directly).

---

## 3. The Async Request APIs (most common runtime crash)

**Every single file** that touches `params`, `searchParams`, `cookies()`, `headers()`, or `draftMode()` must be `async` and `await` them. There is no synchronous escape hatch in v16.

### 3.1 Pages with dynamic segments

Use the global `PageProps<'/route'>` helper generated by `next typegen`. It is type-safe and idiomatic for v16.

```tsx
// app/blog/[slug]/page.tsx
export default async function BlogPost(props: PageProps<'/blog/[slug]'>) {
  const { slug } = await props.params
  const { ref } = await props.searchParams
  return <article>Post: {slug} (ref: {ref ?? 'none'})</article>
}
```

If you cannot use `PageProps`, type manually as `Promise`:

```tsx
export default async function BlogPost({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>
  searchParams: Promise<{ ref?: string }>
}) {
  const { slug } = await params
  const { ref } = await searchParams
  // ...
}
```

### 3.2 Layouts

```tsx
// app/dashboard/[orgId]/layout.tsx
export default async function OrgLayout(props: LayoutProps<'/dashboard/[orgId]'>) {
  const { orgId } = await props.params
  return <div>{props.children}</div>
}
```

### 3.3 Route Handlers

```tsx
// app/api/posts/[id]/route.ts
export async function GET(req: Request, ctx: RouteContext<'/api/posts/[id]'>) {
  const { id } = await ctx.params
  return Response.json({ id })
}
```

### 3.4 cookies / headers / draftMode

These return Promises. Always `await`.

```ts
import { cookies, headers, draftMode } from 'next/headers'

export default async function Page() {
  const cookieStore = await cookies()
  const token = cookieStore.get('session')?.value

  const h = await headers()
  const ua = h.get('user-agent')

  const draft = await draftMode()
  if (draft.isEnabled) { /* ... */ }

  return <div>token: {token}</div>
}
```

To set a cookie (only in Server Actions or Route Handlers):

```ts
'use server'
import { cookies } from 'next/headers'

export async function login(formData: FormData) {
  const cookieStore = await cookies()
  cookieStore.set('session', 'value', { httpOnly: true, secure: true, sameSite: 'lax' })
}
```

### 3.5 Metadata generation also async-aware

```tsx
// app/blog/[slug]/page.tsx
export async function generateMetadata(props: PageProps<'/blog/[slug]'>) {
  const { slug } = await props.params
  return { title: `Post: ${slug}` }
}
```

### 3.6 Image generation functions (opengraph-image, icon, etc.)

```tsx
// app/[locale]/opengraph-image.tsx
export async function generateImageMetadata({ params }: { params: { locale: string } }) {
  // generateImageMetadata STILL gets sync params
  return [{ id: '1' }, { id: '2' }]
}

// But the image function itself gets async params AND async id
export default async function Image({
  params,
  id,
}: {
  params: Promise<{ locale: string }>
  id: Promise<string>
}) {
  const { locale } = await params
  const imageId = await id
  // ...
}
```

### 3.7 sitemap id parameter

```tsx
// app/product/sitemap.ts
export async function generateSitemaps() {
  return [{ id: 0 }, { id: 1 }]
}

export default async function sitemap({ id }: { id: Promise<string> }) {
  const resolvedId = await id
  const start = Number(resolvedId) * 50000
  // ...
}
```

---

## 4. Server vs Client Components — strict rules

| Marker | Where it goes | What's allowed | What's NOT allowed |
|---|---|---|---|
| (none, default) | Server Component | `async`/`await`, direct DB calls, `cookies()`, `headers()`, server-only imports | `useState`, `useEffect`, `onClick`, browser APIs |
| `'use client'` (top of file) | Client Component | hooks, event handlers, browser APIs | direct DB access, server-only modules |
| `'use server'` (top of file or function) | Server Action | runs on server, callable from client | direct rendering output |

**Decision rule for new components:** start as Server Component. Add `'use client'` **only** when you need at least one of: `useState`, `useEffect`, `useReducer`, `useContext`, event handlers (`onClick`, `onChange`), `useRouter`, browser APIs (`window`, `localStorage`).

**Forbidden patterns:**
- Importing a Server Component into a Client Component (breaks the boundary). Pass it as `children` prop instead.
- Calling `cookies()` / `headers()` inside a Client Component (it does not exist there).
- Putting `'use client'` on a layout that does not need it (forces all children into the client bundle).

---

## 5. Caching APIs — decision tree

Three APIs, three jobs. Pick the right one or users see stale data.

### 5.1 `updateTag(tag)` — read-your-writes (Server Actions only)

User just submitted a form and must see the change **immediately**. Same request expires and refreshes data.

```ts
'use server'
import { updateTag } from 'next/cache'

export async function updateProfile(userId: string, data: ProfileInput) {
  await db.users.update(userId, data)
  updateTag(`user-${userId}`)  // user sees fresh data on next render
}
```

Use for: settings forms, profile edits, anything where a user expects "I just changed it, where is it?"

### 5.2 `revalidateTag(tag, profile)` — stale-while-revalidate

Background marker for "this cache key is stale." Other readers see stale content briefly while fresh data loads.

```ts
'use server'
import { revalidateTag } from 'next/cache'

export async function publishPost(postId: string) {
  await db.posts.publish(postId)
  revalidateTag('posts', 'max')   // NOTE: second arg is REQUIRED in v16
}
```

`revalidateTag('posts')` (one argument) is **deprecated and emits a TS error**. The second arg is a `cacheLife` profile name: `'max'`, `'hours'`, `'minutes'`, `'seconds'`, or a custom profile defined in `next.config`.

Use for: blog posts, product catalogs, anything where slight delay is acceptable.

### 5.3 `refresh()` — refresh client router from Server Action

Pulls latest data into client without expiring server cache. Use after writes where you want the UI to re-fetch but not invalidate the underlying cache tag.

```ts
'use server'
import { refresh } from 'next/cache'

export async function markAsRead(id: string) {
  await db.notifications.markRead(id)
  refresh()
}
```

### 5.4 `cacheLife` and `cacheTag` — now stable

```ts
// Before (v15):
import { unstable_cacheLife as cacheLife, unstable_cacheTag as cacheTag } from 'next/cache'

// After (v16):
import { cacheLife, cacheTag } from 'next/cache'
```

---

## 6. `proxy.ts` (formerly `middleware.ts`)

Rename `middleware.ts` to `proxy.ts`. Rename the exported function from `middleware` to `proxy`.

```ts
// proxy.ts
import { NextRequest, NextResponse } from 'next/server'

export function proxy(request: NextRequest) {
  const token = request.cookies.get('session')?.value
  if (!token && request.nextUrl.pathname.startsWith('/dashboard')) {
    return NextResponse.redirect(new URL('/login', request.url))
  }
  return NextResponse.next()
}

export const config = {
  matcher: ['/dashboard/:path*', '/admin/:path*'],
}
```

**Key constraints:**
- Runtime is **Node.js**. The edge runtime is NOT supported in `proxy`. If you need edge, keep using `middleware.ts` (deprecated, still works).
- Config keys with `middleware` in the name were renamed: `skipMiddlewareUrlNormalize` → `skipProxyUrlNormalize`.
- Inside `proxy`, do NOT `await cookies()` from `next/headers` — use `request.cookies` (sync) from the `NextRequest` object.

---

## 7. `next/image` — new defaults that break old code

| Setting | v15 default | v16 default | Action if you need the old behavior |
|---|---|---|---|
| `minimumCacheTTL` | 60s | 4 hours (14400s) | Set `images.minimumCacheTTL: 60` in config |
| `imageSizes` | includes `16` | `16` removed | Add `16` back to `imageSizes` array |
| `qualities` | all allowed | only `[75]` | Set `images.qualities: [50, 75, 100]` |
| Local image with `?query=` | allowed | requires `localPatterns.search` | Add `localPatterns` entry |
| `maximumRedirects` | unlimited | 3 | Set explicitly if you need more |
| Local IP optimization | allowed | blocked | Set `dangerouslyAllowLocalIP: true` (private networks only) |
| `images.domains` | works | **deprecated** | Migrate to `images.remotePatterns` |
| `next/legacy/image` | works | **deprecated** | Switch to `next/image` |

Example for a real project:

```ts
// next.config.ts
const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'cdn.example.com' },
    ],
    qualities: [50, 75, 100],         // if you use non-75 quality anywhere
    minimumCacheTTL: 3600,            // 1 hour if 4 hours is too long
  },
}
```

---

## 8. Parallel Routes — `default.js` is now required

Every parallel slot (`@modal`, `@side`, etc.) **must** have a `default.tsx`. Builds fail without it.

```tsx
// app/@modal/default.tsx
export default function Default() {
  return null
}
```

Or call `notFound()` if the slot should 404 when unmatched:

```tsx
import { notFound } from 'next/navigation'
export default function Default() {
  notFound()
}
```

---

## 9. Cache Components (PPR successor)

If the user asks for Partial Prerendering, the v16 path is **Cache Components**, not `experimental_ppr`. The old segment-level `experimental_ppr` flag has been removed.

```ts
// next.config.ts
const nextConfig: NextConfig = {
  cacheComponents: true,
}
```

Then mark dynamic boundaries with `<Suspense>`:

```tsx
import { Suspense } from 'react'
import { cookies } from 'next/headers'

async function UserGreeting() {
  const c = await cookies()
  const name = c.get('name')?.value ?? 'friend'
  return <p>Hello, {name}</p>
}

export default function Page() {
  return (
    <main>
      <h1>Welcome</h1>
      <Suspense fallback={<p>Loading...</p>}>
        <UserGreeting />
      </Suspense>
    </main>
  )
}
```

Static shell renders ahead; dynamic part streams in. Note: `experimental.dynamicIO` and `experimental.useCache` flags are removed — they're folded into `cacheComponents`.

---

## 10. Stack integration

### 10.1 Neon + Drizzle (Edge-safe driver)

```ts
// lib/db/index.ts
import { neon } from '@neondatabase/serverless'
import { drizzle } from 'drizzle-orm/neon-http'
import * as schema from './schema'

export function getDb() {
  if (!process.env.DATABASE_URL) return null as any
  return drizzle(neon(process.env.DATABASE_URL), { schema })
}
```

```ts
// drizzle.config.ts
import { defineConfig } from 'drizzle-kit'

export default defineConfig({
  schema: './src/lib/db/schema.ts',
  out: './drizzle',
  dialect: 'postgresql',
  dbCredentials: { url: process.env.DATABASE_URL_UNPOOLED! },
})
```

**Env vars (Neon dashboard provides both):**
- `DATABASE_URL` — pooled, use for app code
- `DATABASE_URL_UNPOOLED` — direct, use only for `drizzle-kit` migrations

### 10.2 Better Auth

The user's `userMemories` state Better Auth is the chosen auth library. Standard v16-compatible setup:

```ts
// src/lib/auth.ts
import { betterAuth } from 'better-auth'
import { drizzleAdapter } from 'better-auth/adapters/drizzle'
import { getDb } from '@/lib/db'

export const auth = betterAuth({
  database: drizzleAdapter(getDb(), { provider: 'pg' }),
  emailAndPassword: { enabled: true },
  session: {
    expiresIn: 60 * 60 * 24 * 7,   // 7 days for students
    updateAge: 60 * 60 * 24,        // refresh daily
  },
})
```

Mount the handler:

```ts
// app/api/auth/[...all]/route.ts
import { auth } from '@/lib/auth'
import { toNextJsHandler } from 'better-auth/next-js'

export const { GET, POST } = toNextJsHandler(auth.handler)
```

Protect routes via `proxy.ts`:

```ts
// proxy.ts
import { NextRequest, NextResponse } from 'next/server'
import { getSessionCookie } from 'better-auth/cookies'

export function proxy(request: NextRequest) {
  const session = getSessionCookie(request)
  if (!session && request.nextUrl.pathname.startsWith('/dashboard')) {
    return NextResponse.redirect(new URL('/login', request.url))
  }
  return NextResponse.next()
}

export const config = { matcher: ['/dashboard/:path*'] }
```

Note: `getSessionCookie` only checks cookie presence (fast, no DB call). Do real session validation inside Server Components / Route Handlers with `auth.api.getSession()`.

### 10.3 Tailwind v4

Tailwind v4 ships with Next.js 16's `create-next-app`. Configuration lives in `globals.css`, not `tailwind.config.ts`:

```css
/* src/app/globals.css */
@import "tailwindcss";

/* Read palette from BRAIN.md § Visual Identity (Locked) or DESIGN_GUIDE.md tokens.
   Replace [accent], [accent-faint], [bg], [surface] with the project's actual values. */
@theme {
  --color-accent: [accent];        /* e.g. #22d3ee — from BRAIN.md */
  --color-accent-faint: [accent-faint]; /* e.g. #22d3ee1a */
  --color-bg: [bg];                /* e.g. #0b0b0f */
  --color-surface: [surface];      /* e.g. #16161e */
  --font-syne: var(--font-syne);
  --font-onest: var(--font-onest);
  --font-mono: var(--font-jetbrains-mono);
}
```

Use as `text-accent`, `font-syne`, etc. directly.

### 10.4 Vercel deployment

`vercel.json` is usually unnecessary. Standard flow:

1. Push to GitHub (PAT lives in user's memory).
2. Import repo on Vercel.
3. Set env vars: `DATABASE_URL`, `DATABASE_URL_UNPOOLED`, `BETTER_AUTH_SECRET`, `BETTER_AUTH_URL`, plus anything `NEXT_PUBLIC_*` the client needs.
4. Production branch: `main`.

Build settings: leave defaults — Next 16 + Vercel autodetects.

---

## 11. Runtime config — DELETED, use env vars

`serverRuntimeConfig` and `publicRuntimeConfig` from `next.config` are removed in v16. `getConfig()` no longer works.

```ts
// Server-only — read directly
const dbUrl = process.env.DATABASE_URL

// Client-accessible — must be NEXT_PUBLIC_ prefixed
'use client'
const apiUrl = process.env.NEXT_PUBLIC_API_URL
```

To force runtime evaluation (not build-time inlining) of a server env var, call `connection()` first:

```ts
import { connection } from 'next/server'

export default async function Page() {
  await connection()
  const config = process.env.RUNTIME_CONFIG   // read at request time
  return <p>{config}</p>
}
```

---

## 12. Error → Fix lookup

| Error / symptom | Cause | Fix |
|---|---|---|
| `Cannot destructure property 'X' of 'params' as it is a Promise` | Synchronous params access | Mark function `async`, `await params` |
| `cookies() is not a function` / sync cookie access throws | Used `cookies()` synchronously | `const c = await cookies()` |
| Build fails: `Custom webpack configuration is not supported by Turbopack` | Webpack config present + Turbopack default | Remove webpack config OR add `--webpack` to build script |
| `revalidateTag is deprecated, expected 2 arguments` | One-arg form | `revalidateTag('tag', 'max')` |
| `Module not found: Can't resolve 'middleware'` | File still named middleware after v16 codemod expectations | Rename to `proxy.ts`, rename function to `proxy` |
| Parallel route build error: `default.js required` | Missing default file in slot | Create `app/@slot/default.tsx` returning `null` or calling `notFound()` |
| `localPatterns` security error on `<Image src="/foo?v=1" />` | Local image with query string | Add `images.localPatterns: [{ pathname: '/foo', search: '?v=1' }]` |
| Image quality 80 silently coerced to 75 | New `qualities` default is `[75]` | Add `images.qualities: [50, 75, 100]` |
| Image cache feels stale for hours | `minimumCacheTTL` now 4h default | Lower to `60` if needed |
| `getConfig is not a function` | Used legacy runtime config | Migrate to `process.env.*` + `NEXT_PUBLIC_*` |
| `experimental_ppr is not a valid export` | Old PPR flag | Remove flag; set `cacheComponents: true` in config |
| `process.argv` does not include `'dev'` | Config loads only once now | Check `process.env.NODE_ENV === 'development'` instead |
| `connect ECONNREFUSED` from DB on serverless | Using `pg` (Node sockets) in edge-ish context | Use `@neondatabase/serverless` neon-http driver |
| `relation X does not exist` | Migration not run | `npx drizzle-kit generate && npx drizzle-kit migrate` |

---

## 13. File layout (the default to scaffold)

```
my-app/
├── src/
│   ├── app/
│   │   ├── (auth)/            ← route group: login, signup
│   │   ├── dashboard/         ← protected via proxy.ts
│   │   ├── api/
│   │   │   └── auth/[...all]/route.ts   ← Better Auth handler
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   └── globals.css        ← Tailwind v4 @theme here
│   ├── components/
│   │   ├── ui/
│   │   └── sections/
│   ├── lib/
│   │   ├── db/
│   │   │   ├── index.ts       ← getDb() with neon-http
│   │   │   └── schema.ts      ← Drizzle schema
│   │   ├── auth.ts            ← Better Auth instance
│   │   └── env.ts             ← env var validation
│   └── proxy.ts               ← formerly middleware.ts
├── drizzle/                   ← generated migrations
├── drizzle.config.ts
├── next.config.ts
├── package.json
└── tsconfig.json
```

---

## 14. Pre-deploy / pre-commit checklist

Run through this before saying "done."

- [ ] `npm run build` completes locally (or in CI) with no warnings about webpack/middleware/runtime config
- [ ] Every file using `params`, `searchParams`, `cookies()`, `headers()`, `draftMode()` is `async` and uses `await`
- [ ] `package.json` scripts contain `next dev` / `next build` with **no** `--turbopack` flag
- [ ] `package.json` does not call `next lint` anywhere
- [ ] `next.config` has no `webpack` function, no `serverRuntimeConfig`, no `publicRuntimeConfig`, no `experimental.ppr`, no `experimental.dynamicIO`, no `experimental.useCache`, no top-level `eslint` block
- [ ] If using parallel routes, every `@slot` has a `default.tsx`
- [ ] If file was `middleware.ts`, it is now `proxy.ts` with exported `proxy` function
- [ ] All `revalidateTag(...)` calls have two arguments
- [ ] `images.domains` has been replaced by `images.remotePatterns`
- [ ] No `next/legacy/image` imports remain
- [ ] No emojis in code, UI text, commits, or docs
- [ ] Env vars set in Vercel dashboard for Production AND Preview
- [ ] Drizzle migrations generated and applied against Neon

---

## 15. When you are stuck

If you encounter an error not in section 12:

1. Check the deeper reference: `references/migration-from-15.md` for v15→v16 nuances.
2. Run the official codemod: `npx @next/codemod@canary upgrade latest`.
3. Search the official upgrade guide at `https://nextjs.org/docs/app/guides/upgrading/version-16`.
4. If using an AI coding agent with MCP, the Next.js DevTools MCP server can automate upgrades — install with `npx -y next-devtools-mcp@latest`.

---

## Reference files

- `references/migration-from-15.md` — comprehensive v15 → v16 migration with codemods
- `references/cache-decision-tree.md` — extended decision matrix for caching APIs

Read these only if you hit a case the main file does not cover.
