# README.md Template

Keep it lean. Developer-only. Refer to PLANNER.md for everything else.

---

```markdown
# [Project Name]

[One sentence: what it does.]

## Stack

- Next.js 14 (App Router) + TypeScript
- Tailwind CSS
- Neon (PostgreSQL) + Drizzle ORM
- Better Auth
- Vercel (production), Cloudflare Pages (mirror)

## Prerequisites

- Node 20+
- A Neon project (or any PostgreSQL with two connection strings — pooled + unpooled)
- Vercel account (for deploy)

## Local setup

1. Clone the repo: `git clone [repo-url]`
2. Install: `npm install`
3. Copy `.env.example` to `.env.local` and fill in values (see PLANNER.md → Env Vars)
4. Apply migrations: `npx drizzle-kit migrate`
5. Run dev: `npm run dev`

## Env vars

See PLANNER.md → Env Vars for descriptions. Names only:

```
DATABASE_URL
DATABASE_URL_UNPOOLED
BETTER_AUTH_SECRET
BETTER_AUTH_URL
NEXT_PUBLIC_APP_URL
RESEND_API_KEY
```

## Scripts

```bash
npm run dev          # local dev server
npm run build        # production build
npm run start        # serve production build
npm run lint         # ESLint
npx drizzle-kit generate   # generate migration from schema
npx drizzle-kit migrate    # apply migrations
npx drizzle-kit push       # push schema directly (dev only)
```

## Deploy

- Push to `main` → Vercel auto-deploys to production
- Push to any other branch → Vercel preview deploy
- Cloudflare Pages mirrors `main` automatically

Before promoting a deploy, verify env vars are set in BOTH Vercel and Cloudflare dashboards (Production env).

## Folder structure

```
app/             routes (App Router)
components/      UI primitives and sections
lib/             auth, db, utils
drizzle/         generated migrations
```

For the detailed structure, see PLANNER.md → Architecture.
```
