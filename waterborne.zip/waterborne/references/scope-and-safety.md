# Scope and safety

Waterborne is aggressive by design — its whole point is reaching zero. The risk
is over-reach: deleting an emoji that was real data, or editing files that are
not yours to touch. This file is the brake.

---

## Always out of scope (never edit)

The scanner already skips most of these; you skip the rest by judgment.

- `node_modules/`, `.pnpm-store/`, `vendor/`, any third-party package source
- `.git/`, `.next/`, `.turbo/`, `.vercel/`, `.wrangler/`, `.open-next/`
- Build output: `dist/`, `build/`, `out/`, `coverage/`, `target/`
- Lockfiles: `package-lock.json`, `pnpm-lock.yaml`, `yarn.lock`, `bun.lockb`
- Binary assets: images, fonts, video, audio, PDFs, archives
- Minified/generated files: `*.min.js`, `*.min.css`, generated type files,
  compiled bundles — fix the source, not the artifact
- Anything under a clearly third-party or read-only path

If you find yourself about to edit a file in one of these, stop.

---

## Ambiguous: flag, do not auto-change

Some emojis are **legitimate data**, not house-style violations. Detecting these
is contextual. When a hit looks like one of the following, leave it in place and
list it under "Flagged for review" in the report with `file:line` and the reason.

1. **i18n / locale files.** A flag emoji in `en.json` / `locales/` next to a
   language name ("🇫🇷 Français") may be the intended UI. Flag it; suggest a
   `lucide` flag or an SVG flag set, but do not silently delete language data.

2. **Database seeds / fixtures with user-style content.** A seed row like
   `{ note: "Great job 🎉" }` is simulated user content. Flag it; ask whether
   the seed should be emoji-free.

3. **Tests that assert emoji handling.** A test named `handles emoji input` with
   `expect(render("😀")).toBe(...)` MUST keep its emoji or the test loses its
   purpose. Never touch emoji inside test assertions/fixtures that exist to test
   emoji behavior. (Tests that merely *decorate* output with emoji are fair game
   — strip those.)

4. **Seeded sample/demo data shown as "what a user typed".** If removing the
   emoji would change the meaning of demo content, flag it.

5. **Content authored by end users** (CMS rows, comments, saved notes pulled
   from a DB into a fixture). Not yours to rewrite. Flag.

6. **Documentation that is specifically about emojis** (a guide explaining emoji
   support, a changelog entry "added emoji picker 😀"). Use judgment; usually
   flag rather than gut the meaning.

Rule of thumb: if deleting the emoji could be seen as **altering someone's data
or breaking a test**, flag it. If it is the team's own decorative styling, fix
it.

---

## The line between "delete" and "keep"

| Situation | Action |
|---|---|
| Emoji is house-style decoration in your own source/UI/docs | Replace per `replacement-patterns.md` |
| Emoji conveys functional UI meaning (status, action) | Replace with the matching lucide icon |
| Emoji is inside a test that verifies emoji handling | **Keep**, flag |
| Emoji is real i18n/user/seed data | **Keep**, flag, suggest alternative |
| Emoji is in third-party/build/lock files | **Keep**, never touch (out of scope) |
| Emoji is in a commit message you are writing | **Delete** (no emoji in commits) |

---

## Safe-editing checklist (per file)

Before saving any edited file:

1. Did I change only the emoji and its immediate spacing — nothing else?
2. Is the JSX still balanced and are all strings still closed?
3. Is the `lucide-react` import merged (not duplicated) and fully used?
4. For a `.md` or comment, did I remove trailing/leading whitespace the emoji
   left behind?
5. Did I avoid touching any out-of-scope path?

## Don't break these while sweeping

- **String escaping.** Replacing an emoji inside a template literal or JSON
  string must keep quotes/backticks/escapes intact.
- **Array/object commas.** Removing an emoji from a list literal must not delete
  the comma or bracket around it.
- **Snapshot tests.** If you change rendered output, an existing snapshot test
  may now fail. Note this in the report; update snapshots only if the user
  expects it (`jest -u` / `vitest -u`).
- **Git history.** Waterborne edits the working tree only. It never rewrites
  past commits.

---

## When the project is not React / not Tailwind

The skill is tuned for Fahim's Next.js + Tailwind + lucide-react stack, but the
method generalizes:

- **Vue / Svelte / Angular**: use that ecosystem's lucide port
  (`lucide-vue-next`, `lucide-svelte`, `lucide-angular`) with the same icon
  names, or inline SVG.
- **Plain HTML / server-rendered strings**: inline SVG (pattern 6 in
  `replacement-patterns.md`).
- **Backend-only code (no UI)**: emojis there are in logs/comments/strings —
  delete them (patterns 8, 9, 13). No icons needed.

The detection script and the decision table do not change. Only the icon
delivery mechanism does.
