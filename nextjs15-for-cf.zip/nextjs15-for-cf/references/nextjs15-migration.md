# Next.js 14 → 15 Migration Reference

This file is for when the user is mid-migration or chasing an error that the
SKILL.md identified as a v15 breaking change. Read it in full if the project
is on `next@15.0.x` and stuff broke; skim if just looking up one item.

## Quick Codemod

```bash
# Run from project root - applies most v15 codemods automatically
npx @next/codemod@canary upgrade latest

# Just the async request API codemod (cookies/headers/params/searchParams)
npx @next/codemod@canary next-async-request-api .
```

Codemods are best-effort. Always diff and review before committing. They
miss patterns like destructuring `params` inline or aliasing `cookies`.

---

## 1. Async Request APIs - Full Detail

### What's affected

- `cookies()` from `next/headers`
- `headers()` from `next/headers`
- `draftMode()` from `next/headers`
- `params` prop on `page.tsx`, `layout.tsx`, `route.ts`, `generateMetadata`, `generateStaticParams`
- `searchParams` prop on `page.tsx`

### Page component

```tsx
// app/posts/[slug]/page.tsx
type Props = {
  params: Promise<{ slug: string }>
  searchParams: Promise<{ tab?: string }>
}

export default async function Post({ params, searchParams }: Props) {
  const { slug } = await params
  const { tab } = await searchParams
  return <article data-slug={slug} data-tab={tab} />
}
```

### generateMetadata

```tsx
export async function generateMetadata({ params }: Props) {
  const { slug } = await params
  return { title: slug }
}
```

### generateStaticParams - still synchronous return, params not async here

```tsx
export async function generateStaticParams() {
  // Note: this function returns the params, doesn't receive them
  return [{ slug: 'a' }, { slug: 'b' }]
}
```

### Route Handlers

```ts
// app/api/posts/[id]/route.ts
export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  return Response.json({ id })
}
```

### Using cookies/headers in a Server Action

```ts
'use server'
import { cookies } from 'next/headers'

export async function logout() {
  const cookieStore = await cookies()
  cookieStore.delete('auth-token')
}
```

### Common migration mistake

Destructuring at the prop signature **does not** auto-await:

```tsx
// BAD - looks fine, but { slug } is destructured from a Promise
export default async function Page({ params: { slug } }: Props) {
  return <div>{slug}</div> // slug is undefined
}

// GOOD
export default async function Page({ params }: Props) {
  const { slug } = await params
  return <div>{slug}</div>
}
```

### Sync-access escape hatch (transitional only)

Next.js 15 logs a warning and lets sync access work *for now*. Don't rely on it
- it will be removed. If a codemod missed something, you'll see:

```
A param property was accessed directly with `params.slug`. `params` should be
awaited before accessing its properties.
```

Fix it; don't suppress.

---

## 2. Caching Defaults - Full Detail

### Fetch

```ts
// v14: cached by default ('force-cache')
fetch(url)

// v15: NOT cached by default ('no-store')
fetch(url)

// v15: opt back into caching
fetch(url, { cache: 'force-cache' })
fetch(url, { next: { revalidate: 60 } })       // ISR-style, 60s
fetch(url, { next: { tags: ['posts'] } })       // tag-based, with revalidateTag()
```

### Route Handlers

GET handlers were cached by default in v14, no longer in v15. To re-enable:

```ts
// app/api/data/route.ts
export const dynamic = 'force-static' // explicitly cache
// or
export const revalidate = 3600 // ISR-style on the handler
```

### Client Router Cache

The in-browser cache that backs `<Link>` prefetch. `staleTime` for Page
segments dropped from "session-lived" to 0 in v15. To override:

```ts
// next.config.ts
const nextConfig = {
  experimental: {
    staleTimes: {
      dynamic: 30,  // 30s for dynamic segments
      static: 180,  // 180s for static segments
    },
  },
}
```

### Detection

If a v14 app got faster after upgrade, you broke caching. If it got slower
or upstream bills jumped, same diagnosis. Check `network` tab in DevTools -
repeated requests for the same data on navigation = no caching.

---

## 3. React 19

### Installed by default in v15. Check with `npm ls react react-dom`.

### Peer dep conflicts

Common offenders pinned to React 18: older `@radix-ui/*` versions, older
`framer-motion`, older `react-hook-form`. Bump them or use `--legacy-peer-deps`
during install as a temporary measure.

### Renames and removals

| Old | New |
|---|---|
| `useFormState` | `useActionState` |
| `forwardRef(({ ref, ...props }) => ...)` | Just accept `ref` as a regular prop on function components |
| `ReactDOM.render` | Already gone in 18, fully removed in 19 |

### New: `use()`

Unwrap promises in client components:

```tsx
'use client'
import { use } from 'react'

export function Comments({ commentsPromise }: { commentsPromise: Promise<Comment[]> }) {
  const comments = use(commentsPromise)
  return <ul>{comments.map(c => <li key={c.id}>{c.text}</li>)}</ul>
}
```

Pass a promise from a Server Component into a Client Component and unwrap
with `use()` plus `<Suspense>`.

### Actions improvements

```tsx
'use client'
import { useActionState } from 'react'
import { createPost } from './actions'

export function Form() {
  const [state, formAction, isPending] = useActionState(createPost, null)
  return (
    <form action={formAction}>
      <input name="title" />
      <button disabled={isPending}>Submit</button>
      {state?.error && <p>{state.error}</p>}
    </form>
  )
}
```

---

## 4. Other Notable Changes

### `next/font` - now built-in

`@next/font` package is removed. Use `next/font/google` and `next/font/local`
directly. The codemod handles this.

### `next.config.ts` supported

You can write the config in TypeScript natively now:

```ts
// next.config.ts
import type { NextConfig } from 'next'

const nextConfig: NextConfig = {
  reactStrictMode: true,
}

export default nextConfig
```

### ESLint flat config

v15 supports ESLint 9 flat config (`eslint.config.mjs`). If both
`eslint.config.mjs` and `.eslintrc.*` exist, builds fail with a parse error.
Pick one.

### `experimental.ppr` (Partial Prerendering)

Still experimental in v15. Don't enable unless you've read the docs and
accept breakage. On Cloudflare, PPR's runtime expectations don't match
either adapter cleanly yet - leave it off for dual-deploy.

### `instrumentation.ts` stable

Stable, no longer behind `experimental.instrumentationHook`. Useful for OTel
and error reporting setup.

```ts
// instrumentation.ts (project root, NOT in app/)
export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    await import('./instrumentation-node')
  }
}
```

### Removed

- `next export` CLI command (use `output: 'export'` in config)
- `@next/font` (use `next/font`)
- Square-bracket params being sync (covered above)

---

## 5. Migration Checklist

Run in order. Don't skip steps even if "they look fine."

1. Bump deps: `pnpm add next@15 react@19 react-dom@19 eslint-config-next@15`
2. Bump types: `pnpm add -D @types/react@19 @types/react-dom@19`
3. Run `npx @next/codemod@canary upgrade latest`
4. Diff every changed file; the codemod is aggressive about params/searchParams
5. Search for `cookies()`, `headers()`, `draftMode()` - confirm each is awaited
6. Search for destructured `params` in component signatures - rewrite
7. Audit `fetch()` calls - add `{ cache: 'force-cache' }` or `next.revalidate` where you relied on the old default
8. Audit GET Route Handlers - same caching audit
9. Bump peer deps that complain about React 19 (`npm ls react` to find them)
10. Replace `useFormState` with `useActionState`
11. If using Cloudflare next-on-pages: run a Cloudflare preview build, expect new Edge incompat errors and fix them
12. If using OpenNext: bump `@opennextjs/cloudflare`, check compat date and `nodejs_compat` flag
13. On Vercel: trigger a build with cache cleared, test a Preview deploy before Production
14. Smoke test: auth flow, a static page, a dynamic page, an API route, middleware redirect
