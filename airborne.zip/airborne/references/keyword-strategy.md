# Keyword Strategy

> **LearnDE appears in examples for illustration only.** Run real keyword research for the current project rather than reusing LearnDE's terms.

The deepest leverage in SEO is keyword selection. A perfectly written page targeting the wrong keyword will not rank; a competent page targeting the right keyword will. Airborne always picks the keyword first, then writes.

---

## The Four Buckets of Search Intent

Every keyword fits one of these four. Mismatching intent to page type is the most common SEO failure.

| Intent | Searcher wants | Page type | Example |
|---|---|---|---|
| **Informational** | To learn something | Blog post, guide, glossary, study | "what is DELF B2", "how to deploy Next.js to Cloudflare" |
| **Navigational** | A specific site or brand | Homepage, branded landing | "LearnDE login", "Vercel pricing" |
| **Commercial** | To compare before buying | Comparison page, review, listicle | "best DELF prep platform", "Neon vs Supabase" |
| **Transactional** | To do or buy now | Product page, signup, tool | "buy DSH practice test", "free Next.js SEO checker" |

Rule: open the SERP for the keyword. Whatever Google is already showing in the top 5 is the intent. If the top 5 are all blog posts, do not try to rank a product page there.

---

## The Three-Layer Keyword Stack

Every site Airborne plans gets three layers:

### Layer 1 — Primary Keyword (1 per page)

Criteria:
- Directly describes the page
- Has real search volume (verify with Keyword Planner, Ahrefs, or web search showing active SERPs)
- Achievable difficulty given the site's current authority
- Matches one intent bucket clearly

For a new domain, primary keyword difficulty should typically be in the 0–30 range on standard tools. For an aged domain with backlinks, 30–60 is reachable.

### Layer 2 — Secondary Keywords (3–5 per page)

These support the primary. They are synonyms, broader queries, or related sub-topics that the same page can reasonably satisfy. Each secondary keyword usually becomes an H2 on the page.

Example for a page targeting **"DELF B2 practice tests"**:
- Secondary 1: "DELF B2 mock exam" → H2: "Full mock exams with timing"
- Secondary 2: "DELF B2 production écrite samples" → H2: "Sample writing prompts"
- Secondary 3: "DELF B2 compréhension orale" → H2: "Listening practice with audio"

### Layer 3 — Long-Tail Clusters (10–20 per page or topic)

These are the **conversational, question-shaped queries** that voice search and AI Overviews pull from. Each one is low volume individually but cumulatively they often outperform the primary keyword.

Patterns that produce long-tail keywords:
- `how to [verb] [noun]`
- `what is [thing]`
- `[thing] vs [thing]`
- `[thing] for [audience]`
- `best [thing] in [year]`
- `is [thing] worth it`
- `why is [thing] [adjective]`
- `[thing] examples`
- `[thing] template`
- `[thing] tutorial`

Group long-tail keywords into **clusters** of 3–5 related questions. Each cluster becomes a single blog post or FAQ block, not a separate page.

---

## Competitor SERP Analysis

Before finalizing keywords, look at who already ranks. If the top 3 results are all from sites with thousands of backlinks (Wikipedia, Forbes, established competitors), pick a different keyword or a more specific long-tail variant.

Quick analysis loop:
1. Search the primary keyword in Google
2. Note the top 5 results — domain, page type, content depth, word count
3. Identify what they are missing (a free tool, a specific audience angle, a fresher data point, a clearer structure)
4. Position the new page against that gap

If web search is available, do this for real. If not, surface the assumption explicitly in the report.

---

## Intent Mapping Output Format

In the Airborne report, present keywords like this:

```
### Primary Keyword
"DELF B2 practice tests" — Commercial intent
Why: SERP shows 4/5 comparison and listing pages, fits a landing page. Estimated low-to-moderate difficulty given long-tail specificity.

### Secondary Keywords
| Term | Intent | Target H2 |
|---|---|---|
| DELF B2 mock exam | Commercial | "Timed mock exams" |
| DELF B2 production écrite samples | Informational | "Writing prompt library" |
| DELF B2 prep online | Commercial | "Online prep, anywhere" |

### Long-Tail Clusters
**Cluster 1 — Exam mechanics** (target page: blog post)
- how is DELF B2 scored
- how long is the DELF B2 exam
- what is the passing score for DELF B2

**Cluster 2 — Writing section** (target page: blog post)
- DELF B2 production écrite sample answers
- how to structure a DELF B2 essay
- common DELF B2 writing topics
```

---

## What NOT to Target

Skip these as primary keywords for new sites:

- **Single-word head terms** ("learning", "languages", "marketing") — impossible to rank, no clear intent
- **Branded competitor terms** ("Duolingo alternative" is fine; "Duolingo login" is not — searcher does not want this result)
- **Anything that triggers a knowledge panel or featured snippet from Wikipedia** — the search result is fixed
- **Keywords with mismatched intent** — do not put a signup page on an informational SERP

---

## Verification Checklist

Before locking keywords:

- [ ] Each page has exactly one primary keyword
- [ ] Each primary keyword has been searched and the SERP intent verified
- [ ] Secondary keywords are subordinate to the primary, not competing with it
- [ ] Long-tail clusters are grouped by sub-topic, not just listed
- [ ] No two pages on the site target the same primary keyword (cannibalization)
- [ ] Branded keywords route to brand pages; generic keywords route to content pages
