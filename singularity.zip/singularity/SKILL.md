---
name: singularity
description: >
  Context anchor skill for Fahim's GitHub projects. Singularity is the
  FIRST skill to run when a new project begins — after Fahim explains the
  idea, Singularity interviews him one question at a time, writes
  BRAIN.md, then hands off to tree-man for the page/route manifest before
  passing a combined context block to Council (skipping Council's own
  interview). After Council delivers its verdict,
  repo-maintainer scaffolds the docs, and the build begins. When Fahim
  says "fetch brain", read BRAIN.md + PLANNER.md + DESIGN_GUIDE.md
  together and fully re-anchor. When Fahim says "update brain", rewrite
  BRAIN.md to reflect current evolved state. Trigger phrases: "fetch
  brain", "update brain", "run Singularity", "anchor this", "losing
  context". Core purpose: when Claude drifts, hallucinates, rabbit-holes,
  or loses the plot — Singularity snaps it back to base.
---

# Singularity

Singularity is the context anchor and project kickoff engine for Fahim's projects. It generates and maintains `BRAIN.md` — a single document that captures the **identity** of a project, not its tasks or timelines.

When Claude drifts, hallucinates, over-engineers a side branch, or loses the main thread — Singularity is what snaps it back.

---

## Full Project Kickoff Pipeline

Every new project follows this exact sequence. No step is skipped, no step is reordered.

This includes small, single-feature, or "it's just a utility tool" projects. Project size is not grounds to skip the interview or the tree-man handoff — a one-page tool with one API route still needs Q7/Q9 answered and locked, because that's precisely where an architecture decision (which library, which approach) gets written down before code starts instead of drifting unrecorded mid-build.

```
1. Fahim explains the idea (raw, casual, however it comes)
2. Singularity — interviews Fahim one question at a time (9 questions, including 2 framing-challenge questions)
2.5. Singularity — presents 3 palette options → waits for Fahim to choose → locks into BRAIN.md first
3. Singularity — writes full BRAIN.md → builds Council context block
4. Council PRE-BUILD — receives Singularity's context block, skips its own interview, delivers verdicts
4.5. Singularity — on GO, maps the route manifest (pages, API routes, table names) and locks it into BRAIN.md or ROUTES.md
5. repo-maintainer — scaffolds PLANNER.md, DESIGN_GUIDE.md, README.md, AGENTS.md (reads palette + route manifest from BRAIN.md)
6. Build begins
```

---

## When to run

| Trigger | Action |
|---|---|
| Fahim explains a new project idea | Immediately begin Singularity interview — one question at a time |
| `repo-maintainer` runs on a new project | `BRAIN.md` must already exist from the interview — confirm or write it now |
| `"fetch brain"` | Read `BRAIN.md` + `PLANNER.md` + `DESIGN_GUIDE.md` together. Re-anchor fully. State re-anchor summary before continuing. |
| `"update brain"` | Rewrite `BRAIN.md` to reflect current evolved state of the project |
| `"run Singularity"` | Same as "fetch brain" — full re-anchor |
| `"anchor this"` | Same as "fetch brain" |
| Claude is visibly drifting or losing context | Proactively suggest: *"I may be drifting. Should I fetch brain?"* |

---

## Phase 1 — The Interview

When a new project idea lands, Singularity interviews Fahim **one question at a time**. Wait for the answer before asking the next. Do not dump all questions at once.

### The 9 Questions (in order)

1. **What is this project?** — One line, your words, no jargon
2. **Who is it for?** — The exact user. Not "developers" — which person, doing what, in what situation
3. **What will a user actually do here?** — Walk me through the core action. What do they open, do, and get out of it
4. **Why are you building it?** — The real reason. Gap in the market, personal itch, something that doesn't exist yet
5. **What should it become?** — End state in spirit. Not a feature list — what does "done" feel like
6. **What should it never become?** — Anti-goals. What would make you say "that's not what this is"
7. **Any locked decisions already?** — Stack, auth, design constraints, anything already decided before a line is written

### The 2 framing-challenge questions

Questions 1–7 collect. These two push back — they exist to test the frame
of the idea itself, not just gather detail inside it. Ask them after Q7,
once the full picture is on the table.

8. **What happens if this never gets built?** — Who's actually worse off,
   and how much? If the honest answer is "not much," that's worth knowing
   now, not after a week of building.
9. **Does this need to be its own full app?** — New auth, new database, a
   dual deploy to maintain forever — or could most of the value come from
   something lighter: a script, a template, a feature bolted onto
   something that already exists? If the answer is "yes, it genuinely
   needs to be its own thing," say why — that reason becomes a Locked
   Decision.

### Interview rules
- Ask exactly one question per message
- If an answer is vague, push back once with a specific follow-up before moving on
- Do not editorialize or suggest during the interview — just collect
- **Exception for Q8 and Q9:** these are challenges, not collection. If
  the answer sounds thin — "not much" with no real counter, or "it needs
  to be a full app" with no actual reason — push back once, genuinely, the
  same way a co-founder would. This is a challenge, not a gate: whatever
  Fahim decides after the pushback is final, proceed either way
- After question 9 is answered, proceed to **Phase 1.5** before writing BRAIN.md

---

## Phase 1.5 — Palette Selection

After the interview, **do not write BRAIN.md yet.** Present 3 distinct palette options first.

### Rules
- Every project earns its own palette. `#00e676` is banned as a default — it is a specific product colour, not a universal default.
- Palettes must reflect the product personality from the interview: tone, audience, anti-goals
- Each option must be meaningfully different — not just shade variations of green

### Output format

Present as a comparison table:

```
Which palette fits [project name]?

| Token        | Option A — [name]   | Option B — [name]   | Option C — [name]   |
|--------------|---------------------|---------------------|---------------------|
| bg           | #0b0b0f             | #0c0e14             | #080a0d             |
| surface      | #14161e             | #13151f             | #111318             |
| accent       | #7c3aed (violet)    | #06b6d4 (cyan)      | #f59e0b (amber)     |
| accent-faint | #7c3aed1a           | #06b6d41a           | #f59e0b1a           |
| text         | #f5f5f5             | #f0f4ff             | #fef3c7             |
| border       | #2a2a3a             | #1e2130             | #1f1c14             |
| font-display | Syne                | Instrument Serif    | DM Sans             |

Personality: [one sentence per option — why this palette fits the product]
```

### After Fahim chooses
1. Confirm the chosen palette in one line: *"Palette B locked."*
2. Lock it into `BRAIN.md § Visual Identity (Locked)` **before** any other section is written
3. Then proceed to Phase 2

If Fahim asks to adjust a colour within the chosen option, adjust and reconfirm before proceeding.

---

## Phase 2 — Write BRAIN.md

After the interview is complete:

1. Read `references/brain-template.md`
2. Write `BRAIN.md` using answers from the interview
3. Commit to repo root
4. Confirm: *"Singularity armed. BRAIN.md committed."*
5. Immediately hand off to **tree-man** (see Phase 2.5) before building the Council context block

---

## Phase 2.5 — Hand off to tree-man

After `BRAIN.md` is committed, trigger the **tree-man** skill before Council convenes. Tree-man reads `BRAIN.md` and produces `SITETREE.md` — the page/route manifest — so Council reviews actual routes, not a vague idea. Wait for `SITETREE.md` to be committed before building the Council context block in Phase 3.

If this project came through **club-web-planner** (club/society site), tree-man reformats club-web-planner's existing route output instead of re-deriving it — no duplicate interview.

---

## Phase 3 — Hand off to Council

After `BRAIN.md` is written, Singularity builds a context block and passes it directly to the Council skill. Council must skip its own interview and go straight to verdicts.

### Council context block format

```
PROJECT: [name]
DESCRIPTION: [one-line truth from BRAIN.md]
TARGET USER: [exact user from interview Q2]
CORE USER ACTION: [what a user does, from Q3]
PROBLEM: [why it exists, from Q4]
WHAT IT MUST BECOME: [north star from Q5]
ANTI-GOALS: [what it must never become, from Q6]
LOCKED DECISIONS: [any from Q7]
SITEMAP: [path to SITETREE.md, route count, auth levels in use — from tree-man]
FRAMING NOTES: [only if Q8/Q9 surfaced something worth Council weighing —
  e.g. "justified as a full app because X" or "scope intentionally kept
  to Y after challenging whether it needed to exist at all." Omit this
  line entirely if both answers were straightforward.]
STACK: [Fahim's standard stack + any project-specific choices from Q7]
MODE: PRE
```

### Handoff message to Claude

After building the context block, say:

> *"BRAIN.md is committed. Passing context to Council. Convening PRE-BUILD now."*

Then immediately trigger the Council skill with the context block above. Council proceeds directly to its five personas — no interview.

---

## Phase 4 — After Council

Once Council delivers its PRE-BUILD verdict:

1. Fahim reviews and responds (go / adjust / abort)
2. If GO — before repo-maintainer touches anything, map the route surface
   (see **Route Mapping** below). This is the missing middle step between
   identity (`BRAIN.md`) and blueprint (`PLANNER.md`)
3. Trigger `repo-maintainer` to scaffold `PLANNER.md`, `DESIGN_GUIDE.md`,
   `README.md`, `AGENTS.md` — now grounded in the route manifest instead of
   inferring structure from BRAIN.md alone
4. Build begins

### Route Mapping — the step between BRAIN.md and PLANNER.md

`BRAIN.md` answers what the project *is*. `PLANNER.md` needs what the
project *contains* — actual pages, routes, and endpoints. Jumping straight
from one to the other leaves repo-maintainer scaffolding a blueprint with
nothing concrete to build from, and Fahim ends up backfilling structure
mid-build instead of before it.

After GO, before triggering repo-maintainer:

1. From BRAIN.md's Core User Action (Q3) and What It Must Become (Q5),
   derive the full page list — every route a user can land on: marketing
   pages, auth pages, dashboard, admin, any public listing/detail views
2. List the API surface implied by that page list — every Server Action or
   Route Handler needed (sign up/in/out, CRUD per major entity, webhook
   receivers if a payment provider is a locked decision)
3. Name the DB tables/entities implied by the API surface — names only,
   full schema is `PLANNER.md`'s job, not this step's
4. Write it as a short manifest — either a new `## Route Manifest
   (Pre-Build)` section appended to `BRAIN.md`, or a standalone `ROUTES.md`
   if the list runs long
5. Confirm with Fahim in one line: *"N pages, N API routes, N tables —
   locking this as the build surface. Proceed to repo-maintainer?"*
6. Only after confirmation, trigger `repo-maintainer`

This is structure, not design — no component code, no schema types, no
styling. Just names and shape. `PLANNER.md` still does the real work; this
step gives it something real to start from instead of being vague about it.

---

## What BRAIN.md is NOT

- Not a task list
- Not a timeline or phase tracker (that's PLANNER.md)
- Not a design spec (that's DESIGN_GUIDE.md)
- Not a README
- Not a changelog

## What BRAIN.md IS

The answer to: *"If a new Claude instance with zero context opened this file, would it understand exactly what this project is, why it exists, and what it must never become?"*

If yes — BRAIN.md is doing its job.

---

## BRAIN.md structure

Read `references/brain-template.md` before writing for the first time.

### Sections in order:

#### 1. The One-Line Truth
One sentence. What this project *is*. No fluff. No marketing. The brutal honest summary.

> Example: "Bindu is an anonymous message-receiving SaaS for Bangladeshi users, built with a dark minimal UI and Bengali font support."

#### 2. Why It Exists
2–4 sentences. The problem it solves, the gap it fills, the person it's for. Why Fahim is building it.

#### 3. What It Must Become
The north star. Not a feature list — the *end state*. What does "done" look like in spirit?

#### 4. Core Decisions (Locked)
Architectural and product decisions that are **locked** — not to be revisited, not to be second-guessed by Claude mid-session.

Format:
```
- [LOCKED] Next.js App Router — Edge-compatible, Fahim's standard stack
- [LOCKED] No Google OAuth — credentials-only, by design choice
- [LOCKED] Bengali font self-hosted — CDN was unreliable at load time
```

#### 5. What It Must Never Become
Anti-goals. The things this project should never drift into.

> Example: "Must never become a social network. Must never require phone verification. Must never have a light mode."

#### 6. Current State
Short honest snapshot of where the project is right now. Updated on every "update brain" call.

```
Status: [Alpha / Beta / MVP / Production / Paused / Abandoned]
Last updated: [date]
What works: ...
What's broken or incomplete: ...
What's next (in spirit, not tasks): ...
```

#### 7. The Stack (Frozen)
The confirmed tech stack. Listed once, updated only when a stack change is intentional and confirmed by Fahim.

#### 8. Constraints & Non-Negotiables
Hard limits — technical, design, legal, or personal.

> Examples: "Must deploy to both Vercel and Cloudflare Pages. No emojis in UI — icons only. No Supabase. No light mode."

#### 9. Context Hooks (for Claude)
Specific things Claude tends to forget or get wrong on this project.

> Examples:
> - "The auth is NextAuth v5 beta JWT-only — no DrizzleAdapter, no sessions table"
> - "Upstash Redis is for rate limiting only — not caching"
> - "The Bengali font is Li Ador Noirrit, self-hosted under /public/fonts"

---

## On "fetch brain" — Re-anchor workflow

1. Read `BRAIN.md` from repo
2. Read `PLANNER.md` from repo
3. Read `DESIGN_GUIDE.md` from repo
4. Synthesize all three into active working memory
5. Print re-anchor summary before continuing — never skip this

### Re-anchor summary format

```
Re-anchored.
[Project name] — [one-line truth]
Status: [current state status]
Stack: [frozen stack one-liner]
Locked decisions loaded: [count]
Context hooks loaded: [count]
Ready.
```

---

## On "update brain" — Update workflow

1. Read existing `BRAIN.md`
2. Diff against current conversation state
3. Update **Current State** section — always
4. Add new **Locked Decisions** if any were made this session
5. Add new **Context Hooks** if Claude made errors this session worth remembering
6. Update **What It Must Become** only if the vision has genuinely shifted
7. Never remove `[LOCKED]` entries — mark `[SUPERSEDED by: ...]` with reason if a decision changed
8. Push updated file
9. Confirm: *"Brain updated."*

---

## Relationship to other skills

| Skill | Role | Relation to Singularity |
|---|---|---|
| `council` | PRE/POST build verdict | Runs immediately after Singularity, receives its context block — skips its own interview |
| `repo-maintainer` | Scaffolds PLANNER, DESIGN_GUIDE, README, AGENTS | Runs after Council gives GO verdict and the route manifest is locked |
| `airborne` | SEO content strategy | Singularity's identity is the source of truth Airborne respects |
| `plainsight` | Frontend layout | Singularity's constraints govern design limits |
| `next15builder` / `next16builder` | Build patterns | Singularity's frozen stack is the source of truth |

---

## Rules Claude must follow when Singularity is active

1. **Never contradict a `[LOCKED]` decision** without flagging it explicitly and asking Fahim first
2. **Never suggest a feature** that violates the "What It Must Never Become" section
3. **Never assume the stack** — always read the Frozen Stack section
4. **If context feels lost mid-session** — stop and say: *"I may be drifting. Should I fetch brain?"*
5. **Context Hooks are gospel** — treat them as hard truth, not suggestions
6. **Never skip the tree-man or Council handoffs** on a new project — Singularity → tree-man → Council → repo-maintainer is the sequence, always
