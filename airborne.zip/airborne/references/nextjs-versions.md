# Next.js Version Compatibility (14 / 15 / 16)

> **LearnDE appears throughout as a worked example only.** Swap in the current project's actual name/domain before reusing any snippet.

Airborne's technical output must compile on the user's exact Next.js version. The biggest difference for SEO work is how request-time APIs (`params`, `searchParams`, `cookies`, `headers`) are accessed. Get this wrong and the build breaks.

This file is the lookup table.

---

## Step 0 — Detect the Version

Always start by reading `package.json`:

```bash
cat package.json | grep -E '"next":'
```

Or in code review, look for:
```json
"dependencies": {
  "next": "^14.2.0"   // → Next.js 14
  "next": "^15.0.0"   // → Next.js 15
  "next": "^16.0.0"   // → Next.js 16
}
```

If the version is not pinned, look at the lockfile (`package-lock.json`, `pnpm-lock.yaml`, `bun.lockb`) for the resolved version.

---

## The Critical Difference: Async Request APIs

This is **the** breaking change SEO work hits.

| API | Next.js 14 | Next.js 15 | Next.js 16 |
|---|---|---|---|
| `params` in `generateMetadata`, `page.tsx`, `layout.tsx` | Sync object | Promise (with temporary sync compat) | Promise (sync removed) |
| `searchParams` in `page.tsx` | Sync object | Promise (with temporary sync compat) | Promise (sync removed) |
| `cookies()` | Sync | Async (with temporary sync compat) | Async only |
| `headers()` | Sync | Async (with temporary sync compat) | Async only |
| `draftMode()` | Sync | Async (with temporary sync compat) | Async only |

**Rule:** for Next 15 and Next 16, treat all request APIs as **async** and `await` them. Next 14 stays sync.

---

## generateMetadata — The Three Versions

### Next.js 14

```tsx
// app/blog/[slug]/page.tsx
import type { Metadata } from "next";

type Props = {
  params: { slug: string };
  searchParams: { [key: string]: string | string[] | undefined };
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const post = await getPost(params.slug); // params.slug is sync

  return {
    title: `${post.title} | LearnDE`,
    description: post.description,
    alternates: { canonical: `https://learnde.com/blog/${post.slug}` },
    openGraph: {
      title: post.title,
      description: post.description,
      url: `https://learnde.com/blog/${post.slug}`,
      images: [{ url: post.coverImage, width: 1200, height: 630 }],
      type: "article",
    },
    twitter: {
      card: "summary_large_image",
      title: post.title,
      description: post.description,
      images: [post.coverImage],
    },
  };
}
```

### Next.js 15

```tsx
// app/blog/[slug]/page.tsx
import type { Metadata } from "next";

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params; // must await in Next 15
  const post = await getPost(slug);

  return {
    title: `${post.title} | LearnDE`,
    description: post.description,
    alternates: { canonical: `https://learnde.com/blog/${post.slug}` },
    openGraph: {
      title: post.title,
      description: post.description,
      url: `https://learnde.com/blog/${post.slug}`,
      images: [{ url: post.coverImage, width: 1200, height: 630 }],
      type: "article",
    },
    twitter: {
      card: "summary_large_image",
      title: post.title,
      description: post.description,
      images: [post.coverImage],
    },
  };
}
```

### Next.js 16

```tsx
// app/blog/[slug]/page.tsx
import type { Metadata } from "next";
import type { PageProps } from "next"; // optional helper from `npx next typegen`

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params; // strictly async in Next 16
  const post = await getPost(slug);

  return {
    title: `${post.title} | LearnDE`,
    description: post.description,
    alternates: { canonical: `https://learnde.com/blog/${post.slug}` },
    openGraph: {
      title: post.title,
      description: post.description,
      url: `https://learnde.com/blog/${post.slug}`,
      images: [{ url: post.coverImage, width: 1200, height: 630 }],
      type: "article",
    },
    twitter: {
      card: "summary_large_image",
      title: post.title,
      description: post.description,
      images: [post.coverImage],
    },
  };
}
```

The only difference between 15 and 16 here is **strictness**: in 15, sync access still works (with a warning); in 16, it throws.

---

## page.tsx — params usage

Same async/sync rule applies.

### Next.js 14

```tsx
export default async function BlogPost({ params }: { params: { slug: string } }) {
  const post = await getPost(params.slug);
  return <article>{post.title}</article>;
}
```

### Next.js 15 & 16

```tsx
export default async function BlogPost({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const post = await getPost(slug);
  return <article>{post.title}</article>;
}
```

---

## app/sitemap.ts — Same across all three

The sitemap convention is stable. No version-specific changes for SEO purposes.

```ts
// app/sitemap.ts — works on Next 14, 15, 16
import type { MetadataRoute } from "next";
import { getAllPosts, getAllExams } from "@/lib/content";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = "https://learnde.com";
  const posts = await getAllPosts();
  const exams = await getAllExams();

  const staticPages: MetadataRoute.Sitemap = [
    { url: baseUrl, lastModified: new Date(), changeFrequency: "weekly", priority: 1.0 },
    { url: `${baseUrl}/about`, lastModified: new Date(), changeFrequency: "monthly", priority: 0.6 },
    { url: `${baseUrl}/pricing`, lastModified: new Date(), changeFrequency: "monthly", priority: 0.8 },
  ];

  const dynamicPages: MetadataRoute.Sitemap = [
    ...posts.map((p) => ({
      url: `${baseUrl}/blog/${p.slug}`,
      lastModified: p.updatedAt,
      changeFrequency: "monthly" as const,
      priority: 0.7,
    })),
    ...exams.map((e) => ({
      url: `${baseUrl}/exams/${e.slug}`,
      lastModified: e.updatedAt,
      changeFrequency: "monthly" as const,
      priority: 0.8,
    })),
  ];

  return [...staticPages, ...dynamicPages];
}
```

---

## app/robots.ts — Same across all three

```ts
// app/robots.ts — works on Next 14, 15, 16
import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/admin/", "/api/", "/dashboard/", "/settings/", "/staff/"],
      },
    ],
    sitemap: "https://learnde.com/sitemap.xml",
  };
}
```

---

## Dynamic OG Images — app/og/route.tsx

The `next/og` API for dynamic Open Graph images works the same across 14, 15, and 16, but the params handling for dynamic routes follows the version's async rules.

```tsx
// app/og/route.tsx — same across versions for static OG
import { ImageResponse } from "next/og";

export const runtime = "edge"; // optional; works without

export async function GET() {
  return new ImageResponse(
    (
      <div style={{ fontSize: 64, background: "white", width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center" }}>
        LearnDE
      </div>
    ),
    { width: 1200, height: 630 }
  );
}
```

For per-page OG images that read params (e.g. `/og/blog/[slug]/route.tsx`), apply the version-specific params rules from above.

---

## Middleware vs proxy.ts

This affects SEO when middleware handles redirects, canonical enforcement, or `X-Robots-Tag` headers.

| Version | File | Status |
|---|---|---|
| 14 | `middleware.ts` | Standard, edge runtime |
| 15 | `middleware.ts` | Standard, edge runtime |
| 16 | `proxy.ts` (preferred) or `middleware.ts` (deprecated but still works) | `proxy.ts` runs on Node.js, more predictable |

For Next 16, prefer `proxy.ts` for new code. Existing `middleware.ts` still works but is deprecated.

```ts
// Next 16 — proxy.ts (replaces middleware.ts)
import { NextRequest, NextResponse } from "next/server";

export default function proxy(request: NextRequest) {
  // Force www → apex
  const host = request.headers.get("host");
  if (host?.startsWith("www.")) {
    const url = request.nextUrl.clone();
    url.host = host.replace("www.", "");
    return NextResponse.redirect(url, 301);
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
};
```

For Next 14 and 15, use the same code in `middleware.ts` (the API surface is identical).

---

## Caching (affects SEO indirectly through performance)

This is **not** an SEO-content concern per se, but it affects Core Web Vitals scores and content freshness signals.

### Next.js 14

`fetch()` is cached by default. ISR via `next: { revalidate: 3600 }` option.

### Next.js 15

`fetch()` is **no longer cached by default** in dynamic routes. Add explicit `cache: "force-cache"` or `next: { revalidate: N }` where caching is wanted. Partial Prerendering still experimental.

### Next.js 16

Cache Components introduced — opt-in via `cacheComponents: true` in `next.config.ts`, then use `'use cache'` directive on functions or components:

```ts
// next.config.ts (Next 16)
import type { NextConfig } from "next";
const nextConfig: NextConfig = {
  cacheComponents: true,
};
export default nextConfig;
```

```tsx
// app/blog/[slug]/page.tsx (Next 16)
'use cache'
export default async function BlogPost({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = await getPost(slug);
  return <article>{post.title}</article>;
}
```

For SEO output, recommend Cache Components for static-ish SEO pages (blog posts, landing pages) on Next 16 — they get the freshness of dynamic with the performance of static.

---

## Pages Router (legacy)

If the project uses `pages/` instead of `app/`:

- Use `next/head` for meta tags instead of `generateMetadata`
- Use `getStaticProps` / `getServerSideProps` for data
- `app/sitemap.ts` does NOT work — use a `pages/api/sitemap.xml.ts` API route or a static file
- Pages Router is unchanged across 14/15/16

Most new Fahim projects use App Router. If a project is Pages Router, note it in the Stack Audit and produce Pages-Router-compatible snippets.

---

## Quick Decision Reference

When producing technical SEO output, walk this short table:

| Question | Answer |
|---|---|
| What version is in `package.json`? | 14 / 15 / 16 |
| Is `params` sync or async in templates? | 14: sync. 15: Promise (await). 16: Promise (await, strict) |
| Is `cookies()`/`headers()` sync or async? | 14: sync. 15+: async (await) |
| Use `middleware.ts` or `proxy.ts`? | 14/15: `middleware.ts`. 16: `proxy.ts` (preferred) |
| Default fetch cache? | 14: cached. 15+: not cached, opt in explicitly |
| App Router caching primitive (16)? | Cache Components (`'use cache'`) |
| `app/sitemap.ts` syntax across versions? | Same |
| `app/robots.ts` syntax across versions? | Same |
| JSON-LD insertion pattern? | Same — `<script type="application/ld+json">` in JSX |

When in doubt, **match the syntax to the detected version** and note the version in the report so the user can verify.
