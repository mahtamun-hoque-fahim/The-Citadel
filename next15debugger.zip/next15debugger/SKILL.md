---
name: next15debugger
description: >
  Debugging expertise for Next.js 15.x projects (App Router, React 19, Turbopack).
  SCOPE: Next.js 15.x ONLY — if package.json shows next@16.x, stop and use
  next16-debugger instead. ALWAYS use when the user mentions: a Next.js error,
  build failure, runtime crash, hydration mismatch, async
  params/searchParams/cookies/headers issue, "params is a Promise",
  "[object Promise]" in output, caching anomaly, stale data after upgrade,
  Server/Client component boundary problem, "Event handlers cannot be passed to
  Client Component props", Server Actions silently failing, "use client"/"use
  server" directive issue, middleware redirect loop, Edge Runtime restriction,
  route handler error, dynamic vs static rendering confusion, "Dynamic server
  usage" error, build-works-locally-fails-on-deploy, cold start latency, or any
  unexpected behavior in a Next.js 15.x app. Also use proactively when reading
  Next.js 15 code that looks suspicious — many Next.js 14 patterns are broken in
  15. Do NOT use for next@16.x.
---

# Next.js 15 Debugger

> **Scope: Next.js 15.x only.** If `package.json` shows `next@16.x`, stop here and use **next16-debugger** instead. v16 introduced proxy.ts, fully async request APIs, and Cache Components — debugging patterns differ enough to need a separate skill.

Debug Next.js 15 projects with the discipline of a senior engineer: **read first, classify second, hypothesize third, fix last**. This skill encodes the breaking changes in Next.js 15, the most common failure modes, and a thinking pattern that prevents pattern-matching to outdated Next.js 14 assumptions.

The single most important fact: **a Next.js 14 codebase pasted into 15 will almost always have at least three bugs at once.** If the project recently upgraded, suspect the breaking changes section before anything else.

---

## Part 1 — The Thinking Pattern (do this every time)

A smaller model's most common failure mode is jumping to a fix before understanding the bug. This pattern prevents that. Walk it in order.

### Step 1. Read the error completely
- The **full** message, not the headline.
- The **full** stack trace, not the top frame.
- Note: filename, line number, function name, runtime label (server / client / edge), request URL if any.
- If the user paraphrased the error ("it doesn't work", "the page is broken"), **stop and ask for or reproduce the actual error message**. Do not guess from the symptom alone.

### Step 2. Classify the boundary
Every Next.js bug lives in exactly one of these buckets. Classify before fixing:

- **Build-time** — surfaced by `next build`. TypeScript errors, missing env vars accessed at module level, "Dynamic server usage" in a static context.
- **Server runtime** — Server Component, Route Handler, Server Action, or `generateMetadata`. Logs appear in the terminal (dev) or Vercel/host logs (prod), **never** in the browser console.
- **Client runtime** — Client Component (`'use client'`), browser-only code. Logs in the browser DevTools console.
- **Hydration** — server HTML differs from client first render. Symptom: warning printed by React, sometimes followed by visible re-render or content flash.
- **Edge runtime** — middleware, or any route with `export const runtime = 'edge'`. Limited Node API surface.
- **Caching layer** — data cache, full route cache, router cache, ISR. Symptom: "data is stale" or "data is too fresh".

If you cannot tell which bucket the bug is in, **you cannot fix it**. Re-read the error.

### Step 3. Check Next.js 15 defaults first
Open `package.json`. Find the Next.js version. If it is 15.x and the bug looks like "this used to work", go straight to Part 2 (Breaking Changes) before debugging the user's logic. Three of the most-asked questions about Next.js 15 are answered there.

### Step 4. Form one hypothesis with a falsifiable test
Bad debugging: "let me try changing this and see."
Good debugging: "I believe this fails because **X**. If **X** is true, then **Y** will also be true. Let me check **Y** first." Only after verifying **Y** do you change code.

### Step 5. Isolate when stuck
When nothing makes sense:
- Comment out half the failing file. Does the error still occur?
- If yes, the bug is in the remaining half. Repeat.
- If no, the bug is in the commented half. Uncomment, comment the other half.
- Binary search converges on the bug in ~5 cuts even for large files.

This works for hydration errors, middleware loops, "build is slow", and "page renders blank".

### Step 6. Trust the framework less than your code, but don't rule it out
Default suspicion: your own code. But sometimes the bug is in Next.js itself — especially on canary releases or with Turbopack edge cases. If you have a minimal reproduction and the behavior contradicts the docs, check the Next.js GitHub issues.

### Step 7. The 20-minute rule
If you have spent 20 minutes and are no closer to the fix, **you are guessing**. Stop. Re-read the error from the top. Restart at Step 1. The bug has not moved — your model of it is wrong.

---

## Part 2 — Next.js 15 Breaking Changes (most bugs start here)

### 2A. Async Request APIs — the #1 source of 14→15 bugs

In Next.js 15, these are **Promises** and must be `await`ed:
- `params` and `searchParams` (in `page.tsx`, `layout.tsx`, `route.ts`, `generateMetadata`, `generateViewport`)
- `cookies()` from `next/headers`
- `headers()` from `next/headers`
- `draftMode()` from `next/headers`

```ts
// WRONG — Next.js 14 pattern, broken in 15
export default function Page({ params }: { params: { id: string } }) {
  return <div>{params.id}</div>;
  // Renders "[object Promise]" or crashes with "Cannot read property 'id' of undefined"
}

// RIGHT
export default async function Page({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return <div>{id}</div>;
}
```

```ts
// WRONG
const token = cookies().get('token');

// RIGHT
const cookieStore = await cookies();
const token = cookieStore.get('token')?.value;
```

**Symptoms that point here:**
- `Cannot read property 'X' of undefined` on `params` or `searchParams`
- Rendered output literally shows `[object Promise]`
- `cookies(...).get is not a function`
- Type error: `Property 'X' does not exist on type 'Promise<...>'`

**Fix:** Make the function `async`, type the prop as `Promise<...>`, and `await` it.

### 2B. Caching defaults flipped to opt-in

Three caches changed defaults in 15:

| Cache | Next.js 14 default | Next.js 15 default | Opt back in with |
|---|---|---|---|
| `fetch()` | cached | **not cached** | `fetch(url, { cache: 'force-cache' })` |
| GET Route Handlers | cached | **not cached** | `export const dynamic = 'force-static'` |
| Client Router Cache (pages) | 30s reuse | **0s reuse** | `experimental.staleTimes` in `next.config` |

**Symptoms that point here:**
- "API is being hit way more often after upgrade"
- "Data updates too fast / page is too dynamic"
- Vercel function invocations spiked

**Fix:** Explicitly opt into caching where you want it.

### 2C. React 19 in App Router (App Router defaults to React 19; Pages Router still 18)

- `useFormState` → `useActionState` (old still works with deprecation warning, imported from `react` not `react-dom`).
- `useFormStatus` now exposes `data`, `method`, `action` in addition to `pending`.
- `forwardRef` is no longer needed in most cases — `ref` is a regular prop on function components.
- The new `use()` hook can read promises and context conditionally.

### 2D. Turbopack stable for `next dev`

`next dev --turbopack` is stable. If something works under webpack but not Turbopack, treat it as a real bug worth filing. Production build still uses webpack by default.

### 2E. Other 15.x notes

- `next/font` no longer needs the `next/font/google` workaround — fonts are inlined more aggressively.
- `unstable_after` lets a Server Action keep doing work after the response is sent (background tasks).
- Self-hosting: `output: 'standalone'` is more reliable; `sharp` is the default image optimizer in standalone mode.

---

## Part 3 — Error Catalog (symptom → cause → fix)

### "Hydration failed because the server rendered HTML didn't match the client"

Causes, in descending frequency:
1. `Date.now()`, `Math.random()`, or `new Date()` called during render (not inside `useEffect`).
2. Locale-dependent formatting — `toLocaleString` differs between server locale and browser locale.
3. Browser extensions injecting attributes onto `<html>` or `<body>` (Grammarly, Dark Reader, LastPass).
4. `typeof window !== 'undefined'` branches that render different markup on each side.
5. Conditional rendering based on `localStorage` / `sessionStorage` during initial render.
6. Invalid HTML nesting: `<p><div>` , `<a>` inside `<a>`, `<button>` inside `<button>`. React tries to fix it, hydration explodes.

**Fixes:**
- Move dynamic values into `useEffect`, store in state.
- Use `next/dynamic` with `{ ssr: false }` for browser-only components.
- For extension-injected attributes on `<html>` or `<body>`, add `suppressHydrationWarning` to **that specific element only**.
- Read the diff that React prints in the warning — it tells you exactly which element mismatched.

### "Event handlers cannot be passed to Client Component props"

You are passing a function from a Server Component to a Client Component without the receiver being a client component, or you are trying to pass a function from server to client (functions do not serialize across that boundary).

**Fix:** Add `'use client'` to the file that defines the handler, OR define the handler inside the client component itself.

### "Functions cannot be passed directly to Client Components unless you explicitly expose it by marking it with 'use server'"

You are trying to pass a Server Action without the directive.

**Fix:** At the top of the function or file: `'use server'`. The file must contain only async functions if it has a file-level `'use server'`.

### "Dynamic server usage: Route X couldn't be rendered statically because it used Y"

A page Next.js wanted to statically generate called `cookies()`, `headers()`, dynamic `searchParams`, or `noStore()`.

**Fix paths (pick one):**
- Accept it as dynamic: `export const dynamic = 'force-dynamic'` at the top of the page.
- Wrap the dynamic part in `<Suspense>` so the shell can be prerendered (Partial Prerendering).
- Move the dynamic call into a separate component imported below the Suspense boundary.

### "You're importing a component that needs `next/headers`. That only works in a Server Component"

A Client Component is importing a file that uses `cookies()` or `headers()`.

**Fix:** Extract the server-only logic into a separate file, call it from a Server Component, pass the resulting plain data down as props to the Client Component.

### Middleware redirect loop (browser shows "too many redirects")

You redirect unauthenticated users to `/login`, but `/login` is also matched by your middleware. The middleware sees no auth on `/login` and redirects again. Forever.

**Fix:** Short-circuit at the top of the middleware before any auth check:
```ts
const PUBLIC_PATHS = ['/login', '/signup', '/api/auth'];
if (PUBLIC_PATHS.some(p => request.nextUrl.pathname.startsWith(p))) {
  return NextResponse.next();
}
```
Or exclude them from the matcher config.

### Edge runtime: "Module not found" / "X is not a function" / "Dynamic Code Evaluation is not available"

You are using a Node-only API in middleware or an edge route. Common offenders:
- `fs`, `path`, `child_process`, `os`
- ORMs with native drivers: `pg`, `mysql2`, `better-sqlite3`
- Parts of `crypto` (use Web Crypto's `crypto.subtle` instead)
- `eval`, `new Function(...)`, or libraries that use them internally

**Fix:** Either move the code out of edge runtime (`export const runtime = 'nodejs'`), or swap for an edge-compatible alternative (`@neondatabase/serverless` instead of `pg`, Web Crypto instead of node `crypto`).

### "Cookies cannot be set in a Server Component"

Server Components can **read** cookies. They cannot **write** them. Writes must happen in:
- Server Actions
- Route Handlers
- Middleware (via `NextResponse.cookies.set(...)`)

**Fix:** Move the `cookieStore.set(...)` call into a Server Action or Route Handler.

### Server Action does nothing / form submits silently

Diagnose in this order:
1. Does the function have `'use server'` (file-level or function-level)?
2. Is the function `async`? Server Actions must be async.
3. Is the form wired with `action={myAction}`, not `onSubmit`?
4. Is there a client-side `e.preventDefault()` blocking the form?
5. Is the action throwing an error? **Check the terminal logs**, not the browser console — Server Action errors land on the server side.
6. If using `redirect()` inside the action, it must be called outside any try/catch (redirect throws a special error internally).

### Build succeeds locally, fails on Vercel / Cloudflare

Top causes:
- **Env var read at module level** that exists locally but not in the build environment. Symptom: `Cannot read property of undefined` during build. Fix: read env vars lazily inside functions, or add to platform env vars.
- **Case-sensitive imports** — macOS/Windows file systems are case-insensitive, Linux is not. `import Foo from './foo'` works locally but fails on Linux if the file is `Foo.tsx`.
- **Native dependencies** not building for the target platform (Cloudflare Workers is especially restrictive).
- **Different build command** — Vercel runs `next build`, Cloudflare Pages runs `@cloudflare/next-on-pages`. Edge runtime requirements differ.
- **Node version drift** — local Node 22, platform Node 18, syntax or API mismatch.

**Diagnostic:** Run the exact same build command the platform runs, with the same Node version (use `nvm use` or `.nvmrc`).

### "Slow first request" / cold start latency

- Vercel serverless functions cold-start. Mitigations: smaller bundles, use edge runtime where appropriate, enable fluid compute on Vercel, route warming.
- Creating a new DB connection per request: use a **module-level singleton client** (see Part 5).
- Large dependencies in the bundle: check `next build` output for "First Load JS" per route.
- ISR not configured for pages that could be static.

### 404 on a page that should exist

- Is the file actually named `page.tsx` (or `.ts`/`.jsx`/`.js`)? `Page.tsx` or `index.tsx` will not work in App Router.
- Is it in the correct route group? Files in `(group)` folders do not affect the URL but are still rooted correctly.
- Is middleware redirecting or rewriting it before the page resolves? Check the matcher.
- Is the `app/` directory correctly nested under `src/` if you use `src/`?

### TypeScript: "Type 'Promise<...>' is not assignable to type ..."

You typed `params` or `searchParams` as a plain object instead of a Promise. See Part 2A.

---

## Part 4 — Decision Trees

### Server Component vs Client Component
Default: **Server Component**. Switch to Client Component only if the file needs ANY of:
- `useState`, `useReducer`, `useEffect`, `useRef`, `useContext`, `useLayoutEffect`
- Inline event handlers (`onClick`, `onChange`, `onSubmit` not handled by `action`)
- Browser-only APIs (`window`, `document`, `localStorage`, `navigator`, `IntersectionObserver`)
- Third-party library that uses any of the above (most UI libraries, animation libs, charting libs)
- React Context Provider (consumers can read context in a wrapped tree)

If a parent is a Client Component, **all children imported into it become client** even without their own `'use client'`. To keep a child as Server: pass it as `children` prop instead of importing.

### Edge vs Node runtime
Default: **Node**. Switch to Edge only if ALL of:
- The route is latency-critical AND benefits from global distribution (auth checks at the edge, A/B routing, simple redirects).
- The code uses only edge-compatible APIs.
- The bundle stays small (~1MB compressed; Cloudflare is stricter).

For databases in edge: use `@neondatabase/serverless` (HTTP) or `@vercel/postgres`. Drizzle has `drizzle-orm/neon-http` for this.

### Static vs Dynamic rendering
A route becomes **dynamic** if it calls any of:
- `cookies()`, `headers()`, `draftMode()`
- `searchParams` (the prop itself)
- `noStore()` or `unstable_noStore()`
- `fetch(...{ cache: 'no-store' })`
- Has `export const dynamic = 'force-dynamic'`

Otherwise it is **static** (or `'force-static'` if you want to override and skip the dynamic APIs).

If a route accidentally became dynamic and you wanted it static: find the dynamic call and either remove it, replace it with a static alternative, or wrap that part in `<Suspense>` so the rest can prerender.

---

## Part 5 — Reference: Patterns done right

### Reading params and searchParams (15+)
```ts
export default async function Page({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const { slug } = await params;
  const { q } = await searchParams;
  // ...
}
```

### Reading cookies (Server Component)
```ts
import { cookies } from 'next/headers';

export default async function Page() {
  const cookieStore = await cookies();
  const token = cookieStore.get('session')?.value;
  // ...
}
```

### Setting cookies (Server Action)
```ts
'use server';
import { cookies } from 'next/headers';

export async function login(formData: FormData) {
  // ... validate credentials ...
  const cookieStore = await cookies();
  cookieStore.set('session', token, {
    httpOnly: true,
    secure: true,
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
  });
}
```

### Server Action with revalidation
```ts
'use server';
import { revalidatePath, revalidateTag } from 'next/cache';

export async function createPost(formData: FormData) {
  const title = formData.get('title') as string;
  await db.insert(posts).values({ title });
  revalidatePath('/posts');
  // or: revalidateTag('posts');
}
```

### Cached fetch (opt-in in 15)
```ts
const data = await fetch('https://api.example.com/data', {
  cache: 'force-cache',
  next: { revalidate: 3600, tags: ['data'] },
}).then(r => r.json());
```

### Module-level DB client (singleton — prevents connection storms)
```ts
// lib/db.ts
import { drizzle } from 'drizzle-orm/neon-http';
import { neon } from '@neondatabase/serverless';

const sql = neon(process.env.DATABASE_URL!);
export const db = drizzle(sql);
```

### Middleware with proper public-path exclusion
```ts
// middleware.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

const PUBLIC_PATHS = ['/login', '/signup', '/api/auth'];

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (PUBLIC_PATHS.some(p => pathname.startsWith(p))) {
    return NextResponse.next();
  }

  const session = request.cookies.get('session')?.value;
  if (!session) {
    return NextResponse.redirect(new URL('/login', request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|api/auth|.*\\..*).*)',
  ],
};
```

### Route Handler in 15 (no longer cached by default)
```ts
// app/api/posts/route.ts
import { NextResponse } from 'next/server';

export async function GET() {
  const posts = await db.select().from(postsTable);
  return NextResponse.json(posts);
}

// To cache this route's GET output:
// export const dynamic = 'force-static';
// export const revalidate = 3600;
```

---

## Part 6 — The Investigation Checklist (when you do not know where to start)

Walk this list top to bottom. Do not skip steps even if you "feel" you know the answer.

1. What is the **exact** error message and stack trace? (Quote it verbatim if writing it down.)
2. Did this work before? What changed? Run `git log --oneline -10` and `git diff HEAD~1`.
3. What is the Next.js version? Open `package.json`.
4. Does it reproduce locally with `next dev`?
5. Does it reproduce locally with `next build && next start`? (Many bugs only appear here.)
6. Does it reproduce in production deployment?
7. Which file does the stack trace point to? **Open and read that file in full**, not just the failing line.
8. Which boundary is the bug on (server / client / edge / build / hydration)?
9. Have you formed one specific hypothesis with a falsifiable test?
10. Have you verified the hypothesis **before** changing code?

If steps 1–9 do not reveal it: **isolate**. Comment out half the failing file. Repeat the binary search.

---

## Part 7 — Output discipline when reporting a fix

When you have found and fixed the bug, report it in this shape:

1. **Bug:** one sentence stating what was wrong.
2. **Cause:** one sentence stating *why* it was wrong (which Next.js rule it violated).
3. **Fix:** the minimal code change, with a diff or a clearly marked before/after.
4. **Verify:** how the user can confirm the fix worked (a specific action and expected result).

Do not pad. Do not narrate the journey. The user wants the bug dead, not a memoir.

---

## Final principle

A Next.js 15 bug is almost always one of: an unawaited Promise (Part 2A), a misclassified component boundary (Part 4), a stale caching assumption (Part 2B), or a Node API used in Edge runtime (Part 3). When stuck, check those four first in that order. They cover the majority of real-world failures.
