# Motion Vocabulary

A shared naming reference so motion-hive's own output — and any cross-references from
cave-man or plainsight — names an effect precisely instead of describing it vaguely
("that bouncy thing" → **Pop in**). Use these terms in MOTION.md, in AUDIT findings, and
in code comments above the variant they name.

## Entrances & exits
- **Fade in / Fade out** — opacity change only.
- **Slide in** — enters from off-screen (left/right/top/bottom).
- **Scale in** — grows from smaller to full size, usually paired with a fade.
- **Pop in** — appears with a slight overshoot, like it bounces into place.
- **Reveal** — uncovered gradually via an animated `clip-path` or mask.

## Sequencing
- **Stagger** — several items animate one after another with a small delay between each.
- **Orchestration** — deliberately timing multiple animations so they read as one motion.
- **Fill mode** — whether an element keeps its first/last-frame styles outside the animation's active range (`forwards`).

## Transitions between states
- **Crossfade** — one element fades out as another fades in, same spot.
- **Continuity transition** — a change that keeps the user oriented by visually connecting before/after (e.g. the same rectangle resizing).
- **Shared element transition** — an element travels and transforms from one position to another (a thumbnail expanding into a card).
- **Layout animation** — a size/position change animates to its new spot instead of snapping.
- **Direction-aware transition** — content slides one way going forward, the opposite way going back, so navigation has a sense of direction.

## Scroll
- **Scroll reveal** — elements fade/slide into place as they enter the viewport.
- **Scroll-driven animation** — progress tied directly to scroll position, not time.
- **Parallax** — background and foreground move at different speeds while scrolling.

## Feedback & interaction
- **Press / Tap feedback** — a subtle scale-down on click, so the element feels physical.
- **Rubber-banding** — resistance and snap-back when dragged past a boundary (iOS overscroll feel).
- **Ripple** — a circle expanding from the tap point, confirming the press.

## Easing
- **Ease-out** — starts fast, ends slow. Default for anything responding to the user.
- **Ease-in-out** — slow, fast, slow. Good for elements already on screen moving A to B.
- **Linear** — constant speed. Reserve for spinners/marquees only, never general UI.
- **Asymmetric easing** — accelerates and decelerates at different rates; feels more alive than a symmetric curve.

## Spring animation (the physics-based alternative to fixed-duration easing)
- **Damping** — how quickly a spring settles. Lower damping = more bounce and oscillation. `1.0` = critically damped, no overshoot.
- **Response** — how quickly the value reaches target, in seconds. Not the same thing as duration — a spring's settle time emerges from its parameters, it has no fixed duration.
- **Momentum / Velocity** — motion that carries speed and direction, especially after a drag or interruption; a spring can carry velocity into the next animation when interrupted, an eased transition cannot.
- **Interruptible animation** — can be smoothly redirected mid-flight instead of finishing first. Springs are inherently interruptible; CSS transitions and `@keyframes` are not.

## Looping & ambient motion
- **Loop** — repeats a set number of times or infinitely.
- **Float** — a gentle, continuous up-and-down drift, makes a static element feel alive.
- **Idle animation** — subtle motion while an element sits waiting for interaction.
- Reserve looping/ambient motion for elements that are genuinely idle or genuinely live — a decorative loop with no functional referent is a slop tell (see ui-ux-designer's AI Tells Detector: pulsing status dot, decorative blinking cursor, auto-scrolling marquee).

## Principles to reason with (not just name)
- **Purposeful animation** — motion should orient, give feedback, or show a relationship, not just decorate.
- **Anticipation** — a small wind-up in the opposite direction before a move, hinting at what's about to happen.
- **Follow-through** — parts of an element keep moving and settle slightly after the main motion stops, adding weight.
- **Perceived performance** — the right animation can make an interface feel faster even when it isn't — but the wrong one (see: content invisible at rest, ui-ux-designer's Structural QA tells) makes it feel broken.
- **Frequency of use** — the more often a user sees an animation, the shorter and subtler it should be.
- **Spatial consistency** — animate so an element keeps its identity and position across states; users should never lose track of where something went.
