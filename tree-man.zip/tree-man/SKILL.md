---
name: tree-man
description: >
  Generates the canonical page/route manifest (SITETREE.md) for a new project — a human-readable nested tree plus a machine-readable per-route table covering path, type, auth level, purpose, and nav parent. ALWAYS use right after Singularity commits BRAIN.md and before Council PRE-BUILD convenes — tree-man is Phase 2.5 of the PRE-build pipeline (Singularity → tree-man → Council PRE-BUILD → repo-maintainer → build). Trigger phrases: "tree-man", "sitemap", "route manifest", "page tree", "map the routes", "what pages does this need", or whenever BRAIN.md was just committed and Council hasn't convened yet. For club sites, defer entirely to club-web-planner's own route output instead of re-deriving it — reformat, never duplicate. SITETREE.md becomes a fifth living doc kept in sync afterward by repo-maintainer's "update repo" trigger, not by tree-man. Do NOT use mid-build for one new page — that's a PLANNER.md edit via repo-maintainer, not a tree-man run.
---

# Tree-Man

**Purpose:** produce one canonical, never-improvised page/route manifest before Council reviews the architecture — so Council critiques actual routes instead of a vague idea, and every later skill (Sentinel, Airborne, task-planner) has a single source of truth for what pages exist and who is allowed to see them.

**Not to be confused with `sitemap.xml` / `app/sitemap.ts`.** That is Airborne's job — a machine-readable file for search engines, listing only indexable public routes. SITETREE.md is a planning document for humans and Claude instances, covers every route including authenticated and admin ones, and exists before a single line of code is written. Airborne reads SITETREE.md as its starting route list when generating the actual `sitemap.xml` later — the two are related but never the same file.

## Position in the pipeline

```
Singularity (BRAIN.md) → tree-man (SITETREE.md) → Council PRE-BUILD → repo-maintainer → build begins
```

Runs once per project, immediately after BRAIN.md is committed. Does **not** run mid-build — adding one page later is a `repo-maintainer` edit to an existing SITETREE.md, not a tree-man re-run.

---

## Step 0 — Check for an existing route source

Before drafting anything:

- If this project came through **club-web-planner**, its Step 3 already produced a route list and a folder tree with route groups. Read that output directly. **Reformat it into SITETREE.md — do not re-derive routes from scratch.** Tree-man's job here is canonicalization into the standard format, not duplicate work.
- Otherwise, continue to Step 1.

---

## Step 1 — Draft the manifest from BRAIN.md

Read `BRAIN.md`. Singularity already extracted the target user, the core user action, and any locked decisions — use them to draft a first-pass route list without a multi-round interview. Cover at minimum:

- Every public-facing page (landing, pricing, auth screens)
- Every authenticated page the core user action actually requires
- Any admin/internal page — only if BRAIN.md implies one. Do not invent admin surfaces nobody asked for.

Show Fahim the draft as a flat list, one line per route: `path — purpose — auth level`. Ask once: "Anything missing or wrong here?" This is a confirmation pass, not an interview.

**Project size is not an exemption.** A single-page utility tool with one API route still gets a SITETREE.md — even if it's two rows. The value isn't manifest length, it's that drafting it forces the architecture decision (what the route actually does, what it depends on) to get written down in BRAIN.md before code starts. Skipping PRE phase because a project "looks too small to bother" is exactly how a doc-vs-code mismatch ships unnoticed later — there's no audit step left to catch a decision that was never recorded anywhere.

---

## Step 2 — Write SITETREE.md

Use `references/sitetree-template.md`. Every route gets, at minimum:

| Field | Required | Notes |
|---|---|---|
| Path | yes | exact route, e.g. `/dashboard/settings` |
| Type | yes | `page` \| `route group` \| `API route` \| `layout` |
| Auth level | yes | `public` \| `authenticated` \| `admin` \| `role:[name]` — this is the field Sentinel later verifies against the actual code |
| Purpose | yes | one line |
| Parent | yes | nav/hierarchy parent path, or `—` for top-level |
| Status | yes | always `planned` at creation — repo-maintainer updates this as pages get built and verified |

Output both halves into the same file:
1. A human-readable nested tree (markdown, indented by parent) at the top
2. The full route table below it — the form other skills parse programmatically

Commit `SITETREE.md` to repo root, alongside `BRAIN.md`.

API routes (backend endpoints) do **not** belong here — those stay in PLANNER.md's existing "API Routes" table. SITETREE.md is page/UI routes only; keep the two documents from overlapping.

---

## Step 3 — Hand off to Council PRE-BUILD

Add one field to Singularity's Council context block: `SITEMAP: [path to SITETREE.md, route count, auth levels in use]`. Council needs the route structure in front of it before it delivers a verdict — that is the entire reason this runs before Council, not after.

---

## Ownership after this point

Tree-man's job ends once SITETREE.md is committed and Council has reviewed it. From here on, **repo-maintainer** owns keeping SITETREE.md in sync — it is the fifth living doc, updated under the same "update repo" trigger that already maintains PLANNER.md, DESIGN_GUIDE.md, README.md, and AGENTS.md. Tree-man itself never re-runs mid-project. If it did, this document would rot exactly the way three other pipeline documents were found to have rotted in the June 2026 skill audit: a doc nobody owns drifts from what the code actually does.

---

## Notes

- No emoji anywhere in tree-man output.
- All output is plain markdown written to `SITETREE.md` — no artifact, no widget.
- If BRAIN.md does not exist yet, stop and say: "No BRAIN.md found — run Singularity first." Tree-man never substitutes for the Singularity interview.
