# Caching Decision Tree

When the user asks "should I cache this?" or you need to invalidate cached data after a mutation, use this matrix. Next.js 16 ships three related but distinct APIs from `next/cache`: `updateTag`, `revalidateTag`, and `refresh`. Picking the wrong one shows users stale data and looks like a bug.

## The matrix

| Scenario | API | Why |
|---|---|---|
| User just submitted their own data and must see it immediately | `updateTag(tag)` | Read-your-writes: expires AND refreshes within the same request |
| Something changed that affects other users; delay is acceptable | `revalidateTag(tag, 'max')` | Stale-while-revalidate: readers see old data until next render |
| Want the client router to re-render with fresh data without invalidating the underlying tag | `refresh()` | Just nudges the router, does not touch cache |
| Cache something for N seconds | `cacheLife({ revalidate: N })` inside the cached function | Declarative lifetime |
| Tag a cached value so it can be invalidated later | `cacheTag('my-tag')` inside the cached function | Couples cache to a tag |

## Examples by use case

### Settings form (user changes their own profile)

```ts
'use server'
import { updateTag } from 'next/cache'

export async function saveProfile(userId: string, data: ProfileInput) {
  await db.users.update(userId, data)
  updateTag(`user-${userId}`)
}
```

User sees their new profile immediately on the next render. Other users continue to see whatever was cached.

### Admin publishes a blog post

```ts
'use server'
import { revalidateTag } from 'next/cache'

export async function publishPost(postId: string) {
  await db.posts.publish(postId)
  revalidateTag('posts', 'max')
}
```

Other users browsing the blog see the new post within seconds. Slight delay is fine for blogs.

### User marks a notification as read; header bell needs to update

```ts
'use server'
import { refresh } from 'next/cache'

export async function markAsRead(notificationId: string) {
  await db.notifications.markRead(notificationId)
  refresh()
}
```

Client router re-renders, fetching the latest notification count for the bell icon.

### Cached data fetcher with a tag and lifetime

```ts
import { cacheLife, cacheTag } from 'next/cache'

async function getPost(slug: string) {
  'use cache'
  cacheTag(`post-${slug}`)
  cacheLife('hours')
  return await db.posts.findUnique({ where: { slug } })
}
```

Then any `revalidateTag(`post-${slug}`, 'max')` or `updateTag(`post-${slug}`)` invalidates this.

## `cacheLife` profiles

The second argument to `revalidateTag` is a profile name. Built-in profiles (verify against current docs as values may evolve):

| Profile | Approx lifetime |
|---|---|
| `'seconds'` | very short, near-realtime |
| `'minutes'` | short |
| `'hours'` | medium |
| `'days'` | long |
| `'weeks'` | very long |
| `'max'` | indefinite, manually invalidated |

You can also define custom profiles in `next.config.ts`:

```ts
const nextConfig: NextConfig = {
  cacheLife: {
    blog: { stale: 60 * 5, revalidate: 60 * 60, expire: 60 * 60 * 24 },
  },
}
```

Then: `revalidateTag('posts', 'blog')`.

## Anti-patterns

- **Calling `revalidateTag('foo')` with one argument.** Deprecated in v16; throws a TS error. Always pass a profile.
- **Using `updateTag` outside a Server Action.** It is Server Actions only. In Route Handlers or background jobs, use `revalidateTag`.
- **Calling `refresh()` after a mutation and expecting cache to clear.** It does not — it just re-renders the client. Pair with `updateTag` or `revalidateTag` if data is cached.
- **Forgetting `'use cache'` on a function you `cacheTag` inside.** The directive is what opts the function into the cache; without it the tag does nothing.
- **Using `unstable_cacheLife` / `unstable_cacheTag` imports.** Stable in v16; drop the `unstable_` prefix.
