# Cache Components & PPR — Deep Reference

Next.js 16 unified its caching story under one config flag and one directive. The mental model is different enough from Next 14/15 that pre-2026 patterns will produce wrong behavior even when they compile.

## The mental model in one paragraph

In Next 14/15, the App Router was **static by default with dynamic escape hatches**. Calling `cookies()` or `headers()` implicitly opted the whole route into dynamic rendering. The implicit-ness was confusing — pages flipped between static and dynamic based on what you called inside them.

In Next 16 with `cacheComponents: true`, the model **inverts**: everything is dynamic by default. You opt **into** caching explicitly with the `'use cache'` directive. Static and dynamic parts coexist in the same route via `<Suspense>` boundaries — the static shell renders at build, dynamic parts stream at request time. This is Partial Prerendering, now the only PPR model.

## Enabling Cache Components

```ts
// next.config.ts
import type { NextConfig } from 'next'
const nextConfig: NextConfig = {
  cacheComponents: true,
}
export default nextConfig
```

The old flags are gone — do not use:
- `experimental.ppr` — gone
- `experimental.dynamicIO` — gone
- `experimental.useCache` — gone
- `experimental_ppr` route segment config — gone

## The `'use cache'` directive

It works at three scopes:

### File-level
```tsx
// Entire file is cached
'use cache'
export async function getProducts() { /* ... */ }
export async function getCategories() { /* ... */ }
```

### Function-level
```tsx
export async function getProduct(id: string) {
  'use cache'
  return db.products.findFirst({ where: { id } })
}
```

### Component-level
```tsx
async function ProductList() {
  'use cache'
  const products = await db.products.findMany()
  return <ul>{products.map(p => <li key={p.id}>{p.name}</li>)}</ul>
}
```

The directive must be the first statement, like `'use client'` or `'use server'`.

## Cache lifetime and tags

```tsx
import { cacheLife, cacheTag } from 'next/cache' // stable, no unstable_ prefix in 16

async function getProduct(id: string) {
  'use cache'
  cacheLife('hours')
  cacheTag(`product-${id}`)
  return db.products.findFirst({ where: { id } })
}
```

### Built-in `cacheLife` profiles
- `'seconds'` — very short-lived (10s)
- `'minutes'` — medium-short (1 hour with 5 min revalidate)
- `'hours'` — medium (1 day with 1 hour revalidate)
- `'days'` — long-lived (1 week with 1 day revalidate)
- `'weeks'` — very long (1 month with 1 week revalidate)
- `'max'` — effectively forever (1 year)

You can also define custom profiles in `next.config.ts`:
```ts
const nextConfig: NextConfig = {
  cacheComponents: true,
  experimental: {
    cacheLife: {
      'product-listing': {
        stale: 60,         // client-side: serve stale for 60s
        revalidate: 300,   // server-side: revalidate after 5 min
        expire: 3600,      // hard expiry: 1 hour
      },
    },
  },
}
```

### `cacheTag` patterns

Tags should encode what changes together. Common patterns:
- Per-entity: `cacheTag('product', \`product-${id}\`)` — invalidating `product-${id}` clears one, `product` clears all
- Per-user: `cacheTag(\`user-${userId}-orders\`)` — clears only this user's data
- Per-collection: `cacheTag('products', 'categories')` — broad sweep

Multiple tags can be passed: `cacheTag('a', 'b', 'c')`.

## Invalidation: `revalidateTag` vs `updateTag` vs `refresh`

These three solve different problems. Picking the wrong one is a common Next 16 bug.

### `revalidateTag(tag, lifeProfile)` — stale-while-revalidate

Marks the cache entry as stale. The next request gets the stale data immediately and the cache is refreshed in the background. The user **does not see their write** on the response to their own action.

```ts
'use server'
import { revalidateTag } from 'next/cache'

export async function publishPost(id: string) {
  await db.posts.update({ where: { id }, data: { published: true } })
  revalidateTag(`post-${id}`, 'max') // second arg required in Next 16
}
```

Use for: blog posts, product catalogs, docs, marketing pages — anywhere a slight propagation delay is acceptable.

### `updateTag(tag)` — read-your-writes

Expires the cache immediately within the same request. The user's response **already reflects their write**. Server Actions only.

```ts
'use server'
import { updateTag } from 'next/cache'

export async function updateProfile(userId: string, data: ProfileData) {
  await db.users.update({ where: { id: userId }, data })
  updateTag(`user-${userId}`)
}
```

Use for: forms, settings, anything where the user clicks Save and expects to see the change.

### `refresh()` — refresh the client router

Refreshes the current route on the client without invalidating any cache tags. Like a router-level "re-fetch the data we have."

```ts
'use server'
import { refresh } from 'next/cache'

export async function markNotificationAsRead(id: string) {
  await db.notifications.update({ where: { id }, data: { read: true } })
  refresh()
}
```

Use for: small interactions where you want the UI to re-pull but no specific cache tag is affected.

### Decision table

| Situation | Use |
|---|---|
| User just clicked "Save" on a form | `updateTag` |
| Editor published a blog post; readers see updates eventually | `revalidateTag('posts', 'max')` |
| User marked a notification read; refresh the count badge | `refresh()` |
| Admin updated a product; show all viewers in ~5 min | `revalidateTag(\`product-${id}\`, 'minutes')` |
| Cache-busting after a webhook | `revalidateTag('content', 'max')` |

## The `<Suspense>` requirement

With `cacheComponents: true`, dynamic data **must** be wrapped in `<Suspense>`. The error `Uncached data was accessed outside of <Suspense>` means a component is reading request-time data (cookies, headers, uncached fetches, awaited params) without a Suspense boundary above it.

```tsx
// Wrong — page is rendered as if static, but reads cookies
export default async function Page() {
  const c = await cookies()
  return <div>Hello {c.get('name')?.value}</div>
}

// Right — static shell, dynamic part in Suspense
export default function Page() {
  return (
    <div>
      <h1>Welcome</h1>
      <Suspense fallback={<span>Loading…</span>}>
        <Greeting />
      </Suspense>
    </div>
  )
}

async function Greeting() {
  const c = await cookies()
  return <>Hello {c.get('name')?.value}</>
}
```

The fallback should be visually similar to the final content to avoid layout shift.

### Pattern: passing a promise into a child

A clean way to keep async data inside Suspense without prop-drilling resolved values:

```tsx
export default async function Page(props: PageProps<'/map'>) {
  const coords = props.searchParams // a Promise — pass it through, don't await here
  return (
    <Suspense fallback={<span>Loading map…</span>}>
      <Map coords={coords} />
    </Suspense>
  )
}

async function Map({ coords }: { coords: Promise<{ lat: string; lng: string }> }) {
  const { lat, lng } = await coords // awaited inside the Suspense boundary
  const data = await fetch(`https://api/map?lat=${lat}&lng=${lng}`).then(r => r.json())
  return <pre>{JSON.stringify(data)}</pre>
}
```

## Debugging cache misses

### Symptom: data is stuck on stale values

1. Is the data source cached? Look for `'use cache'` in the function or file.
2. What tags does it carry? Look for `cacheTag(...)`.
3. Is something invalidating those tags? Search the codebase: `grep -rn "revalidateTag\|updateTag" app/ src/`
4. Is the tag string a literal match? `revalidateTag('product-${id}')` (literal) won't match `cacheTag(\`product-${id}\`)` (template) — they're different strings.
5. Is the `cacheLife` profile too long? `'max'` is a year; consider downgrading.
6. If the user expects to see their write immediately, you probably want `updateTag` not `revalidateTag`.

### Symptom: data is recomputed every request

1. Is `'use cache'` actually at the top of the function/file?
2. Did you accidentally read request-time data (`cookies`/`headers`) inside a cached function? That opts it out — uncached request APIs are not allowed inside `'use cache'`.
3. Is the function being called with arguments that always differ? Cache keys include the arguments. `getData(new Date())` will miss every time.

### Symptom: hydration mismatch after enabling `cacheComponents`

The static shell ships without dynamic data. The client tries to hydrate and finds the dynamic content. Wrap every dynamic branch in `<Suspense>`, ensuring the fallback shape matches what arrives.

### Use `next build --debug-prerender`

When the build error is opaque ("blocking-route" or "Uncached data" with no component name), this flag emits stack traces that name the exact component:

```bash
next build --debug-prerender
```

## Migration from Next 15 PPR (`experimental_ppr`)

If you used route-level `experimental_ppr` in Next 15:

```tsx
// Before (Next 15)
export const experimental_ppr = true

export default async function Page() {
  // dynamic parts implicitly inside Suspense
}
```

Move to:

```tsx
// After (Next 16)
// next.config.ts: cacheComponents: true (global)
// no route-level flag needed

export default async function Page() {
  return (
    <>
      <StaticShell />
      <Suspense fallback={<Skeleton />}>
        <DynamicPart />
      </Suspense>
    </>
  )
}
```

The route-segment flag is gone — there is no per-route opt-in anymore. Once `cacheComponents` is on, it applies globally and you control granularity via `'use cache'` and `<Suspense>`.

## `unstable_` prefix removal

These imports are now stable in Next 16. Drop the prefix:

```ts
// Before
import {
  unstable_cacheLife as cacheLife,
  unstable_cacheTag as cacheTag,
} from 'next/cache'

// After
import { cacheLife, cacheTag } from 'next/cache'
```

`unstable_cache` itself is deprecated — migrate to `'use cache'` directive. The codemod covers most of this.
