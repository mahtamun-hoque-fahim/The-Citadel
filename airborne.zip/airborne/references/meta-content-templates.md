# Meta Content Templates

> **LearnDE examples are illustrative only.** Replace brand name, domain, and niche-specific terms with the current project's own before using any template verbatim.

Production-ready patterns for meta titles, descriptions, and page copy. Every template here is tested against SERP behaviour — they are not theoretical.

**Read `references/tone-modes.md` first.** Every template below has a default tone (noted per page-type playbook). Apply the tone rules from that file when filling in templates.

---

## Tone Reference (quick)

| Tone | Where it applies | Voice |
|---|---|---|
| **SEO-First** | Blog, guides, glossary, FAQ, study | Informational, answer-shaped, keyword-anchored |
| **Marketing-First** | Pricing, signup, hero blocks, comparison, CTAs | Active, benefit-led, verb-led CTAs, honest urgency |
| **User-First** | Dashboard, settings, errors, account, in-app | Plain, supportive, low-jargon, lean meta |
| **Best Mix** | Homepage, key landings, product detail | Layered: marketing hero → SEO body → marketing close |

Full rules and worked examples in `references/tone-modes.md`.

---

## Meta Title — The Rules

- **Length:** 50–60 characters. Google truncates around 60.
- **Structure:** Primary keyword in the first half. Brand at the end after a separator.
- **Separator:** Use ` — ` (em dash) or ` | ` (pipe). Pick one and stay consistent across the site.
- **Tone:** Specific over generic. "Free DELF B2 Practice Tests with Native Tutor Feedback" beats "DELF B2 Practice Tests".
- **One unique title per page.** Duplicate titles are an SEO bug.
- **Sentence case** unless the brand uses Title Case officially.

### Proven Title Patterns

| Pattern | Example | When to use |
|---|---|---|
| `[Primary KW] — [Differentiator] \| [Brand]` | `DELF B2 Practice Tests — Built by Native Tutors \| LearnDE` | Homepage, primary landing |
| `[Number] [Thing] for [Audience] (in [Year])` | `7 DELF B2 Writing Templates for Bangladeshi Students (2026)` | Listicle blog posts |
| `How to [Verb] [Object]: [Specific Outcome]` | `How to Pass DELF B2: Score 16/20 in 8 Weeks` | How-to blog posts |
| `[Tool Name]: Free [Function] for [Audience]` | `DSH Practice Test: Free Online Mock Exam for German Students` | Free tool pages |
| `[Primary] vs [Competitor]: [Decision Angle]` | `Neon vs Supabase: Which Postgres Is Right for Next.js?` | Comparison pages |
| `[Primary KW] \| [Brand]` | `Pricing \| LearnDE` | Pure navigational pages (about, pricing, contact) |

### Anti-patterns to avoid

- `Home — LearnDE` (label, not copy)
- `Welcome to Our Site` (zero keyword value)
- `LearnDE \| LearnDE \| Best Platform Ever` (brand stuffing)
- `🚀 The #1 DELF Platform 🎯` (emojis — banned anyway; also reduces CTR for serious queries)
- `DELF, DELF B2, DELF practice, DELF tests, French exam` (keyword stuffing)

---

## Meta Description — The Rules

- **Length:** 150–160 characters. Mobile truncates earlier (~120), so front-load value.
- **Must include:** primary keyword (once, naturally), value proposition, action verb
- **Tone:** active voice, second person ("you"), benefit-oriented
- **No duplicate descriptions** across pages

### Description Templates

| Pattern | Example |
|---|---|
| Problem + solution + CTA | `Stuck on DELF B2 writing? Get 50+ sample essays with line-by-line feedback from native tutors. Start your free practice test today.` |
| Number + specificity + outcome | `7 production-ready DELF B2 writing templates used by students who scored 16+. Free download, no signup required.` |
| Comparison + clarity | `Neon and Supabase both offer Postgres, but they solve different problems. Compare pricing, latency, and DX in 3 minutes.` |
| Tool + benefit + free | `Free DSH mock exam with automatic scoring. Practice all 4 sections, get a detailed score report in under 60 minutes.` |

---

## Page-Type Playbooks

### Homepage — Tone: Best Mix

Structure:
- **Meta title:** `[Primary value prop with keyword] | [Brand]` (SEO discipline)
- **Meta description:** 1-line problem, 1-line solution, 1 CTA verb (SEO + click)
- **H1:** Bold value proposition with the primary keyword woven in. Not "Welcome". (Marketing layer)
- **Hero subhead:** 1 sentence, 15–25 words, who it's for + what they get. (Marketing layer)
- **Below-fold H2s:** each one targets a secondary keyword and answers a top searcher question. (SEO layer)
- **Final CTA block:** verb-led primary CTA + objection handler. (Marketing layer)
- **Schema:** `Organization` + `WebSite` (with SearchAction if there's site search) + relevant content schema (Course, Product, etc.)

Example (LearnDE):

```
Meta title (58 chars): DELF, DSH & TestDaF Prep Built by Native Tutors | LearnDE
Meta description (157 chars): Prepare for DELF, DSH, or TestDaF with timed mock exams, sample answers, and feedback from native tutors. Free practice test, no card required.

H1: Pass your French or German exam with native-tutor-built prep
Subhead: Timed mocks, real sample answers, and tutor feedback — built for Bangladeshi students preparing for DELF, DSH, and TestDaF.
```

See `references/tone-modes.md` → "Tone 4 — Best Mix" for the full layered example.

### Blog Post — Tone: SEO-First

Structure:
- **Meta title:** Front-load the long-tail keyword. Year tag if the topic dates.
- **Meta description:** Promise the specific takeaway and how long it takes to read.
- **H1:** Matches the meta title closely but written for humans
- **Opening paragraph:** answer-shaped — answer the title's implied question in the first 1–2 sentences. Crawlers and AI Overviews pick this up.
- **H2 outline:** answers each sub-question in the long-tail cluster
- **First 100 words:** Primary keyword appears naturally, set the stakes, preview the answer
- **FAQ block at bottom:** captures long-tail questions verbatim
- **Schema:** `Article` + `BreadcrumbList`. Add `FAQPage` if there's a Q&A block.

### Product / Landing Page (Commercial intent) — Tone: Marketing-First (with SEO meta)

Structure:
- **Meta title:** Primary keyword + biggest differentiator
- **Meta description:** Outcome-led, includes price point or "free" if applicable
- **H1:** Outcome the user gets, not the product name. ("Pass DELF B2 in 8 weeks" not "DELF B2 Course")
- **Hero CTAs:** verb-led, specific (`Start your free mock` not `Get started`)
- **H2s:** features grouped by user job-to-be-done, not by feature list
- **Social proof:** specific numbers when true, testimonials otherwise. Never fake.
- **Objection handling:** placed near the primary CTA. Only true statements ("No card required").
- **Schema:** `Product` (if pricing exists) or `SoftwareApplication`. Include `aggregateRating` only if real reviews exist.

### Pricing Page — Tone: Marketing-First (with SEO meta)

Structure:
- **Meta title:** Include the actual price points if cheap-to-mid (helps qualified clicks): `Pricing — Free Mocks, ৳1,499 Bundles, ৳4,999 Full Course | LearnDE`
- **Meta description:** What each tier costs, in one line
- **H1:** Outcome framing ("Pick the prep that fits your timeline") not "Pricing"
- **Plan cards:** name, price, 3–5 bullet outcomes per plan, verb-led CTA per plan
- **Below cards:** money-back / no-card statements only if true
- **Schema:** `Product` per plan with `Offer`, `priceCurrency`, `price`, `availability`

### Comparison / "vs" Page — Tone: Marketing-First (with SEO meta)

Structure:
- **Meta title:** `[Thing A] vs [Thing B]: [Decision angle]`
- **Meta description:** State the verdict or the deciding factor
- **H1:** The question searchers actually ask
- **Structure:** comparison table near the top, then a section per dimension, then a "which to pick" decision tree
- **Schema:** `Article`

### Study / Research Page — Tone: SEO-First

Structure:
- **Meta title:** `[Topic]: [Methodology Tag] Study (Year)` — e.g. `Remote Work in Bangladesh: 2026 Survey of 1,200 Workers`
- **Meta description:** Sample size, key finding, who it's for
- **H1:** Headline finding, not the topic
- **H2s:** abstract, methodology, key findings, full data, citation
- **Schema:** `Article` with `author`, `datePublished`, plus `Dataset` if raw data is downloadable

### Free Tool Page — Tone: Best Mix (free tool + SEO surface)

Structure:
- **Meta title:** `Free [Function]: [Specific Benefit]` — keep "free" in the title
- **Meta description:** What it does + that it's free + no signup if true
- **H1:** Action-oriented — "Check your DELF B2 readiness in 5 minutes" (Marketing layer)
- **Tool UI itself:** User-First copy on buttons, errors, results
- **H2s below the tool:** how it works, who it's for, FAQs (SEO layer)
- **Schema:** `SoftwareApplication` with `applicationCategory: "UtilityApplication"` and `offers.price: "0"`

### Dashboard / App Surface — Tone: User-First

Structure:
- **Meta title:** `[Section] — [Brand]` (just enough for the browser tab)
- **Meta description:** May be empty; the page is `noindex` anyway
- **Robots:** `noindex, nofollow` (logged-in surface)
- **H1:** Plain section label ("Your prep dashboard")
- **Greeting:** "Welcome back, [name]." or just the user's first name
- **Section copy:** state-first ("Your next session is on Tuesday, 28 May at 7:00 PM")
- **Empty states:** present-perfect-negative + verb-led next step ("You haven't taken a mock exam yet. Start your first one.")
- **Error states:** what went wrong + cause + retry path
- **No schema** (waste of crawl budget on noindex pages)

### Settings / Account — Tone: User-First

Structure:
- **Meta title:** `Account settings — [Brand]`
- **Robots:** `noindex, nofollow`
- **H1:** Plain ("Account settings", "Notification preferences")
- **Section labels:** descriptive ("Email and password", "Subscription and billing")
- **Form labels:** what the field is, plainly ("Email address", not "Your contact email")
- **Validation messages:** specific ("This email is already registered. Sign in instead?")
- **Confirmations:** short and reassuring ("Saved." / "Password updated.")

### Login / Signup / Auth — Tone: Marketing-First (often noindex)

Structure:
- **Meta title:** `Sign up — Free [thing] | [Brand]` or `Log in to [Brand]`
- **Robots:** signup pages are usually `index` (Marketing); login pages usually `noindex` (private)
- **H1:** Outcome-framed for signup ("Start your free mock exam"), plain for login ("Log in")
- **Form:** as few fields as possible. Each field labeled plainly.
- **Submit button:** verb + value ("Create your free account", not "Sign up")
- **Below form:** trust signal ("No card required. Cancel anytime.") — only if true
- **Schema:** none (auth pages don't benefit)

### 404 / Error Pages — Tone: User-First

Structure:
- **Meta title:** `Page not found — [Brand]`
- **Robots:** 404 returns proper 404 status; do not `noindex` (Google handles 404s natively)
- **H1:** "We couldn't find that page."
- **Body:** brief explanation + 2–3 links back to useful pages (home, blog, search)
- **No marketing copy.** A 404 is not a conversion opportunity.

### Legal / Privacy / Terms — Tone: User-First

Structure:
- **Meta title:** `Privacy Policy | [Brand]`, `Terms of Service | [Brand]`
- **Robots:** `index, follow` (these should be indexable for trust)
- **H1:** Plain ("Privacy Policy", "Terms of Service")
- **Body:** Plain language, scannable, with section H2s. No marketing voice.
- **Schema:** none required

---

## H1 Discipline

- Exactly **one** H1 per page. Multiple H1s split ranking signals.
- The H1 must contain the primary keyword (or a near-variant).
- The H1 is for **humans first** — readable, benefit-oriented. Keyword fits *inside* the sentence, not bolted on.
- Do not duplicate the meta title verbatim; they serve different surfaces.

Good: `Pass DELF B2 with mock exams and tutor feedback`
Bad: `DELF B2 Practice Tests` (label, not copy — fine for meta title, weak for H1)

---

## Body Copy Principles

1. **Primary keyword appears in the first 100 words.** Naturally.
2. **Secondary keywords appear in their owning H2 section.** Don't sprinkle randomly.
3. **Long-tail keywords answered in FAQ-style sub-sections** at the bottom of the page.
4. **Active voice, second person.** "You can submit your essay" beats "Essays can be submitted".
5. **No keyword stuffing.** If a sentence would be better without the keyword, omit the keyword.
6. **Specific over abstract.** "Scored 16/20 in 8 weeks" beats "Improve your scores fast".
7. **Avoid AI writing tells.** No "delve", no "in today's fast-paced world", no rule-of-three sentences in every paragraph. See the `humanizer` skill if heavy revision is needed.

---

## Internal Linking — Anchor Text

- Use **descriptive anchor text** that matches the target page's keyword. Avoid "click here", "read more".
- 3–5 internal links per long-form page is the sweet spot.
- Link from high-traffic pages **to** new pages to pass authority.
- Linking should feel natural in the prose, not bolted into a sidebar list.

Output format in the report:

```
Internal links for /blog/delf-b2-writing-templates:
- Anchor: "DELF B2 practice tests" → /exams/delf-b2
- Anchor: "DELF B2 scoring guide" → /blog/how-delf-b2-is-scored
- Anchor: "book a tutor session" → /tutors
```

---

## Image Alt Text

- Describe the image **content**, not the image **purpose**
- Keyword inclusion is fine when it accurately describes the image; do not force it
- Decorative images get `alt=""` (empty, not omitted)
- Max ~125 characters

Good: `Student taking a timed DELF B2 mock exam on LearnDE dashboard`
Bad: `image1.png` or `DELF DELF B2 practice exam test French language learning Bangladesh`

---

## URL Slug Rules

- Lowercase, hyphenated, no underscores
- Strip stop words unless they change meaning (`how-to-pass-delf-b2` is fine; `the-best-delf-platform` → `best-delf-platform`)
- Keep under 60 characters where possible
- Match the primary keyword closely
- No dates in slugs for evergreen content (you'll want to update without changing the URL)
- No IDs or query params if avoidable (`/posts/42` is worse than `/blog/pass-delf-b2`)
