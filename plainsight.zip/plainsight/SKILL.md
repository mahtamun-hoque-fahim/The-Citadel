---
name: plainsight
description: >
  IMPLEMENTATION skill for Next.js (App Router) + Tailwind CSS. Write and fix
  code — not critique. For design critique or accessibility audits, use
  ui-ux-designer first, then come back here to implement. "Review and fix" =
  ui-ux-designer critique pass THEN plainsight, never both at once. Use for:
  building pages, dashboards, forms, navigation, modals, tables, marketing
  sites, auth screens, admin panels, or fixing broken layouts. Two modes:
  BUILD (generate from patterns) and FIX (diagnose and minimally patch).
  Catches: centering lies, hero void, CTA drift, grid collapse, marquee
  clipping, sticky failures, dropdown clipping, modal z-index wars, table
  overflow, hydration mismatches, Tailwind v3-vs-v4 mixing, Next 15+ async
  params errors, unnecessary use-client directives.
  In BUILD mode: reads SITETREE.md Layout Architecture section before writing
  the first component — section-sequence is the required build order, not a
  suggestion. Runs the AI tells detector against its own output before presenting.
  Commands: "polish [target]", "typeset [target]", "distill [target]".
---

# plainsight

A universal fixer and builder for any Next.js + Tailwind project. Two modes:

- **BUILD** — generating a new page, section, or component. Start from `patterns/` and apply rules from the start.
- **FIX** — patching an existing broken layout. Start from `symptoms.md`, then apply the minimal change from `fixer-protocol.md`.

This skill assumes nothing about the project's aesthetic, color palette, or component library. The code patterns use Tailwind's default neutral palette (`bg-neutral-950`, `text-neutral-100`, etc.); swap for the project's tokens (`bg-background`, `text-foreground`, shadcn variables, or custom colors) without changing the structure. The structural rules are universal.

## Scope — implementation only

Plainsight writes and fixes code. It does not critique designs, audit UX, or produce feedback reports. If you need critique, use **ui-ux-designer** first; once you have prioritised fixes, come back here to implement them.

**"Review and fix this UI"** is a two-step task:
1. **ui-ux-designer** → critique pass (WCAG, Fitts, layout issues, token violations)
2. **plainsight** → implementation pass (apply the fixes in code)

Running plainsight alone on a "review" request will produce a refactored layout without any guarantee the underlying UX problems are solved — or worse, it will introduce new problems while fixing the visible ones.

---

## Choose your mode

**BUILD mode** — when generating something new:
1. Check if `SITETREE.md` exists and has a Layout Architecture entry for this route. If it does, the `section-sequence` is the required build order — build every section in the sequence in order. Do not abbreviate, re-order, or invent sections not listed. The `layout-family` determines which pattern file to open.
2. Open the matching file in `patterns/` using the layout-family → patterns mapping below.
3. Copy the CORRECT example, adapt content and colors.
4. Run the anti-slop check (see below) against output before presenting it.
5. Run `checklist.md` § Build before declaring done.
6. **Hand off to motion-hive before calling the page done.** Read `SITETREE.md`'s project-level `MOTION_INTENSITY` dial. If it's >= 4, motion-hive BUILD mode runs next on the page just scaffolded — treat this as part of finishing the page, not a separate later request. Only skip it when MOTION_INTENSITY <= 3 (form-heavy/data-tool pages, which cap low by tree-man's own derivation rules) or when `SITETREE.md` doesn't exist at all.

**FIX mode** — when patching something broken:
1. Describe the visual symptom in one sentence
2. Look it up in `symptoms.md`
3. Apply the minimal patch from `fixer-protocol.md`
4. Run `checklist.md` § Fix before declaring done

**SITETREE.md layout-family → patterns/ mapping:**

| layout-family | Primary pattern file |
|---|---|
| `marketing` | `patterns/layouts.md` § Marketing — section-sequence drives build order |
| `dashboard` | `patterns/layouts.md` § Dashboard — sidebar always persistent, never hamburger |
| `editorial` | `patterns/layouts.md` § Editorial — body max 72ch, no image zones in body |
| `card-grid` | `patterns/data-display.md` § Card grid — filter bar always present |
| `form-wizard` | `patterns/forms.md` — one CTA per screen, no decorative elements |
| `split-screen` | `patterns/layouts.md` § Split — alternation direction set by first split |
| `bento` | `patterns/layouts.md` § Bento — max 2 cell sizes, hero cell always largest |
| `minimal` | `patterns/layouts.md` § Minimal — no nav, no motion, entire page above fold |

## The twelve failure modes

These are the bugs you ship by default unless you actively prevent them. Each is preventable; each has a named symptom in `symptoms.md`.

1. **Centering lies.** `text-center` on a parent does nothing if the child has its own `max-w-*` and no `mx-auto`. The text reads centered in your head; it renders left-aligned in a narrow column anchored to the left edge.
2. **Hero void.** `min-h-screen flex items-center` plus a fixed header centers the hero in the *full* viewport, leaving a header-sized void above the fold.
3. **CTA drift.** Buttons written inline after a paragraph (`<p>...</p><a/><a/>`) inherit the paragraph's text flow and land beside the last line instead of stacking below it.
4. **Grid collapse.** `grid grid-cols-4` looks right in code but renders 1-column on every viewport when the parent is a `flex flex-col items-center` with no width, or when responsive prefixes are missing.
5. **Marquee clipping.** A scrolling ticker without duplicated content and matching animation math clips characters at one or both edges.
6. **Sticky failures.** `sticky top-0` does nothing when any ancestor has `overflow-hidden`, `overflow-auto`, or `overflow-scroll`. The element silently scrolls away.
7. **Dropdown clipping.** A dropdown menu mounted inside a card with `overflow-hidden` gets cut off at the card edge. The menu opens, you just can't see most of it.
8. **Modal stacking.** Backdrop without `fixed inset-0`, body scroll not locked, z-index lower than a sticky header, or no focus trap. Pick any one and the modal is broken.
9. **Card-height ragged.** Cards in a grid with different content lengths produce a ragged bottom edge. Cause: missing `h-full` on the card or `items-stretch` on the grid (which is default but easy to override).
10. **Text overflow blowout.** Long usernames, URLs, or filenames push their container wider than intended, breaking the whole row. Cause: no `truncate`, no `min-w-0` on flex children, no `break-words`.
11. **Sidebar/main mismatch.** Fixed sidebar + main with no left padding/margin = sidebar overlaps content. Or sidebar without mobile collapse strategy = sidebar covers everything on phones.
12. **Hydration mismatch.** Server-rendered HTML differs from first client render — `Date.now()`, `Math.random()`, browser-extension attributes on `<body>`, or `localStorage` reads outside `useEffect`.
13. **Edge-flush cards in a scroller.** Cards inside a horizontal scroller or tab panel sit flush against the container edge on one side while keeping a gutter on the other, so their edge and any rounded corner get clipped. Cause: the scroll panel is sized wider than its clip box. Keep a consistent inset on both sides.
14. **Text occlusion.** A decorative box, a stacked layer, or an inline element with leaked padding lands on top of text instead of beside it. Cause: overlapping layers with no reserved space for the text underneath. Give the text room, or move it out from under the layer above it.

## Non-negotiable rules

**R1. Every section has a container.** A `<section>` handles vertical rhythm and background; an inner `<div className="mx-auto max-w-* px-*">` handles horizontal bounds. Never collapse them.

**R2. Centering requires three things together.** Block-level centering needs `mx-auto` AND `max-w-*`. Text wrap inside needs `text-center`. Forgetting any of the three is the #1 cause of "looks broken" generations.

**R3. Button groups are flex containers.** Never write `<p>subtitle</p><a/><a/>` as siblings. Always wrap CTAs in `<div className="flex flex-col sm:flex-row gap-3 ...">`. Same for any group of buttons, links, or controls that should sit together.

**R4. Overflow ancestors break sticky and dropdowns.** Before adding `sticky` or a popover/menu, audit ancestors for `overflow-*`. If any ancestor has it, sticky won't stick and the menu will clip. Either remove the overflow, change positioning to `fixed`, or portal the menu to `<body>`.

**R5. Modals need four things.** `fixed inset-0` backdrop, `z-50` (above all sticky/fixed UI), body scroll lock while open, focus trap. If using shadcn/Radix Dialog, all four are handled. If hand-rolling, do all four explicitly.

**R6. Flex children that can shrink need `min-w-0`.** Flex items default to `min-width: auto`, which means they refuse to shrink below their content size. Long text inside a flex child breaks layouts. Add `min-w-0` to any flex child containing text that might be long, plus `truncate` on the text element itself.

**R7. Grid cards stretch by default; protect it.** Use `h-full` on the card root so even if a parent overrides `items-stretch`, the card fills its grid track. Combine with `flex flex-col` inside the card to push footers (buttons, metadata) to the bottom with `mt-auto`.

**R8. Server is default; client is opt-in.** Add `"use client"` only when the file uses `useState`, `useEffect`, event handlers, refs, or browser APIs. Hero sections, feature grids, footers, tables of static data, and marketing copy are server components.

**R9. Tailwind v3 or v4 — pick one, check `package.json` first.** v4 uses `@import "tailwindcss"` and `@theme`; v3 uses three `@tailwind` directives and `tailwind.config.ts`. Mixing the two produces an unstyled page with no error.

**R10. No emojis. Anywhere.** Code, UI, comments, commit messages, button labels, marquee items. Use `lucide-react` for icons; use `<span className="size-1 rounded-full bg-*">` for bullets.

## Anti-slop build rules

In BUILD mode, check output against this table before presenting it. These are the defaults Claude reaches for. They are banned as defaults — not because they're always wrong, but because they're never a conscious choice.

| Tell | What to do instead |
|---|---|
| Icon-in-circle for every feature card | No icon, or one illustration per section, or varied treatments |
| Purple-to-blue gradient as hero background | Flat dark surface + cave-man IMAGE-BRIEF for a real image |
| Stats row with three numbers and no source | Remove it, or one number with real citation and context |
| Two equal-weight CTAs (primary + outline, same size) | Primary dominant; secondary smaller, less padding, muted |
| Generic CTA copy ("Get Started", "Learn More") | Name the user's next specific action |
| `animate-ping` on status indicators | Static indicator, or `animate-pulse` only when genuinely live |
| Three-column equal-weight feature grid under hero | Vary: bento, feature-split rows, asymmetric layout |
| Gradient text on every heading | One instance max per page on highest-priority claim only |
| Checklist feature list (tick + short text × N) | Outcome-focused copy; checklist only in pricing comparison |
| Wavy SVG section divider | Background color alternation from tree-man rhythm field |
| `backdrop-blur` on more than one surface | One glassmorphic surface per view, everything else solid |
| Four equal-width footer columns | Vary widths or reduce to three columns |
| Floating generic dashboard mockup in hero | Real product screenshot or cave-man IMAGE-BRIEF |
| Background grid/dot at 3–6% opacity | Remove unless product is grid-native |
| "Powerful", "seamless", "robust" in headlines | Flag for Humanizer — these words mean nothing |

## Design mode and density

Read the Project dials block from SITETREE.md before writing any component.

**VISUAL_DENSITY** sets component density defaults:

| Score | Defaults |
|---|---|
| 1–4 | `py-32` sections, `max-w-2xl` content, single CTA, generous whitespace |
| 5–7 | `py-20` sections, `max-w-4xl` content, standard spacing |
| 8–10 | `py-12` sections, full-width content, compact type scale, data-forward |

**design-mode** sets component style defaults. These are starting points — DESIGN_GUIDE.md tokens always win.

**`minimalist`** — Editorial product UI. Notion/Linear vibes. Restrained, crisp, functional.
```
Border radius:  rounded-sm or none. Never rounded-2xl.
Borders:        border/border-white/10. Never box-shadow for separation.
Typography:     Inter, Geist, or system-ui. One weight jump between heading/body (400 → 700).
                Letter-spacing: -0.01em on headings only. Body: 0.
Color:          Monochrome base + one accent used sparingly. Never two accent colors.
Spacing:        py-16 to py-20 for sections. Tight grid (gap-4 to gap-6).
Decoration:     None. If an element has no function, remove it.
Motion:         Snappy spring only (stiffness 380, damping 30). No scroll-driven hooks.
                Hover states and focus rings — nothing else.
Icons:          lucide-react at 16px. Never decorative icon-in-circle.
```

**`soft`** — Polished, calm, expensive UI. Premium feel over functionality density.
```
Border radius:  rounded-2xl to rounded-3xl. Consistent across all cards and inputs.
Borders:        Subtle (border-white/5 or border-white/8). Shadows for elevation:
                shadow-[0_1px_3px_rgba(0,0,0,0.3)] for cards, never shadow-md or shadow-lg flat.
Typography:     DM Sans, Plus Jakarta Sans, or high-weight Inter (500 body, 700 heading).
                Letter-spacing: -0.02em on display, -0.01em on headings.
Color:          Muted accent (never neon). Accent at 60% saturation of brand color.
                Surface tones warm-tinted toward accent (never pure gray).
Spacing:        py-24 to py-32 for sections. Generous gap (gap-8 to gap-12).
Decoration:     Subtle only — grain texture at 3%, single gradient accent glow in hero.
Motion:         Fluid spring throughout (stiffness 180, damping 22). Section reveals
                with whileInView. Scroll parallax on hero when MOTION_INTENSITY ≥ 6.
Icons:          lucide-react at 20px with accent color on key icons.
```

**`brutalist`** — Hard mechanical language. Swiss type, sharp contrast, experimental layout.
```
Border radius:  0. Everything sharp.
Borders:        Heavy borders (border-2 or border-4) in high-contrast color.
                Never shadows — only borders create depth.
Typography:     Condensed display (e.g. Barlow Condensed, Space Grotesk Bold) for headings.
                Uppercase headings. Aggressive weight contrast (900 heading, 400 body).
                Large type: h1 at 6rem–10rem or larger. Type is the visual element.
Color:          Near-black on white or white on near-black. One color accent maximum,
                used only on the single most important element per page.
Spacing:        Sections bleed to edges — no container max-width on hero and CTA.
                Negative space is intentional, not generous. Tight or zero gap.
Layout:         Intentional asymmetry. One large element + one small, not three equal.
                Overlapping elements, text over images without overlay.
Decoration:     None. The typography IS the decoration.
Motion:         Sparingly. Impact moments only — a sharp scale on CTA hover, a hard
                clip-path reveal. Never fluid springs. CSS transitions preferred.
```

**`inferred`** — treat as minimalist until BRAIN.md or DESIGN_GUIDE.md suggests otherwise.

DESIGN_GUIDE.md tokens always override mode defaults — check it first.

## Command vocabulary

**`polish [target]`** — focused visual upgrade without restructuring. Tighten spacing rhythm (pick 1–2 gap values and use consistently), upgrade missing hover/focus/active/disabled states, fix contrast below 4.5:1, verify every interactive element has a visible focus ring, ensure no layout shifts on state change. Do not change structure, palette, or component shape.

**`typeset [target]`** — fix typography only. Establish a 3-level scale with dramatic size jumps between levels. Add `font-bold` or `font-semibold` to headings if all text is `font-medium`. Set `leading-tight` on headings, `leading-relaxed` on body. Apply `tracking-tight` on display text ≥ 40px only. Add `max-w-prose` to any prose container. Flag single-face pages and propose a second face with genuine contrast.

**`distill [target]`** — strip decorative to functional minimum. Identify every element without functional purpose (gradient blobs, background patterns, visual dividers, redundant shadow layers). Remove them. Collapse redundant wrappers. Merge inconsistent shadow/border values down to 2. Strip icon labels where icon already communicates unambiguously. Same information, fewer layers, lower cognitive load.

**`harden [target]`** — add robustness: error states, empty states, loading states, text overflow handling, long-string edge cases, 44×44px minimum touch targets, i18n-safe layouts. For every interactive element: disabled state? Error state? Loading state? If not, add them.

**`onboard [target]`** — design the first-run experience: empty states with clear calls to action, progressive feature disclosure, activation paths from zero to first value. Every empty state answers: what does this become when populated? What should I do first?

**`layout [target]`** — fix spacing and visual rhythm without changing content. Pick 2–3 spacing values and use only those. Apply gestalt: proximity (related elements grouped), similarity (same treatment = same meaning), continuity (eye follows a clear path to the CTA).

**`adapt [target]`** — make the component responsive. Every breakpoint: does the layout work? Touch targets ≥ 44px on mobile? Text readable? Output the responsive implementation, not just the issues.

**`extract [target]`** — identify repeated patterns and extract into reusable components. Name after purpose, not appearance. Output with correct props and TypeScript types.

**`delight [target]`** — add one moment of unexpected quality: a micro-interaction on the success state, a subtle color shift on active nav, a hover state revealing secondary info. One per component maximum. Only when MOTION_INTENSITY ≥ 5.

**`overdrive [target]`** — add one technically extraordinary effect. Not general polish — a single showpiece that makes engineers stop and ask how it was done. Examples: a particle system on the hero CTA hover, a custom WebGL shader as section background, a magnetic cursor that deforms toward interactive elements, a scroll-driven number counter with spring easing, a real-time cloth simulation on a section divider. One per project. Scoped to one element or zone. Never decorative throughout. Only when DESIGN_VARIANCE ≥ 7.

**`redesign [target]`** — audit an existing page or component first, then fix it. Read order: DESIGN_GUIDE.md → existing code → identify top 5 issues (hierarchy, spacing, contrast, slop patterns, layout) → fix each in priority order → run AI tells detector against the output before presenting. Never restructure the data model — only visual/layout changes. For brand-new pages, use BUILD mode instead.

**`variants [target]`** — build 2–3 genuinely different implementations of the same component behind a visual switcher. Not minor tweaks — different layout families, different motion approaches, different density levels. Each variant is fully functional. Output includes a `<VariantSwitcher />` wrapper that renders each side by side or toggle-able. Useful for: hero sections (editorial vs bento vs split-screen), nav patterns (sidebar vs top vs floating), card grids (equal-weight vs bento vs list). Pick the strongest, delete the others.

## Library selection

Before reaching for a library, pick the right tool. These rules apply in BUILD mode.

**Design system fit — check this before defaulting to Tailwind + shadcn.** Not every brief is a Tailwind-utilities project. If BRAIN.md's target user or product context matches one of these, reach for the official system instead of hand-rolling its look:

| Brief reads as… | Reach for | Why |
|---|---|---|
| Enterprise B2B / analytics in the Microsoft ecosystem | `@fluentui/react-components` | Official Fluent tokens and accessibility, not worth recreating by hand |
| IBM-style enterprise data density | `@carbon/react` + `@carbon/styles` | Mature dense-data patterns already solved |
| Government / public-sector, UK | `govuk-frontend` | Often a compliance expectation, not just a look |
| Government / public-sector, US | `uswds` | Same reasoning |
| Fast local-business MVP with no design system of its own | Bootstrap 5.3 | Boring and fast is correct here — don't over-design a booking form for a local shop |
| Everything else in Fahim's usual stack (indie SaaS, portfolios, dashboards) | Tailwind v4 utilities + shadcn/ui (own the code) | The default — stays the default unless the brief signals otherwise |

One system per project — never mix an official system's components with hand-rolled Tailwind recreations of that same system's look. If the brief is an aesthetic rather than an institutional context (glassmorphism, brutalism, bento, editorial, dark-tech), there's no official package for it either way — build it with Tailwind + native CSS as usual, and say in comments what's borrowed inspiration versus official material.

**Motion:**
- Springs, layout animations, exit animations, gesture-driven values → Framer Motion
- Simple hover fade, basic CSS transition → plain CSS (no Framer needed)
- Predetermined animation that must survive main-thread congestion → WAAPI or CSS `@keyframes`
- Number changing in place → `NumberFlow` (digit transitions that Framer can't do properly)

**Components:**
- Toast notifications → `Sonner` — built for exactly this; do not hand-roll
- Dropdown, dialog, tooltip with manual focus handling → `Base UI` — handles accessibility, focus trapping, and dismissal correctly
- 1,000+ row list → `Virtuoso` before pagination hacks
- Conditional class logic → `clsx` for ad-hoc; `cva` when a component has real typed variants (size, intent, state)

**Charts:**
- Static charts, most use cases → `recharts`
- Live data scrolling with time → `Liveline`

**Styling:**
- `clsx` and `cva` compose — cva uses clsx-style inputs internally. Use both.

**Never:**
- Hand-roll a toast component when Sonner exists
- Use an abandoned package when a maintained alternative exists
- Install Framer Motion for a hover that CSS handles in 2 lines

## File routing

| Doing this | Open this |
|---|---|
| Building a hero, section, app shell, dashboard, auth page | `patterns/layouts.md` |
| Building a navbar, sidebar, mobile drawer, tabs, breadcrumbs, dropdown menu | `patterns/navigation.md` |
| Building inputs, validation, multi-step forms, search, auth forms, action bars | `patterns/forms.md` |
| Building tables, lists, cards, stats, badges, pagination, empty states | `patterns/data-display.md` |
| Building modals, drawers, toasts, popovers, tooltips, alerts, banners | `patterns/overlays.md` |
| Adding interactivity, Server Actions, async params, fonts, metadata | `nextjs-rules.md` |
| Fixing a visual symptom in existing code | `symptoms.md` |
| Deciding how much to refactor when fixing | `fixer-protocol.md` |
| Before declaring anything done | `checklist.md` |

## Color palette assumption

Patterns use Tailwind's neutral palette as a safe default. To adapt:

- **shadcn/ui project**: swap `bg-neutral-950` → `bg-background`, `text-neutral-100` → `text-foreground`, `border-neutral-800` → `border-border`, `bg-neutral-900` → `bg-card`, accent colors → `bg-primary` / `text-primary-foreground`
- **Custom palette**: search-and-replace neutral shades for your scale (e.g. `slate-*`, `zinc-*`, `stone-*`) and accent colors for your brand color
- **Light theme**: invert the neutral scale (`bg-neutral-50`, `text-neutral-900`, `border-neutral-200`)

Structure does not change. Colors do.
