# Dual-Deploy Patterns - Worked Examples

Code recipes that ship cleanly to both Vercel and Cloudflare. Each section
is a complete, copy-pasteable pattern with reasoning.

## 1. Database Client (Neon + Drizzle)

### Goal
One client that works in Node runtime (Vercel default) and Edge runtime
(Cloudflare next-on-pages, or Vercel Edge Functions).

```ts
// lib/db/index.ts
import { neon } from '@neondatabase/serverless'
import { drizzle } from 'drizzle-orm/neon-http'
import * as schema from './schema'

let _db: ReturnType<typeof createDb> | null = null

function createDb() {
  const url = process.env.DATABASE_URL
  if (!url) {
    throw new Error('DATABASE_URL is not set')
  }
  return drizzle(neon(url), { schema })
}

export function getDb() {
  if (!_db) _db = createDb()
  return _db
}
```

### Why this works
- `@neondatabase/serverless` uses HTTP, not TCP - no socket support needed
- `neon-http` driver from Drizzle is the matching adapter
- Lazy init prevents the client from constructing at module load (which would crash builds that don't have `DATABASE_URL` in their env)
- Single export, no per-runtime branching

### Why NOT use the Pool/serverless variant by default
The `Pool`-based driver (`drizzle-orm/neon-serverless`) supports transactions
but only works in Node runtime. Use it only when you genuinely need
multi-statement transactions. For read-heavy apps, `neon-http` is correct.

---

## 2. Hash / Crypto

### Goal
Hash a string in code that may run in Node or Edge.

```ts
// lib/crypto.ts
export async function sha256Hex(input: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(input))
  return Array.from(new Uint8Array(buf))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
}

export function randomToken(bytes = 32): string {
  const arr = new Uint8Array(bytes)
  crypto.getRandomValues(arr)
  return Array.from(arr).map(b => b.toString(16).padStart(2, '0')).join('')
}
```

### Why this works
`crypto.subtle` and `crypto.getRandomValues` are Web standard APIs available
in both Node 18+ and the V8 isolate. No `import` needed - `crypto` is global
in both environments.

### Anti-pattern
```ts
import crypto from 'node:crypto' // breaks on Cloudflare next-on-pages
crypto.createHash('sha256')
```

---

## 3. Cookie-Based Session

### Goal
Set, read, and clear an auth cookie in a way that works in middleware (Edge)
and Server Actions (Node or Edge).

```ts
// lib/session.ts
import { cookies } from 'next/headers'

const COOKIE_NAME = 'session'
const MAX_AGE = 60 * 60 * 24 * 7 // 7 days

export async function setSession(token: string) {
  const c = await cookies()
  c.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: MAX_AGE,
  })
}

export async function getSession(): Promise<string | null> {
  const c = await cookies()
  return c.get(COOKIE_NAME)?.value ?? null
}

export async function clearSession() {
  const c = await cookies()
  c.delete(COOKIE_NAME)
}
```

In middleware, read directly from `req.cookies`:

```ts
// middleware.ts
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export function middleware(req: NextRequest) {
  const token = req.cookies.get('session')?.value
  if (!token && req.nextUrl.pathname.startsWith('/dashboard')) {
    return NextResponse.redirect(new URL('/login', req.url))
  }
  return NextResponse.next()
}

export const config = {
  matcher: ['/dashboard/:path*'],
}
```

### Why this works
- `next/headers` `cookies()` works in Server Components, Route Handlers, and Server Actions on both platforms (must be `await`ed in v15)
- Middleware uses `req.cookies` which is sync and Edge-native
- No DB query in middleware - the token is enough to gate access; verify on the route itself if you need user identity

---

## 4. File Uploads

### Goal
Accept a user upload and persist it. R2 on Cloudflare, Blob on Vercel
becomes a dependency tangle - use S3-compatible R2 from both.

```ts
// lib/storage.ts
import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3'
import { getSignedUrl } from '@aws-sdk/s3-request-presigner'

const s3 = new S3Client({
  region: 'auto',
  endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: {
    accessKeyId: process.env.R2_ACCESS_KEY_ID!,
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY!,
  },
})

export async function uploadObject(key: string, body: Uint8Array | string, contentType: string) {
  await s3.send(new PutObjectCommand({
    Bucket: process.env.R2_BUCKET!,
    Key: key,
    Body: body,
    ContentType: contentType,
  }))
}

export async function getPresignedUrl(key: string, expiresIn = 3600) {
  return getSignedUrl(s3, new GetObjectCommand({
    Bucket: process.env.R2_BUCKET!,
    Key: key,
  }), { expiresIn })
}
```

### Why this works
- `@aws-sdk/client-s3` works in Node and Edge (it uses `fetch` under the hood)
- R2 is S3-compatible, so the same client targets it
- Same code, same bucket, both platforms can read/write

### Vercel-only alternative
`@vercel/blob` is simpler but locks you in. Only use if Cloudflare deploy
is decorative (not really used).

---

## 5. Route Handler That Streams

### Goal
Stream a long response (LLM completion, CSV export) without hitting Vercel's
function timeout.

```ts
// app/api/stream/route.ts
export const runtime = 'edge' // or 'nodejs' - streaming works in both

export async function GET() {
  const encoder = new TextEncoder()

  const stream = new ReadableStream({
    async start(controller) {
      for (let i = 0; i < 10; i++) {
        controller.enqueue(encoder.encode(`chunk ${i}\n`))
        await new Promise(r => setTimeout(r, 500))
      }
      controller.close()
    },
  })

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      'Cache-Control': 'no-cache',
    },
  })
}
```

### Why this works
- `ReadableStream` is a Web standard - works on both platforms
- Vercel's function timeout only counts wall time until the stream closes; chunks reset the keepalive
- Cloudflare Workers have no equivalent timeout for streaming responses within the CPU limit

---

## 6. Server Action with Form

### Goal
Mutate data and revalidate, working identically on both.

```tsx
// app/posts/new/page.tsx
import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'
import { getDb } from '@/lib/db'
import { posts } from '@/lib/db/schema'

async function createPost(formData: FormData) {
  'use server'
  const title = formData.get('title') as string
  const content = formData.get('content') as string

  if (!title || !content) {
    throw new Error('Missing fields')
  }

  const db = getDb()
  await db.insert(posts).values({ title, content })

  revalidatePath('/posts')
  redirect('/posts')
}

export default function NewPostPage() {
  return (
    <form action={createPost}>
      <input name="title" required />
      <textarea name="content" required />
      <button type="submit">Create</button>
    </form>
  )
}
```

### Why this works
- Server Actions are runtime-agnostic - Next.js handles the wire format
- `revalidatePath` works on both platforms (via the incremental cache on OpenNext, via Vercel's cache on Vercel)
- The DB client is the dual-deploy one from section 1

### Caveat on next-on-pages
`revalidatePath` is a no-op on `@cloudflare/next-on-pages` because there's no
incremental cache. The action still works (data is inserted), but the page
won't update until the user navigates fresh or the cache key naturally
expires. This is one of the bigger reasons to prefer OpenNext.

---

## 7. Reading Env Vars Safely

### Goal
One module that validates env at startup, so missing vars fail loudly
instead of silently `undefined`.

```ts
// lib/env.ts
const required = [
  'DATABASE_URL',
  'R2_ACCOUNT_ID',
  'R2_ACCESS_KEY_ID',
  'R2_SECRET_ACCESS_KEY',
  'R2_BUCKET',
] as const

type RequiredKey = typeof required[number]

function load() {
  const out: Partial<Record<RequiredKey, string>> = {}
  const missing: string[] = []
  for (const k of required) {
    const v = process.env[k]
    if (!v) missing.push(k)
    else out[k] = v
  }
  if (missing.length) {
    throw new Error(`Missing required env vars: ${missing.join(', ')}`)
  }
  return out as Record<RequiredKey, string>
}

let _env: Record<RequiredKey, string> | null = null
export function env() {
  if (!_env) _env = load()
  return _env
}
```

### Usage
```ts
import { env } from '@/lib/env'

const db = drizzle(neon(env().DATABASE_URL))
```

### Why lazy
On Cloudflare, env vars are injected at request time, not build time. Eagerly
reading `process.env.X` at module load returns `undefined` during the build,
even though the var is set at runtime. Lazy access defers the read until
inside a request handler.

On Vercel, env vars are available at both build and runtime, but lazy access
costs nothing and unifies the pattern.

---

## 8. Platform Detection (Use Sparingly)

```ts
// lib/platform.ts
export const platform = {
  isVercel: !!process.env.VERCEL,
  isCloudflarePages: !!process.env.CF_PAGES,
  isCloudflareWorkers: !!process.env.CLOUDFLARE_WORKERS,
  isCloudflare: !!process.env.CF_PAGES || !!process.env.CLOUDFLARE_WORKERS,
} as const
```

### When to use
- Conditional analytics (`@vercel/analytics` only on Vercel)
- Platform-specific bindings (KV on Cloudflare, KV on Vercel = different libs)
- Region-aware logic

### When NOT to use
- Anywhere in business logic. If a feature behaves differently on each
  platform, that's a bug, not a feature.
- To work around an Edge constraint - fix the code to be Edge-safe instead.
