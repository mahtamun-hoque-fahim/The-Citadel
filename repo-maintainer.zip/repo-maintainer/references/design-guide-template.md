# DESIGN_GUIDE.md Template

Use this structure. Replace bracket placeholders with project-specific values.

---

```markdown
# [Project Name] — Design Guide

Implementation spec for the design system. No rationale. No marketing copy. Just tokens, patterns, and constraints.

## Color tokens

CSS variables in `app/globals.css` (Tailwind v4 — tokens auto-promote to utilities):

```css
/* ⚠ Replace all [placeholder] values with the palette chosen in BRAIN.md § Visual Identity.
   Never commit placeholder tokens — they must be real values before any component is built. */
@import "tailwindcss";

@theme {
  /* Surfaces — from BRAIN.md palette */
  --color-bg: [bg];                     /* e.g. #0b0b0f */
  --color-surface: [surface];           /* e.g. #16161e */
  --color-surface-elevated: [surface-elevated]; /* e.g. #1e1e2a */
  --color-border: [border];             /* e.g. #2a2a3a */

  /* Text — usually neutral, rarely project-specific */
  --color-text: #f5f5f5;
  --color-text-muted: #a0a0a0;
  --color-text-faint: #6a6a6a;

  /* Brand — from BRAIN.md palette */
  --color-accent: [accent];             /* e.g. #7c3aed */
  --color-accent-hover: [accent-hover]; /* e.g. #6d28d9 */
  --color-accent-faint: [accent-faint]; /* e.g. #7c3aed1a — 10% opacity */

  /* Semantic — keep neutral unless project overrides */
  --color-success: #22c55e;
  --color-warning: #f59e0b;
  --color-danger: #ef4444;
  --color-info: #3b82f6;
}
```

Referenced in Tailwind config:
```ts
theme: {
  extend: {
    colors: {
      bg: 'var(--color-bg)',
      surface: 'var(--color-surface)',
      accent: 'var(--color-accent)',
      // ...
    }
  }
}
```

## Typography

**Families** (loaded via `next/font` in `app/layout.tsx`):
- Display: Syne (`--font-syne`) — for h1, h2, hero text
- Body: Onest (`--font-onest`) — default for everything else
- Mono: JetBrains Mono (`--font-jetbrains-mono`) — code, IDs, timestamps

**Weights used:**
- Body: 400 (regular), 500 (medium for emphasis), 600 (buttons)
- Display: 600 (semibold), 700 (bold for hero)
- Mono: 400, 500

**Size scale** (rem):
| Token | Size | Use |
|---|---|---|
| `text-xs` | 0.75rem | Captions, badges |
| `text-sm` | 0.875rem | Secondary text, form labels |
| `text-base` | 1rem | Body |
| `text-lg` | 1.125rem | Lead paragraphs |
| `text-xl` | 1.25rem | h4 |
| `text-2xl` | 1.5rem | h3 |
| `text-3xl` | 1.875rem | h2 |
| `text-4xl` | 2.25rem | h1 body pages |
| `text-6xl` | 3.75rem | Hero headlines |

**Line height:** 1.6 for body, 1.2 for display.

## Spacing scale

Tailwind defaults. Common values: 2 (8px), 4 (16px), 6 (24px), 8 (32px), 12 (48px), 16 (64px), 24 (96px).

## Border radius

| Token | Value | Use |
|---|---|---|
| `rounded-sm` | 4px | Inputs, badges |
| `rounded-md` | 6px | Buttons (default) |
| `rounded-lg` | 8px | Cards |
| `rounded-xl` | 12px | Modals, large panels |
| `rounded-full` | 9999px | Avatars, pill buttons |

## Shadows

```css
--shadow-sm: 0 1px 2px rgb(0 0 0 / 0.4);
--shadow-md: 0 4px 12px rgb(0 0 0 / 0.5);
--shadow-lg: 0 12px 32px rgb(0 0 0 / 0.6);
--shadow-glow: 0 0 24px var(--color-accent-faint);
```

Use sparingly on dark theme — depth comes from surface lightness, not shadow.

## Components

### Button — primary
```tsx
<button className="bg-accent text-bg px-4 py-2 rounded-md font-semibold hover:bg-accent-hover transition-colors">
  Action
</button>
```

### Button — secondary
```tsx
<button className="bg-surface text-text px-4 py-2 rounded-md border border-border hover:bg-surface-elevated transition-colors">
  Cancel
</button>
```

### Button — ghost
```tsx
<button className="text-text-muted hover:text-text px-3 py-2 rounded-md transition-colors">
  Skip
</button>
```

### Input
```tsx
<input className="bg-surface border border-border rounded-md px-3 py-2 text-text placeholder-text-faint focus:border-accent focus:outline-none transition-colors" />
```

### Card
```tsx
<div className="bg-surface border border-border rounded-lg p-6">
  ...
</div>
```

### Badge
```tsx
<span className="inline-flex items-center px-2 py-0.5 rounded-sm text-xs font-medium bg-accent-faint text-accent">
  ACTIVE
</span>
```

## Animation defaults

- Hover transitions: `transition-colors duration-150 ease-out`
- Modal/drawer enter: `transition-all duration-200 ease-out`
- Page reveal: `transition-opacity duration-300 ease-out`
- Maximum UI animation: 300ms. Longer feels sluggish.

Always wrap motion in `prefers-reduced-motion`:
```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
  }
}
```

## Dark mode notes

This project is dark-first. No light mode unless added explicitly.

- Never use pure black for backgrounds — use the `--color-bg` token (a near-black from the palette, not pure `#000000`), which avoids halation artifacts next to light text
- Never use pure white for text — use `#f5f5f5` or `--color-text`; reduces eye strain on dark backgrounds
- Shadows are less effective on dark surfaces; use border + slight surface lift (`--color-surface-elevated`) for elevation

## Focus indicators

Always visible. Never `outline: none` without a replacement.

```css
*:focus-visible {
  outline: 2px solid var(--color-accent);
  outline-offset: 2px;
}
```
```
