# Turbopack Compatibility & Common Errors

In Next 16, Turbopack is the default bundler for both `next dev` and `next build`. The `--turbopack` flag is now a no-op; the escape hatch is `--webpack`. Most projects work without changes, but a real minority hit compatibility issues. This reference is the troubleshooting layer.

## Decision: stay on Turbopack or opt out?

Stay on Turbopack (recommended) if:
- You use the default Next.js stack (built-in CSS Modules, Tailwind, PostCSS, MDX)
- You don't have custom webpack plugins
- Your CSS-in-JS library is modern (Emotion v11+, styled-components v6+, vanilla-extract, panda-css)

Opt out with `next build --webpack` (and `next dev --webpack`) if:
- You have a custom webpack config with plugins that have no Turbopack equivalent
- You use module federation
- You use a CSS-in-JS library that's webpack-only (Emotion v10-, styled-components v5-)
- You depend on a webpack loader that's not in [Turbopack's compat list](https://nextjs.org/docs/app/api-reference/config/next-config-js/turbopack)

```json
// package.json — opt out for build only, keep Turbopack for dev
{
  "scripts": {
    "dev": "next dev",
    "build": "next build --webpack",
    "start": "next start"
  }
}
```

## Config location moved

The `experimental.turbopack` block in Next 15 is now top-level `turbopack` in Next 16:

```ts
// Before (Next 15)
const nextConfig: NextConfig = {
  experimental: {
    turbopack: { rules: { /* ... */ } },
  },
}

// After (Next 16)
const nextConfig: NextConfig = {
  turbopack: { rules: { /* ... */ } },
}
```

## Common errors

### Error: `Module not found: Can't resolve 'fs'` (or `crypto`, `path`, `stream`, etc.)

**Cause:** Client-side code imports a module that uses Node.js built-ins. Webpack used to silently provide empty stubs via `resolve.fallback`. Turbopack surfaces the import.

**Right fix:** Refactor so the offending import doesn't reach client code. Common causes:
- A utility file is imported by both server and client code, and contains `import fs from 'fs'`. Split it into `utils.server.ts` (Node-only) and `utils.client.ts` (browser-safe).
- A library has a "universal" entry point that imports Node modules at the top level. Use a server-only import path or `import dynamic from 'next/dynamic'` with `{ ssr: false }`.
- A Server Component is being imported into a Client Component (which silently bundles the server code for the client). Pass the Server Component as a child instead.

**Last-resort fix:** Tell Turbopack to alias the Node module to an empty file:

```ts
// next.config.ts
const nextConfig: NextConfig = {
  turbopack: {
    resolveAlias: {
      fs: { browser: './empty.ts' },
      crypto: { browser: './empty.ts' },
    },
  },
}
```

Where `empty.ts` is:
```ts
export default {}
```

Treat this as a flag that a real refactor is needed.

### Error: `Failed to resolve module ~bootstrap/dist/...`

**Cause:** Turbopack does not support the legacy tilde (`~`) prefix in Sass imports. This was a webpack convention.

**Fix:** Drop the tilde:
```scss
// Before
@import '~bootstrap/dist/css/bootstrap.min.css';
@import '~@fontsource/inter/index.css';

// After
@import 'bootstrap/dist/css/bootstrap.min.css';
@import '@fontsource/inter/index.css';
```

If you can't modify the imports (third-party code), add an alias:
```ts
const nextConfig: NextConfig = {
  turbopack: {
    resolveAlias: { '~*': '*' },
  },
}
```

### Error: `webpack configuration was found, refusing to build`

**Cause:** Next 16 detects a custom `webpack` function or `webpack` config in `next.config` and refuses to build with Turbopack to prevent silent misconfiguration.

**Three options:**

1. **Use Turbopack anyway, ignoring the webpack config:**
   ```bash
   next build --turbopack
   ```
   (Even though Turbopack is default, this flag forces it and bypasses the safety check.)

2. **Migrate the webpack config to Turbopack:** Most webpack customizations map to `turbopack.rules`. See the [Turbopack config docs](https://nextjs.org/docs/app/api-reference/config/next-config-js/turbopack).

3. **Stay on webpack:**
   ```bash
   next build --webpack
   ```

If you didn't write a webpack config yourself, a plugin (often analytics, monitoring, or Sentry) is injecting one. Check `next.config.ts` and any wrapping `withX(nextConfig)` calls.

### Error: `Cannot find module 'next/dist/build/webpack/...'`

**Cause:** A package imports webpack internals directly. These paths often move or vanish under Turbopack.

**Fix:** Find which package is doing this (`npm ls <missing-module>` often helps) and either upgrade it or open an issue. As a workaround, build with `--webpack`.

### Error: `Custom loader X is not supported`

**Cause:** Turbopack supports many but not all webpack loaders. Some loaders are reimplemented in Rust; others require a Turbopack-native equivalent.

**Fix:** Check the [Turbopack supported loaders list](https://nextjs.org/docs/app/api-reference/config/next-config-js/turbopack#supported-loaders). Common workable substitutions:
- `raw-loader` → built-in `?raw` import suffix or `turbopack.rules` with `as: '*.txt'`
- `url-loader` / `file-loader` → built-in static asset imports
- `babel-loader` → built-in SWC; only needed for `babel-plugin-react-compiler` when using React Compiler

If your loader isn't supported, build with `--webpack`.

## Configuring Turbopack rules

For custom file transformations, use `turbopack.rules`. The shape:

```ts
const nextConfig: NextConfig = {
  turbopack: {
    rules: {
      '*.svg': {
        loaders: ['@svgr/webpack'],
        as: '*.js',
      },
    },
  },
}
```

Each glob maps to an array of loaders. The `as` field tells Turbopack the output module type.

## Filesystem cache (beta, opt-in)

For faster cold starts in `next dev`:

```ts
const nextConfig: NextConfig = {
  experimental: {
    turbopackFileSystemCacheForDev: true,
  },
}
```

Trade-off: roughly doubles memory usage in dev. If you're on a memory-constrained machine and hitting OOM, disable it.

## Sass module imports from node_modules

Turbopack fully supports importing Sass from `node_modules`:

```scss
// Works in Turbopack
@import 'bootstrap/dist/css/bootstrap.min.css';
```

The webpack-era tilde syntax (`@import '~bootstrap/...'`) is not supported.

## `next dev` writes to `.next/dev` now

In Next 16, `next dev` and `next build` use separate output directories so they can run concurrently. Any tooling that reads `.next/` for traces/manifests should look at `.next/dev/` for dev artifacts.

For Turbopack tracing:
```bash
# Old
npx next internal trace .next/trace-turbopack

# New
npx next internal trace .next/dev/trace-turbopack
```

## Diagnosing weirdness

If `next dev` works but `next build` fails (or vice versa), and the error message isn't clear:

1. **Clear the cache:** `rm -rf .next && next build`. Stale artifacts are a top cause of mysterious build failures.
2. **Try the other bundler:** If `next build` fails on Turbopack, try `next build --webpack`. If webpack fails too, the bug isn't bundler-specific. If only Turbopack fails, you've localized the issue to a Turbopack-specific incompatibility.
3. **Check `next build --debug-prerender`:** If the error is about prerendering or "blocking-route," this flag emits component-level stack traces.
4. **Check the package versions:** A common silent failure is `next` upgraded but a `@next/*` companion package (mdx, bundle-analyzer, third-party-cache, etc.) still on 15.x. Bump them together.

## Side note: legacy CSS-in-JS

If your project still depends on Emotion v10 or styled-components v5, **the migration path is not "Turbopack support."** Those versions are years EOL and the recommendation is to upgrade the CSS-in-JS library itself. As a transitional measure, `next build --webpack` works.

For modern CSS-in-JS (Emotion v11+, styled-components v6+, vanilla-extract, panda, stylex), Turbopack works out of the box.
