# Tone Modes — The Four Voices Airborne Writes In

Tone is decided **before** the content is written. The same product information demands different language depending on where the user encounters it. This file is the operational guide for picking and executing each tone.

---

## Why Tone Matters More Than Most SEO Advice Admits

A meta description written like a brochure on a dashboard page reads as desperate. A login form titled "Unlock your potential" wastes the user's time. A blog post written like a sales pitch gets bounced. Search engines reward sites that **serve the visitor's intent at each surface** — tone IS the signal.

Airborne uses four tones. Each has a clear purpose, vocabulary set, and structural rules.

---

## Tone 1 — SEO-First

**Where it applies:** blog posts, guides, glossary, FAQ, study pages, public docs, comparison content where the SERP shows informational results.

**Optimized for:** crawl signals, keyword coverage, answer-shape for AI Overviews and featured snippets, dwell time.

### Voice rules

- **Answer-shaped first sentence.** Open with the answer to the question the title implies. Crawlers and AI Overviews pick this up.
- **Scannable structure.** H2 every ~200–400 words. Short paragraphs (2–4 sentences max). Lists where they help.
- **Keyword discipline.** Primary keyword in title, H1, first 100 words, and at least one H2. Secondary keywords distributed across H2s. No stuffing.
- **Informational vocabulary.** "Means", "is defined as", "occurs when", "the difference between", "compared to", "in practice". Avoid sales verbs.
- **Cite specifics.** Numbers, dates, names, examples. "The DELF B2 oral exam runs 20 minutes" beats "The oral exam is relatively short".
- **Internal links with descriptive anchor text.** Anchor matches the linked page's keyword.

### Worked example

**Page:** `/blog/how-delf-b2-is-scored`

```
Meta title: How DELF B2 Is Scored: Section Weights and Passing Marks Explained
Meta description: DELF B2 is scored out of 100, with each section worth 25 points. You need 50 overall and a minimum of 5 per section to pass. Full breakdown inside.

H1: How the DELF B2 exam is scored

Opening paragraph:
The DELF B2 exam is scored out of 100 points, with the four sections — listening, reading, writing, and speaking — each worth 25 points. To pass, you need a total of at least 50 and a minimum of 5 points in every section. This guide breaks down exactly how examiners award marks in each section and where most candidates lose points.

H2: The four scored sections (with weights)
H2: How the writing section (production écrite) is graded
H2: How the speaking section (production orale) is graded
H2: What happens if you fall below 5 in one section
H2: Frequently asked questions
  H3: Can I retake just one section?
  H3: How long do results take?
  H3: Is the scoring the same for DELF B2 Junior?
```

### Schema

`Article` + `FAQPage` (if the FAQ block is real) + `BreadcrumbList`.

---

## Tone 2 — Marketing-First

**Where it applies:** pricing pages, signup/login pages, hero blocks on landing pages, comparison ("vs") pages, feature pages, CTA buttons, conversion microcopy, email subject lines.

**Optimized for:** click-through, form completion, trial signups, paid conversion.

### Voice rules

- **Lead with the outcome, not the feature.** "Pass DELF B2 in 8 weeks" beats "Comprehensive DELF B2 course material".
- **Second person, active voice.** "You'll get" beats "Users receive".
- **Verb-led CTAs.** "Start a free practice test" beats "Click here" or "Get started".
- **Honest urgency only.** "Free until launch" if true. Never fake countdowns or fake scarcity.
- **Concrete proof beats adjectives.** "1,247 students passed in 2025" beats "trusted by thousands". If you don't have the number, don't fake it.
- **Objection handling near the CTA.** "No credit card required", "Cancel anytime", "Money-back guarantee" — only what's true.
- **Short sentences.** Marketing copy that reads slowly loses clicks.

### Vocabulary swap table

| Avoid (generic) | Use (active outcome) |
|---|---|
| "Get started" | "Start your free mock exam" |
| "Learn more" | "See sample writing prompts" |
| "Sign up" | "Create your free account" |
| "Solutions" | "What you can do" |
| "Innovative" | (delete, replace with the concrete thing) |
| "Best-in-class" | (delete, replace with proof) |
| "Powerful" | (delete, replace with what it does) |

### Worked example

**Page:** `/pricing`

```
Meta title: Pricing — Free Mocks, ৳1,499 Bundles, ৳4,999 Full Course | LearnDE
Meta description: Start free with one DELF B2 mock exam. Upgrade to a 5-mock bundle for ৳1,499 or the full 8-week course with tutor feedback for ৳4,999.

H1: Pick the prep that fits your timeline

Subhead: Free mocks for self-paced learners. Bundles for serious prep. Full course with tutor feedback for the score you actually need.

Plan card 1 — Free
- One full DELF B2 mock exam
- Automatic scoring
- Sample answer for one writing prompt
- CTA: "Start your free mock"

Plan card 2 — Bundle (৳1,499)
- 5 full mock exams
- Detailed score reports
- Writing template library
- CTA: "Get the 5-mock bundle"

Plan card 3 — Full Course (৳4,999)
- Everything in Bundle
- 8-week structured plan
- Native tutor reviews on 4 writing tasks
- 2 live oral exam simulations
- CTA: "Enroll in the full course"

Below cards:
"No card required for the free mock. Money-back guarantee on the full course if you don't see a 2-point improvement in 4 weeks."
```

### Schema

`Product` per plan with `Offer`, `priceCurrency`, `price`, `availability`. `Organization` for the brand.

---

## Tone 3 — User-First

**Where it applies:** dashboards, settings, account pages, onboarding flows, in-app help, error and empty states, form labels and validation messages, confirmation screens, legal pages, post-signup welcome.

**Optimized for:** clarity, low cognitive load, low friction, no-surprise behavior. **Almost always `noindex`.**

### Voice rules

- **Plain language, no jargon.** "Change your password" beats "Update credentials".
- **Describe state, not action where state matters.** Empty state: "You haven't taken a mock exam yet" beats "No data found".
- **Help, don't sell.** A dashboard is not the place for upgrade pressure. If an upgrade is genuinely needed, link to it once, calmly.
- **Error messages: cause + fix.** "We couldn't save your essay. The connection dropped — try again in a moment." Not "Error 500".
- **Confirmations are reassuring.** "Saved" not "Operation completed successfully".
- **Meta is lean.** Page title for browser tab + minimal description. No marketing language. Often `noindex`.
- **No emojis.** (Site-wide rule.)

### Empty-state, error, and success microcopy patterns

| State | Pattern | Example |
|---|---|---|
| Empty | "[Subject] [verb in present perfect negative]. [What to do next, as a CTA]." | "You haven't booked a tutor session yet. Browse available tutors." |
| Error | "[What went wrong, plain]. [Cause if known]. [How to fix or retry]." | "We couldn't load your mock exam. The server timed out — refresh to try again." |
| Loading | "[Verb -ing] [object]." | "Loading your score report." |
| Success | "[Past tense action]." or "[Action]. [Optional what's next]." | "Saved." / "Essay submitted. Your tutor will review it within 24 hours." |
| Confirmation | "[Are you sure question, neutral]." | "Delete this draft? You can't undo this." |

### Worked example

**Page:** `/dashboard`

```
Page title (browser tab): Dashboard — LearnDE
Meta: noindex (logged-in only)

H1: Your prep dashboard

Greeting (variable): "Welcome back, [name]."

Section 1 — Next session
"Your next tutor session is on Tuesday, 28 May at 7:00 PM. Reschedule or join from your sessions tab."

Section 2 — Progress
"You've completed 3 of 12 mock exams. Latest score: 14/25 in writing, 18/25 in reading."

Empty state (if no mocks taken):
"You haven't taken a mock exam yet. Start your first one — it takes about 75 minutes."
[CTA: Start a mock exam]

Error state (if data fetch fails):
"We couldn't load your progress. Refresh the page or check back in a moment."
```

### Schema

None on `noindex` pages. (Schema for unindexed pages wastes Google's crawl budget and provides no benefit.)

---

## Tone 4 — Best Mix

**Where it applies:** homepage, key landing pages (one per primary product), product/course detail pages, the most important comparison page, the about page when it functions as a soft conversion page.

**Optimized for:** all three at once — search visibility, click-through from organic and ads, in-page conversion, and clarity for users who arrive from anywhere.

### How to layer the tones

Best Mix pages are structured top-to-bottom in **layered order**:

```
Layer 1 (top of page, marketing): Hero headline + sub + primary CTA. Marketing-First tone.
Layer 2 (mid-page, SEO): Body sections with H2/H3, keyword-rich, answer-shaped. SEO-First tone.
Layer 3 (bottom of page, marketing): Final CTA + objection handling + social proof. Marketing-First tone.
Layer 4 (meta, SEO): generateMetadata + JSON-LD. SEO-First discipline.
```

Within each layer, follow that tone's rules strictly. The transitions between layers are the design challenge — handle them with a transitional H2 ("Here's how it works" or "What you'll get") rather than abrupt jumps.

### Worked example

**Page:** `/` (LearnDE homepage)

```
Meta title (SEO-First, 58 chars): DELF, DSH & TestDaF Prep Built by Native Tutors | LearnDE
Meta description (SEO + click): Prepare for DELF, DSH, or TestDaF with timed mocks, sample answers, and feedback from native tutors. Free practice test, no card required.

— LAYER 1: Marketing hero —
H1: Pass your French or German exam with native-tutor-built prep
Subhead: Timed mocks, real sample answers, and tutor feedback — built for Bangladeshi students preparing for DELF, DSH, and TestDaF.
Primary CTA: "Start your free mock exam"
Secondary CTA: "See sample writing answers"

— LAYER 2: SEO body —
H2: Built for the exam you're actually taking
[3 short blocks: DELF, DSH, TestDaF — each with a sentence and a "See [exam] prep" link]

H2: How LearnDE prep works
[3-step explanation with H3s: 1. Take a diagnostic mock, 2. Follow your 8-week plan, 3. Get tutor feedback on every writing task]

H2: Real results from real students
[Specific numbers with source — "1,247 students passed in 2025" only if true. Otherwise testimonial blocks.]

H2: Frequently asked questions
H3: How long do I need to prepare for DELF B2?
H3: Can I get a refund if my score doesn't improve?
H3: Are the tutors native French and German speakers?
H3: Do you support DSH from any university?

— LAYER 3: Marketing close —
H2: Start without paying anything
Subhead: One free mock exam, full scoring, no card. See where you stand in 75 minutes.
Primary CTA: "Take your free mock"

— LAYER 4: Schema —
Organization + WebSite (with SearchAction if site has search) + Course (for each exam) + FAQPage (if FAQ is on the page)
```

---

## Picking the Tone — Decision Tree

When the route's purpose is ambiguous, walk this tree:

```
Is the page reachable only after login?
  YES → User-First (probably noindex)
  NO  → continue

Is the page primary purpose to convert (signup, buy, book)?
  YES → Marketing-First (with SEO meta if public)
  NO  → continue

Is the page primary purpose to answer a search query or teach?
  YES → SEO-First
  NO  → continue

Does the page need to do all three (rank + convert + serve users)?
  YES → Best Mix
  NO  → default to SEO-First if public, User-First if not
```

---

## Cross-Tone Anti-Patterns

These mistakes ruin pages in predictable ways. Airborne never produces them.

| Mistake | Why it fails |
|---|---|
| Marketing copy on dashboards | Reads as desperate; users want to do work, not be sold to |
| Generic SEO meta on conversion pages | Misses click-through opportunity from SERPs and ads |
| Sales-pitch blog posts | Bounces visitors who came for an answer; bad dwell time = bad rankings |
| Bare "Dashboard" meta titles on Best Mix homepages | Wastes the most valuable meta slot on the site |
| Marketing language in error messages | Erodes trust at the exact moment trust matters most |
| Stuffed keywords in form labels | Form completion drops; SEO doesn't help on `noindex` pages anyway |
| Long paragraphs in marketing hero | Loses clicks; hero copy must be scannable in under 5 seconds |
| Plain "Submit" buttons on Marketing pages | Loses conversion vs verb-led specific CTAs |
