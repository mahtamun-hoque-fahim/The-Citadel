# Replacement patterns

Exact, copy-adaptable transforms for each context the decision table sends you
to. Every pattern is **before → after**. Follow the one that matches where the
emoji lives. When in doubt about which icon name, see `emoji-icon-map.md`.

The golden rule: **change the glyph, change nothing else.** Keep surrounding
markup, spacing, and logic identical. The smallest correct edit is the right
edit.

---

## 1. JSX/TSX text node → lucide icon

The emoji sits inside rendered JSX as a text child.

```tsx
// BEFORE
<h1>Ship faster 🚀</h1>

// AFTER
import { Rocket } from "lucide-react";
...
<h1 className="flex items-center gap-2">
  Ship faster <Rocket className="size-6" />
</h1>
```

Notes:
- Wrap text + icon so they align: add `inline-flex items-center gap-2` (or
  `flex` on a block parent). Without it the icon baseline looks off.
- Match `size-*` to the text size: `size-4` for body, `size-5`/`size-6` for
  headings. Use `aria-hidden="true"` on purely decorative icons:
  `<Rocket className="size-5" aria-hidden="true" />`.

## 2. Button / link label → leading or trailing icon

```tsx
// BEFORE
<button>Save 💾</button>

// AFTER
import { Save } from "lucide-react";
...
<button className="inline-flex items-center gap-2">
  <Save className="size-4" aria-hidden="true" />
  Save
</button>
```

Convention: action icons lead (icon then label); directional/affordance icons
trail (`Continue <ArrowRight />`).

## 3. List item bullet emoji → dot or icon

If the emoji is a **decorative bullet** (every item starts with the same glyph),
use a dot, not an icon:

```tsx
// BEFORE
<li>🔹 Fast setup</li>

// AFTER
<li className="flex items-start gap-2">
  <span className="mt-1.5 inline-block size-1.5 shrink-0 rounded-full bg-current" />
  <span>Fast setup</span>
</li>
```

If each item's emoji is **meaningfully different** (one means speed, one means
security), use the matching lucide icon per item instead of a dot.

## 4. Import handling (the part weak models get wrong)

- If the file **already imports** from `lucide-react`, merge into that line. Do
  not add a second import.

```tsx
// BEFORE (file already has)
import { Menu, X } from "lucide-react";

// AFTER (added Rocket — merged, not a new line)
import { Menu, X, Rocket } from "lucide-react";
```

- Keep names sorted-ish but do not reorder the whole file; just append.
- Place a brand-new `lucide-react` import with the other third-party imports,
  after React and before local (`@/...`) imports.
- After replacing, scan the file for any icon you imported but no longer use and
  remove it — an unused import can fail lint/build in strict repos.

## 5. React Server Component vs Client Component

`lucide-react` icons render fine in **both** Server and Client Components — they
are plain SVG. Adding an icon does **not** require `"use client"`.

- Do NOT add `"use client"` just to use an icon.
- Only keep/add `"use client"` if the file already needed it (state, effects,
  handlers). Adding it unnecessarily turns a server component into a client
  bundle for no reason.

## 6. Plain HTML (no React) → inline SVG

For `.html` files, email templates, or string-built markup, you cannot import a
component. Inline the lucide SVG (copy the path from lucide.dev → "Copy SVG"):

```html
<!-- BEFORE -->
<span class="status">Done ✅</span>

<!-- AFTER (lucide "check" path inlined) -->
<span class="status" style="display:inline-flex;align-items:center;gap:.4rem">
  Done
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
       viewBox="0 0 24 24" fill="none" stroke="currentColor"
       stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
       aria-hidden="true">
    <path d="M20 6 9 17l-5-5"/>
  </svg>
</span>
```

For a decorative bullet in plain HTML, use a CSS dot instead of an SVG:
`<span style="display:inline-block;width:6px;height:6px;border-radius:9999px;background:currentColor"></span>`.

## 7. Accessibility / SEO strings → plain words (NEVER an icon)

`alt`, `aria-label`, `title`, meta title, meta description, OG tags, JSON-LD,
and any screen-reader string must be **plain text**. Putting an icon or emoji
here is worse than the original.

```tsx
// BEFORE
<img src="/hero.png" alt="Our product 🚀" />
<meta name="description" content="The fastest notes app 🔥 ever" />

// AFTER
<img src="/hero.png" alt="Our product" />
<meta name="description" content="The fastest notes app ever" />
```

If the emoji carried meaning, fold it into words: `aria-label="Delete 🗑️"` →
`aria-label="Delete"`.

## 8. Code comments → delete

```ts
// BEFORE
// TODO 🚧 wire up auth ⚠️

// AFTER
// TODO: wire up auth
```

Strip the emoji and any now-dangling spaces. No icon, ever, in a comment.

## 9. console.log / logger → delete or text tag

```ts
// BEFORE
console.log("✅ user created", user.id);
console.error("❌ failed", err);

// AFTER (plain)
console.log("user created", user.id);
console.error("failed", err);

// AFTER (if a status marker is genuinely useful)
console.log("[ok] user created", user.id);
console.error("[error] failed", err);
```

## 10. Toast / notification → move meaning to the icon prop

Do not embed an emoji in the message string. If the toast library supports an
icon, pass the lucide icon there; otherwise prepend a small icon element.

```tsx
// BEFORE
toast.success("✅ Saved");

// AFTER (sonner / most libs already render a success icon)
toast.success("Saved");

// AFTER (custom toast that takes an icon)
import { CheckCircle2 } from "lucide-react";
toast({ icon: <CheckCircle2 className="size-4" />, message: "Saved" });
```

## 11. Markdown / docs → delete (or word)

```md
<!-- BEFORE -->
## 🚀 Getting Started
- ✅ Install deps
- 🎉 You're done!

<!-- AFTER -->
## Getting Started
- Install deps
- You're done
```

Headings and list items stay clean. If an emoji marked status meaningfully
("done vs pending"), replace with a word ("Done:", "Pending:"), not a glyph.

## 12. CSS / Tailwind `content` → drop the glyph

```css
/* BEFORE */
.note::before { content: "💡 "; }

/* AFTER — remove the pseudo-element decoration; render a real icon in markup,
   or use an SVG background */
.note::before {
  content: "";
  display: inline-block;
  width: 1rem; height: 1rem;
  margin-right: .25rem;
  background: url("/icons/lightbulb.svg") center / contain no-repeat;
}
```

Prefer rendering a lucide icon in the component over a CSS pseudo-element when
the project is React.

## 13. package.json / JSON config / .env → delete

```jsonc
// BEFORE
"scripts": { "dev": "next dev", "ship": "echo 🚀 && vercel --prod" }

// AFTER
"scripts": { "dev": "next dev", "ship": "echo deploying && vercel --prod" }
```

These are not display surfaces; strip the glyph, keep the command working.

---

## After every file

1. Re-read the edited lines once — JSX must still be balanced, strings still
   quoted, commas intact.
2. Confirm the lucide import line is merged and every imported icon is used.
3. Move to the next file. Run the full re-scan only after all files are done.
