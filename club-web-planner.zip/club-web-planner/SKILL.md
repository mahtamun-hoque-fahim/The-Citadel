---
name: club-web-planner
description: Full pre-development planner for university club websites. ALWAYS use when Fahim mentions planning or building a site for any student club or society — debate, tech, arts, business, sports, or general. Triggers on "plan a club site", "website for my club", "club web project", "site for [any] club", or any student org web project even if phrased casually. Produces user flow diagram, DB schema, color-anchored design system, folder structure, Better Auth flow, bKash manual payment system (TrxID + Reference to admin dashboard), Drizzle schema, env vars, GitHub repo note, and Gantt timeline. Tuned for Next.js 16 + Tailwind + Neon + Drizzle + Better Auth + Vercel (Fahim's stack). Not a shortcut around Singularity — checks for BRAIN.md first and routes through Singularity, then Council PRE-BUILD, same as any other project.
---

# Club Web Planner

Produces a complete pre-development plan for a university club website. Visually rich — use the Visualizer for diagrams and design widgets.

## Core model to internalize before starting

Two system-level rules apply to EVERY club site this skill plans. Internalize these before writing anything — they affect architecture, DB schema, user flow, feature specs, and auth design.

### Rule 1 — Sign-up gate: Members must register to participate

**No guest participation.** Any action that involves taking part in club activities requires a Better Auth account. This covers: RSVPing to events, applying to join, registering for tournaments, submitting applications, accessing resources, and making payments.

The public zone is read-only and informational. Once a user wants to *do* anything:
1. They are redirected to `/sign-up` if not authenticated, or `/sign-in` if returning
2. After Better Auth flow, a user row exists with `role: member` by default
3. They are redirected back to the page they came from (use `?callbackURL=/path`)
4. Now they can participate

Every CTA on public pages ("Register for event", "Apply to join", "Pay for tournament") must check session first. If no session → redirect to sign-up with callback URL.

In the user flow diagram, show this redirect loop explicitly with a labeled arrow:
"→ sign-up required → Better Auth → back to action"

### Rule 2 — bKash manual payment flow

**No payment gateway. No API. No SDK.** All paid activities use a dead-simple manual model: the user sends money to a bKash number (whatever number the club uses — personal or merchant, doesn't matter), then submits their Transaction ID and a Reference so the admin can verify it.

The full user journey for any paid activity:

```
1. User finds a paid event/activity (public page — visible to all)
2. User clicks "Register" or "Pay to join"
3. Session check → if none: redirect to sign-up → return here after auth
4. User lands on /pay/[event-slug]
5. Page shows:
   - Event name and amount due (in BDT)
   - The club's bKash number (collected during planning — see Round 2)
   - Instruction: "Send the amount to the number above, then fill in your details below"
   - Two fields:
       a. Transaction ID — labelled "Your bKash Transaction ID (starts with Trx)"
       b. Reference    — labelled "Reference you used in the payment"
   - Submit button
6. On submit:
   - payment_submissions row created with status = 'pending'
   - User sees "Submitted! You'll receive an email once the admin verifies your payment."
   - Resend fires an acknowledgement email to the user
7. Admin goes to /admin/payments:
   - Sees a table: user name, event, Transaction ID, Reference, submitted_at, status
   - Admin cross-checks against their own bKash app/statement manually
   - Clicks APPROVE or REJECT (with optional note)
8. On admin action → Resend fires outcome email to user:
   - APPROVED: "Confirmed! You're registered for [event]."
   - REJECTED: "We couldn't verify your payment. Please resubmit or contact us."
9. On approval: user's participation status for that event is activated in the DB
```

That's the whole model. No validation of TrxID format beyond "not empty". No merchant distinction. The admin is the source of truth — they look at their bKash app and compare. The site's only job is to collect, store, and display the TrxID + Reference clearly.

**Never suggest Stripe, SSLCommerz, or any payment gateway.** This is the payment model.

## Step 0 — Singularity gate (always check first)

This skill is **not** a shortcut around Singularity. Before Round 1:

1. Check for `BRAIN.md` in the project.
2. **If absent:** stop. Tell Fahim: "No BRAIN.md found — run Singularity first so this club site gets anchored like any other project." Do not run Round 1/2 or produce the plan until BRAIN.md exists (or Fahim explicitly overrides).
3. **If present:** read it, carry its locked decisions (palette, positioning, constraints) into Step 1 instead of re-asking for them.

After the plan in Step 3 is produced, hand its route list and folder tree to **tree-man** for reformatting into `SITETREE.md` — tree-man does not re-derive routes for club sites, it canonicalizes what this skill already produced. Then route the full plan through **Council PRE-BUILD** before Fahim starts building — same as every other project.

## Step 1 — Intake interview (always run first)

Two rounds. Never start the plan until both are complete.

### Round 1 — Club identity

Open with a natural prose question:
> "What's the name of the club, and which university is it at?"

Then immediately follow with an `ask_user_input_v0` widget:

```
Q1 (single_select): What type of club is this?
  Options: Debate / Law / Academic | Tech / Programming | Arts / Creative / Media |
           Business / Entrepreneurship | Science / Research | Sports / Fitness | Other

Q2 (multi_select): What features does the site need?
  Options: Events & Calendar | Member Portal / Dashboard | Blog / News |
           Join / Application Form | Admin Panel | Countdown / Tournament page |
           Resources / Docs library | Public leaderboard or rankings | Paid events / activities
```

Note: "Paid events / activities" triggers the bKash payment flow (Rule 2). If selected, the payment system is fully included in the plan. If NOT selected, the payment system is still mentioned in "Out of scope" as an easy future addition.

Wait for Round 1 before asking Round 2.

### Round 2 — Stack, color, repo, bKash

Ask as prose (not a widget — all open-ended):

> 1. "What's your preferred stack? (say 'default' for Next.js + Neon + Better Auth, or name your stack)"
> 2. "What base color are you vibing with? Hex, name, or feeling — anything works."
> 3. "What's the GitHub repo URL where I'll push the project scaffold?"

If "Paid events / activities" was selected in Round 1, add a 4th question:

> 4. "What's the bKash number users should send money to? (personal or merchant — doesn't matter)"

Store as `BKASH_NUMBER`. Displayed on the payment page and stored as env var.

Do not begin the plan until both rounds are fully answered.

## Step 2 — Process the inputs

**Club identity string.** Compose: `[Club Name] — [University Name] — [Club Type]`. Used in page title, DB comment, folder structure comment, env var header, closing section.

**Color system derivation.** From the user's base color, derive:
- Primary — the base color (exact hex or closest named equivalent)
- Primary dark — ~20% darker (hover states, text on light)
- Primary light — ~80% lighter (badge backgrounds, subtle fills)
- Surface dark — near-black harmonizing with the primary hue
- Surface light — off-white harmonizing with the primary hue
- Accent — complementary pop color (optional, for CTAs)
- Semantic — green (success), amber (warning), red (danger) — always standard

The base color is the anchor. Never default to a generic palette.

**Club type → aesthetic:**

| Club type | Aesthetic | Display | Body | Mono |
|---|---|---|---|---|
| Debate / Law / Academic | Authoritative, serif-led | Playfair Display | Inter | JetBrains Mono |
| Tech / Programming | Dark, monospace-forward | Space Grotesk | DM Sans | JetBrains Mono |
| Arts / Creative / Media | Editorial, expressive | Fraunces | DM Sans | — |
| Business / Entrepreneurship | Confident, corporate | Sora | Inter | — |
| Science / Research | Precise, structured | IBM Plex Sans | IBM Plex Sans | IBM Plex Mono |
| Sports / Fitness | Bold, high-contrast | Barlow Condensed | Barlow | — |
| Other / General | Friendly, approachable | DM Sans | DM Sans | DM Mono |

**Stack resolution.** Default (if user says "default" or leaves blank): Next.js 16 + Tailwind + Neon + Drizzle + Better Auth + Resend + Vercel. Secondary target: Cloudflare Workers via `@opennextjs/cloudflare` (replaces deprecated `@cloudflare/next-on-pages`). Add automatically if Cloudflare is in memories/context.

**Payment flag.** If "Paid events / activities" was selected in Round 1 Q2: `PAYMENT_ENABLED = true`. Payment system is fully included in schema, user flow, folder structure, feature specs, and env vars. If not selected: `PAYMENT_ENABLED = false`. Mention bKash payment as an easy v2 addition in Out of scope.

## Step 3 — Produce the full plan (in this order)

Never skip a section. Use Visualizer for diagrams and design widgets.

### 3a. User flow diagram (Visualizer — SVG)

Show all zones and routing. If `PAYMENT_ENABLED`, include the payment flow as its own sub-path:
- From "Paid event page" → "Sign-up gate" → "/pay/[slug]" → "Pending confirmation" node
- Arrow from "Admin approves" → "RSVP activated + email sent"

Color coding:
- gray — zone container labels
- purple — landing, dashboard
- teal — content pages (blog, events, resources)
- coral — action pages (apply, countdown, payment page)
- amber — auth gate
- green — payment confirmed / approved state
- red — admin zone nodes
- blue — email/notification nodes (if shown)

Max ~18 nodes when payment is included. Keep it clean — use sub-paths, not sprawl.

### 3b. Site architecture (prose)

All pages, grouped by zone. Format: `path` — purpose (one sentence). If `PAYMENT_ENABLED`, include:
```
/pay/[context-slug]           Bkash payment submission (TrxID + Reference form)
/pay/[context-slug]/submitted Confirmation: "Your payment is under review"
/admin/payments               Admin: review, approve, reject payment submissions
```

Use club-specific terminology throughout. Be exhaustive for selected features.

### 3c. Stack decision table (markdown table)

Columns: Concern | Choice | Why. Standard rows: Framework, Styling, Database, ORM, Auth, Email, Forms, Rich text (if blog), Deployment. If `PAYMENT_ENABLED`, add:
```
| Payments | bKash (manual) | No gateway needed — manual TrxID verification via admin panel |
```
Auth row should be: "Better Auth — role-based (member, admin), email/password, refresh tokens, Drizzle adapter."

### 3d. Database schema (Visualizer — HTML widget)

3-column grid of monospace table cards. Header colors: blue (user), green (content), yellow (junction), red (admin), gray (utility).

Always include Better Auth tables (`user`, `session`, `account`, `verification`) and (if apply form selected) `applications`. If `PAYMENT_ENABLED`, always include `payment_submissions`:

```
payment_submissions
─────────────────────────────────────
id              uuid PK
user_id         text FK → user.id
context_type    enum (event_rsvp | membership | workshop | tournament)
context_id      uuid  (ID of the event or activity being paid for)
bkash_trx_id    text  (the Transaction ID the user got from bKash)
reference       text  (whatever reference the user used in the payment)
amount          decimal
status          enum (pending | approved | rejected)
admin_note      text nullable
submitted_at    timestamptz defaultNow
reviewed_at     timestamptz nullable
```

Domain-specific columns on other tables:
- Debate: `motion text`, `format text`, `wins int`, `losses int`, `speaker_points decimal`
- Tech: `github_url text`, `skills text[]`, `preferred_language text`
- Arts: `portfolio_url text`, `medium text[]`
- Business: `linkedin_url text`, `startup_idea text`, `industry text`
- Science: `research_area text`, `lab_affiliation text`
- Sports: `position text`, `jersey_number int`, `stats jsonb`

### 3e. Design guide (Visualizer — HTML widget)

Four sections, all anchored to the user's base color:

1. **Color palette** — 6-8 swatches with evocative names. Derived from Step 2 color processing. If `PAYMENT_ENABLED`, include a "Pending amber" and "Approved green" swatch for payment status UI.

2. **Typography** — Display, heading, body, mono fonts. Club-specific copy samples (not Lorem Ipsum):
   - Debate: `"The House Believes..."` / `"Spring Championship 2026"`
   - Tech: `"git commit -m 'init'"` / `"Build. Ship. Repeat."`
   - Arts: `"Opening Night — Gallery 3"` / `"Call for Submissions"`
   - Sports: `"Match Day"` / `"Season Record: 12W 3L"`

3. **Type scale** — 5 sizes rendered: display → h1 → h2 → body → small.

4. **Component tokens** — Primary button, secondary button, 4-6 domain badges. If `PAYMENT_ENABLED`, also show payment-specific badges rendered inline:
   - "PENDING REVIEW" (amber), "PAYMENT VERIFIED" (green), "REJECTED" (red), "BDT 500" (neutral)
   
   Layout tokens as text: max container, card padding, section gap, border radius.

Design philosophy paragraph (2-3 sentences).

### 3f. Folder structure (code block)

Full Next.js 16 App Router folder tree. Top comment: `// [Club Name] — [University]`. Route groups: `(public)`, `(auth)`, `(member)`, `(admin)`. If `PAYMENT_ENABLED`, include:

```
app/
  (member)/
    pay/
      [context-slug]/
        page.tsx          Bkash TrxID + Reference form
        submitted/
          page.tsx        "Under review" confirmation screen
  (admin)/
    admin/
      payments/
        page.tsx          Payment submissions table: approve / reject

components/
  payment/
    BkashPaymentForm.tsx  TrxID + Reference inputs with validation
    PaymentStatusBadge.tsx
    PaymentConfirmation.tsx

lib/
  payment.ts              validateTrxId(), submitPayment(), approvePayment()
```

Always include `/.env.example` at root and `/drizzle/` for migrations.

### 3g. Auth + payment flow diagram (Visualizer — mermaid)

If `PAYMENT_ENABLED`, extend the auth diagram to include the payment path:
```
Visit paid event → Session? → No → Sign up → Return to event
Session? → Yes → /pay/[slug] → Submit TrxID+Ref → Pending
Admin reviews → Approve → Email sent → RSVP activated
Admin reviews → Reject → Email sent → User notified
```
Keep to ~14 nodes. Use `flowchart LR` direction.

If `PAYMENT_DISABLED`, standard auth diagram (~10 nodes).

### 3h. Drizzle schema (code block)

Full TypeScript. Header: `// [Club Name] — [University] — Drizzle Schema`. Order: imports → enums → Better Auth tables (`user`, `session`, `account`, `verification`) → domain tables → `payment_submissions` (if enabled) → junction tables.

If `PAYMENT_ENABLED`, include:
```ts
export const contextTypeEnum = pgEnum('context_type', ['event_rsvp', 'membership', 'workshop', 'tournament'])
export const paymentStatusEnum = pgEnum('payment_status', ['pending', 'approved', 'rejected'])

export const paymentSubmissions = pgTable('payment_submissions', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: text('user_id').references(() => user.id, { onDelete: 'cascade' }),
  contextType: contextTypeEnum('context_type').notNull(),
  contextId: uuid('context_id').notNull(),
  bkashTrxId: text('bkash_trx_id').notNull(),
  reference: text('reference').notNull(),
  amount: decimal('amount', { precision: 10, scale: 2 }).notNull(),
  status: paymentStatusEnum('status').default('pending'),
  adminNote: text('admin_note'),
  submittedAt: timestamp('submitted_at').defaultNow(),
  reviewedAt: timestamp('reviewed_at'),
  reviewedBy: text('reviewed_by').references(() => user.id),
})
```

### 3i. Feature specifications (prose)

One paragraph per non-trivial feature. If `PAYMENT_ENABLED`, include a dedicated "bKash manual payment system" section:

> **bKash manual payment system.** When a user wants to register for a paid event or activity, they are first checked for a session — if absent, redirected to sign-up with a callback URL. Once authenticated, they land on `/pay/[context-slug]`, which shows the event name, amount in BDT, and the club's bKash number with a simple instruction to send the money and note their Transaction ID. The form collects two fields: Transaction ID (the TrxID from their bKash app) and Reference (whatever they typed in the payment note). Both are required, no format enforcement beyond "not empty". On submit, a `payment_submissions` row is created with `status: 'pending'`, a `context_type` marking what was paid for, and the `context_id` linking to the specific event. Resend fires an acknowledgement email. The user sees a confirmation screen telling them to wait. In the admin panel at `/admin/payments`, the admin sees a clean table: user name, event, TrxID, Reference, submitted time, status. The admin opens their bKash app, finds the transaction, and clicks Approve or Reject — with an optional note. Resend fires the outcome email to the user. On approval, the user's registration for that event is activated in the DB. This same flow handles all paid scenarios via the `context_type` enum — no separate payment logic per feature.

Also cover: sign-up gate (how the "redirect to sign-up" pattern works across all CTAs), multi-step application form (name all steps and fields), countdown page behavior (if selected), member dashboard (exact data shown, tailored to club type), blog categories (named for this club), admin panel capabilities per section.

### 3j. Environment variables (code block)

`.env.local` format. Header: `# [Club Name] — Environment Variables`. Always include:
```bash
# Neon
DATABASE_URL=
DATABASE_URL_UNPOOLED=

# Better Auth
BETTER_AUTH_SECRET=    # 32+ chars: openssl rand -base64 32
BETTER_AUTH_URL=       # full production URL

# App
NEXT_PUBLIC_APP_URL=

# Email
RESEND_API_KEY=
```

If `PAYMENT_ENABLED`, add:
```bash
# bKash
BKASH_NUMBER=          # The bKash number users send money to (displayed on the payment page)
```

End with: "Copy to `.env.example` with all values blanked, then commit `.env.example` to the repo."

### 3k. Build timeline (Visualizer — mermaid gantt)

`dateFormat YYYY-MM-DD`, start from today's approximate date. If `PAYMENT_ENABLED`, add payment tasks to the appropriate phase:
```
section Phase 3 — Member zone & payments
  bKash payment form + validation    :3d
  Payment submission flow            :2d
  Admin payment review panel         :3d
  Resend approval/rejection emails   :2d
```
5 phases total. Domain-specific phase names. `milestone` for launch.

### 3l. Stack-specific gotchas

Only for the chosen stack. Pull from `references/stack-notes.md`. Standard checks: Neon + Cloudflare lazy `getDb`, Better Auth Edge compat (auth route as Node runtime), next/image unoptimized on Cloudflare, countdown hydration.

If `PAYMENT_ENABLED`, always add:
> **Duplicate submission guard.** Check for an existing `payment_submissions` row with the same `(user_id, context_id, status='pending')` before inserting — prevents a user submitting twice for the same event while their first submission is still pending admin review.

### 3m. Out of scope

2-4 sentences. If `PAYMENT_DISABLED`, mention bKash payment as a first easy v2 addition. Name 3-4 other features excluded from v1. Note which are easy to add given existing schema.

## Step 4 — Closing

Always end with both:

**Repo reminder:**
> "Your first push to [repo URL] should be the folder structure scaffold and `.env.example`. Never commit real env values — rotate any credentials immediately if they leak into git history."

**Next step offer:**
> "Ready to start generating code? I'd suggest starting with Phase 1 — [specific first task, e.g. 'Drizzle schema + Better Auth setup'] — so the data foundation is solid before any UI work."

## Reference files

Read `references/stack-notes.md` for ready-to-paste code:
- Neon + Drizzle: two drivers, lazy `getDb()`, drizzle.config, migration commands, common errors
- Better Auth: setup, middleware, catch-all route, client, role-based protection, Edge runtime caveats
- Cloudflare Pages: next.config.js, build config, Edge Runtime rules
- Next.js App Router: Server Components, Server Actions, route group layouts, countdown hydration fix
- Resend: basic pattern, env vars

## Quality checklist

Before finishing:
- [ ] Club name and university appear throughout — not just in the intro
- [ ] User's base color anchors the entire design palette
- [ ] Color names are evocative (not "Dark Gray")
- [ ] DB columns are domain-specific for the club type
- [ ] Font samples use club-specific copy, not Lorem Ipsum
- [ ] Component badges are domain-specific
- [ ] If `PAYMENT_ENABLED`: `payment_submissions` table included in schema
- [ ] If `PAYMENT_ENABLED`: `/pay/[context-slug]` in site architecture and folder structure
- [ ] If `PAYMENT_ENABLED`: bKash number shown on payment page (from `BKASH_NUMBER` env var)
- [ ] If `PAYMENT_ENABLED`: admin `/admin/payments` shows TrxID + Reference for manual verification
- [ ] If `PAYMENT_ENABLED`: payment badges shown in design guide component tokens
- [ ] If `PAYMENT_ENABLED`: `BKASH_NUMBER` in env vars
- [ ] If `PAYMENT_ENABLED`: payment tasks in Gantt Phase 3
- [ ] Sign-up gate behavior described in feature specs and shown in user flow
- [ ] Folder structure uses route groups and maps to all selected features
- [ ] Drizzle schema: correct imports, enums, FKs, club-specific columns
- [ ] Gantt phases reference club domain where natural
- [ ] Stack gotchas match only the chosen stack
- [ ] GitHub repo URL appears in closing
- [ ] `.env.example` mentioned in folder structure and closing
- [ ] No emojis anywhere in output
- [ ] Visualizer used for: user flow SVG, DB schema widget, design guide widget, auth/payment flow, Gantt
