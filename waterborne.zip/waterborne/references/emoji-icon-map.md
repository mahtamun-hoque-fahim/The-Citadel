# Emoji → lucide-react icon map

The job: given an emoji glyph (and its Unicode name, which the scanner prints),
pick the correct `lucide-react` component. Three outcomes are possible:

1. **Map** — the emoji has a clear lucide equivalent (most cases). Use the table.
2. **Delete** — the emoji is purely decorative/emotional with no UI function.
   Remove it; do not substitute an icon.
3. **Fallback** — no exact table entry. Follow the fallback procedure at the end.

All icon names below are valid `lucide-react` exports. lucide renames icons
occasionally; if `npm run build` reports an unknown export, check the current
name on https://lucide.dev and use that. Known renames are listed at the bottom.

Default styling for an inline icon: `className="size-4"` (16px) or `size-5`
(20px). Match the surrounding text size; never hardcode width/height when a
Tailwind `size-*` class fits.

---

## Status / feedback

| Emoji | Unicode name | lucide icon |
|---|---|---|
| ✅ ✔️ ✔ ☑️ | CHECK MARK / HEAVY CHECK MARK | `Check` (bare) or `CheckCircle2` (badge) |
| ❌ ✖️ ✗ ✘ | CROSS MARK / MULTIPLICATION X | `X` (bare) or `XCircle` (badge) |
| ⚠️ | WARNING SIGN | `AlertTriangle` |
| ❗ ❕ ‼️ | EXCLAMATION MARK | `AlertCircle` |
| ❓ ❔ | QUESTION MARK | `HelpCircle` |
| ℹ️ | INFORMATION SOURCE | `Info` |
| 🚫 ⛔ | NO ENTRY / PROHIBITED | `Ban` |
| 🔴 | RED CIRCLE | `Circle` (with `fill-red-500 text-red-500`) |
| 🟢 | GREEN CIRCLE | `Circle` (with `fill-green-500 text-green-500`) |
| 🟡 | YELLOW CIRCLE | `Circle` (with `fill-yellow-500 text-yellow-500`) |
| 💯 | HUNDRED POINTS | delete, or `BadgeCheck` if it means "verified" |

## Actions / tools

| Emoji | Unicode name | lucide icon |
|---|---|---|
| 🚀 | ROCKET | `Rocket` |
| 🔧 🛠️ | WRENCH / HAMMER AND WRENCH | `Wrench` |
| ⚙️ | GEAR | `Settings` |
| 🔨 | HAMMER | `Hammer` |
| 🔍 🔎 | MAGNIFYING GLASS | `Search` |
| ✏️ 🖊️ 📝 | PENCIL / MEMO | `Pencil` (edit) / `FileText` (note) |
| 🗑️ | WASTEBASKET | `Trash2` |
| 📌 | PUSHPIN | `Pin` |
| 📎 | PAPERCLIP | `Paperclip` |
| 🔗 | LINK SYMBOL | `Link` |
| 📤 ⬆️(upload) | OUTBOX TRAY | `Upload` |
| 📥 ⬇️(download) | INBOX TRAY | `Download` |
| 🔄 | ANTICLOCKWISE ARROWS | `RefreshCw` |
| ➕ | HEAVY PLUS SIGN | `Plus` |
| ➖ | HEAVY MINUS SIGN | `Minus` |
| ✂️ | SCISSORS | `Scissors` |
| 💾 | FLOPPY DISK | `Save` |
| 📋 | CLIPBOARD | `Clipboard` |
| 🔘 | RADIO BUTTON | `CircleDot` |
| 🎛️ | CONTROL KNOBS | `SlidersHorizontal` |

## Communication

| Emoji | Unicode name | lucide icon |
|---|---|---|
| 📧 ✉️ 📩 📨 | ENVELOPE / E-MAIL | `Mail` |
| 💬 🗨️ | SPEECH BALLOON | `MessageSquare` |
| 📞 ☎️ | TELEPHONE | `Phone` |
| 🔔 | BELL | `Bell` |
| 🔕 | BELL WITH SLASH | `BellOff` |
| 📢 📣 | LOUDSPEAKER / MEGAPHONE | `Megaphone` |
| 📡 | SATELLITE ANTENNA | `Satellite` / `Rss` |

## Files / data

| Emoji | Unicode name | lucide icon |
|---|---|---|
| 📁 🗂️ | FILE FOLDER | `Folder` |
| 📂 | OPEN FILE FOLDER | `FolderOpen` |
| 📄 📃 📑 | PAGE / DOCUMENT | `FileText` |
| 📊 | BAR CHART | `BarChart3` |
| 📈 | CHART INCREASING | `TrendingUp` |
| 📉 | CHART DECREASING | `TrendingDown` |
| 🏷️ | LABEL | `Tag` |
| 🗄️ | FILE CABINET | `Archive` |
| 🔖 | BOOKMARK | `Bookmark` |
| 📚 📖 | BOOKS / OPEN BOOK | `BookOpen` |

## Media

| Emoji | Unicode name | lucide icon |
|---|---|---|
| 🎵 🎶 | MUSICAL NOTE(S) | `Music` |
| 🎤 | MICROPHONE | `Mic` |
| 🎥 🎬 | MOVIE CAMERA / CLAPPER | `Video` / `Film` |
| 📷 📸 | CAMERA | `Camera` |
| 🖼️ | FRAMED PICTURE | `Image` |
| 🔊 | SPEAKER HIGH VOLUME | `Volume2` |
| 🔇 | MUTED SPEAKER | `VolumeX` |
| ▶️ | PLAY BUTTON | `Play` |
| ⏸️ | PAUSE BUTTON | `Pause` |
| ⏹️ | STOP BUTTON | `Square` |
| ⏭️ | NEXT TRACK | `SkipForward` |
| ⏮️ | LAST TRACK | `SkipBack` |
| 🎧 | HEADPHONE | `Headphones` |

## Time

| Emoji | Unicode name | lucide icon |
|---|---|---|
| ⏰ | ALARM CLOCK | `AlarmClock` |
| ⏱️ ⏲️ | STOPWATCH / TIMER | `Timer` |
| 🕐..🕧 | CLOCK FACE | `Clock` |
| ⌛ ⏳ | HOURGLASS | `Hourglass` |
| 📅 📆 🗓️ | CALENDAR | `Calendar` |

## People

| Emoji | Unicode name | lucide icon |
|---|---|---|
| 👤 🙋 | BUST IN SILHOUETTE | `User` |
| 👥 | BUSTS IN SILHOUETTE | `Users` |
| 👍 | THUMBS UP | `ThumbsUp` |
| 👎 | THUMBS DOWN | `ThumbsDown` |
| 🤝 | HANDSHAKE | `Handshake` |
| 👋 | WAVING HAND | delete (decorative) or `Hand` |
| 🎉 🥳 🙌 👏 😀 😄 🙂 😉 😎 🤔 🙏 💪 | celebration / emotion | **delete** (decorative, no UI function) |

## Navigation / place

| Emoji | Unicode name | lucide icon |
|---|---|---|
| 🏠 🏡 | HOUSE | `Home` |
| 📍 | ROUND PUSHPIN | `MapPin` |
| 🗺️ | WORLD MAP | `Map` |
| 🌍 🌎 🌏 | GLOBE | `Globe` |
| 🧭 | COMPASS | `Compass` |
| 🚩 | TRIANGULAR FLAG | `Flag` |
| ➡️ | RIGHTWARDS ARROW (emoji) | `ArrowRight` |
| ⬅️ | LEFTWARDS ARROW (emoji) | `ArrowLeft` |
| ⬆️ | UPWARDS ARROW (emoji) | `ArrowUp` |
| ⬇️ | DOWNWARDS ARROW (emoji) | `ArrowDown` |
| 🔙 🔚 🔛 🔜 🔝 | back/end/on/soon/top | text label, not an icon |

(Note: the plain typographic arrows `→ ← ↑ ↓` are NOT emoji and the scanner
ignores them. Leave them alone.)

## Concepts / objects

| Emoji | Unicode name | lucide icon |
|---|---|---|
| 💡 | LIGHT BULB | `Lightbulb` |
| 🔑 | KEY | `Key` |
| 🔒 🔐 | LOCK | `Lock` |
| 🔓 | OPEN LOCK | `Unlock` |
| 🛡️ | SHIELD | `Shield` |
| ⭐ 🌟 ✨ | STAR / SPARKLES | `Star` (rating) / `Sparkles` (AI/magic) |
| ❤️ 🧡 💛 💚 💙 💜 | HEART | `Heart` |
| 🔥 | FIRE | `Flame` |
| ⚡ | HIGH VOLTAGE | `Zap` |
| 🎯 | DIRECT HIT | `Target` |
| 🏆 | TROPHY | `Trophy` |
| 🎁 | WRAPPED GIFT | `Gift` |
| 💰 💵 💲 | MONEY / DOLLAR | `DollarSign` / `Wallet` |
| 🛒 | SHOPPING CART | `ShoppingCart` |
| 📦 | PACKAGE | `Package` |
| 💻 | LAPTOP | `Laptop` |
| 🖥️ | DESKTOP COMPUTER | `Monitor` |
| 📱 | MOBILE PHONE | `Smartphone` |
| ⌨️ | KEYBOARD | `Keyboard` |
| 🖨️ | PRINTER | `Printer` |
| 🔋 | BATTERY | `BatteryFull` |
| 🔌 | ELECTRIC PLUG | `Plug` |
| 💎 | GEM STONE | `Gem` |
| 🧩 | PUZZLE PIECE | `Puzzle` |
| 🚗 | AUTOMOBILE | `Car` |
| ✈️ | AIRPLANE | `Plane` |
| 🗝️ | OLD KEY | `KeyRound` |
| 🧪 | TEST TUBE | `FlaskConical` |
| 🩺 | STETHOSCOPE | `Stethoscope` |
| 💊 | PILL | `Pill` |
| 🧠 | BRAIN | `Brain` |
| 🤖 | ROBOT | `Bot` |
| 👁️ | EYE | `Eye` |

## Weather / nature

| Emoji | Unicode name | lucide icon |
|---|---|---|
| ☀️ | SUN | `Sun` |
| 🌙 | CRESCENT MOON | `Moon` |
| ☁️ | CLOUD | `Cloud` |
| 🌧️ | CLOUD WITH RAIN | `CloudRain` |
| ⛈️ | THUNDER CLOUD | `CloudLightning` |
| ❄️ | SNOWFLAKE | `Snowflake` |
| 🌱 | SEEDLING | `Sprout` |
| 🌳 🌲 | TREE | `TreeDeciduous` / `TreePine` |
| 🍃 🌿 | LEAF | `Leaf` |
| 💧 | DROPLET | `Droplet` |
| 🌈 | RAINBOW | delete (decorative) |

---

## Fallback procedure (no table entry)

1. Read the Unicode name the scanner printed. It usually states the concept
   plainly (e.g. "PERSON RUNNING", "BANK", "HOSPITAL").
2. Search https://lucide.dev for that concept word. lucide has 1400+ icons;
   most concrete nouns exist (`Building2`, `Hospital`, `Footprints`, etc.).
3. If a close icon exists, use it.
4. If nothing fits AND the emoji is **decorative/emotional**, delete it.
5. If nothing fits but the emoji is **functional** (it conveys real meaning the
   user relies on), use a neutral placeholder (`CircleDot` or `Dot`) and
   **flag it in the report** so Fahim can choose a better icon. Never leave the
   emoji in to "be safe" — leaving it fails the scan gate.

## Known lucide name gotchas

- Older guidance used `XCircle`, `CheckCircle` — current lucide-react exports
  are `XCircle` and `CheckCircle2`. Prefer the `2` variant if a build error
  says the bare name is missing.
- `Trash` exists but `Trash2` (with lid lines) is the common choice.
- `Image` may collide with the DOM `Image` global in some files; alias it:
  `import { Image as ImageIcon } from "lucide-react"`.
- There is no `Emoji`, `Smiley`, or `PartyPopper` worth using in production —
  those map to **delete**.
- If any import errors at build, the icon was renamed; confirm on lucide.dev.
