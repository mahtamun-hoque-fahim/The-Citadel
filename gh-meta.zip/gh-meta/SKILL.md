---
name: gh-meta
description: >
  GitHub metadata manager for Fahim's projects. Fills the GitHub About section
  (description, homepage, topics), detects whether a project needs a LICENSE
  file and which one (MIT vs All Rights Reserved — from repo visibility, the
  saas topic, and BRAIN.md anti-goals), manages semantic versioning via git
  tags and npm version, generates changelogs from git log, and creates GitHub
  releases via gh CLI. Two modes: INIT (seed About + license from BRAIN.md)
  and RELEASE (bump version, changelog, release, sync About). ALWAYS use when
  Fahim says "gh-meta", "fill about", "cut a release", "bump version", "tag
  this", "what version am I on", "ship the release", "create github release",
  "gh release", "seed the about", "update topics", "add a license", "what
  license", or "do I need a license". Runs at Phase 0 init after
  repo-maintainer, and Phase 5 after Council POST, before ticket-checker.
  Reads BRAIN.md for seeding; reads Airborne/Humanizer for release copy.
  Never edits code — metadata, versioning, and licensing only.
---

# gh-meta

GitHub metadata manager. Two modes: **INIT** (project creation) and **RELEASE** (ship time).
Read-only **READ** mode also available for status checks without writing anything.

---

## When to Use

| Trigger | Mode |
|---|---|
| New project, repo-maintainer just scaffolded docs | INIT |
| "fill about", "gh-meta init", "seed github about", "set up topics" | INIT |
| Council POST said SHIP | RELEASE |
| "bump version", "cut a release", "tag this", "gh-meta release" | RELEASE |
| "what version am I on", "release list", "release history" | READ |
| Topics or description changed without a version bump | SYNC (About only) |

---

## Phase 0 — Always First: Auth + Snapshot

Run this before any write operation.

```bash
# 1. Verify gh CLI is authenticated
gh auth status

# 2. Snapshot current GitHub state before overwriting anything
gh repo view --json name,description,url,topics,latestRelease,defaultBranchRef
```

If `gh auth status` fails: stop. Tell Fahim to run `gh auth login` first. Do not proceed until authenticated.

**Scope note:** `gh repo edit` (description, homepage, topics) is a repo-settings change, not a content push — it needs broader scope than the push-only PAT Fahim hands over for skill zips elsewhere. A classic PAT needs the `repo` scope; a fine-grained PAT needs **Administration: Read and write** on that repo specifically. If `gh repo edit` fails with a permissions error even though `gh auth status` passed, that's the scope, not the auth — tell Fahim plainly rather than retrying. Same security rule applies regardless: a fresh token in-chat, never persisted, rotate after use.

---

## INIT Mode — Seed the About Section at Project Start

**Trigger:** New project, immediately after repo-maintainer scaffolds docs.

### Step 1 — Source the description

**Standard path — BRAIN.md exists (any project that went through Singularity):**

Extract:
- Project tagline / one-liner → `--description`
- Deployment URL → `--homepage`
- Tech stack list → base topics

**Meta-repo path — no BRAIN.md (skill libraries, tool collections, portfolio repos that never went through Singularity — e.g. The-Citadel):**

Don't block waiting for a file that will never exist for this category of repo. Ask Fahim directly for the one-line description, or use copy he's already drafted in-chat. No deployment URL applies — skip `--homepage` unless he gives one (e.g. a docs site). Topics still come from Step 2, just scanned against the repo's actual contents (skill folders, README, package.json if present) instead of a single app's `package.json`.

### Step 2 — Auto-generate topics from package.json

Scan `dependencies` + `devDependencies` and apply this mapping:

| Detected package | Topics to add |
|---|---|
| `next` | `nextjs` |
| `typescript` / `@types/*` | `typescript` |
| `tailwindcss` | `tailwind-css` |
| `drizzle-orm` | `drizzle-orm` |
| `better-auth` | `better-auth` |
| `@neondatabase/serverless` | `neon` · `postgresql` |
| `lemon-squeezy` / `@lemonsqueezy/*` | `lemon-squeezy` · `saas` |
| `@upstash/redis` | `upstash` · `redis` |
| `resend` | `resend` |
| `cloudinary` | `cloudinary` |
| `ably` | `ably` · `realtime` |
| `framer-motion` | `framer-motion` |
| `@vercel/og` | `vercel` |
| `zod` | `zod` |
| `trpc` / `@trpc/*` | `trpc` |
| `socket.io` | `websocket` · `realtime` |
| `stripe` | `stripe` · `payments` |

Always add project-category tags from BRAIN.md "What It Is" section (e.g. `saas`, `dashboard`, `auth`, `payments`, `open-source`).

GitHub topic limit: 20. Trim least-specific ones if over.

### Step 3 — Detect license need and write LICENSE if confirmed

Nobody upstream decides this today — Singularity locks identity, tree-man locks routes, but licensing has no owner. gh-meta is the right place to catch it: it already reads BRAIN.md and the topic list at this exact moment, and a `LICENSE` file is metadata, not code, same category as everything else gh-meta touches.

**Check current state first — never overwrite a license Fahim already chose:**
```bash
gh repo view --json visibility,licenseInfo
```
If `licenseInfo` is already non-null, skip this step entirely and say so in the report.

**Decision table** (uses the `saas` topic already produced in Step 2 — no new classification system):

| Repo visibility | `saas` topic present? | BRAIN.md anti-goals mention competitors/cloning/IP | Recommendation |
|---|---|---|---|
| Private | any | any | Skip — no LICENSE needed, code never leaves the repo |
| Public | yes | no | **All Rights Reserved** — public-facing SaaS, visible but not licensed for reuse |
| Public | yes | yes | **All Rights Reserved** — anti-goal confirms it |
| Public | no | yes | **All Rights Reserved** — IP-protection anti-goal overrides category |
| Public | no | no | **MIT** — open tool/library/portfolio default, GitHub convention |

**Always confirm before writing — same pattern as Singularity's palette lock, never silent:**
> "This reads as [public open tool / public SaaS / private SaaS]. Recommending **[MIT / All Rights Reserved / no license file]**. Lock it in?"

If Fahim names a specific license instead (Apache-2.0, GPL, etc.), use that — the table is a default, not a rule.

**MIT** — write `LICENSE`:
```
MIT License

Copyright (c) [YYYY] Mahtamun Hoque Fahim

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
```

**All Rights Reserved** — write `LICENSE`:
```
Copyright (c) [YYYY] Mahtamun Hoque Fahim. All Rights Reserved.

This source code is made publicly visible for portfolio and demonstration
purposes only. No permission is granted to copy, modify, distribute,
sublicense, or use this code, in whole or in part, for any purpose,
without explicit prior written permission from the copyright holder.
```

`[YYYY]` = current year. Copyright holder is the legal name (Mahtamun Hoque Fahim), not the brand name — brand names don't hold copyright.

**Retrofit check (any mode, not just INIT):** if gh-meta runs in RELEASE or READ mode on a repo where `licenseInfo` is null and visibility is public, surface a one-line flag in the report — `"No LICENSE on a public repo. Run gh-meta INIT to fix."` — rather than staying silent. Cutting a release on an unlicensed public repo is exactly the kind of gap this pipeline exists to catch, not just at project birth.

### Step 4 — Output the command

```bash
gh repo edit \
  --description "One-line description from BRAIN.md tagline" \
  --homepage "https://your-deployed-url.com" \
  --topics "nextjs,typescript,tailwind-css,drizzle-orm,better-auth,neon,saas"
```

### Step 5 — Generate README badges

Inject these at the top of README.md (below the project title):

```markdown
![Version](https://img.shields.io/github/v/release/mahtamun-hoque-fahim/{repo}?style=flat-square&color=00e676)
![License](https://img.shields.io/github/license/mahtamun-hoque-fahim/{repo}?style=flat-square)
![Stars](https://img.shields.io/github/stars/mahtamun-hoque-fahim/{repo}?style=flat-square)
```

Replace `{repo}` with the actual repo name. Badges are live — they pull from GitHub automatically once a release is cut. The License badge now has something real to reflect once Step 3 commits a file, instead of permanently reading "no license."

---

## RELEASE Mode — Cut a Version at Ship Time

**Trigger:** Council POST said SHIP. Runs before ticket-checker.

Order is strict. Do not skip steps.

### Step 1 — Read current version

```bash
git describe --tags --abbrev=0        # latest tag → e.g. v1.0.0
git describe --tags                   # current position → e.g. v1.0.0-3-gabcd123
git tag -l --sort=-v:refname          # full tag history, semver sorted
```

If no tags exist yet: first release, starting from `v0.1.0`. Ask Fahim: patch, minor, or major for the first cut?

### Step 2 — Generate changelog from git log

```bash
# Commits since last tag (or all commits if first release)
git log $(git describe --tags --abbrev=0 2>/dev/null || git rev-list --max-parents=0 HEAD)..HEAD \
  --pretty=format:"- %s (%h)"
```

Claude sorts and formats the raw output into structured sections:

```markdown
## [vX.Y.Z] — YYYY-MM-DD

### Added
- New feature description (abc1234)

### Fixed
- Bug description (def5678)

### Changed
- Behaviour change description (ghi9012)
```

Prepend this entry to `CHANGELOG.md`. Create the file if it doesn't exist.

Commit prefixes as a guide:
- `feat:` / `add:` → Added
- `fix:` / `bug:` → Fixed
- `refactor:` / `chore:` / `style:` → Changed
- `docs:` → skip (internal)

### Step 3 — Bump the version

**For Next.js / Node projects (package.json present):**

```bash
npm version patch    # bug fix: 1.0.0 → 1.0.1
npm version minor    # new feature: 1.0.0 → 1.1.0
npm version major    # breaking change: 1.0.0 → 2.0.0
```

`npm version` automatically edits `package.json`, commits `vX.Y.Z`, and creates the git tag.

**For projects without package.json:**

```bash
# Edit VERSION file manually, then:
git add CHANGELOG.md VERSION
git commit -m "chore: release vX.Y.Z"
git tag -a vX.Y.Z -m "Release vX.Y.Z"
```

### Step 4 — Push code and tag together

```bash
git push origin main --follow-tags
```

`--follow-tags` pushes the commit and the new tag in one command. Never push them separately — race conditions between code and tag cause broken release states.

### Step 5 — Create the GitHub release

```bash
gh release create vX.Y.Z \
  --title "vX.Y.Z — Short title from Airborne/Humanizer copy" \
  --notes "$(git log PREV_TAG..vX.Y.Z --pretty=format:'- %s (%h)')"
```

Claude generates this command filled in with the real version number, a polished title (sourced from Airborne/Humanizer if available, otherwise from BRAIN.md tagline), and the formatted changelog notes from Step 2.

### Step 6 — Sync About description (if changed)

Run only if Airborne/Humanizer produced copy that improves on the original INIT description:

```bash
gh repo edit \
  --description "Updated polished description from Airborne/Humanizer output" \
  --homepage "https://live-deployed-url.com"
```

Topics are sticky — only update if the stack genuinely changed (new major dependency added or removed).

---

## READ Mode — Check State Without Writing

No writes. Safe to run at any time.

```bash
gh auth status                                         # confirm authenticated
gh release list                                        # all releases, newest first
gh release view                                        # latest release detail
gh repo view --json name,description,url,topics,latestRelease,licenseInfo   # full current metadata
git describe --tags --abbrev=0                         # current version tag
git tag -l --sort=-v:refname                           # full version history
git log $(git describe --tags --abbrev=0)..HEAD --oneline       # unreleased commits
```

Use when Fahim says "what version am I on", "show release history", or "what's unreleased."

---

## SYNC Mode — About Only (No Version Bump)

When description or topics need updating without a release:

```bash
gh auth status

# Read current state
gh repo view --json description,url,topics

# Update only what changed
gh repo edit \
  --description "..." \
  --topics "..."
```

Do not run `npm version` or create a release in this mode.

---

## Pipeline Position

### Phase 0 — Project Init

```
singularity → BRAIN.md committed
  → tree-man → SITETREE.md
  → Council PRE-BUILD → verdict
  → repo-maintainer → docs scaffolded
  → gh-meta INIT mode      ← seeds About + LICENSE + README badges
  → build begins
```

### Phase 5 — Ship

```
Council POST → SHIP verdict
  → gh-meta RELEASE mode
      ↳ Step 1: read current version
      ↳ Step 2: changelog from git log
      ↳ Step 3: npm version patch/minor/major
      ↳ Step 4: git push --follow-tags
      ↳ Step 5: gh release create
      ↳ Step 6: gh repo edit (description sync if changed)
  → ticket-checker
  → git push to production
```

---

## Connections

| Skill | Direction | What transfers |
|---|---|---|
| **singularity** | singularity → gh-meta | BRAIN.md: description, deployment URL, tech stack, anti-goals → INIT About command + LICENSE recommendation |
| **airborne** | airborne → gh-meta | Polished meta description → RELEASE About update + release title |
| **humanizer** | humanizer → gh-meta | De-AI'd copy → RELEASE About update |
| **repo-maintainer** | gh-meta → repo-maintainer | `git describe --tags` version tag → README version badge in AGENTS.md sync |
| **compass** | compass routes to gh-meta | Phase 5 slot: after Council POST, before ticket-checker |
| **ticket-checker** | gh-meta → ticket-checker | Checkpoint: version bumped, release created, About synced, license resolved |

---

## Output Format

gh-meta always produces this structure:

```
┌──────────────────────────────────────────────────────┐
│  gh-meta — [INIT / RELEASE / READ / SYNC]            │
│  Project: [name]    Mode: [mode]    Date: [YYYY-MM-DD]│
└──────────────────────────────────────────────────────┘

VERSION
  Current:   v1.x.x
  Previous:  v1.x.y
  Bump type: patch / minor / major

LICENSE
  Status:    [none found / MIT / All Rights Reserved / already set]
  Action:    [skipped — private repo / proposed — awaiting confirm / written]

CHANGELOG
  Commits since last tag: [N]
  [formatted CHANGELOG.md entry — copy-paste ready]

COMMANDS (run in order)
  1. [command]
  2. [command]
  3. [command]
  ...

BADGES (inject into README.md)
  [markdown badge lines]

STATUS: DONE / NEEDS AUTH / BLOCKED: [reason]
```

All commands are numbered, copy-paste ready, and ordered for safe execution. Never reorder them.

---

## Trigger Phrases

`gh-meta` · `fill about` · `cut a release` · `bump version` · `version bump` ·
`tag this` · `what version am I on` · `update release` · `ship the release` ·
`create github release` · `gh release` · `seed the about` · `release history` ·
`update topics` · `gh-meta init` · `gh-meta release` · `gh-meta read` · `gh-meta sync` ·
`add a license` · `what license` · `license this` · `do I need a license`
