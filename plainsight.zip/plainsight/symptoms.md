# Symptoms

Lookup table for fixing existing broken code. Find the visual symptom, read the cause, apply the fix. Each entry is a one-line patch unless noted.

When in doubt, search this file for the keyword that matches what the user said: "centered", "overlap", "clip", "scroll", "stuck", "stretch", "shift".

---

## Centering

### Subtitle / paragraph renders left-aligned in a narrow column anchored to the left edge
**Cause:** Has `max-w-*` without `mx-auto`. `text-center` on the parent only centers text inside the narrow box, not the box itself.
**Fix:** Add `mx-auto` to the element with `max-w-*`. Or move the `max-w-*` to a wrapper that has `mx-auto`, and remove it from the inner element.

### Heading centered but subtitle left-aligned right under it
**Cause:** Heading inherits `text-center` from the parent; subtitle has its own `max-w-*` that pins it left.
**Fix:** Wrap both in `<div className="mx-auto max-w-2xl text-center">` so they share one centered container.

### Block element refuses to center even with `text-center` on parent
**Cause:** `text-center` only centers inline content. Block elements need `mx-auto` and an explicit width or `max-w-*`.
**Fix:** Add `mx-auto max-w-fit` (or any `max-w-*`).

### Items in a flex container won't center vertically
**Cause:** Missing `items-center`, or container has no defined height.
**Fix:** Add `items-center` to the flex parent. If the parent height equals its content height, add `min-h-*` or stretch with `h-full`.

---

## Hero / above-the-fold

### Hero content sits below the fold; large empty space above it
**Cause:** `min-h-screen flex items-center` + fixed/sticky header. Hero centers in the *full* viewport, leaving header-sized gap.
**Fix:** Replace `min-h-screen` with `min-h-[calc(100svh-4rem)]` (use your header height in rem).

### Hero looks fine on desktop but content gets pushed off-screen on mobile Safari
**Cause:** Using `vh` instead of `svh`/`dvh`. iOS Safari address bar toggles change `vh` measurements.
**Fix:** Swap `min-h-screen` → `min-h-svh`, `h-screen` → `h-svh`.

### CTA buttons sit next to the subtitle's last line instead of below it
**Cause:** Buttons are direct siblings of `<p>` and inherit text flow.
**Fix:** Wrap buttons in `<div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center">`.

### Hero image/mockup floats next to text on desktop but should stack
**Cause:** Two sibling blocks inside a parent without a grid/flex layout, only inline-block whitespace.
**Fix:** Wrap in `<div className="grid grid-cols-1 gap-8 lg:grid-cols-2 items-center">`.

---

## Grids

### Grid renders 1 column at every viewport regardless of `grid-cols-N`
**Cause:** Parent is `flex flex-col items-center` with no width — grid is constrained to content width.
**Fix:** Either remove `items-center` from the parent, or add `w-full` to the grid.

### Grid renders 2 columns at every breakpoint, ignoring `lg:grid-cols-4`
**Cause:** Missing responsive prefix on the base class (`grid-cols-2 lg:grid-cols-4` keeps 2 cols below lg). Or the section's container is too narrow at lg.
**Fix:** Use `grid-cols-1 sm:grid-cols-2 lg:grid-cols-4` and confirm parent has `max-w-7xl` or wider.

### Cards in a grid have different heights, ragged bottom edge
**Cause:** Cards have different content lengths; default grid stretch is being overridden somewhere.
**Fix:** Add `h-full` to the card root and `flex flex-col` inside. Pin footers with `mt-auto`.

### Last row of grid has fewer cards and they're centered, looking off
**Cause:** This is grid default behavior — not a bug, but rarely desired.
**Fix:** Pad to a multiple of the column count, or use a list with `flex flex-wrap` and accept the natural left-alignment.

### Grid has uneven horizontal spacing between cards
**Cause:** Margin on individual cards instead of `gap-*` on the grid.
**Fix:** Remove card margins; add `gap-4` (or appropriate) to the grid container.

---

## Marquee / ticker

### Marquee text clips on one or both edges, characters cut off
**Cause:** Track content not duplicated, or animation translates by a value that doesn't match the duplication count.
**Fix:** Render content twice (`[...items, ...items]`) and animate to exactly `-50%`. For three copies, animate to `-33.333%`.

### Marquee jumps at the loop point instead of being seamless
**Cause:** Animation translates by a value that doesn't reset content to the same visual position.
**Fix:** Same as above — duplication count and translation must satisfy `translate = -100/N %`.

### Marquee items break onto new lines instead of flowing horizontally
**Cause:** Missing `whitespace-nowrap` on items, or missing `flex w-max` on track.
**Fix:** Add both. Container needs `overflow-hidden`.

---

## Sticky and fixed

### `sticky` element scrolls away with the page, ignoring `top-0`
**Cause:** An ancestor has `overflow-hidden`, `overflow-auto`, or `overflow-scroll`. Sticky binds to the nearest scroll container; if that's not the viewport, it sticks within that container only.
**Fix:** Remove `overflow-*` from the ancestor. If you can't, switch to `fixed` positioning and handle layout shift manually.

### Sticky table header doesn't stay visible while scrolling the table
**Cause:** The scroll context is fine but `<thead>` has no `sticky top-0` AND the wrapper needs explicit height (`max-h-*` + `overflow-auto`) for the sticky to have something to stick to.
**Fix:** `<thead className="sticky top-0 bg-neutral-950 z-10">` and wrap the table in `<div className="max-h-96 overflow-auto">`. Background on `<thead>` is essential — otherwise content shows through.

### Fixed header overlaps initial content under it
**Cause:** Fixed elements are removed from flow; content under them isn't offset.
**Fix:** Add `pt-14` (or your header height) to the page wrapper or the first section.

---

## Overflow and clipping

### Dropdown menu / popover is cut off at a card edge
**Cause:** An ancestor has `overflow-hidden` (commonly on cards with `rounded-* overflow-hidden`). The menu is rendered inside that ancestor and clips to its bounds.
**Fix:** Either (a) remove `overflow-hidden` from the ancestor, (b) move the menu out of the clipping ancestor in the DOM, or (c) use Radix/Headless UI which portals the menu to `<body>`.

### Tooltip near screen edge gets cut off
**Cause:** Tooltip positioned with `absolute` doesn't know about viewport edges.
**Fix:** Use Radix Tooltip or `@floating-ui/react` for collision detection. Hand-rolled tooltips only work in the middle of the screen.

### Image overflows its container instead of fitting
**Cause:** No size constraint on the image, or missing `object-cover`/`object-contain`.
**Fix:** `<img className="size-full object-cover">` inside a sized container. For `next/image` with `fill`, parent needs `relative` and a defined height.

### Modal/drawer doesn't cover the full screen
**Cause:** Missing `fixed inset-0` on the backdrop.
**Fix:** `<div className="fixed inset-0 z-50 bg-black/70">` for the backdrop.

---

## Text and content overflow

### Long username/email breaks the entire row layout
**Cause:** Flex children default to `min-width: auto`, refusing to shrink below content size. `truncate` does nothing because the parent expands instead.
**Fix:** Add `min-w-0` to the flex child wrapper, then `truncate` on the text element. Also ensure other flex siblings have `shrink-0` so they don't get squeezed.

### URL or code string overflows a card or container
**Cause:** Long unbreakable strings (URLs, code) don't break at word boundaries.
**Fix:** Add `break-all` for ruthless breaking, or `break-words` for word-aware breaking with fallback. For code, `overflow-x-auto` on a `<pre>` is better.

### Multi-line text expected to wrap but renders on one line that overflows
**Cause:** Parent has `whitespace-nowrap` somewhere, or it's inside a flex row without `min-w-0`.
**Fix:** Remove `whitespace-nowrap`. Add `min-w-0` to the flex parent.

### Long content pushes button or icon out of its row
**Cause:** Icon/button has no `shrink-0`; flex distributes shrinkage proportionally.
**Fix:** Add `shrink-0` to elements that must keep their size.

### Text needs to truncate after N lines
**Cause:** `truncate` only does single-line truncation.
**Fix:** Use `line-clamp-2` (or 3, 4) for multi-line.

---

## Tables

### Table overflows page on mobile, makes user scroll the whole page horizontally
**Cause:** No scroll wrapper around the table.
**Fix:** Wrap the `<table>` in `<div className="overflow-x-auto">`. Add `min-w-[640px]` (or appropriate) to the table so columns don't squish into illegibility.

### Table headers don't stay visible when scrolling a tall table
**Cause:** No sticky thead, or scroll context not on the right ancestor.
**Fix:** Wrap in `<div className="max-h-96 overflow-auto">`, then `<thead className="sticky top-0 bg-neutral-950">`.

### Cell content overflows the cell
**Cause:** Long content + `min-w-*` on the cell.
**Fix:** Add `max-w-[Npx]` and `truncate` to the cell. Consider showing full text in a tooltip.

---

## Modals and dialogs

### Page scrolls behind an open modal
**Cause:** Body scroll not locked.
**Fix:** Toggle `document.body.style.overflow = "hidden"` while modal is open. Restore on close. Or use Radix Dialog (handles automatically).

### Modal appears under the navbar / sticky header
**Cause:** Modal z-index ≤ navbar z-index.
**Fix:** Modal at `z-50`, navbar at `z-40` (or lower).

### Modal backdrop doesn't dismiss the modal when clicked
**Cause:** Backdrop click handler missing, or backdrop is wrapping the panel so all clicks (including panel) close it.
**Fix:** Backdrop and panel as siblings. Click handler on backdrop only.

### Focus stays on the page behind the modal; user can Tab outside
**Cause:** No focus trap.
**Fix:** Use Radix/Headless UI Dialog. Hand-rolling focus trap is error-prone.

### Modal stays open when Escape is pressed
**Cause:** No keydown listener.
**Fix:** `useEffect` with `window.addEventListener("keydown", e => e.key === "Escape" && onClose())`.

---

## Sidebar and app shell

### Sidebar covers content on desktop
**Cause:** Sidebar is `fixed` but main container has no left padding/margin matching sidebar width.
**Fix:** Add `lg:pl-64` (matching sidebar `w-64`) to the main content wrapper.

### Sidebar takes full width on mobile, blocking content
**Cause:** Sidebar visible at all viewports without mobile drawer pattern.
**Fix:** `hidden lg:block` on the sidebar, and add a mobile drawer triggered by a hamburger button.

### Main content area is too narrow despite sidebar being collapsed
**Cause:** Main has hardcoded `lg:pl-64` but sidebar is now `w-16` (collapsed).
**Fix:** Lift collapsed state to the layout; conditionally apply `lg:pl-16` or `lg:pl-64`.

### Long content in a flex main column blows out the sidebar
**Cause:** Main is a flex child without `min-w-0`. Flex children refuse to shrink below content size.
**Fix:** Add `min-w-0` to the main flex child.

---

## Buttons and forms

### Clicking a button inside a form submits the form unintentionally
**Cause:** Button defaults to `type="submit"` inside a form.
**Fix:** Add `type="button"` to any button that isn't the form's submit action.

### Form field focus ring is invisible
**Cause:** `focus:outline-none` removed the ring without adding a replacement.
**Fix:** Replace with `focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500`.

### Label doesn't activate input when clicked
**Cause:** `<label>` and `<input>` not linked.
**Fix:** `<label htmlFor="x">` + `<input id="x">`.

### Submit button doesn't show loading state during pending Server Action
**Cause:** Using local `useState` for pending instead of `useFormStatus`.
**Fix:** In a client child of the form, `const { pending } = useFormStatus()`.

---

## Images

### Image renders stretched or squashed
**Cause:** Width and height set without `object-cover` / `object-contain`.
**Fix:** `<img className="size-full object-cover">` to crop to box, or `object-contain` to letterbox.

### Layout jumps when image loads
**Cause:** No reserved space for the image.
**Fix:** Wrap in `<div className="relative aspect-video">` and use `<Image fill>`. Or pass explicit `width`/`height` to `<Image>`.

### `next/image` with `fill` shows nothing
**Cause:** Parent has no `relative` or no defined height.
**Fix:** Parent needs `position: relative` and a height (via `aspect-*` or explicit `h-*`).

---

## Hydration and SSR

### Console warning: "Hydration failed because the initial UI does not match"
**Cause:** Server HTML ≠ first client render. See `nextjs-rules.md` § Hydration traps for the five common causes.
**Fix:** Identify which element the warning points at; fix per the rules.

### Theme flashes wrong color on page load (dark/light flicker)
**Cause:** Theme value resolved client-side after SSR.
**Fix:** Use `next-themes` with `attribute="class"` and `disableTransitionOnChange`. Set initial theme via cookie read in the server layout, OR use a blocking inline script in `<head>` that sets the class before paint.

### `localStorage` read crashes the build
**Cause:** Reading `localStorage` at module top level or in render body — runs during SSR where `localStorage` doesn't exist.
**Fix:** Move inside `useEffect`, or guard with `typeof window !== "undefined"`.

---

## Tailwind specific

### Utility classes appear in HTML but render unstyled
**Cause:** Tailwind v3 `@tailwind` directives in a v4 project (or vice versa). Silently does nothing.
**Fix:** Check `package.json` for `tailwindcss` version. For v4: `@import "tailwindcss"`. For v3: `@tailwind base; @tailwind components; @tailwind utilities;`.

### Custom color/font from `tailwind.config.ts` doesn't work in v4 project
**Cause:** v4 doesn't read `tailwind.config.ts` by default — tokens go in `@theme {}` in CSS.
**Fix:** Move tokens to `@theme` block in `globals.css`. Or add `@config "./tailwind.config.ts"` at the top of CSS to opt in.

### Arbitrary value `bg-[#abc123]` doesn't render
**Cause:** Tailwind couldn't see the file (content paths in v3 config) or content scanner missed it (v4 should auto-detect).
**Fix:** v3: check `content: [...]` in config. v4: ensure file is in scanned source directory.

### `dark:` variants not applying
**Cause:** Either dark class not on `<html>`, or v4 project without `@variant dark` setup.
**Fix:** v3: `darkMode: "class"` in config, add `class="dark"` to `<html>`. v4: add `@custom-variant dark (&:where(.dark, .dark *))` to `globals.css` then `class="dark"` on `<html>`.

---

## Animations and transitions

### `transition` doesn't trigger
**Cause:** No property change happens after first render. Or browser optimizes away a transition between same values.
**Fix:** Toggle a class or inline style that changes the transitioned property. For mount animations, use `data-[state=open]:animate-in` (Radix) or render after `mounted` flag.

### CSS height animation doesn't work
**Cause:** Can't transition from `height: auto` to `0`. CSS doesn't know "auto".
**Fix:** Use `max-height` with a big number, or `grid-template-rows: 0fr` → `1fr` trick, or use a library like Radix Accordion that handles this.

### Page scroll behaves weirdly after animation
**Cause:** Animation modifies `transform` or `opacity` on a parent of fixed/sticky elements — breaks their positioning context.
**Fix:** Move the animated element to a sibling, not an ancestor, of the sticky/fixed element.

---

## Accessibility

### Tab order is wrong; keyboard users can't reach elements
**Cause:** `tabindex` overridden, or interactive elements are `<div>` without `role="button"` and `tabindex="0"`.
**Fix:** Use `<button>` for buttons. Don't use `tabindex > 0`. Use `tabindex="0"` only on custom interactive elements that also have a role.

### Screen reader announces buttons as "button button button" with no labels
**Cause:** Icon-only buttons without `aria-label`.
**Fix:** Add `aria-label="..."` to every icon-only button.

### Color contrast fails accessibility audit
**Cause:** Text on background doesn't meet WCAG AA (4.5:1 for normal text, 3:1 for large).
**Fix:** Bump up the text color brightness. On dark themes, `text-neutral-400` is the minimum for body; `text-neutral-300` is safer.
