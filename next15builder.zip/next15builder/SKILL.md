---
name: next15builder
description: >
  Comprehensive build playbook for Next.js 15 projects. ALWAYS use this skill
  when the user mentions: building, scaffolding, or working on a Next.js 15
  project; "Next.js 15", "App Router", "create-next-app", "Server Components",
  "Server Actions", "use client", "use server", route handlers, middleware,
  dynamic routes, params, searchParams, cookies(), headers(), generateMetadata,
  generateStaticParams, layout.tsx, page.tsx, loading.tsx, error.tsx,
  not-found.tsx, fetch caching, revalidatePath, revalidateTag, Tailwind v4 setup,
  shadcn/ui in App Router, next.config.ts, Turbopack, React 19 in Next, hydration
  errors in Next, or any "params should be awaited" error. SCOPE: Next.js 15 only.
  For Next.js 16 projects (proxy.ts, cacheComponents, updateTag, Turbopack default),
  use next16builder instead. Use proactively at the START of any new Next.js 15
  feature so the code is correct on the first attempt, not after errors.
---

# Next15Builder

> A build-time playbook for Next.js 15 (15.x only). For Next.js 16 projects, use **next16builder** — it has the correct patterns for proxy.ts, cacheComponents, updateTag, and Turbopack-as-default. Read this BEFORE writing any Next.js 15 code. Lower-capability models: follow the rules and decision trees in order — do not improvise.

---

## 0. The Five Hard Rules (read these first, every time)

These are the rules where breaking even one causes a runtime or build error in Next.js 15+. Memorize them before writing a single line.

1. **`params`, `searchParams`, `cookies()`, `headers()`, `draftMode()` are all Promises. ALWAYS `await` them.**
2. **`fetch()` is uncached by default** in Next.js 15+. Opt in with `{ cache: 'force-cache' }` or `{ next: { revalidate: N } }`.
3. **Server Components are the default.** Add `'use client'` only when you need state, effects, browser APIs, or event handlers.
4. **You can import Client → into Server, but never Server → into Client.** A Client Component can receive Server Components as `children` props, but cannot `import` them.
5. **`cookies()`, `headers()`, `redirect()`, `notFound()` only work in Server Components, Server Actions, Route Handlers, and Middleware.** Never in Client Components.

If a build or runtime error mentions any of these, recheck the rule first before writing new code.

---

## 1. The Mental Model (the thinking pattern)

Before writing any Next.js code, walk these decisions in order. Do NOT skip steps.

**Step A — Identify the file's location and role**
- `app/**/page.tsx` → a route. Server Component by default. Receives `params` and `searchParams` as **Promises**.
- `app/**/layout.tsx` → wraps a route segment. Server Component by default. Receives `params` as a **Promise** and `children` as a node.
- `app/**/route.ts` → a Route Handler (REST endpoint). Exports HTTP methods (`GET`, `POST`, etc.). The 2nd arg's `params` is a **Promise**.
- `app/**/loading.tsx` / `error.tsx` / `not-found.tsx` → segment UI states. `error.tsx` must be a Client Component.
- `middleware.ts` (root) → runs on the Edge. No DB calls with Node drivers. No `cookies()` from `next/headers` — use `req.cookies` instead.
- A component file under `components/` → Server by default unless it uses state/effects/events.

**Step B — Decide Server or Client**
Ask: does this file need ANY of the following?
- `useState`, `useEffect`, `useReducer`, `useContext`, `useRef`
- Event handlers (`onClick`, `onChange`, `onSubmit`)
- Browser APIs (`window`, `document`, `localStorage`, `navigator`)
- Third-party hooks (React Query, Zustand, Framer Motion's `motion.div` with animation props, etc.)

If YES to ANY → put `'use client'` on line 1.
If NO → leave it as a Server Component. Server Components can be `async` and `await` data directly.

**Step C — Decide data fetching strategy**
- Reading data for initial render → fetch in the Server Component directly (`async function Page() { const data = await ... }`).
- Mutating data from a form/button → use a Server Action (`'use server'`).
- Fetching from the client after interaction → use a Route Handler + `fetch()` from the Client Component, or a library like SWR/React Query.

**Step D — Decide caching**
- Static data that rarely changes → `fetch(url, { cache: 'force-cache' })` or `{ next: { revalidate: 3600 } }`.
- Per-request data (auth, dashboards) → leave as default (uncached) or use `{ cache: 'no-store' }` for clarity.
- After mutations → call `revalidatePath('/path')` or `revalidateTag('tag-name')` inside the Server Action.

**Step E — Type the props correctly**
Always use the new Promise-based prop types. See Section 3.

---

## 2. Project Initialization (the only correct way)

Use this exact command for new projects. Do not deviate.

```bash
npx create-next-app@latest my-app --typescript --tailwind --eslint --app --src-dir --import-alias "@/*"
```

Flags explained (low models: do not omit any):
- `--typescript` — TypeScript is non-negotiable.
- `--tailwind` — installs Tailwind v4 (in current scaffolds) with the new CSS-first setup.
- `--eslint` — adds Next's flat-config ESLint.
- `--app` — App Router (the only router pattern this skill covers).
- `--src-dir` — code lives under `src/`. Keeps the root clean.
- `--import-alias "@/*"` — `@/lib/foo` resolves to `src/lib/foo`.

After creation, the canonical structure (use this exact layout):

```
my-app/
├── src/
│   ├── app/
│   │   ├── layout.tsx          ← root layout, exports metadata, html/body
│   │   ├── page.tsx            ← landing route
│   │   ├── globals.css         ← Tailwind v4 import lives here
│   │   ├── (auth)/             ← route group: layout isolation only, no URL segment
│   │   │   ├── login/page.tsx
│   │   │   └── signup/page.tsx
│   │   ├── dashboard/
│   │   │   ├── layout.tsx
│   │   │   ├── page.tsx
│   │   │   ├── loading.tsx
│   │   │   └── [id]/page.tsx   ← dynamic segment
│   │   └── api/
│   │       └── auth/
│   │           └── route.ts    ← Route Handler
│   ├── components/
│   │   ├── ui/                 ← shadcn primitives (if used)
│   │   └── ...                 ← feature components
│   ├── lib/
│   │   ├── db/
│   │   │   ├── index.ts        ← drizzle client
│   │   │   └── schema.ts
│   │   ├── auth.ts             ← auth helpers
│   │   ├── env.ts              ← env var validation
│   │   └── utils.ts            ← cn() and small helpers
│   └── middleware.ts           ← optional, root-level
├── public/
├── drizzle/                    ← if using Drizzle migrations
├── drizzle.config.ts
├── next.config.ts              ← TypeScript config (Next 15+)
├── postcss.config.mjs
├── tsconfig.json
├── package.json
└── .env.local                  ← gitignored
```

**Run scripts** (in `package.json`):
- `dev` — `next dev --turbo` (Turbopack is stable in 15+).
- `build` — `next build`.
- `start` — `next start`.
- `lint` — `next lint`.

---

## 3. The Async Request APIs (THE breaking change)

This is the #1 source of errors in Next.js 15+ code written from Next 14 muscle memory. Every type that used to be `T` is now `Promise<T>`.

### page.tsx with dynamic params

```tsx
// src/app/blog/[slug]/page.tsx

// CORRECT — Next.js 15+
type PageProps = {
  params: Promise<{ slug: string }>
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}

export default async function BlogPostPage({ params, searchParams }: PageProps) {
  const { slug } = await params
  const { ref } = await searchParams
  return <article>Post: {slug} (ref: {ref})</article>
}

// WRONG — Next.js 14 style, will produce a runtime warning in 15 and a hard error in 16
export default function BlogPostPage({ params }: { params: { slug: string } }) {
  return <article>Post: {params.slug}</article> // ERROR: params should be awaited
}
```

### layout.tsx with dynamic params

```tsx
// src/app/dashboard/[orgId]/layout.tsx
type LayoutProps = {
  children: React.ReactNode
  params: Promise<{ orgId: string }>
}

export default async function DashboardLayout({ children, params }: LayoutProps) {
  const { orgId } = await params
  return (
    <section data-org={orgId}>
      {children}
    </section>
  )
}
```

### generateMetadata

```tsx
import type { Metadata } from 'next'

type Props = { params: Promise<{ slug: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  return { title: `Post: ${slug}` }
}
```

### cookies(), headers(), draftMode()

```ts
// CORRECT
import { cookies, headers, draftMode } from 'next/headers'

export async function getSession() {
  const cookieStore = await cookies()
  const token = cookieStore.get('session')?.value
  const ua = (await headers()).get('user-agent')
  const { isEnabled } = await draftMode()
  return { token, ua, isEnabled }
}

// WRONG
const cookieStore = cookies()                   // Promise<ReadonlyRequestCookies> — not the store
const token = cookies().get('session')          // ERROR
```

### Route Handlers (`route.ts`)

```ts
// src/app/api/posts/[id]/route.ts
import { NextRequest, NextResponse } from 'next/server'

type Ctx = { params: Promise<{ id: string }> }

export async function GET(req: NextRequest, { params }: Ctx) {
  const { id } = await params
  return NextResponse.json({ id })
}

export async function DELETE(req: NextRequest, { params }: Ctx) {
  const { id } = await params
  // ... delete logic
  return new NextResponse(null, { status: 204 })
}
```

### Client Components reading `params`

If you must consume params in a Client Component, the parent Server Component should `await` them and pass primitives down — do NOT pass the Promise through.

```tsx
// Server (page.tsx)
export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  return <ClientChild id={id} />
}

// Client
'use client'
export function ClientChild({ id }: { id: string }) { /* ... */ }
```

If you absolutely need the Promise in a Client Component, use React's `use()` hook:

```tsx
'use client'
import { use } from 'react'

export function ClientChild({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  return <div>{id}</div>
}
```

---

## 4. Server vs Client Components — Decision Tree

```
START
 │
 ├── Does the file need useState/useEffect/useRef/useContext? ─── YES → Client Component
 │
 ├── Does it use onClick/onChange/onSubmit handlers?           ─── YES → Client Component
 │
 ├── Does it use window/document/localStorage/navigator?       ─── YES → Client Component
 │
 ├── Is it error.tsx?                                          ─── YES → Client Component (required)
 │
 ├── Does it use a client-only library (Framer Motion, Recharts,
 │   React Query hooks, Zustand, Tone.js, etc.)?              ─── YES → Client Component
 │
 └── Otherwise                                                  → Server Component (default)
```

**Server Component capabilities** (use these freely):
- `async function` with `await` for data
- Direct DB/ORM access (Drizzle, Prisma, etc.)
- `cookies()`, `headers()`, `draftMode()` from `next/headers`
- `redirect()`, `notFound()` from `next/navigation`
- Reading env vars without `NEXT_PUBLIC_` prefix

**Client Component restrictions**:
- No `async` components (only `async` event handlers / effects)
- No direct DB access
- No `next/headers` imports
- Only env vars prefixed with `NEXT_PUBLIC_` are readable
- Server Components can be passed in as `children` or props, but cannot be `import`-ed

### The composition pattern (correct way to mix)

```tsx
// src/components/ClientShell.tsx
'use client'
import { useState } from 'react'

export function ClientShell({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false)
  return (
    <div>
      <button onClick={() => setOpen(o => !o)}>Toggle</button>
      {open && <aside>{children}</aside>}  {/* children can be a Server Component */}
    </div>
  )
}

// src/app/page.tsx (Server)
import { ClientShell } from '@/components/ClientShell'
import { ServerData } from '@/components/ServerData' // also a Server Component

export default function Page() {
  return (
    <ClientShell>
      <ServerData />
    </ClientShell>
  )
}
```

---

## 5. Data Fetching & Caching (the rules changed in 15)

In Next.js 14 `fetch()` was cached by default. In **Next.js 15+ it is NOT.** This trips up everyone migrating, and lower models often produce stale/incorrect caching code.

### Default behavior

```ts
// Uncached — runs on every request (Next 15+ default)
const res = await fetch('https://api.example.com/posts')

// Cached forever (until next deploy)
const res = await fetch('https://api.example.com/posts', { cache: 'force-cache' })

// Revalidated every 60 seconds (ISR-style)
const res = await fetch('https://api.example.com/posts', { next: { revalidate: 60 } })

// Tagged for on-demand revalidation
const res = await fetch('https://api.example.com/posts', { next: { tags: ['posts'] } })
```

### Route Handlers (`GET`) are also uncached by default

```ts
// src/app/api/posts/route.ts

// To cache: use the `dynamic` export
export const dynamic = 'force-static'         // cache aggressively
export const revalidate = 60                   // ISR every 60s

export async function GET() { /* ... */ }
```

### Mutations + revalidation (Server Actions pattern)

```ts
// src/app/actions/posts.ts
'use server'
import { revalidatePath, revalidateTag } from 'next/cache'
import { getDb } from '@/lib/db'
import { posts } from '@/lib/db/schema'

export async function createPost(formData: FormData) {
  const db = getDb()
  const title = formData.get('title') as string
  await db.insert(posts).values({ title })
  revalidatePath('/posts')         // refresh the list page
  // OR
  revalidateTag('posts')           // refresh anything tagged 'posts'
}
```

### Streaming with Suspense (parallel data fetching)

```tsx
// src/app/dashboard/page.tsx
import { Suspense } from 'react'
import { UserStats } from './UserStats'
import { RecentActivity } from './RecentActivity'

export default function Dashboard() {
  return (
    <>
      <Suspense fallback={<StatsLoader />}>
        <UserStats />
      </Suspense>
      <Suspense fallback={<ActivityLoader />}>
        <RecentActivity />
      </Suspense>
    </>
  )
}
```

Each Suspense boundary streams independently. Use this for slow data sources instead of awaiting everything serially.

---

## 6. Routing Patterns (App Router)

| File / Folder           | Purpose                                                    |
| ----------------------- | ---------------------------------------------------------- |
| `page.tsx`              | Renders a route. Required to make a folder routable.       |
| `layout.tsx`            | Wraps a segment. Persists across navigation.               |
| `loading.tsx`           | Auto Suspense fallback for the segment.                    |
| `error.tsx`             | Error boundary. **Must be Client Component.**              |
| `not-found.tsx`         | 404 UI for the segment.                                    |
| `route.ts`              | REST endpoint. Exports HTTP methods.                       |
| `default.tsx`           | Default slot for parallel routes.                          |
| `[slug]`                | Single dynamic segment.                                    |
| `[...slug]`             | Catch-all.                                                 |
| `[[...slug]]`           | Optional catch-all.                                        |
| `(group)`               | Route group — does NOT add a URL segment.                  |
| `@slot`                 | Parallel route slot.                                       |
| `(.)foo` `(..)foo`      | Intercepting routes (for modal-over-page patterns).        |

### Linking and navigation

```tsx
// Client- or Server-side links
import Link from 'next/link'
<Link href="/dashboard" prefetch>Dashboard</Link>

// Programmatic navigation — Client only
'use client'
import { useRouter } from 'next/navigation'
const router = useRouter()
router.push('/dashboard')
router.refresh()  // re-fetches Server Components for the current route
```

Common mistake: importing `useRouter` from `next/router` (Pages Router). **Always** import from `next/navigation` in the App Router.

---

## 7. Server Actions (the form/mutation pattern)

Server Actions are the canonical way to mutate data. Use them instead of building a Route Handler + `fetch` round-trip when the call originates from your own UI.

### Inline action (simplest form)

```tsx
// src/app/contact/page.tsx
export default function ContactPage() {
  async function submit(formData: FormData) {
    'use server'
    const email = formData.get('email') as string
    // ... do work
  }
  return (
    <form action={submit}>
      <input name="email" type="email" />
      <button type="submit">Send</button>
    </form>
  )
}
```

### Extracted action (preferred for reuse)

```ts
// src/app/actions/contact.ts
'use server'

export async function sendContact(formData: FormData) {
  const email = formData.get('email') as string
  // ...
}
```

```tsx
// src/app/contact/page.tsx
import { sendContact } from '@/app/actions/contact'
export default function Page() {
  return (
    <form action={sendContact}>
      <input name="email" />
      <button>Send</button>
    </form>
  )
}
```

### Action with progressive enhancement (`useActionState`)

```tsx
'use client'
import { useActionState } from 'react'    // React 19 hook
import { sendContact } from '@/app/actions/contact'

export function ContactForm() {
  const [state, formAction, pending] = useActionState(sendContact, { ok: false })
  return (
    <form action={formAction}>
      <input name="email" />
      <button disabled={pending}>{pending ? 'Sending...' : 'Send'}</button>
      {state.ok && <p>Sent.</p>}
    </form>
  )
}
```

For this to type-check, the action must return state matching the initial value:

```ts
'use server'
export async function sendContact(prev: { ok: boolean }, formData: FormData) {
  // ...
  return { ok: true }
}
```

### Server Action rules

- Always validate inputs (use Zod). Never trust `formData.get()` directly.
- Always `revalidatePath` or `revalidateTag` after mutating.
- For redirects post-mutation: `redirect('/dashboard')` from `next/navigation`.
- Errors thrown inside a Server Action bubble to the nearest `error.tsx`.

---

## 8. Middleware

Middleware runs on the Edge runtime for every matching request. It is the right place for: auth gating, redirects, A/B routing, locale detection, rewrite logic.

```ts
// src/middleware.ts
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export function middleware(req: NextRequest) {
  const token = req.cookies.get('session')?.value

  if (!token && req.nextUrl.pathname.startsWith('/dashboard')) {
    const url = req.nextUrl.clone()
    url.pathname = '/login'
    url.searchParams.set('next', req.nextUrl.pathname)
    return NextResponse.redirect(url)
  }

  return NextResponse.next()
}

export const config = {
  matcher: ['/dashboard/:path*', '/admin/:path*'],
}
```

### Middleware rules (critical for lower models)

- **Use `req.cookies` and `req.headers`** — NOT `cookies()` / `headers()` from `next/headers`.
- **No Node.js APIs** — no `fs`, `crypto` (use Web Crypto instead), no `Buffer`, no `process.env` lookups that depend on Node-specific modules.
- **No DB queries with Node drivers**. If you must hit a DB, use an Edge-compatible driver (e.g. `@neondatabase/serverless`).
- **Keep it fast.** Middleware runs on every request — minimize work.
- **`matcher` is your friend.** Without it, middleware runs on every static asset too.

---

## 9. Tailwind v4 Setup (CSS-first, no JS config)

Tailwind v4 is the default for new `create-next-app` scaffolds. Configuration moved from `tailwind.config.js` to CSS-side directives. Lower models often regress to v3 patterns — do not.

### `postcss.config.mjs` (auto-generated, do not edit unless needed)

```js
export default {
  plugins: {
    '@tailwindcss/postcss': {},
  },
}
```

### `src/app/globals.css`

```css
@import "tailwindcss";

/* Read palette from BRAIN.md § Visual Identity (Locked) or DESIGN_GUIDE.md tokens.
   Replace [accent], [accent-faint], [bg], [surface] with the project's actual values. */
@theme {
  --color-accent: [accent];        /* e.g. #7c3aed — from BRAIN.md */
  --color-accent-faint: [accent-faint]; /* e.g. #7c3aed1a */
  --color-bg: [bg];                /* e.g. #0b0b0f — from BRAIN.md, not a hardcoded default */
  --color-surface: [surface];      /* e.g. #14161e — from BRAIN.md, not a hardcoded default */
  --font-display: var(--font-syne);
  --font-sans: var(--font-onest);
  --font-mono: var(--font-jetbrains-mono);
}

/* Dark mode via the `dark` class on <html> */
@custom-variant dark (&:where(.dark, .dark *));

@layer base {
  body { @apply bg-background text-foreground antialiased; }
}
```

### Using design tokens

CSS variables defined in `@theme` are auto-promoted to utility classes:
- `--color-accent` → `text-accent`, `bg-accent`, `border-accent`, etc.
- `--font-display` → `font-display`.

### Migration trap (when upgrading from v3)

If you see `tailwind.config.ts` still in the repo with `content: [...]` paths, that file is now optional. v4 auto-scans your project. Either delete it or keep only the things v4 still respects (plugins, presets).

---

## 10. TypeScript Patterns

### Strict tsconfig (use this baseline)

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["dom", "dom.iterable", "esnext"],
    "module": "esnext",
    "moduleResolution": "bundler",
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "jsx": "preserve",
    "incremental": true,
    "isolatedModules": true,
    "resolveJsonModule": true,
    "skipLibCheck": true,
    "allowJs": true,
    "paths": { "@/*": ["./src/*"] },
    "plugins": [{ "name": "next" }]
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}
```

### Page prop types — let Next generate them (Next 15.5+ feature)

Run `npx next typegen` (Next 15.5+) to generate route-aware prop types:

```tsx
export default async function Page(props: PageProps<'/blog/[slug]'>) {
  const { slug } = await props.params
  return <h1>{slug}</h1>
}
```

If typegen isn't available, hand-write Promise types as shown in Section 3.

### Env var typing

```ts
// src/lib/env.ts
const required = ['DATABASE_URL', 'AUTH_SECRET'] as const

for (const key of required) {
  if (!process.env[key]) throw new Error(`Missing env var: ${key}`)
}

export const env = {
  DATABASE_URL: process.env.DATABASE_URL!,
  AUTH_SECRET: process.env.AUTH_SECRET!,
  NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL!,
}
```

---

## 11. `next.config.ts` (TypeScript config — Next 15+)

```ts
import type { NextConfig } from 'next'

const config: NextConfig = {
  reactStrictMode: true,
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'images.unsplash.com' },
      { protocol: 'https', hostname: '**.public.blob.vercel-storage.com' },
    ],
  },
  experimental: {
    // turn on per-feature as needed
  },
}

export default config
```

### Common config knobs

- `images.remotePatterns` — required for any `next/image` with an external host.
- `redirects()` — server-side redirects.
- `rewrites()` — proxy-style URL mapping.
- `headers()` — set security headers (CSP, HSTS, etc.).
- `serverExternalPackages: ['some-node-only-pkg']` — opt a package out of bundling.

---

## 11.5 Database Setup (Neon + Drizzle, lazy init)

```ts
// src/lib/db/index.ts
import { neon } from '@neondatabase/serverless'
import { drizzle } from 'drizzle-orm/neon-http'
import * as schema from './schema'

export function getDb() {
  if (!process.env.DATABASE_URL) return null as any
  return drizzle(neon(process.env.DATABASE_URL), { schema })
}
```

**Never** export a top-level `db` constant built from `drizzle(neon(...))` directly. That line runs the moment the module is imported — any file that imports it (a route handler, `auth.ts`, middleware) drags an eager connection attempt into Next's build-time static analysis, even when the build environment has no `DATABASE_URL` yet. This is the exact cause behind "build succeeds locally, fails on Vercel/Cloudflare" in Section 13 — and it's a real bug Fahim has hit in production. Call `getDb()` inside the function body that needs it, every time, never at module scope:

```ts
import { getDb } from '@/lib/db'

export async function createPost(formData: FormData) {
  const db = getDb()
  await db.insert(posts).values({ title: formData.get('title') as string })
}
```

Every database example elsewhere in this file already follows this pattern — `getDb()` called inside the function body, never a top-level `db` import.

## 12. Auth Pattern (Better Auth recommendation)

For new projects in this stack, prefer **Better Auth** (TypeScript-first, multi-provider, refresh-token support, Next.js-optimized) over NextAuth or hand-rolled JWT cookies.

```ts
// src/lib/auth.ts
import { betterAuth } from 'better-auth'
import { drizzleAdapter } from 'better-auth/adapters/drizzle'
import { getDb } from '@/lib/db'

export const auth = betterAuth({
  database: drizzleAdapter(getDb(), { provider: 'pg' }),
  emailAndPassword: { enabled: true },
  socialProviders: {
    google: {
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    },
  },
  session: {
    expiresIn: 60 * 60 * 24 * 7, // 7 days
    updateAge: 60 * 60 * 24,     // refresh daily
  },
})
```

```ts
// src/app/api/auth/[...all]/route.ts
import { auth } from '@/lib/auth'
import { toNextJsHandler } from 'better-auth/next-js'

export const { GET, POST } = toNextJsHandler(auth)
```

### Session reading in Server Components

```tsx
import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'

export default async function ProtectedPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session) redirect('/login')
  return <div>Hello {session.user.email}</div>
}
```

### Middleware-based protection

```ts
// src/middleware.ts
import { NextResponse, type NextRequest } from 'next/server'

export function middleware(req: NextRequest) {
  const session = req.cookies.get('better-auth.session_token')
  if (!session) return NextResponse.redirect(new URL('/login', req.url))
  return NextResponse.next()
}

export const config = { matcher: ['/dashboard/:path*'] }
```

---

## 13. Common Errors → Fixes

| Error message                                                              | Cause                                                | Fix                                                                    |
| -------------------------------------------------------------------------- | ---------------------------------------------------- | ---------------------------------------------------------------------- |
| `Route "/x" used \`params.y\`. params should be awaited`                   | Synchronous access to `params`                       | Make the component `async` and `await params`. Type as `Promise<...>`. |
| `cookies() was called outside a request scope`                             | Used `cookies()` in a non-request context            | Move into a Server Component, Route Handler, or Server Action.         |
| `cookies() should be awaited before using its value`                       | Forgot to await `cookies()`                          | `const store = await cookies()` then `store.get(...)`.                 |
| `You're importing a component that needs useState`                         | Used a React hook in a Server Component             | Add `'use client'` at the top of the file.                             |
| `Functions cannot be passed directly to Client Components`                 | Tried to pass a function prop from Server to Client | Wrap it in a Server Action (`'use server'`) or pass primitives.        |
| `Hydration failed because the server rendered HTML didn't match the client`| Time/random/locale-based render mismatch             | Move dynamic value into `useEffect`, or use `suppressHydrationWarning`. |
| `Module not found: Can't resolve 'fs'` (in Edge/Client)                    | Node-only module pulled into Edge/Client bundle      | Move usage to a Server Component or `route.ts` with Node runtime.      |
| `Error: Dynamic server usage: cookies`                                     | Used `cookies()` in a statically-rendered page       | Add `export const dynamic = 'force-dynamic'` or use it conditionally.  |
| `useRouter` returns `null` / errors                                        | Imported from `next/router`                          | Import from `next/navigation` instead.                                 |
| `revalidatePath is not a function`                                         | Imported from wrong path                             | `import { revalidatePath } from 'next/cache'`.                         |
| Tailwind classes not applying                                              | Tailwind v3 config used with v4, or dynamic class    | Use full class names (no template-string colors), drop v3 config.      |
| `EPERM` / `.next` lock errors on Windows                                   | Stale dev server                                     | Kill the `next dev` process, delete `.next`, restart.                  |
| `Application error: a server-side exception has occurred`                  | Uncaught error in Server Component / Action          | Wrap in try/catch, surface via `error.tsx`, check server logs.         |
| `Cannot read properties of undefined (reading 'env')` at build             | Missing env var at build time                        | Add to `.env.local` and to deployment env. Validate via `lib/env.ts`.  |

---

## 14. Performance & Image / Font Patterns

### Images

```tsx
import Image from 'next/image'

<Image
  src="/hero.png"          // local file in /public
  alt="Hero"
  width={1200}
  height={600}
  priority                  // for above-the-fold images only
/>

// Remote image — host must be in next.config.ts remotePatterns
<Image src="https://images.unsplash.com/photo-..." alt="..." width={800} height={600} />

// Fill mode — parent MUST have `position: relative` and a sized container
<div className="relative h-64 w-full">
  <Image src="/banner.jpg" alt="" fill className="object-cover" />
</div>
```

### Fonts (next/font, zero layout shift)

```tsx
// src/app/layout.tsx
import { Inter, JetBrains_Mono } from 'next/font/google'

const inter = Inter({ subsets: ['latin'], variable: '--font-sans' })
const mono = JetBrains_Mono({ subsets: ['latin'], variable: '--font-mono' })

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${mono.variable}`}>
      <body>{children}</body>
    </html>
  )
}
```

Reference in Tailwind v4 via `@theme { --font-sans: var(--font-sans); }`.

---

## 15. Deployment

### Vercel (preferred for Next.js)

- Auto-detects Next.js. No `vercel.json` needed for standard projects.
- Add every env var to **Production**, **Preview**, AND **Development** scopes.
- For database migrations, use a separate `DATABASE_URL_UNPOOLED` for the migration tool; keep pooled `DATABASE_URL` for app code.
- Production branch defaults to `main`. Change in Project Settings if needed.

### Self-hosting (Node)

```bash
next build
next start -p 3000
```

Set `output: 'standalone'` in `next.config.ts` for a minimal Docker image.

### Cloudflare Pages / Workers

- Use `@cloudflare/next-on-pages` build step.
- All routes run on the Edge — no `pg`, no `fs`, no `crypto` (use Web Crypto). Use `@neondatabase/serverless` for Postgres.
- Set `images: { unoptimized: true }` if not using Cloudflare Images.

---

## 16. Pre-Flight Checklist (run mentally before declaring "done")

Lower models: walk this list at the end of EVERY Next.js task before responding "done". If you can't tick a box, fix it.

- [ ] Every `page.tsx` / `layout.tsx` / `route.ts` that uses `params` or `searchParams` types them as `Promise<...>` and `await`s them.
- [ ] Every `cookies()`, `headers()`, `draftMode()` call is `await`ed.
- [ ] No Server Component uses `useState` / `useEffect` / `onClick`.
- [ ] No Client Component is marked `async`.
- [ ] No `import` of a Server Component inside a Client Component (passing as `children` is fine).
- [ ] `useRouter` imported from `next/navigation` (not `next/router`).
- [ ] `fetch()` calls have explicit caching (`force-cache`, `revalidate`, or comment confirming uncached is intentional).
- [ ] Server Actions end with `revalidatePath` / `revalidateTag` / `redirect` as appropriate.
- [ ] Forms post to a Server Action via `action={...}`, not via client-side `fetch` round-trips.
- [ ] All `next/image` external hosts are listed in `next.config.ts` → `images.remotePatterns`.
- [ ] No emojis in code, UI, commits, or documentation.
- [ ] No `.env*` file committed; sensitive values not hardcoded.
- [ ] No `console.log` of secrets, tokens, or PII left in code.
- [ ] `npm run build` would succeed (no TS errors, no missing env, no Edge/Node mixups).

---

## 17. Anti-Patterns to Never Generate

These are patterns lower models frequently produce. Do NOT.

- **Don't** write `params: { id: string }` — it must be `Promise<{ id: string }>` in Next 15+.
- **Don't** call `cookies()` without `await`.
- **Don't** import from `next/router` in App Router code.
- **Don't** use `getServerSideProps` / `getStaticProps` — those are Pages Router.
- **Don't** mark a Page or Layout component as `'use client'` unless absolutely required (it forces the whole subtree client-side and disables Server Component data fetching).
- **Don't** build dynamic Tailwind class names like `` `text-${color}-500` ``. The JIT can't see them.
- **Don't** use `<img>` for non-trivial images — use `next/image`.
- **Don't** use `<a href>` for internal navigation — use `<Link>`.
- **Don't** use `localStorage` in a Server Component (it doesn't exist there).
- **Don't** put a Server Action inside a Client Component's body — extract to a `'use server'` module.
- **Don't** rely on the synchronous-cookies compat shim from Next 15 — it's removed in 16. Always await.
- **Don't** read `process.env.X` without `NEXT_PUBLIC_` prefix in a Client Component — it will be `undefined`.
- **Don't** add emojis anywhere in generated code, UI strings, commits, or docs.

---

## 18. Quick Templates (copy-and-adapt)

### A complete dynamic route page with metadata, loading, error

```tsx
// src/app/blog/[slug]/page.tsx
import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { getDb } from '@/lib/db'
import { posts } from '@/lib/db/schema'
import { eq } from 'drizzle-orm'

type Props = { params: Promise<{ slug: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const db = getDb()
  const [post] = await db.select().from(posts).where(eq(posts.slug, slug)).limit(1)
  return { title: post?.title ?? 'Not found' }
}

export default async function BlogPostPage({ params }: Props) {
  const { slug } = await params
  const db = getDb()
  const [post] = await db.select().from(posts).where(eq(posts.slug, slug)).limit(1)
  if (!post) notFound()
  return (
    <article>
      <h1>{post.title}</h1>
      <div>{post.body}</div>
    </article>
  )
}
```

```tsx
// src/app/blog/[slug]/loading.tsx
export default function Loading() {
  return <div className="animate-pulse">Loading post...</div>
}
```

```tsx
// src/app/blog/[slug]/error.tsx
'use client'
export default function Error({ error, reset }: { error: Error; reset: () => void }) {
  return (
    <div>
      <p>Failed to load post: {error.message}</p>
      <button onClick={reset}>Try again</button>
    </div>
  )
}
```

### A form with Server Action and progressive enhancement

```ts
// src/app/actions/contact.ts
'use server'
import { z } from 'zod'
import { revalidatePath } from 'next/cache'
import { getDb } from '@/lib/db'
import { messages } from '@/lib/db/schema'

const schema = z.object({
  email: z.string().email(),
  body: z.string().min(1).max(2000),
})

type State = { ok: boolean; error?: string }

export async function sendContact(_prev: State, formData: FormData): Promise<State> {
  const db = getDb()
  const parsed = schema.safeParse({
    email: formData.get('email'),
    body: formData.get('body'),
  })
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message }
  await db.insert(messages).values(parsed.data)
  revalidatePath('/admin/messages')
  return { ok: true }
}
```

```tsx
// src/app/contact/contact-form.tsx
'use client'
import { useActionState } from 'react'
import { sendContact } from '@/app/actions/contact'

export function ContactForm() {
  const [state, action, pending] = useActionState(sendContact, { ok: false })
  return (
    <form action={action} className="space-y-4">
      <input name="email" type="email" required className="border p-2 w-full" />
      <textarea name="body" required className="border p-2 w-full" />
      <button type="submit" disabled={pending} className="bg-accent text-black px-4 py-2">
        {pending ? 'Sending...' : 'Send'}
      </button>
      {state.error && <p className="text-red-500">{state.error}</p>}
      {state.ok && <p className="text-green-500">Sent.</p>}
    </form>
  )
}
```

### A Route Handler with auth + validation

```ts
// src/app/api/posts/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { getDb } from '@/lib/db'
import { posts } from '@/lib/db/schema'

const createSchema = z.object({ title: z.string().min(1), body: z.string() })

export async function GET() {
  const db = getDb()
  const all = await db.select().from(posts)
  return NextResponse.json(all)
}

export async function POST(req: NextRequest) {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const parsed = createSchema.safeParse(body)
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues }, { status: 400 })
  }
  const db = getDb()
  const [row] = await db.insert(posts).values(parsed.data).returning()
  return NextResponse.json(row, { status: 201 })
}
```

---

## 19. When You Get Stuck — Diagnosis Order

If a Next.js 15+ build or runtime is failing, walk this in order. Do not skip steps.

1. **Read the error completely.** Next 15's error overlay tells you the file, the line, AND the docs link. Open the docs link.
2. **Check Section 13 (Common Errors).** 80% of errors are listed there with the fix.
3. **Check Section 0 (Five Hard Rules).** Is one being violated?
4. **Try `rm -rf .next && npm run dev`.** Half of phantom errors are stale cache.
5. **Check that the file is in the right place** (`page.tsx` vs `route.ts` vs `layout.tsx`).
6. **Check Server vs Client boundary.** Did you add `'use client'` where needed, or accidentally where not needed?
7. **Run `npm run build` locally.** Build errors are stricter than dev — they catch things dev misses.
8. **Check env vars.** Missing `NEXT_PUBLIC_` prefix on client values; missing values entirely in deploy env.
9. **Last resort:** search the exact error string in the Next.js GitHub issues. Real bugs are tracked there.

---

## End of Skill

Lower models: when invoked, read this entire file before generating code. Apply Section 1 (Mental Model) to every decision and Section 16 (Pre-Flight Checklist) before finishing. The async APIs change (Section 3) is the single most common source of bugs — never forget it.
