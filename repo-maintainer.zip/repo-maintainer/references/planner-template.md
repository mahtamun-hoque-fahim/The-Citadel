# PLANNER.md Template

Use this structure. Fill every section. Replace bracket placeholders.

---

```markdown
# [Project Name] — Planner

> One-line description: [what it does, for whom]

## Project Overview

**Purpose.** [What problem this solves in 2-3 sentences.]

**Target user.** [Who uses this. Be specific — "university debate club coaches" not "students".]

**Key value.** [The single most important thing this product delivers. One sentence.]

**Current phase.** [Planning / Building / Polishing / Live]

---

## Architecture

**Stack:**
- Framework: Next.js 14 App Router
- Language: TypeScript (strict)
- Styling: Tailwind CSS + CSS variables
- Database: Neon PostgreSQL
- ORM: Drizzle
- Auth: Better Auth
- Email: Resend
- Deployment: Vercel (primary), Cloudflare Pages (secondary)

**Deployment topology:**
- `main` → Vercel production
- PRs → Vercel preview
- `main` → Cloudflare Pages production (mirror)

**Folder structure (summary):** [link to README for full tree]

---

## User Flows

### Flow 1: [Name, e.g. "Student signs up and joins a class"]
1. User lands on `/`
2. Clicks "Sign up"
3. Redirected to `/sign-up`
4. Enters email + password → Better Auth creates user with `role: student`
5. Redirected to `/dashboard`
6. Sees empty state with "Join a class" CTA
7. Enters class code → joined → class appears in dashboard

### Flow 2: [Name]
[Same structure]

---

## DB Schema

Drizzle schema lives in `lib/db/schema.ts`. Summary:

### users
| column | type | notes |
|---|---|---|
| id | text PK | nanoid |
| email | text unique | |
| name | text | |
| role | enum | student / staff / admin |
| createdAt | timestamp | defaultNow |

### sessions / accounts / verification
[Standard Better Auth tables — see references/better-auth.md in mahtamun-fullstack skill]

### [domain table]
[Same structure]

---

## API Routes

| Method | Path | Auth | Body | Response |
|---|---|---|---|---|
| GET | /api/projects | session | — | Project[] |
| POST | /api/projects | session | `{ name }` | Project |
| PATCH | /api/projects/[id] | session + owner | `{ name? status? }` | Project |
| DELETE | /api/projects/[id] | session + owner | — | `{ ok: true }` |

[Add Server Actions section if used heavily]

---

## Env Vars

| Name | Required | Description | Example |
|---|---|---|---|
| DATABASE_URL | yes | Neon pooled connection | postgresql://...?sslmode=require |
| DATABASE_URL_UNPOOLED | yes | Neon direct connection (migrations) | postgresql://...?sslmode=require |
| BETTER_AUTH_SECRET | yes | Session signing secret (32+ chars) | (openssl rand -base64 32) |
| BETTER_AUTH_URL | yes | Public app URL | https://[project].com |
| NEXT_PUBLIC_APP_URL | yes | Same as above, client-readable | https://[project].com |
| RESEND_API_KEY | optional | For transactional email | re_... |

---

## Timeline / Phases

### Phase 1 — Foundation
Status: `[x]` done

- [x] Repo created, Vercel connected
- [x] Drizzle schema for core tables
- [x] Better Auth setup
- [x] Middleware protection

### Phase 2 — Core flows
Status: `[~]` in progress

- [x] Sign up / sign in
- [~] Dashboard scaffolding
- [ ] First domain feature
- [ ] Empty states

### Phase 3 — Polish
Status: `[ ]` pending

- [ ] Mobile responsiveness audit
- [ ] Accessibility pass (WCAG 2.2 AA)
- [ ] OG images
- [ ] Production deploy verification

---

## Next Steps

In order:
1. [Most immediate concrete task]
2. [Next concrete task]
3. [Following task]

Rewrite this section fresh on every `update repo` sync.

---

## Notes & decisions

[Free-form section for decisions worth remembering: "we chose X over Y because Z" — keep it brief, append-only, dated entries.]

**2026-05-22.** Migrated from split-cookie JWT auth to Better Auth. Reason: refresh tokens + unified session for both student and staff roles.
```
