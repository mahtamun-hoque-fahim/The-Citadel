---
name: cave-man
description: >
  Post-build visual-opportunity audit for Fahim's stack (Next.js, Tailwind, dark-first palette).
  Runs LAST in POST-BUILD, after airborne/humanizer, right before council — audits the truly final
  page set so nothing it briefs gets rewritten later. Reads SITETREE.md Layout Architecture section
  (tree-man output) to classify zones precisely before scanning any code. Classifies every visual
  zone by both verdict (NEEDS-ART, HAS-ART, KEEP-FLAT) and image type (inline, background, overlay,
  texture, parallax) — because a hero needs a background image while a feature split needs an inline
  image, and cave-man knows the difference. For NEEDS-ART zones, inserts a reserved-space placeholder
  with a 4-field brief tag (IMAGE-TYPE, IMAGE-BRIEF, IMAGE-OVERLAY, IMAGE-RESPONSIVE) plus a skeleton
  structure comment showing exactly how to integrate the art when it arrives. Never generates the
  artwork itself — the brief is the deliverable, the art is Fahim's. A scoped motion-hive touch-up
  follows to skeleton-treat the new placeholders before council POST.
  Trigger: "cave-man", "visual audit", "image audit", "where should images go",
  "find image opportunities", or a finished site that still reads flat or templated.
---

# cave-man

**Purpose:** find every place a custom visual would actually move the needle, find every place it
would not, classify each opportunity by how the image integrates with the layout, and prep the
structural slot with a clear brief for Fahim to design against.

**Position in pipeline:**
```
Waterborne → motion-hive AUDIT → valley-of-death → sentinel → airborne → humanizer → cave-man → motion-hive touch-up → council POST
```

---

## Why This Exists

Sites built by Claude read flat because the only visual content a model can produce on its own is
CSS — gradient meshes, icon-in-a-circle grids, abstract blobs. Those patterns are cheap to generate
and exactly why they look templated. The sites that read expensive (Linear, Stripe, Vercel marketing)
almost always have a custom photograph, illustration, or render doing real work in the hero and
feature zones — something a designer made, not something a stylesheet generated.

Fahim has a decade in Figma. The correct division of labor is: Claude identifies where a visual is
needed, what kind of visual integration fits the zone, and what the image should depict — Fahim
makes the actual call on what it looks like. cave-man only does the first half.

The old version of this skill told you where to put images without knowing how to integrate them.
A hero always got an `IMAGE-BRIEF:` comment. A feature split got the same comment. They are not
the same — a hero background is an image that IS the surface, with text layered over it, needing
an overlay for legibility. A feature split image is an inline element in a two-column grid. The
same brief format produced unusable guidance. This version classifies integration first.

---

## Phase 0 — Read Context First

Read in this order. All four are inputs to the zone classifier in Phase 2.

**SITETREE.md — Layout Architecture section (primary input):**
This is tree-man's output. The `section-sequence` field per page tells cave-man exactly which
sections exist and what order they appear in. The `layout-family` tells cave-man the overall
integration pattern. The `density` field tells cave-man whether a section has room for visual
content. The `rhythm` field tells cave-man which sections are already dark (background may add
noise) vs light (background image would add depth). If SITETREE.md is missing, scan `/app`
directly and note: "SITETREE.md missing — scanned /app, recommend running tree-man."

**BRAIN.md / DESIGN_GUIDE.md:**
Palette tokens and product mood. Briefs must reference real tokens (`bg-surface`, `accent`,
`accent/20`) — never raw hex. The product mood determines brief tone: a fintech product gets
"clean architectural photography, cool tones" not "vibrant lifestyle imagery."

**PLANNER.md:**
Which routes are public/marketing vs internal/functional. Confirms the MARKETING/FUNCTIONAL
classification where SITETREE.md layout-family is ambiguous.

**MOTION.md (if it exists):**
motion-hive BUILD output. If a zone already has a scroll-driven hook registered in MOTION.md,
its image type is likely `parallax` — note this in the brief rather than treating it as a
plain background zone.

---

## Phase 1 — Classify Every Page

Tag each route MARKETING or FUNCTIONAL using layout-family from SITETREE.md:

| Layout family | Classification |
|---|---|
| `marketing` | MARKETING |
| `split-screen` | MARKETING |
| `bento` | MARKETING |
| `card-grid` | MARKETING (portfolio) or FUNCTIONAL (admin listing) — check PLANNER.md |
| `editorial` | MARKETING (blog, docs landing) — body content is KEEP-FLAT, page-level zones may not be |
| `dashboard` | FUNCTIONAL |
| `form-wizard` | FUNCTIONAL |
| `minimal` | FUNCTIONAL (404, maintenance) — exception: 404 page may warrant a small illustration |

FUNCTIONAL pages get one line in the report: `"flat is correct"` — and are skipped.
Do not hunt for art opportunities on a settings page or a data table. Custom illustration on a
functional surface is a regression, not a feature.

---

## Phase 2 — Zone Classifier

Two passes per MARKETING page. First: derive image types from SITETREE.md section-sequence.
Second: verify against actual code.

### Pass A — Section-sequence to image type mapping

Read the `section-sequence` for the page from SITETREE.md Layout Architecture. Map each section
entry to its image integration type using this table:

| Section in sequence | Image type | Notes |
|---|---|---|
| `hero` (first section, full-width) | `parallax` or `background` | Parallax if MOTION.md registers a scroll hook here; background otherwise |
| `feature-split(×N)` | `inline` | The image column of the split. One per split row. |
| `testimonials` (full-bleed) | `background` or `overlay` | Background if testimonial text is small; overlay if dense quote text needs legibility treatment |
| `cta-band` (full-bleed dark) | `texture` or `background` | Texture for subtle depth; background if there's a strong visual story to tell |
| `how-it-works` (3-step) | `inline` (one per step) or `KEEP-FLAT` | Only if steps are visual/product-based; skip if steps are icon-and-text |
| `logo-wall` | `KEEP-FLAT` | SVG logos, never images |
| `pricing` | `KEEP-FLAT` | Dense data, no image |
| `faq` | `KEEP-FLAT` | Reading surface, no image |
| `footer` | `KEEP-FLAT` | Functional zone |
| `bento-grid` | `inline` per cell | Each bento cell that features a product capability gets one inline image |
| `card-grid` | `inline` per card | Card thumbnail/media slot — one per card, consistent ratio |
| `post-header` (editorial) | `inline` (cover image) | Blog post header gets a cover image |
| `body-content` (editorial) | `KEEP-FLAT` | Editorial body is a reading surface — no decorative images |
| `kpi-row`, `data-table`, `chart-zone` | `KEEP-FLAT` | Dashboard elements, all functional |
| `empty-state` | `inline` (small illustration) | Friendly empty-state graphic — mark as EXCEPTION-SMALL-ART |

Sections not in this table: classify by zone rules in Pass B.

### Pass B — Zone rules for unlisted sections

For any zone not covered by the section-sequence mapping above, use these rules:

| Zone signal | Image type |
|---|---|
| Full-width section, text overlaid, dark or atmospheric | `background` |
| Full-width section, text overlaid, image is purely mood (not content) | `overlay` |
| Full-width section, first section on the page with scroll room below | `parallax` |
| Two-column layout with one column dedicated to a visual | `inline` |
| Dark section needing depth without a focal point | `texture` |
| Card, list item, or grid cell with a dedicated media slot | `inline` |
| Repeated icon-in-circle treatment across 4+ cards (icon fatigue) | `inline` (one merged illustration, not per-card) |
| Pricing, settings, forms, data tables, admin panels | `KEEP-FLAT` |

**Density overrides:** If SITETREE.md marks a section as `density: dense`, lean toward
`KEEP-FLAT` or `texture` only. Dense sections rarely benefit from a full image and often look
cluttered when one is added.

**Rhythm overrides:** If SITETREE.md marks a section as already dark in the `rhythm` field
(e.g., `dark(hero)` in the alternation), adding a background image can be redundant unless the
image adds narrative content. Prefer `texture` for already-dark sections where depth is needed.

---

## Phase 3 — Print the Audit Table Before Touching Anything

| Page | Section | Zone | Verdict | Image type | Current treatment |
|---|---|---|---|---|---|
| `app/page.tsx` | `hero` | Full-width hero | NEEDS-ART | background | gradient blob — no image |
| `app/page.tsx` | `feature-split(×3)` | Right column, row 1 | NEEDS-ART | inline | empty div, 16:9 |
| `app/page.tsx` | `feature-split(×3)` | Right column, row 2 | NEEDS-ART | inline | empty div, 16:9 |
| `app/page.tsx` | `feature-split(×3)` | Right column, row 3 | NEEDS-ART | inline | empty div, 16:9 |
| `app/page.tsx` | `logo-wall` | Logo strip | KEEP-FLAT | — | SVG logos, correct |
| `app/page.tsx` | `testimonials` | Full-bleed block | NEEDS-ART | overlay | solid color bg only |
| `app/page.tsx` | `pricing` | Plan cards | KEEP-FLAT | — | flat is correct |
| `app/pricing/page.tsx` | `hero` | Page header | HAS-ART | — | real screenshot wired |
| `app/dashboard/page.tsx` | — | All zones | FUNCTIONAL | — | flat is correct, skipped |

Print this table and wait before inserting anything, unless told to run autonomously — then proceed
in priority order: hero zones first (highest traffic, biggest lift), then feature splits, then
secondary zones.

---

## Phase 4 — Insert Placeholder and Brief

For every NEEDS-ART and EXCEPTION-SMALL-ART zone, insert the 4-field comment block immediately
above the placeholder element. The placeholder element encodes the correct structural wrapper for
the assigned image type.

### 4-field comment format

```tsx
{/* IMAGE-TYPE: [inline | background | overlay | texture | parallax] */}
{/* IMAGE-BRIEF: [slot-id] | [aspect-ratio] | [brief text — palette tokens only, no hex] */}
{/* IMAGE-OVERLAY: [Tailwind class e.g. bg-black/50] | none */}
{/* IMAGE-RESPONSIVE: [mobile intent — what changes at < 640px] */}
```

All four fields are required for background, overlay, and parallax types.
For inline and texture types, IMAGE-OVERLAY is `none` and IMAGE-RESPONSIVE is a one-liner.

**grep compatibility:** `grep -r "IMAGE-BRIEF:" .` still harvests all open art slots.

---

### Skeleton per image type

Each image type gets a specific placeholder element structure. The structure is the skeleton —
it shows exactly how the art integrates when it arrives, so Fahim designs to the right
constraints from the start.

#### inline

Use when: image is a discrete element in the flow — product screenshot, feature illustration,
card media, blog cover.

```tsx
{/* IMAGE-TYPE: inline */}
{/* IMAGE-BRIEF: feat-01 | 16:9 | product dashboard screenshot, dark bg-surface, blue accent data points */}
{/* IMAGE-OVERLAY: none */}
{/* IMAGE-RESPONSIVE: aspect ratio holds at mobile, width becomes full-bleed */}
<div
  data-image-slot="feat-01"
  className="relative aspect-video w-full overflow-hidden rounded-2xl border border-dashed border-white/10 bg-surface/40"
>
  {/*
    When art is ready:
    <Image src="/feat-01.webp" fill className="object-cover" alt="[brief text]" />
  */}
</div>
```

Common ratios per zone: hero feature screenshot → `aspect-video` (16:9). Card media →
`aspect-[4/3]`. Blog cover → `aspect-[21/9]`. Step illustration → `aspect-square`.

#### background

Use when: image IS the surface — hero section, full-bleed CTA band, page backgrounds where
text lives on top. Always needs an overlay for text legibility.

```tsx
{/* IMAGE-TYPE: background */}
{/* IMAGE-BRIEF: hero-01 | full-bleed | abstract 3D render, bg-surface dark tones, accent glow top-left, single floating UI card at 3/4 angle, no baked-in text */}
{/* IMAGE-OVERLAY: bg-black/50 (H1 + subtext sit directly on image) */}
{/* IMAGE-RESPONSIVE: mobile — bg-cover bg-top to keep subject visible; verify CTA stays above fold */}
<section
  data-image-slot="hero-01"
  className="relative min-h-screen overflow-hidden border border-dashed border-white/10 bg-surface/40"
>
  {/*
    When art is ready:
    1. <div className="absolute inset-0 bg-[url('/hero-01.webp')] bg-cover bg-center" />
    2. <div className="absolute inset-0 bg-black/50" />
    3. <div className="relative z-10">{existing hero content}</div>
  */}
</section>
```

**Overlay opacity rule:** The opacity value in IMAGE-OVERLAY is determined by what sits on top.
- H1 + body text directly on image → `bg-black/50` minimum
- H1 only, large type → `bg-black/35` acceptable
- Decorative section with no reading text → `bg-black/20` or `overlay` type instead

#### overlay

Use when: image is behind a semi-transparent color layer — the image reinforces mood without
being readable as content. Lower visual priority than background type.

```tsx
{/* IMAGE-TYPE: overlay */}
{/* IMAGE-BRIEF: testimonial-01 | full-bleed | wide architectural photography, cool neutral tones, low detail acceptable */}
{/* IMAGE-OVERLAY: bg-bg/75 (image visible at 25% through the surface color) */}
{/* IMAGE-RESPONSIVE: mobile — bg-cover, image detail lost at small sizes — acceptable for overlay type */}
<section
  data-image-slot="testimonial-01"
  className="relative overflow-hidden border border-dashed border-white/10 bg-surface/40"
>
  {/*
    When art is ready:
    1. <div className="absolute inset-0 bg-[url('/testimonial-01.webp')] bg-cover bg-center opacity-25" />
    2. Existing section content remains on top with no overlay div needed — opacity on the image itself
  */}
</section>
```

Overlay differs from background in that the color surface dominates and the image is secondary.
The image should be low-detail photography or texture that adds depth without competing with content.

#### texture

Use when: repeating or subtle pattern adds surface depth with no focal point — grain, noise,
geometric repeat, subtle grid. Atmospheric only.

```tsx
{/* IMAGE-TYPE: texture */}
{/* IMAGE-BRIEF: cta-texture-01 | tile | subtle noise grain at 4% opacity on dark bg-surface, seamlessly tileable */}
{/* IMAGE-OVERLAY: none (texture is applied directly at low opacity) */}
{/* IMAGE-RESPONSIVE: tile behavior unchanged at mobile */}
<section
  data-image-slot="cta-texture-01"
  className="relative overflow-hidden border border-dashed border-white/10 bg-surface/40"
>
  {/*
    When art is ready:
    <div
      className="absolute inset-0 opacity-[0.04]"
      style={{ backgroundImage: "url('/cta-texture-01.png')", backgroundRepeat: 'repeat' }}
    />
  */}
</section>
```

Textures are always at 3–8% opacity. Anything higher competes with content and reads as
unintentional noise. Brief them as "seamlessly tileable, [surface color] tones."

#### parallax

Use when: scroll-driven background — image moves at a different rate than content as the user
scrolls. Most common on hero sections and large editorial breaks.

```tsx
{/* IMAGE-TYPE: parallax */}
{/* IMAGE-BRIEF: hero-parallax-01 | full-bleed + 20% taller than viewport | landscape aerial, dark muted tones, soft blur acceptable, no focal subject at exact center */}
{/* IMAGE-OVERLAY: bg-black/40 */}
{/* IMAGE-RESPONSIVE: mobile — disable parallax (useParallax hook checks pointer: coarse), fall back to bg-cover bg-center fixed treatment */}
<section
  data-image-slot="hero-parallax-01"
  className="relative min-h-screen overflow-hidden border border-dashed border-white/10 bg-surface/40"
>
  {/*
    When art is ready (motion-hive BUILD already wired the scroll hook if MOTION.md exists):
    <motion.div style={{ y }} className="absolute inset-0 scale-110">
      <Image src="/hero-parallax-01.webp" fill className="object-cover" alt="" />
    </motion.div>
    <div className="absolute inset-0 bg-black/40" />
    <div className="relative z-10">{existing hero content}</div>

    If no scroll hook in MOTION.md: check with motion-hive BUILD before wiring.
  */}
</section>
```

**Parallax image sizing:** parallax images must be taller than the viewport to allow movement.
Always brief them as "full-bleed + 20% taller than viewport" or they will show white edges at
scroll extremes.

**Mobile rule:** disable parallax on `pointer: coarse` devices (touch screens). Parallax on
touch creates a fixed-background look that is often unintentional. The IMAGE-RESPONSIVE field
for parallax always notes: "disable on touch, fall back to bg-cover."

---

## Phase 5 — Cave Report

```
────────────────────────────────────────
CAVE-MAN — [Project Name] — [Date]
────────────────────────────────────────
Pages scanned:          N marketing, N functional
Zones already correct:  N  (HAS-ART)
Zones needing art:      N  (NEEDS-ART + EXCEPTION)
Cheap fillers replaced: N
Icon-fatigue merges:    N

NEEDS ART — design these next:

  slot-id          type         file:line       brief
  ──────────────────────────────────────────────────────
  hero-01          background   app/page.tsx:18   abstract 3D render, bg-surface dark tones...
  feat-01          inline       app/page.tsx:56   dashboard screenshot, accent data points...
  feat-02          inline       app/page.tsx:88   workflow diagram, soft bg-surface tones...
  testimonial-01   overlay      app/page.tsx:140  architectural photography, cool neutrals...
  cta-texture-01   texture      app/page.tsx:190  noise grain, bg-surface tones, tileable...

KEEP FLAT — no art needed:
  /dashboard, /settings, /admin/*  — functional surfaces
  logo-wall (app/page.tsx:72)      — SVG logos, correct as-is
  pricing section (app/page.tsx:162) — dense data, no art

Harvest open slots anytime:  grep -r "IMAGE-BRIEF:" .
────────────────────────────────────────
motion-hive touch-up is clear to run (scoped — new data-image-slot elements only).
────────────────────────────────────────
```

---

## Operating Rules

**Never generates the artwork.** The brief is the deliverable — the art is Fahim's, made
wherever he chooses. No image-gen API calls for production art, ever.

**Never writes to living docs.** No edits to `DESIGN_GUIDE.md`, `PLANNER.md`, or `BRAIN.md`.
The brief lives only as inline code comments beside the placeholder. Nothing for repo-maintainer
to sync. Nothing that drifts out of date.

**Never touches FUNCTIONAL pages** beyond the one-line confirmation. One exception: a `minimal`
404 page may warrant one EXCEPTION-SMALL-ART slot for a small friendly illustration.

**Always use palette tokens in briefs.** `bg-surface`, `accent`, `accent/20` — never `#131720`
or `#00e676`. The brief is read by a human designer who works in the same design system.

**Overlay opacity is not optional for background and parallax types.** If text sits on the
image, IMAGE-OVERLAY always has a value. Leaving it blank means whoever implements the slot
will guess at the overlay, usually wrong.

**Aspect ratio matches the actual grid slot.** Check the surrounding layout before assigning
a ratio. A feature-split right column is `aspect-video`. A square card media slot is
`aspect-square`. Guessing without checking leads to image crops that don't fit the intent.

**Icon fatigue rule.** Four or more feature cards on one page with identical icon-in-circle
treatment is one merged NEEDS-ART opportunity — one hero illustration or one pattern — not
four separate inline briefs. Merge them into one slot at the section level.

**These placeholders are not mock data.** A `data-image-slot` div is a pending art slot —
valley-of-death's hardcoded-data check should not flag it.

**Parallax zones and MOTION.md.** If MOTION.md registers a scroll hook for a section, the
image type is `parallax`. Don't override it to `background` — the hook is already wired and
the skeleton comment points to it. If no scroll hook exists in MOTION.md for what looks like
a parallax candidate, brief it as `parallax` and add a note: "motion-hive BUILD needed before
wiring the scroll hook."

**If SITETREE.md is missing,** scan `/app` directly, flag the gap, do not block. Without the
Layout Architecture section, use Pass B zone rules only and note in the report that type
assignments are heuristic, not derived from confirmed section-sequence data.
