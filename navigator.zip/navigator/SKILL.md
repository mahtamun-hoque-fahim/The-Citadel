---
name: navigator
description: >
  Test-Driven Development discipline (RED-GREEN-REFACTOR) for Next.js using
  Vitest + React Testing Library, mapped specifically onto App Router's
  testable and non-testable surfaces — Server Actions, Route Handlers,
  Client Components, and the hard limit that Vitest cannot unit-test async
  Server Components. ALWAYS use when Fahim says "navigator", "TDD this",
  "write the test first", "red green refactor", "test-driven", or whenever
  new feature code is about to be written and tests should come first. Applies
  at the start of any new feature or route — not only a brand-new repo — but
  does NOT retrofit tests onto already-written, untested code (that's
  characterization testing, a different exercise this skill doesn't cover).
---

# Navigator

The discipline of writing the test before the code, for Fahim's stack
specifically. Not a generic "how TDD works" explainer — this skill exists
because Next.js App Router has a real, current limitation that breaks naive
TDD if you don't route around it on purpose.

### What "deferred" actually means here

This activates at the start of writing **new behavior** — a new Server
Action, a new route, a new component — whether that's day one of a fresh
repo or a new feature inside a project that's been live for months. The RED
step requires the behavior not exist yet; once code is already written and
shipped without tests, adding tests to it afterward is a different exercise
(characterization testing — describing what the code *does*, not what it
*should* do). That's not what this skill does. If the goal is "add tests to
my already-shipped, untested code," say so explicitly — this skill will say
clearly that it's out of scope rather than quietly applying the wrong
technique.

---

## The hard constraint that shapes everything below

Per Next.js's own testing guide (App Router, current as of v16.2.9):

> Since `async` Server Components are new to the React ecosystem, Vitest
> currently does not support them. While you can still run unit tests for
> synchronous Server and Client Components, we recommend using E2E tests for
> `async` components.

Most real App Router pages that fetch data **are** async Server Components.
This means the naive version of TDD — "write a test that renders the page,
make it pass" — is structurally impossible for the majority of actual pages
in this stack. Navigator's whole design exists to route around this
correctly instead of pretending it isn't true.

The fix: never put logic worth testing *inside* an async Server Component.
Extract the data-fetching and business logic into a plain function, TDD that
function with Vitest, and let the async Server Component itself be a thin,
untested wrapper that just calls it and renders. Cover the actual page-level
async behavior with Playwright E2E instead — outside this skill's scope, but
necessary to know about.

---

## What's testable where

| Surface | Vitest unit test? | Approach |
|---|---|---|
| Plain functions (validators, formatters, business logic) | Yes | Classic TDD, nothing Next.js-specific |
| Client Components (`"use client"`) | Yes | Vitest + RTL + jsdom; mock `next/navigation` hooks |
| **Synchronous** Server Components | Yes | Treat as a plain function returning JSX — Next's own docs test exactly this |
| **Async** Server Components | **No — unsupported** | Extract data-fetching into a separate function, test that. Cover the component itself with Playwright E2E only |
| Server Actions | Yes | Import and call directly as an async function; mock the DB/external calls |
| Route Handlers (`route.ts`) | Yes | Construct a `NextRequest`, call the exported `GET`/`POST` directly, assert on the `Response` |
| `proxy.ts` / `middleware.ts` | Yes | Same pattern — call the exported function directly with a constructed request |
| Drizzle queries | Yes, two tiers | **Unit**: mock the Drizzle client. **Integration**: point at a branched Neon DB, never at the dev database |

---

## Setup (run once per project)

```bash
npm install -D vitest @vitejs/plugin-react jsdom @testing-library/react \
  @testing-library/dom @testing-library/jest-dom @testing-library/user-event \
  vite-tsconfig-paths
```

`vitest.config.mts`:
```ts
import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'
import tsconfigPaths from 'vite-tsconfig-paths'

export default defineConfig({
  plugins: [tsconfigPaths(), react()],
  test: {
    environment: 'jsdom',
    setupFiles: ['./vitest.setup.ts'],
  },
})
```

`vitest.setup.ts`:
```ts
import '@testing-library/jest-dom/vitest'
```

`package.json`:
```json
{
  "scripts": {
    "test": "vitest run",
    "test:watch": "vitest",
    "test:ui": "vitest --ui"
  }
}
```

Note the official Next.js example wires `"test": "vitest"`, which defaults
to watch mode. Split it as above — `vitest run` for CI and one-shot runs
(this is what ticket-checker and any CI step should call), `vitest:watch`
for the actual RED-GREEN-REFACTOR loop while writing code.

**If the project already has a Jest setup** (inherited, not started fresh),
stay on Jest rather than migrating mid-project purely for this skill — the
loop below applies identically, only the runner command and mock syntax
(`jest.mock` vs `vi.mock`) differ. Vitest is the default for new projects on
this stack because of faster ESM-native execution and because none of
Fahim's projects currently have any test infrastructure to inherit from.

---

## The loop

### RED
1. Pick the smallest next behavior — ideally one `task-planner` TASK.
2. Write a test describing that behavior. Nothing else yet.
3. Run it. Confirm it fails **for the right reason** — an assertion failure
   because the behavior doesn't exist, not a typo or import error. If the
   test doesn't run at all, that's not RED yet — fix the test first.

### GREEN
4. Write the minimum code to make that one test pass. Resist building ahead
   for a test that doesn't exist yet.
5. Run the full suite, not just the new test — confirm green across the
   board, no regression in what was already passing.

### REFACTOR
6. With everything green, clean up: remove duplication, rename, extract.
   Re-run tests after every small change, not just at the end.
7. Stop the moment the code reads clearly. Refactoring is cleanup, not a
   second feature pass.

Repeat for the next behavior. Never refactor on a red bar — fix forward to
green first, clean up second.

---

## Worked example — a Server Action

**RED** — write the test first, against a function that doesn't validate yet:
```ts
// app/notes/actions.test.ts
import { describe, it, expect, vi } from 'vitest'
import { createNote } from './actions'

vi.mock('@/lib/db', () => ({ db: { insert: vi.fn() } }))

describe('createNote', () => {
  it('rejects an empty title', async () => {
    const result = await createNote({ title: '', content: 'hello' })
    expect(result.success).toBe(false)
    expect(result.error).toBe('Title is required')
  })
})
```
Run it. It fails — `createNote` either doesn't exist or doesn't validate.
That failure is the RED.

**GREEN** — the minimum to pass this one test:
```ts
// app/notes/actions.ts
'use server'

export async function createNote(input: { title: string; content: string }) {
  if (!input.title.trim()) {
    return { success: false, error: 'Title is required' }
  }
  return { success: true }
}
```
Nothing about the DB insert is wired yet — this test didn't ask for that.

**REFACTOR** — only once a second test (the successful-insert case) is also
green, and only if duplication actually shows up between the two cases.
Until then, there's nothing to refactor — two clean branches in one short
function isn't a smell yet.

---

## Worked example — a Route Handler

```ts
// app/api/notes/[id]/route.test.ts
import { GET } from './route'
import { NextRequest } from 'next/server'
import { describe, it, expect } from 'vitest'

describe('GET /api/notes/[id]', () => {
  it('returns 401 with no session', async () => {
    const req = new NextRequest('http://localhost:3000/api/notes/123')
    const res = await GET(req, { params: Promise.resolve({ id: '123' }) })
    expect(res.status).toBe(401)
  })
})
```
Note the `params` is a `Promise` — Next.js 15+ dynamic params are async, and
the test has to match that shape or it'll pass for the wrong reason.

---

## Test pyramid for this stack

Given the testability table above, the natural shape is:

- **Most tests** — unit tests on extracted business logic, Server Actions,
  Route Handlers. Fast, DB mocked, this is where the RED-GREEN-REFACTOR
  loop lives day to day.
- **Some tests** — Client Component tests with real user interaction
  (`@testing-library/user-event`).
- **Few tests** — Playwright E2E, reserved for full user journeys and for
  anything involving an async Server Component, since that's the only way
  to cover those at all.
- **Sparing integration tests** — real Drizzle queries against a branched
  Neon database, not the dev database. Neon's branching is fast enough to
  do this per test run without it being a chore.

---

## Operating Rules

- **Never skip RED.** Writing the implementation first and the test after
  isn't TDD — it tends to produce a test that confirms what the code
  happens to do, not what it should do.
- **Confirm the failure reason.** A test that "fails" because of a typo or
  missing import isn't validating anything yet.
- **One behavior per test.** A test asserting five unrelated things makes
  every failure ambiguous to diagnose.
- **Don't build ahead of the current test.** If test #1 doesn't need the DB
  wired up, don't wire it up yet — that's what test #2 is for.
- **Refactor only on green.** A failing test gets fixed forward first;
  refactoring on a red bar conflates two different problems at once.
- **Don't fight the async Server Component limitation.** Extract and test
  the logic; let Playwright cover the component. Trying to force a Vitest
  unit test onto an async Server Component wastes time on something that
  doesn't work, not something that's merely hard.
- **Mock for unit, branch for integration.** Automated tests never point at
  the same database as local dev — that's how test runs quietly corrupt
  real working data.

---

## Relationship to other skills

| Skill | Relation to navigator |
|---|---|
| **task-planner** | Each atomic task can become one RED-GREEN-REFACTOR cycle — the task's "Verify" step is the test going green. |
| **ticket-checker** | Once Playwright E2E tests exist for core flows, they can eventually automate what ticket-checker currently lists as manual checks (route rendering, auth gate behavior, the final smoke test). |
| **next15builder / next16builder** | Scaffold the project first; navigator's Setup section runs immediately after, before any feature code is written. |
| **sentinel** | A fully tested route can still have a structural auth gap — passing tests confirm intended behavior works, not that nothing unintended is also possible. Sentinel checks the latter. |
