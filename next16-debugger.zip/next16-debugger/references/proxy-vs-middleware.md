# `proxy.ts` vs `middleware.ts` — Migration & Runtime Guide

Next 16 renames the middleware convention to `proxy.ts` and switches its default runtime from Edge to Node.js. The rename is mechanical; the runtime change has architectural consequences. This document covers both.

## The mechanical rename

```bash
# 1. Rename the file
mv middleware.ts proxy.ts

# 2. Rename the exported function inside it
```

```ts
// Before — middleware.ts
import { NextResponse, type NextRequest } from 'next/server'

export function middleware(request: NextRequest) {
  return NextResponse.next()
}

export const config = {
  matcher: ['/dashboard/:path*'],
}
```

```ts
// After — proxy.ts
import { NextResponse, type NextRequest } from 'next/server'

export function proxy(request: NextRequest) {
  return NextResponse.next()
}

export const config = {
  matcher: ['/dashboard/:path*'],
}
```

The function name `proxy` is recommended even if you previously used a default export.

## Config flag renames

Anything with `middleware` in the name in `next.config` is renamed:

```ts
// Before
const nextConfig: NextConfig = {
  skipMiddlewareUrlNormalize: true,
  skipMiddlewareRedirect: true, // hypothetical example
}

// After
const nextConfig: NextConfig = {
  skipProxyUrlNormalize: true,
  skipProxyRedirect: true,
}
```

The Next 16 codemod handles file rename, function rename, and config flag renames in one pass:

```bash
npx @next/codemod@canary upgrade latest
```

## The runtime change — this is the important part

`middleware.ts` ran on the **Edge runtime** by default. `proxy.ts` runs on **Node.js**, and the runtime is **not configurable**.

### What this means in practice

**You gain (in `proxy.ts`):**
- Full access to Node.js built-ins: `fs`, `crypto`, `path`, `child_process`, etc.
- npm packages that depend on Node APIs (JWT libraries, full ORMs, etc.) work
- Slower cold start vs Edge, but no API restrictions

**You lose (vs `middleware.ts`):**
- Edge runtime's global distribution (Vercel's Edge Network, Cloudflare Workers)
- The performance characteristics of an Edge function (sub-50ms cold start)

### When to keep `middleware.ts` (the Edge case)

`middleware.ts` is **deprecated but still works in Next 16**. The official guidance is to keep it if you need Edge runtime. Concrete cases:

1. **Cloudflare Pages deployments.** Cloudflare Pages requires Edge runtime. `proxy.ts` is Node-only and will fail to deploy. **Keep `middleware.ts`.**
2. **Vercel deployments where you've intentionally chosen Edge** for latency reasons (e.g. geo-routing decisions that should run at the network edge, not in a regional Node function).
3. **Projects with global users** where the routing decision must happen at the user's nearest PoP.

### When to migrate to `proxy.ts`

1. You deploy to Vercel and don't care about Edge specifically
2. Your middleware uses Node-only APIs that you've been working around with polyfills or imports from `@neondatabase/serverless` style packages
3. You want to use a full ORM, JWT library with Node crypto, or any other package that pulled you out of Edge compatibility

## Architectural shift: routing vs auth

The rename signals an intended conceptual split. Next 16's recommendation:

- **`proxy.ts`** = network-layer concerns: URL rewrites, header injection, geo-routing, A/B variant assignment via cookie
- **Layouts / Server Components / Server Actions** = auth checks, session validation, business logic

In other words: stop doing auth in `proxy.ts`. Do it in a layout or a wrapping Server Component.

### Before (Next 15 pattern)

```ts
// middleware.ts
export function middleware(req: NextRequest) {
  const token = req.cookies.get('auth-token')?.value
  const isProtectedRoute = req.nextUrl.pathname.startsWith('/dashboard')

  if (isProtectedRoute && !validToken(token)) {
    return NextResponse.redirect(new URL('/login', req.url))
  }

  return NextResponse.next()
}
```

### After (Next 16 pattern)

```tsx
// app/dashboard/layout.tsx
import { redirect } from 'next/navigation'
import { cookies } from 'next/headers'

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const c = await cookies()
  const token = c.get('auth-token')?.value
  if (!validToken(token)) {
    redirect('/login')
  }
  return <>{children}</>
}
```

The layout pattern has several advantages:
- It runs in the Node runtime where your auth library lives (no Edge-compat workarounds)
- It can access the database directly (no need for a separate session-check call)
- It composes naturally with route groups — protect everything under `(authed)/` with one layout
- TypeScript knows the user is authenticated downstream of the layout

`proxy.ts` (or `middleware.ts`) becomes optional, used only for genuinely network-layer concerns.

## Better Auth context (Fahim's stack)

Better Auth, like Auth.js v5 / NextAuth.js, supports both middleware-based and Server-Component-based session validation. The recommendation aligns with Next 16's direction:

- Use `proxy.ts` (or stay on `middleware.ts` for Edge) **only** for URL-shape decisions (e.g. rewriting `/blog/123` to `/blog/[id]`)
- Do session validation in a layout, using `await auth.api.getSession({ headers: await headers() })`
- Persist sessions via cookies; let layouts and Server Components read them

### Concrete pattern with Better Auth

```tsx
// app/(authed)/layout.tsx
import { auth } from '@/lib/auth'
import { headers } from 'next/headers'
import { redirect } from 'next/navigation'

export default async function AuthedLayout({ children }: { children: React.ReactNode }) {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session) redirect('/login')
  return <>{children}</>
}
```

Group all protected routes under `app/(authed)/`. One layout, one check, no middleware.

## Edge runtime: how to stay on `middleware.ts` cleanly

If you need to keep `middleware.ts` because you deploy to Cloudflare Pages or want Edge:

```ts
// middleware.ts — keep as-is
import { NextResponse, type NextRequest } from 'next/server'

export function middleware(request: NextRequest) {
  // Edge-compatible code only:
  // - No Node built-ins
  // - No full ORMs (use @neondatabase/serverless if you need DB access)
  // - Crypto must be Web Crypto API, not Node's `crypto`
  return NextResponse.next()
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico).*)'],
  runtime: 'edge', // explicit for clarity, though it's the default
}
```

You may see deprecation warnings in the build output — those are informational. The framework continues to support `middleware.ts` for Edge until further notice.

## Decision flowchart

```
Does your deployment require Edge runtime (Cloudflare Pages, or Vercel Edge by choice)?
  │
  ├─ Yes  → Keep middleware.ts. Don't rename to proxy.ts. Accept the deprecation warning.
  │
  └─ No   → Does your middleware do auth/session checks?
              │
              ├─ Yes  → Move auth to a layout. Optionally delete the middleware file entirely.
              │         Use proxy.ts only if you have remaining network-layer logic.
              │
              └─ No   → Rename middleware.ts → proxy.ts. The codemod handles it.
                        Update config flags (skipMiddlewareUrlNormalize → skipProxyUrlNormalize).
```

## Common debugging scenarios

### Symptom: "middleware not running"

After upgrade, the middleware appears to be skipped.

**Check:**
1. Is the file still named `middleware.ts`? In Next 16, if Next can't find a recognized file, it silently no-ops. Either keep `middleware.ts` (works, deprecated) or rename to `proxy.ts`.
2. If you renamed, is the exported function still called `middleware`? It must be renamed to `proxy`.
3. Is the `matcher` correct? Test by adding a `console.log` at the top of the function and watching the dev server logs.

### Symptom: "proxy.ts fails to deploy on Cloudflare Pages"

**Cause:** `proxy.ts` is Node-only. Cloudflare Pages requires Edge.

**Fix:** Rename back to `middleware.ts`. Accept the deprecation warning. Watch Next.js release notes for the eventual Edge story for `proxy.ts` (the team has indicated they'll publish guidance).

### Symptom: "TypeError: nodejs API X is not available" in proxy.ts

**Cause:** Confusion — `proxy.ts` is Node-only and should have full access. This error usually means you're actually still on `middleware.ts` (which runs on Edge by default).

**Fix:** Verify the filename and the exported function name. Run `grep -n "export function" middleware.ts proxy.ts 2>/dev/null`.

### Symptom: "auth check passes in proxy.ts but user still gets logged-out page"

**Cause:** Race condition between proxy.ts logic and Server Component rendering, or cookie not being properly forwarded.

**Fix:** Move the auth check out of `proxy.ts` and into a layout, per the recommended pattern. Layouts run in the same request context as the page and have reliable access to cookies.

## Quick reference

| Old (Next 15) | New (Next 16) |
|---|---|
| `middleware.ts` | `proxy.ts` (if no Edge needed) |
| `export function middleware(...)` | `export function proxy(...)` |
| Runtime: Edge by default | Runtime: Node.js (fixed) |
| `skipMiddlewareUrlNormalize` | `skipProxyUrlNormalize` |
| Auth checks in middleware | Auth checks in layouts |
| Edge-only APIs (Web Crypto, fetch) | All Node APIs available |
| Global edge distribution | Regional Node function |
