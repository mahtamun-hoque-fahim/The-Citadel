# LearnDE Auth Migration — Legacy → Better Auth

Migrating from the legacy split-cookie pattern (`auth-token` 7-day for students + `staff-token` 8-hour for staff) to Better Auth with unified sessions and refresh tokens.

The DB is being rebuilt after dashboards are finalized, so this migration can do a clean cutover rather than running both auth systems in parallel. Preserve cleanup helpers in case any data needs to come across.

## Phase order

Do not interleave phases. Finish each before starting the next.

1. **Schema** — add Better Auth tables, mark legacy tables for removal
2. **Setup** — install, configure `lib/auth.ts`, catch-all route, client
3. **Middleware** — replace legacy JWT verification with `auth.api.getSession()`
4. **Routes** — replace `auth-token` / `staff-token` reads everywhere
5. **UI** — swap legacy sign-in / sign-up components for Better Auth client calls
6. **Cleanup** — delete legacy JWT helpers, cookie utilities, and stale env vars
7. **DB rebuild** — drop legacy tables, run fresh migrations

## Phase 1 — Schema

Add `user`, `session`, `account`, `verification` tables (see `better-auth.md` for full definitions). Add `role` enum with `student | staff | admin`.

Mark legacy tables for removal but don't drop yet:
```ts
// lib/db/schema.ts — at top
// LEGACY — drop after Phase 7
export const legacyUsers = pgTable('legacy_users', { ... })
export const legacyStaff = pgTable('legacy_staff', { ... })
```

Generate + apply:
```bash
npx drizzle-kit generate
npx drizzle-kit migrate
```

## Phase 2 — Setup

Install:
```bash
npm install better-auth
```

Files to create:
- `lib/auth.ts` — Better Auth config
- `lib/auth-client.ts` — React client
- `app/api/auth/[...all]/route.ts` — catch-all handler

Env vars to add to Vercel/Cloudflare:
```
BETTER_AUTH_SECRET=
BETTER_AUTH_URL=https://learnde.com
NEXT_PUBLIC_APP_URL=https://learnde.com
```

Generate the secret:
```bash
openssl rand -base64 32
```

## Phase 3 — Middleware

**Before** (legacy):
```ts
// middleware.ts — DELETE
import { verify } from 'jsonwebtoken'

export function middleware(req) {
  const authToken = req.cookies.get('auth-token')?.value
  const staffToken = req.cookies.get('staff-token')?.value
  // ... JWT verification, role branching
}
```

**After** (Better Auth):
```ts
// middleware.ts
import { NextResponse } from 'next/server'
import { auth } from '@/lib/auth'

export async function middleware(req) {
  const session = await auth.api.getSession({ headers: req.headers })
  const path = req.nextUrl.pathname

  if (!session) {
    if (path.startsWith('/dashboard') || path.startsWith('/staff')) {
      return NextResponse.redirect(new URL('/sign-in', req.url))
    }
    return NextResponse.next()
  }

  // Role gates
  if (session.user.role === 'student' && path.startsWith('/staff')) {
    return NextResponse.redirect(new URL('/dashboard', req.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ['/dashboard/:path*', '/staff/:path*', '/admin/:path*'],
}
```

## Phase 4 — Routes

Search the codebase for every reference to legacy cookies. Replace.

```bash
grep -rn "auth-token\|staff-token" app/ lib/
```

For each result:

**Before:**
```ts
const token = cookies().get('auth-token')?.value
const payload = verify(token, process.env.JWT_SECRET!)
const userId = payload.userId
```

**After:**
```ts
const session = await auth.api.getSession({ headers: headers() })
if (!session) return Response.json({ error: 'Unauthorized' }, { status: 401 })
const userId = session.user.id
```

For role checks:
**Before:** `if (payload.role !== 'staff') ...`
**After:** `if (session.user.role !== 'staff') ...`

## Phase 5 — UI

Replace legacy sign-in form:

```tsx
'use client'
import { signIn } from '@/lib/auth-client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

export function SignInForm() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const router = useRouter()

  async function handleSubmit() {
    const { error } = await signIn.email({ email, password })
    if (error) {
      setError(error.message)
      return
    }
    router.push('/dashboard')
  }

  return (
    <div>
      <input type="email" value={email} onChange={e => setEmail(e.target.value)} />
      <input type="password" value={password} onChange={e => setPassword(e.target.value)} />
      <button onClick={handleSubmit}>Sign in</button>
      {error && <p>{error}</p>}
    </div>
  )
}
```

Note: no `<form>` tag, no `onSubmit` — Better Auth client handles the request directly.

## Phase 6 — Cleanup

Delete:
- `lib/auth/jwt.ts` (or wherever JWT helpers live)
- `lib/auth/cookies.ts` (custom cookie setters)
- Legacy `JWT_SECRET` and any `*_TOKEN_*` env vars
- Any `/api/login` / `/api/staff-login` / `/api/logout` Route Handlers

Search for stragglers:
```bash
grep -rn "JWT_SECRET\|jsonwebtoken\|auth-token\|staff-token" .
```

Should return zero results.

## Phase 7 — DB rebuild

After cutover and verification:
```bash
# In drizzle schema, delete legacy tables
# Generate the drop migration
npx drizzle-kit generate
npx drizzle-kit migrate
```

Confirm in Neon dashboard that legacy tables are gone.

## Verification checklist

- [ ] Sign up as student → redirected to `/dashboard`
- [ ] Sign up as staff (manual role update for now) → can access `/staff`
- [ ] Student trying `/staff/*` → redirected to `/dashboard`
- [ ] Staff trying `/admin/*` → allowed if role=admin, redirected if not
- [ ] Sign out clears session — refreshing protected page redirects to `/sign-in`
- [ ] Session persists across page refresh
- [ ] Session refresh works after 24h (check `updateAge: 60 * 60 * 24`)
- [ ] No `auth-token` or `staff-token` strings remain in source
- [ ] All legacy env vars removed from Vercel and Cloudflare dashboards
- [ ] Production build passes
- [ ] One round of manual smoke test on Vercel preview before promoting

## Rollback plan

If something breaks badly post-cutover:
1. Revert the merge commit on `main`
2. Vercel auto-deploys the previous version
3. Legacy tables are still in DB (not dropped until Phase 7) — sessions resume working
4. Better Auth tables stay; they won't interfere with legacy code

Do not run Phase 7 (DB drop) until at least 48 hours of stable production traffic on Better Auth.
