# Navigation

Navbars, sidebars, mobile drawers, tabs, breadcrumbs, command bars, dropdown menus.

## Top navbar — static

```tsx
export default function Navbar() {
  return (
    <header className="sticky top-0 z-40 border-b border-neutral-800 bg-neutral-950/80 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        <a href="/" className="flex items-center gap-2 font-semibold">
          <Mic className="size-5 text-violet-400" />
          <span>Brand</span>
        </a>

        <nav className="hidden items-center gap-6 md:flex">
          <a href="#features" className="text-sm text-neutral-300 hover:text-white">Features</a>
          <a href="#pricing" className="text-sm text-neutral-300 hover:text-white">Pricing</a>
          <a href="#docs" className="text-sm text-neutral-300 hover:text-white">Docs</a>
        </nav>

        <div className="flex items-center gap-2">
          <a href="/login" className="hidden text-sm text-neutral-300 hover:text-white md:block">
            Sign in
          </a>
          <a href="/signup" className="rounded-full bg-violet-500 px-3.5 py-1.5 text-sm font-medium text-white hover:bg-violet-600">
            Sign up
          </a>
          <MobileMenuButton className="md:hidden" />
        </div>
      </div>
    </header>
  );
}
```

Critical pieces:
- `sticky top-0` with `z-40` — high enough to clear most content, low enough to sit under modals (`z-50`).
- `backdrop-blur` + semi-transparent background — the modern frosted-glass look. Add `supports-[backdrop-filter]:bg-neutral-950/60` for graceful degradation.
- `h-14` (56px) is the standard. Adjust hero math (`calc(100svh-3.5rem)`) accordingly. For `h-16` (64px), use `4rem`.

## Top navbar — transparent-on-scroll

```tsx
"use client";
import { useEffect, useState } from "react";

export default function ScrollNavbar() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 transition-colors ${
        scrolled
          ? "border-b border-neutral-800 bg-neutral-950/80 backdrop-blur"
          : "border-b border-transparent"
      }`}
    >
      {/* navbar content */}
    </header>
  );
}
```

Note: `fixed` (not `sticky`) so the navbar overlays the hero. Pair with hero `pt-14` (or whatever the navbar height is) so content does not sit underneath on initial paint.

## Sidebar — desktop, fixed

See `patterns/layouts.md` § App shell for the full pattern. The sidebar's own internals:

```tsx
import { Home, Inbox, Settings, BarChart3 } from "lucide-react";
import { usePathname } from "next/navigation";

const items = [
  { href: "/app", label: "Overview", icon: Home },
  { href: "/app/inbox", label: "Inbox", icon: Inbox, badge: 3 },
  { href: "/app/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/app/settings", label: "Settings", icon: Settings },
];

export default function SidebarNav() {
  const pathname = usePathname();
  return (
    <nav className="px-2 py-3 space-y-0.5">
      {items.map((item) => {
        const active = pathname === item.href;
        return (
          <a
            key={item.href}
            href={item.href}
            aria-current={active ? "page" : undefined}
            className={`group flex items-center gap-3 rounded-md px-3 py-2 text-sm transition ${
              active
                ? "bg-neutral-900 text-white"
                : "text-neutral-400 hover:bg-neutral-900/50 hover:text-neutral-200"
            }`}
          >
            <item.icon className="size-4 shrink-0" />
            <span className="flex-1 truncate">{item.label}</span>
            {item.badge && (
              <span className="rounded-full bg-violet-500/20 px-1.5 text-xs font-medium text-violet-300">
                {item.badge}
              </span>
            )}
          </a>
        );
      })}
    </nav>
  );
}
```

- `shrink-0` on the icon prevents it from compressing when the label is long.
- `truncate` on the label needs `min-w-0` somewhere; `flex-1` provides it implicitly via `min-width: 0` not being inherited — but if truncation fails, add `min-w-0` to the label span.
- `aria-current="page"` is the accessibility convention; the `aria-[current=page]:` Tailwind selector lets you style without a class prop.

Uses `usePathname` → file needs `"use client"`. If you want a server-side sidebar, pass the active path as a prop from the layout.

## Sidebar — collapsible (icon-only when collapsed)

```tsx
"use client";
import { useState } from "react";

export default function CollapsibleSidebar() {
  const [collapsed, setCollapsed] = useState(false);
  return (
    <aside
      className={`fixed inset-y-0 left-0 z-40 hidden border-r border-neutral-800 bg-neutral-950 transition-[width] duration-200 lg:block ${
        collapsed ? "w-16" : "w-64"
      }`}
    >
      <div className="flex h-14 items-center justify-between px-4">
        {!collapsed && <span className="font-semibold">Brand</span>}
        <button
          onClick={() => setCollapsed((c) => !c)}
          className="rounded p-1 hover:bg-neutral-800"
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          <ChevronsLeft className={`size-4 transition-transform ${collapsed ? "rotate-180" : ""}`} />
        </button>
      </div>
      {/* nav items hide their text when collapsed */}
    </aside>
  );
}
```

Pair with main wrapper that responds:

```tsx
<div className={`transition-[padding] ${collapsed ? "lg:pl-16" : "lg:pl-64"}`}>
```

The collapsed/expanded state has to be shared between sidebar and main. Lift state to the layout, or use a context, or use cookies for server-render persistence.

## Mobile drawer (off-canvas menu)

```tsx
"use client";
import { useState, useEffect } from "react";
import { X, Menu } from "lucide-react";

export default function MobileDrawer({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);

  // Lock body scroll while open
  useEffect(() => {
    if (open) {
      const original = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => { document.body.style.overflow = original; };
    }
  }, [open]);

  // Close on Escape
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="rounded p-2 hover:bg-neutral-900 lg:hidden"
        aria-label="Open menu"
      >
        <Menu className="size-5" />
      </button>

      {/* Backdrop */}
      <div
        onClick={() => setOpen(false)}
        className={`fixed inset-0 z-40 bg-black/60 transition-opacity lg:hidden ${
          open ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      />

      {/* Drawer panel */}
      <div
        className={`fixed inset-y-0 left-0 z-50 w-72 max-w-[85vw] border-r border-neutral-800 bg-neutral-950 transition-transform lg:hidden ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
        role="dialog"
        aria-modal="true"
      >
        <div className="flex h-14 items-center justify-between px-4">
          <span className="font-semibold">Menu</span>
          <button
            onClick={() => setOpen(false)}
            className="rounded p-1 hover:bg-neutral-800"
            aria-label="Close menu"
          >
            <X className="size-5" />
          </button>
        </div>
        <div className="overflow-y-auto p-4">{children}</div>
      </div>
    </>
  );
}
```

Four things this gets right that AI generations usually miss:

1. **Body scroll lock** — without it, the page scrolls behind the drawer.
2. **Escape key** — keyboard users expect it.
3. **Backdrop click to close** — separate `<div>` with `onClick`, not a wrapper around the panel (clicks on the panel itself would also close it then).
4. **`pointer-events-none` on hidden backdrop** — without it, the invisible backdrop still intercepts clicks on the page below.

For production, prefer Radix Dialog or Headless UI Dialog over hand-rolled — they handle focus trap, `inert` on background, and ARIA attributes correctly.

## Breadcrumbs

```tsx
import { ChevronRight } from "lucide-react";

export default function Breadcrumbs({ items }: { items: { label: string; href?: string }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="flex items-center gap-1 text-sm text-neutral-400">
      {items.map((item, i) => {
        const isLast = i === items.length - 1;
        return (
          <div key={i} className="flex items-center gap-1">
            {item.href && !isLast ? (
              <a href={item.href} className="hover:text-white">{item.label}</a>
            ) : (
              <span aria-current={isLast ? "page" : undefined} className={isLast ? "text-white" : ""}>
                {item.label}
              </span>
            )}
            {!isLast && <ChevronRight className="size-3.5 shrink-0 text-neutral-600" />}
          </div>
        );
      })}
    </nav>
  );
}
```

## Tabs — horizontal

```tsx
"use client";
import { useState } from "react";

const tabs = [
  { id: "overview", label: "Overview" },
  { id: "activity", label: "Activity" },
  { id: "settings", label: "Settings" },
];

export default function Tabs() {
  const [active, setActive] = useState("overview");
  return (
    <div>
      <div className="border-b border-neutral-800">
        <div className="-mb-px flex gap-6 overflow-x-auto">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setActive(t.id)}
              className={`whitespace-nowrap border-b-2 px-1 py-3 text-sm font-medium transition ${
                active === t.id
                  ? "border-violet-400 text-white"
                  : "border-transparent text-neutral-400 hover:border-neutral-700 hover:text-neutral-200"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>
      <div className="py-6">
        {/* active panel */}
      </div>
    </div>
  );
}
```

Notes:
- `-mb-px` on the inner row pulls the active border down to overlap the container border exactly.
- `overflow-x-auto` on the tab strip handles tab overflow on mobile.
- `whitespace-nowrap` on each tab prevents wrapping.

For route-based tabs, swap `useState` for `usePathname` and render `<Link>` instead of `<button>`.

## Dropdown menu (vanilla, no library)

Hand-rolled dropdowns are where dropdown clipping bugs come from. The safest pattern: keep the menu positioned absolutely, never inside an `overflow-hidden` ancestor. For production, prefer Radix `DropdownMenu` or shadcn's wrapper.

```tsx
"use client";
import { useState, useRef, useEffect } from "react";
import { ChevronDown } from "lucide-react";

export default function Dropdown() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  // Close on outside click
  useEffect(() => {
    if (!open) return;
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    window.addEventListener("mousedown", onClick);
    return () => window.removeEventListener("mousedown", onClick);
  }, [open]);

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="inline-flex items-center gap-1.5 rounded-md border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-sm hover:bg-neutral-800"
      >
        Options <ChevronDown className="size-3.5" />
      </button>

      {open && (
        <div
          role="menu"
          className="absolute right-0 z-50 mt-1 w-48 overflow-hidden rounded-md border border-neutral-800 bg-neutral-900 shadow-lg"
        >
          <button role="menuitem" className="block w-full px-3 py-2 text-left text-sm hover:bg-neutral-800">Edit</button>
          <button role="menuitem" className="block w-full px-3 py-2 text-left text-sm hover:bg-neutral-800">Duplicate</button>
          <div className="my-1 border-t border-neutral-800" />
          <button role="menuitem" className="block w-full px-3 py-2 text-left text-sm text-red-400 hover:bg-neutral-800">Delete</button>
        </div>
      )}
    </div>
  );
}
```

If this dropdown lives inside a `overflow-hidden` card and gets clipped: either remove the overflow from the card, or use Radix `DropdownMenu` which portals the menu to `<body>`.

## Command palette / search bar (visual only)

```tsx
<div className="relative">
  <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-neutral-500" />
  <input
    type="search"
    placeholder="Search..."
    className="w-full rounded-md border border-neutral-800 bg-neutral-900 py-2 pl-9 pr-3 text-sm placeholder:text-neutral-500 focus:border-violet-500 focus:outline-none focus:ring-2 focus:ring-violet-500/20"
  />
  <kbd className="absolute right-3 top-1/2 hidden -translate-y-1/2 rounded border border-neutral-700 bg-neutral-800 px-1.5 py-0.5 text-xs text-neutral-400 sm:block">
    ⌘K
  </kbd>
</div>
```

`top-1/2 -translate-y-1/2` is the universal centering pattern for absolute-positioned icons inside inputs.

## Pagination

```tsx
<nav aria-label="Pagination" className="flex items-center justify-between border-t border-neutral-800 pt-4">
  <p className="text-sm text-neutral-400">
    Showing <span className="font-medium text-white">1</span> to <span className="font-medium text-white">10</span> of{" "}
    <span className="font-medium text-white">42</span> results
  </p>
  <div className="flex gap-1">
    <button className="rounded-md border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-sm hover:bg-neutral-800 disabled:opacity-50" disabled>
      Previous
    </button>
    <button className="rounded-md border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-sm hover:bg-neutral-800">
      Next
    </button>
  </div>
</nav>
```
