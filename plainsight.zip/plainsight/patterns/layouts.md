# Layouts

Page-level structure: sections, heroes, app shells, dashboards, auth pages, error pages, settings layouts.

## Section + container shell

The base building block for any page section.

```tsx
<section className="py-20 sm:py-28">
  <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
    {/* content */}
  </div>
</section>
```

- `<section>` owns vertical rhythm and background (full-bleed colors, gradients).
- Inner `<div>` owns horizontal bounds and padding.
- Never collapse them. A full-bleed background on a section with content centered to `max-w-7xl` requires this exact split.

Common max-widths:
- `max-w-7xl` (80rem / 1280px) — default for marketing and most app pages
- `max-w-6xl` (72rem / 1152px) — comfortable reading layouts
- `max-w-4xl` (56rem / 896px) — long-form content, blog posts, settings forms
- `max-w-3xl` (48rem / 768px) — single-column CTA cards, narrow forms
- `max-w-2xl` (42rem / 672px) — auth pages, modal-like landing sections
- `max-w-md` / `max-w-sm` — login forms, narrow utility pages

## Heading + subtitle block

```tsx
// CORRECT — mx-auto on the wrapper, text-center on the wrapper, no max-w on subtitle
<div className="mx-auto max-w-2xl text-center">
  <p className="text-xs font-medium uppercase tracking-[0.2em] text-neutral-400">
    Section eyebrow
  </p>
  <h2 className="mt-3 text-4xl font-bold tracking-tight sm:text-5xl">
    Headline with <span className="text-violet-400">accent</span>
  </h2>
  <p className="mt-4 text-lg text-neutral-400">
    Supporting sentence that explains the section.
  </p>
</div>
```

```tsx
// BROKEN — subtitle pins to the left edge of its parent
<div className="text-center">
  <h2>Headline</h2>
  <p className="max-w-md text-lg">Supporting sentence...</p>
</div>
```

`max-w-md` on the subtitle without `mx-auto` constrains width and leaves it flush left. `text-center` on the parent only centers text *within* that left-anchored narrow box.

## Hero — centered

```tsx
<section className="relative flex min-h-[calc(100svh-4rem)] items-center justify-center overflow-hidden">
  <div className="mx-auto max-w-5xl px-4 py-20 text-center sm:px-6 lg:px-8">
    <span className="inline-flex items-center gap-2 rounded-full border border-neutral-700 bg-neutral-900/50 px-3 py-1 text-xs font-medium text-neutral-300">
      <span className="size-1.5 rounded-full bg-violet-400" />
      Free — no account required
    </span>

    <h1 className="mt-6 text-5xl font-bold tracking-tight sm:text-7xl lg:text-8xl">
      Headline, <span className="text-violet-400">accent.</span>
    </h1>

    <p className="mx-auto mt-6 max-w-2xl text-lg text-neutral-400">
      One or two sentences that say what this is and why someone should care.
    </p>

    <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
      <a href="/app" className="inline-flex items-center gap-2 rounded-full bg-violet-500 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-violet-600">
        Primary CTA
      </a>
      <a href="#features" className="inline-flex items-center gap-2 rounded-full border border-neutral-700 bg-neutral-900/50 px-5 py-2.5 text-sm font-medium text-neutral-200 transition hover:bg-neutral-800">
        Secondary CTA
      </a>
    </div>
  </div>
</section>
```

Hero height rule: `min-h-[calc(100svh-Xrem)]` where X equals header height (typically 4rem for a 64px header). Never bare `min-h-screen` when a fixed header exists. Use `svh` (small viewport height) or `dvh` (dynamic) — `vh` breaks on mobile Safari address-bar transitions.

## Hero — split (text left, visual right)

```tsx
<section className="overflow-hidden py-20 sm:py-28">
  <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
    <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-2 lg:gap-16">
      <div>
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
          Headline that wraps across two or three lines on desktop
        </h1>
        <p className="mt-6 max-w-xl text-lg text-neutral-400">
          Two-sentence subtitle. Constrained so it does not stretch to the full
          column width.
        </p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <a href="/app" className="inline-flex items-center justify-center gap-2 rounded-full bg-violet-500 px-5 py-2.5 text-sm font-medium text-white">
            Primary
          </a>
          <a href="#" className="inline-flex items-center justify-center gap-2 rounded-full border border-neutral-700 px-5 py-2.5 text-sm font-medium text-neutral-200">
            Secondary
          </a>
        </div>
      </div>

      <div className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-neutral-800 bg-neutral-900">
        {/* image, mockup, or illustration */}
      </div>
    </div>
  </div>
</section>
```

Notes:
- `items-center` aligns the text block and the visual on their vertical centers when the visual is taller.
- The visual uses `aspect-[4/3]` so it scales responsively without layout shift.
- Stack vertically on mobile, side-by-side from `lg` up.

## App shell — sidebar + main

The most common dashboard layout.

```tsx
// app/(app)/layout.tsx
import Sidebar from "@/components/sidebar";
import TopBar from "@/components/topbar";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-svh bg-neutral-950">
      <Sidebar /> {/* fixed lg:w-64 */}
      <div className="lg:pl-64">
        <TopBar /> {/* sticky top-0 z-30 h-14 */}
        <main className="px-4 py-6 sm:px-6 lg:px-8">{children}</main>
      </div>
    </div>
  );
}
```

```tsx
// components/sidebar.tsx — desktop pattern (mobile drawer in patterns/navigation.md)
export default function Sidebar() {
  return (
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 border-r border-neutral-800 bg-neutral-950 lg:block">
      <div className="flex h-14 items-center px-4 font-semibold">Brand</div>
      <nav className="px-2 py-2">
        {/* nav links */}
      </nav>
    </aside>
  );
}
```

Sidebar/main mismatch is the #1 dashboard bug. Three things must line up:

1. Sidebar is `fixed inset-y-0 left-0 w-64` (or `w-72`) on desktop.
2. Main wrapper is `lg:pl-64` (matching the sidebar width).
3. On mobile, sidebar is `hidden lg:block` and a drawer takes over (see `patterns/navigation.md`).

If the sidebar is in normal flow (not fixed), use flex instead:

```tsx
<div className="flex min-h-svh">
  <aside className="hidden w-64 shrink-0 border-r lg:block">...</aside>
  <main className="flex-1 min-w-0">...</main>
</div>
```

`min-w-0` on the flex main is critical (R6). Without it, any wide content (a table, a long URL) pushes the main wider than its flex track and breaks the layout.

## Dashboard page (inside the app shell)

```tsx
export default function DashboardPage() {
  return (
    <div className="mx-auto max-w-7xl space-y-8">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Dashboard</h1>
          <p className="text-sm text-neutral-400">
            Overview for the last 30 days
          </p>
        </div>
        <div className="flex gap-2">
          <button className="rounded-md border border-neutral-800 bg-neutral-900 px-3 py-1.5 text-sm hover:bg-neutral-800">
            Export
          </button>
          <button className="rounded-md bg-violet-500 px-3 py-1.5 text-sm font-medium text-white hover:bg-violet-600">
            New
          </button>
        </div>
      </div>

      {/* stats grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* stat cards from patterns/data-display.md */}
      </div>

      {/* main content row */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">{/* chart or table */}</div>
        <div>{/* sidebar widget */}</div>
      </div>
    </div>
  );
}
```

## Settings layout (sidebar nav + form sections)

```tsx
export default function SettingsLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold tracking-tight">Settings</h1>
        <p className="text-sm text-neutral-400">Manage your account and preferences</p>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-[200px_1fr]">
        <nav className="space-y-1">
          {settingsTabs.map((t) => (
            <a
              key={t.href}
              href={t.href}
              className="block rounded-md px-3 py-2 text-sm text-neutral-300 hover:bg-neutral-900 aria-[current=page]:bg-neutral-900 aria-[current=page]:text-white"
            >
              {t.label}
            </a>
          ))}
        </nav>
        <div className="space-y-8">{children}</div>
      </div>
    </div>
  );
}
```

The `grid-cols-[200px_1fr]` syntax pins the nav at exactly 200px and gives main the rest. Stacks vertically below `lg`.

## Auth pages (centered card)

```tsx
export default function LoginPage() {
  return (
    <div className="flex min-h-svh items-center justify-center px-4 py-12">
      <div className="w-full max-w-sm">
        <div className="text-center">
          <h1 className="text-2xl font-semibold tracking-tight">Sign in</h1>
          <p className="mt-2 text-sm text-neutral-400">
            Enter your details to continue
          </p>
        </div>

        <form className="mt-8 space-y-4">
          {/* form fields from patterns/forms.md */}
        </form>

        <p className="mt-6 text-center text-sm text-neutral-400">
          Don&apos;t have an account?{" "}
          <a href="/signup" className="text-violet-400 hover:underline">
            Sign up
          </a>
        </p>
      </div>
    </div>
  );
}
```

The auth shell: `min-h-svh` + flex centering + a fixed-width card. Works for login, signup, password reset, magic-link confirmation, 2FA prompts.

## Error pages — 404 and error.tsx

```tsx
// app/not-found.tsx
export default function NotFound() {
  return (
    <div className="flex min-h-svh flex-col items-center justify-center px-4 text-center">
      <p className="text-sm font-medium text-violet-400">404</p>
      <h1 className="mt-3 text-3xl font-bold tracking-tight sm:text-4xl">
        Page not found
      </h1>
      <p className="mt-3 max-w-md text-neutral-400">
        The page you&apos;re looking for doesn&apos;t exist or has moved.
      </p>
      <a
        href="/"
        className="mt-6 inline-flex items-center gap-2 rounded-full bg-violet-500 px-4 py-2 text-sm font-medium text-white"
      >
        Go home
      </a>
    </div>
  );
}
```

```tsx
// app/error.tsx — MUST be a client component
"use client";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="flex min-h-svh flex-col items-center justify-center px-4 text-center">
      <h1 className="text-3xl font-bold tracking-tight">Something went wrong</h1>
      <p className="mt-3 max-w-md text-sm text-neutral-400">
        An unexpected error occurred. You can try again, and we&apos;ve been
        notified.
      </p>
      <button
        onClick={() => reset()}
        className="mt-6 rounded-full bg-violet-500 px-4 py-2 text-sm font-medium text-white"
      >
        Try again
      </button>
    </div>
  );
}
```

## Two-column reading layout (docs, blog)

```tsx
<div className="mx-auto grid max-w-7xl grid-cols-1 gap-12 px-4 py-12 lg:grid-cols-[240px_minmax(0,1fr)] lg:gap-16 lg:px-8">
  <aside className="hidden lg:block">
    <div className="sticky top-20">
      {/* table of contents or doc nav */}
    </div>
  </aside>
  <article className="prose prose-invert min-w-0 max-w-none">
    {children}
  </article>
</div>
```

`minmax(0,1fr)` on the content column is what allows the article to shrink below its content size and respect the grid track. Without it, wide content (code blocks, images) blows the column out.

`min-w-0` on the article does the same thing; both belt-and-braces for code blocks that don't wrap.

`sticky top-20` works here because no ancestor has `overflow-*`. If the sticky nav fails to stick, audit ancestors (R4).

## Background decoration

For a subtle gradient glow at the top of the page:

```tsx
// app/layout.tsx, inside <body>
<div className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(ellipse_at_top,rgba(139,92,246,0.15),transparent_50%)]" />
{children}
```

`pointer-events-none` is non-negotiable — without it, the decoration intercepts every click. `-z-10` puts it behind everything. `fixed` keeps it in place during scroll.
